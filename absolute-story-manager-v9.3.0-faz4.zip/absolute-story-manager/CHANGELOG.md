# Absolute Story Manager — Changelog

> Tüm sürüm geçmişi: eklenen özellikler, düzeltmeler ve iyileştirmeler.

---

## v9.3.0 — Faz 4: Backlog Turu (2026-09-25)

🏗️ **"Temeli betona dök" sürümü** — Planın F-04..F-12 backlog kartları (sıralı adaylık) tam tur uygulandı: şema kısıtları, dayanıklı görev kuyruğu, gerçek-zaman kanalı, yedek 2.0, eklenti yüzeyi, erişilebilirlik, undo/redo, tip denetimi ve tarayıcı E2E. 2077 → **2129** birim/entegrasyon testi (+52; E2E 2 testi ayrı koşulur) ve **asm0003/asm0004/asm0005** migrations.

### 🗄️ F-06 — Veri Modeli Sağlamlaştırma
- **Yapısal FK kapsaması**: 20 → 58 yabancı anahtar; `ondelete=CASCADE` (bölüm silinince sürümleri, proje silinince kitaba ait her şey otomatik gider) ve `SET NULL` (bölüm silinince gönderimin/sohbetin bölüm bağlantısı boşa çekilir, kayıt yaşamaya devam eder). Önceden FK bildirilen kolonlar da `ondelete` kazandı
- **Doğal anahtar UNIQUE'ları**: sözlük terimi, özel sözlük kelimesi, snippet adı (proje bazında), günlük tarihi (proje+ tarih — eskiden GLOBAL tek-tarih kısıtı çoklu-kitap kullanımını sessizce kırıyordu), kilometre taşı/başarım anahtarları, beta okuma ilerlemesi
- **CHECK kısıtları x27**: boolean kolonlar `IN (0,1)`, sayaçlar negatif-olamaz, günlük enerjisi 1–5, sohbet `role`/`mode` enum'ları, sürüm numarası ≥ 1
- **BOOLEAN tip geçişi**: pinned/done/used/is_checked/case_sensitive/is_pinned kolonları INTEGER → BOOLEAN (CHECK ile birlikte gerçek anlamda zorlanır)
- **Migration asm0003** (metadata-güdümlü tam yeniden inşa): SQLite ADD CONSTRAINT yapamadığından tablolar DDL'den yeniden kurulur; yükseltme sırasında **yetim satırlar ondelete kuralına göre temizlenir** (kendine-referanslı zincirler döngülü), NULL project_id'ler 'default'a geri dolgular, unique çiftleri deterministik tekilleştirilir, boolean/enum dışı değerler normalize edilir ve sonunda `PRAGMA foreign_key_check` boş olmak zorundadır. FTS5 trigger'ları yeniden kurulur. `downgrade` gevşek şemaya döner
- **Servis uyumu**: glossary/snippet çift kayıtları temiz ValidationError ile reddedilir (500 değil); `import` "duplicate" stratejisi sözlükte "skip + not" olarak belgelenir; hayalet bölümde checklist otomatik tohumlaması boş döner; `run_db_migrations` boş `alembic_version` tablosunu da legacy benimsemesine yönlendirir
- Polimorfik tablolar (activity_log, ai_history, undo) bilinçli olarak FK'sız — varlık türü çalışma zamanında belirleniyor

### ⚙️ F-05 — Dayanıklı Görev Kuyruğu
- **Yeni `background_tasks` tablosu (asm0004)**: export işleri artık bellek-içi cache'te değil SQLite'ta — **uygulama kapansa da görev durumu kaybolmaz**; açılışta `recover_stale_running` yarım kalan işleri tekrar kuyruğa alır
- **Tek daemon worker**: atomik claim (pending→running), ilerleme/aşama güncellemesi, sonuç/hata kaydı; TEST modunda başlamaz, testler `execute_one` ile senkron sürer
- **Büyüme denetimi**: `purge_finished` — 7 günden eski VEYA son 200'ü aşan bitmiş satırları siler (arşiv dosyalarına dokunmaz)
- Export arayüzü değişmedi: `async_export` kuyruğa ekler, `get_export_status` DB'den okur; eski UI kelime dağarı (processing/done/error) korunur. **Yeni rotalar**: `GET /tasks`, `GET /tasks/<id>`

### 📡 F-04 — Merkezi Gerçek-Zaman Kanalı
- **`core/events.py` EventBus**: tek pub/sub veri yolu; abone başına 200 olaylık backlog — dolu abone üreticiyi ASLA bloklamaz, yayın asla istisna fırlatmaz
- **`GET /events` SSE akışı**: `retry: 3000` (kopunca tarayıcı 3 sn'de döner), adlandırılmış olay çerçeveleri, 15 sn `: ping` keepalive, bağlantı kopunca abonelik temizlenir
- Görev kuyruğu olayları (task.enqueued/progress/done/failed/recovered) ve yedek olayları (backup.created) aynı kanaldan akar; **`window.asmEvents`** (core.js) JS tüketicisi — export sayfası poll'un yanında SSE ile anında tamamlanır

### 💾 F-09 — Yedek 2.0
- **Opsiyonel AES-256 şifreleme** (`backup_password` ayarı; WinZip-AES via pyzipper): stdlib parolasız OKUYAMAZ — yedek dosyaları harici diskte/bulutta gerçekten korumalı. Parola ayarı `********` maskesiyle saklanır (yanlışlıkla silinmez); restore parola parametresi destekler
- **Harici hedef kopyası** (`backup_target_dir`): yedek otomatik USB/SMB klasörüne kopyalanır; hedef erişilemezse yedek yine de oluşur (uyarı log'u)
- **Artımlı yedek modu** (`backup_incremental`): DB + raw her zaman; medya yalnızca (boyut, mtime) manifest'ten değişenler — `_incr` sonekli arşivler zincirlenir, `data/backup_manifest.json` durumu izler
- Ayarlar sayfası: parola/hedef/mod alanları; `backup.created` olayı veri yoluna düşer

### 🔌 F-12 — Eklenti Yüzeyi (v10 tohumu)
- **`core/hooks.py`**: `after_export` / `after_chapter_save` / `after_backup` olaylarında kullanıcı betikleri koşar — stdin'de JSON olay, 30 sn zaman aşımı, stdout/stderr log'da; **betik hatası ana akışı ASLA bozmaz**
- **Varsayılan KAPALI** (`hooks_enabled`); betik listesi `hooks_scripts` ayarında JSON (bilinçli tasarım: yerel tek-kullanıcı uygulaması — ayara yazabilmek zaten tam kontrole eş)
- Tetik noktaları: export tamamlandı, bölüm kaydedildi, yedek oluşturuldu

### ♿ F-07 — Erişilebilirlik Paketi
- **Label/ID eşleşmesi**: 46 şablonda kodmod — 142 id eklendi, 275 etiket `for` ile bağlandı; kopuk `for` referansları temizlendi (id kapsamı %33 → %63+). Jinja döngülerindeki alanlar bilinçli atlandı (id çoğaltmak HTML'i bozardı)
- **Modal odak tuzağı** (core.js `asmA11y`): görünür modal açıkken Tab/Shift+Tab modal içinde döngüler, odak kaçarsa içeri çekilir, ESC görünür modalı kapatır (statik gizlenir, dinamik kaldırılır) — eski global ESC'in gizli statik modalları DOM'dan silebilme hatası da böyle kapandı
- **Modal ARIA'sı**: `role="dialog"`, `aria-modal`, `aria-labelledby`, kapatma düğmesinde `aria-label`

### ↩️ F-10 — Undo/Redo Genelleştirmesi
- **İki yığın semantiği** (`undo_operations.stack`, asm0005 — ADD COLUMN + geri dolgu): delete → undo → **redo** → undo... sınırsız; yeni yıkıcı eylem redo geçmişini temizler. **Yeni rota**: `POST /redo`; `/undo/list` stack + can_redo bildirir
- **Tüm varlık türlerinde undo**: not, sözlük terimi, günlük girişi, kaynak, gönderim silmeleri artık generik `snapshot_row` ile yakalanır (kayıt: tam kolon kümesi + tarih ayrıştırma); bölüm/karakter/plan/dünya zengin snapshot'ları kaldı yerinde
- **Çatışma zarfı**: geri yükleme unique kısıtı ihlal ederse (ör. aynı tarihe yeni günlük) temiz `ok:False, action:conflict` döner — 500 yok
- **Büyüme denetimi + depolama**: snapshot'lar zlib ile sıkıştırılır ("z1:" önekli; eski düz JSON geriye uyumlu okunur) VE tablo 100 satır / 16 MB bayt bütçesiyle budanır
- Delta tabanlı bölüm sürüm depolama bilinçli ertelendi (sürüm okuma yolları kritik; sıkıştırma + bütçe depolama amacını risksiz karşılar)

### 🔎 F-11 — mypy Kademeli Sıkılaştırma
- pyproject'ta strict set: `core/events`, `core/hooks`, `core/version`, `models/background_task`, `services/task_queue_service` (SQLAlchemy 2.0 Mapped tipleriyle) — **yeni kod zorunlu kuralı**; `follow_imports=silent` ile eski kod kademeli katılım için hazır. CI'da mypy adımı + test kapısı

### 🌐 F-08 — Playwright E2E (ana yazma akışı)
- **`tests/e2e/`**: gerçek sunucu süreci (scripts/e2e_server.py — izole DB, gerçek worker) + gerçek Chromium; akış: kurulum → bölüm oluştur (EasyMDE) → editörde yaz + **autosave yanıtı** → senkron TXT indirmesi **yazılan metni içerir** (kalıcılığın uçtan uca kanıtı) → asenkron DOCX (kuyruk + SSE gerçek indirme). **Sıfır konsol hatası sözleşmesi**
- Ana süitten ayrı koşulur (`pytest tests/e2e/`; CI'da ayrı iş) — motor çakışması yok; playwright yoksa net skip

### 🔧 Altyapı & Düzeltmeler (tur boyunca)
- **asm0003 kompozisyon güvenliği**: rebuild yalnız mevcut tabloları/DEĞİŞKEN kolonları taşır — sonraki migration'ların kolonları (asm0005 stack) eski DB'lerde yükseltmeyi kırmaz; asm0004/asm0005 idempotent
- `requirements.txt`/`lock`: pyzipper 0.4.0; `requirements-dev.txt`: mypy 2.3.1; CI: mypy + ayrı e2e işi
- Yol boyunca yakalanan gerçek hatalar: checklist'in hayalet bölüm tohumlaması, `[-2000]` indeks/dilim yazım hatası (hook çıktısı), kodmodun çapraz-eşleşen etiket regex'i (dashboard.html restore edildi + regex daraltıldı), `import` "duplicate"+glossary çakışması

---

## v9.2.0 — Faz 3: Özellik Derinleştirme (2026-09-25)

🚀 **"Değer görünür olsun" sürümü** — Geliştirme planının Faz 3 derin kartları (F-01..F-03) uygulandı: dört AI sağlayıcısı, gerçek i18n, modern editör. 2077 test (1997 → 2077, +80 yeni).

### 🤖 F-01 — AI Sağlayıcı Adaptör Katmanı
- **Dört sağlayıcı tek arayüzde**: `services/ai_providers.py` — Ollama (yerel), OpenAI-uyumlu (Groq/OpenRouter/LM Studio/Z.ai…), **Anthropic native** (`/v1/messages`) ve **Google Gemini** (`:generateContent`) adaptörleri. `generate()`/`generate_streaming()`/`list_models()` tek dispatch noktasından; bilinmeyen sağlayıcı adı eskisi gibi OpenAI-uyumluya düşer (uyarı log'lu)
- **Çağrı güvenilirliği**: TÜM sağlayıcı çağrıları paylaşılan `requests.Session` üzerinden; üstel backoff'lu retry (3 deneme — yalnız bağlantı hatası/zaman aşımı/5xx'te, 4xx'te asla); `(connect, read)` zaman aşımı ikilisi (connect 10 sn ile sınırlı — ölü host saniyeler içinde anlaşılır hata verir). 2 başarısız denemeden sonra kullanıcı net bir mesaj alır: hangi işlem, kaç deneme, hangi URL
- **Thinking filtresi tek yerde**: `_ThinkingStreamFilter` artık dört sağlayıcının akışına da merkezî uygulanıyor; Anthropic thinking blokları ve Gemini thought parçaları adaptör düzeyinde atlanıyor
- **Ayarlar**: sağlayıcı seçicide Anthropic + Gemini; preset'leriyle (base URL + öneri modeli) birlikte. `/ai/models` dört sağlayıcıda da çalışıyor (rota artık `ai_service.list_models()`'ı çağırıyor — retry/timeout bundan da faydalanıyor)
- **mock_ai_server.py çok-diyalekt**: tek sahte sunucu dört sağlayıcı telaffuzunu konuşuyor (OpenAI-compat, Anthropic SSE, Gemini `?alt=sse`, Ollama NDJSON) — canlı thread'li testler gerçek HTTP üzerinden dört motoru da geziyor

### 🌍 F-02 — Gerçek i18n
- **Çeviriler JSON'a taşındı**: `services/i18n_service.py` içinden `translations/{en,tr,es,fr,de}.json`'a (düz anahtar → metin, dil başına dosya; diff dostu). `json.loads` çakışan anahtarları sessizce birleştirdiği için duplicate-taraması artık HAM METİN üzerinden yapıyor (S-05 mirası JSON dünyasına taşındı); beş dosyanın anahtar kümeleri birebir eşit olmalı (parite)
- **`get_translation_dict` önbelleklendi**: her şablon render'ında ~90 anahtarlı düz dict'i baştan kuruyordu; artık dil başına önbellek + `set_language` invalidasyonu
- **FOUC bitti**: sidebar'ın 84 etiketi artık sunucu tarafında `{{ t('nav.x') }}` ile basılıyor — `base.html`'deki 90 satırlık navMap DOM-çevirme hack'i (sayfa İngilizce boyanıp sonra JS ile Türkçeleşiyordu) tamamen kaldırıldı. Topbar arama kutusu placeholder'ı da dahil
- **CI kilidi**: şablonlarda kullanılan her `t('...')` anahtarı çeviri dosyalarında olmalı — yeni nav linki artık anahtar eklemeyi zorunlu kılıyor (kabul kriteri testi)
- **latin-ext fontlar**: Inter 400/600, Noto Serif, JetBrains Mono latin-ext alt kümeleri vendor'a eklendi; `@font-face` blokları `unicode-range` ile ayrıldı — Türkçe ş/ğ/İ/ı artık sistem fontuna düşmüyor, aynı ailede kalıyor
- **Komut paleti çevrildi**: sabit İngilizce "New Chapter" vb. etiketler `window.ASM_T` (sunucu-render düz dict) üzerinden çözülüyor; arama ÇEVİRİLMİŞ etiketler üzerinde puanlanıyor

### ✍️ F-03 — Editör Modernizasyonu (EasyMDE → CodeMirror 6)
- **Arşivlenmiş → aktif bakım**: editör motoru CodeMirror 6'ya geçti. Bundle `scripts/cm6_build/entry.mjs`'ten esbuild ile YEREL olarak üretilip `static/vendor/codemirror/`'a işleniyor (çalışma anında npm gerekmez; `scripts/build_cm6.sh` yeniden üretir). MANIFEST'te `local:` kaynağı olarak beyanlı
- **Boyut raporu (kabul kriteri)**: EasyMDE 339.492 B (js 326.569 + css 12.923) → CodeMirror 6 360.094 B (gzip 117.000 B) — gömülü kod-bloğu ayrıştırıcıları (lezer js/css/html, ~120 KB) bilinçli olarak çıkarıldı; satır numaraları/geçmiş/arama/GFM dahil tek dosya. Test ±%15 pencereyle kilitli
- **Feature flag'li geçiş**: `editor.engine` ayarı — varsayılan `codemirror`, `easymde` geri dönüş yolu. Sayfa yalnız seçilen motorun vendor yükünü indiriyor. Ayarlar → Editor'de seçici
- **Tek entegrasyon noktası korunabildi**: `chapter_editor.js` motor-bağımsız — `AsmCM6Editor.create()` EasyMDE-uyumlu nesne döndürüyor (`value()`/`.codemirror.on("change")`/`execCommand`), autosave/sprint/AI akışları DOKUNULMADI; AI araç çubuğu tanımları iki motor arasında paylaşılan tek kaynak
- **28 maddelik fonksiyonel parite listesi** testle kilitli: biçimlendirme komutları (bold/italic/başlık/alıntı/listeler/bağlantı/görsel/kod/tablo), bul/değiştir, önizleme/yan yana/tam ekran, kısayol yardımı, kılavuz, AI eylemleri, durum çubuğu (satır/kelime/imleç), spellcheck, tab 4, minHeight 400px, autofocus
- **Önizleme sunucu-taraflı**: CM6'nın preview panesi `POST /chapters/preview-md`'den render alıyor — TEK markdown boru hattı (`md_to_html`, derleme/okuma moduyla aynı kaynak), çevrimdışı-güvenli, ayrı JS renderer vendor'u yok
- **Gerçek tarayıcı E2E'si**: headless Chromium'da doğrulandı — yazma + kelime sayacı, seçim + kalın, sunucu-render önizleme, yan yana, tam ekran, arama paneli, AI araç çubuğu (21 düğme) ve sıfır konsol hatası

---

## v9.1.0 — Faz 2: Mimari Sağlamlık (2026-09-19)

🏗️ **"Yapıyı sağlamlaştır" sürümü** — Geliştirme planının Faz 2'si (M-01..M-08) uygulandı: şema evrimi, izolasyon, performans, merkezileştirme ve kapsam. 1997 test (1810 → 1997, +187 yeni).

### 🧬 Veritabanı Şema Evrimi
- **M-01 — Alembic devrede, auto-migrate emekli**: Basit `create_all + ADD COLUMN` yürütme zamanı otomatik geçişi sona erdi; şema artık sürümlü geçişlerle (`alembic/versions/`: asm0001 baseline 40 tablo + 82 index, asm0002 composite versiyon indeksi) yönetiliyor. Boş DB'de `alembic upgrade head` tüm şemayı kuruyor; v9.0.x veritabanları ilk çalıştırmada otomatik benimseniyor (şema hizalama → DB yanına zaman damgalı yedek → baseline stamp → upgrade); `alembic downgrade -1` ile geri alma test ediliyor. CI'da boş DB üzerinde yükseltme/geri alma/yükseltme turu zorunlu. `scripts/init_db.py` yeni akışı raporluyor; `requirements.txt`'e aslında eksik olan `alembic` bağımlılığı eklendi (yorumu vardı, satırı unutulmuştu)
- **M-01 güvenlik ağı**: conftest artık test DB'lerini head'de damgalıyor — `init_db`'nin hızlı yolu istek başına ~1 ms

### 🏝️ Proje İzolasyonu
- **M-02 — "Kitaplar adadır" vaadi gerçek**: AI bağlam motoru (`build_context`/`build_prompt`) ve arama (`search_all/search_chapters/search_characters/search_world`) AKTİF kitaba kilitlendi — önceki tüm sorgular filtresizdi ve çoklu kitapta karakterler/dünya/sözlük/örgü belleği prompt'a sızıyordu. `bundle.stats()` artık hangi kitabın AI'ya anlatıldığını raporluyor (AI panelde görünür); çapalar: iki kitaplı seed'de yalnız aktif kitabın varlıkları

### ⚡ Performans
- **M-03 — N+1 paketi**: Her sayfa isteğinde kitap başına bir word_count sorgusu (10 kitap = 10 gereksiz sorgu) TEK `GROUP BY SUM`'a indi; iki ayrı read_session tek oturumda birleşti; globals 60 sn TTL cache (her `Setting.set` anında geçersizleştirir — kitap değiştirme/theme anında yansıyor)
- **M-03 — Ayar snapshot'ı**: `Setting.get` istek başına onlarca SELECT atıyordu; artık modül düzeyi snapshot (yazma/rollback/seed'de geçersizleşir). GET semantics birebir korundu
- **M-03 — reorder_chapters**: N adet `SELECT`'li get döngüsü TEK CASE tabanlı bulk UPDATE'e indi
- **M-03 — plot-memory**: `defer(Chapter.content)` ile yüzlerce KB'lık içerik kolonu artık sadece gerçekten gerektiğinde yükleniyor
- **M-03 — GERÇEK bug bulundu**: versiyon budama, `Setting.get`'in yanlışlıkla tetiklediği autoflush'a gizlice güveniyordu; snapshot bunu kaldırınca her kayıtta bir fazla versiyon hayatta kalıyordu — budama artık açık `s.flush()` ile doğru (ve bundan böyle yan etkiye bağımlı değil)

### 🏛️ Kod Sağlığı — Backend
- **M-04 — Merkezi hata zarfı**: 173 tekrarlı `try/except AsmError → jsonify` bloğunun 144'ü kaldırıldı (AST-güdümlü, yalnız birebir kanonik desen); endpoint'ler sadece `AsmError` fırlatıyor, app.py'deki TEK handler üretiyor: `{"ok": false, "error", "code"}` + doğru status. Handler artık istemci tipini anlıyor: fetch/XHR/JSON → zarf, tarayıcı sayfa gezintisi → arkadaşça hata sayfası (önceki davranış: sayfa rotalarında çiğ JSON!). 22 uçtanlı sözleşme testi kilitliyor; chat.py'nin iki katmanlı yakalayıcıları bilinçli şekilde korundu
- **M-05 — Helper dedup**: `_safe_filename` 3 kopya (bilinçli olarak BİRBİRİNDEN FARKLI davranışlar!) → `services/_common.safe_filename` + 3 preset (SLUG/SCRIV/EXPORT) — bayt-özdeş altın testlerle kilitli. `_md_to_html` 2 kopya (el yapımı vs markdown-lib — gerçekten farklı araçlar) tek yerde `md_to_html`/`md_to_html_minimal` olarak yaşıyor. `__import__('re')` vb. 32 nokta normal import'lara döndü
- **M-05 — 2 gizli import döngüsü kapatıldı**: `_common → models → checklist_service → _common` (yalnız import sırası tesadüfüyle çalışıyordu) tembel importlarla; `models/__init__ → service modelleri` döngüye toleranslı hale getirildi — artık HER import sırası güvenli

### 🎨 Kod Sağlığı — Frontend
- **M-06 — Editör göçü (878 satır)**: `chapters/edit.html`'deki dev inline script `static/js/chapter_editor.js`'e taşındı (reading_mode.js deseni); veri akışı `#editor-data` JSON bloğuyla (`chapterId/aiEnabled/autosaveInterval/targetWordCount`); şablon 1112 → 236 satır. "Şablonda çalıştırılabilir script yok" kuralı testle kilitlendi
- **M-05/M-07 — core.js**: `asmFetch` (farklı sözleşmelerle 2 kopya — son yüklenen kazanıyordu, okuma sayfalarında sessiz sözleşme çatışması!) ve `escapeHtml` (3 kopya) tek kanonik kaynağa indi; base.html ilk yüklenen dosya; reading_mode çağrıları modern sözleşmeye göçtürüldü
- **M-07 — Vendor lazy-load**: vis-network (689 KB) + Chart.js (206 KB) + EasyMDE (327 KB) + vendor CSS artık SADECE kullanan sayfada yükleniyor (graph/atlas-türleri, dashboard/analytics/pacing, editör, gruplar) — sade bir not/arama sayfası önce ~1,5 MB vendor indiriyordu, şimdi sıfır
- **M-07 — `?v=` cache-busting tek makro**: `asset()` her statik URL'i `?v=9.1.0` ile damgalıyor (el yazması ?v=2/?v=v83 etiketleri kaldırıldı); SW cache sürümü `core/version` ile senkron

### 🧪 Test Derinliği (M-08)
- Kapsam: checklist %34→**100**, travel %45→**100**, interactive_epub %22→**100**, quickswitch %27→**80**, ai_service %57→**72** (canlı mock sunucuyla streaming + durumlu thinking filtresi + JSON onarımı), chapters route %53→**69**
- +187 test: migrations (14), izolasyon (19), performans (12), hata zarfı (26), helper dedup (32), editör JS (9), asset pipeline (18), checklist (8), travel (8), quickswitch (8), epub (3), AI streaming (13), chapters ek (17)

### 🔄 Sürüm
- `core/version.py` → **9.1.0**; start.bat/start.sh banner'ları ve SW cache sürümü aynı kaynaktan

---

## v9.0.1 — Faz 1: Stabilite ve Güvenlik (2026-09-15)

🛡️ **"Temeli sağlamlaştır" sürümü** — Geliştirme planının Faz 1'i (S-01..S-10) uygulandı: yeni özellik yok, risk kapatıldı. 1810 test (1748 → 1810, +62 yeni).

### 🔒 Güvenlik
- **S-01 — Varsayılan bind host 127.0.0.1**: Uygulama artık ağa bilinçli tercih olmadan açılmıyor (`ASM_HOST`/`HOST` env ile açılabilir); start.bat'taki `HOST=0.0.0.0` kaldırıldı, README'ye güvenlik notu eklendi
- **S-02 — CSRF muafiyeti kodla zorlanıyor**: "Sadece localhost" tasarım varsayımı artık yorum değil kod — bind host loopback değilse hiçbir blueprint CSRF muafiyeti almıyor; ağ modunda tokensuz POST'lar 400 dönüyor, form/asmFetch token gönderdiği için UI çalışmaya devam ediyor
- **S-06 — .env koruması**: `.gitignore`'a `.env` eklendi (API anahtarı taşıyabilir); `!.env.example` istisnasıyla şablon korunuyor

### 💾 Veri Güvenliği
- **S-03 — Medya dosyaları artık yedekleniyor**: `data/media/` (haritalar, avatarlar, müzik) ZIP yedeklerine `media_manifest.txt` ile birlikte giriyor; restore path-traversal korumasıyla medyayı geri yazıyor. `backup_include_media` ayarı (varsayılan açık) ile kapatılabilir
- **S-03 — Medya transferi**: `/settings/export-media` + `/settings/import-media` uçlarıyla tam proje taşınması için medya paketi; JSON export'unda `media_files` manifest'i

### 🐛 Kritik Düzeltmeler
- **S-04 — `/ai/models` artık çalışıyor**: AI açıkken ayarlar sayfası 500 veriyordu (`_get_config(None)` → `None.query`); oturum artık serviste güvenli açılıyor, mock'lu entegrasyon testleri eklendi
- **S-09/ruff — Python 3.11 uyumluluğu**: `ai_service.py`'deki iç içe tırnaklı f-string 3.11'de SyntaxError'du (proje `>=3.11` iddia ediyor); düzeltildi
- **S-09/ruff — Not bağlantıları ilk kez çalışıyor**: `link_url` Jinja global'i `url_for`'u hiç import etmiyordu — tüm not çapraz referansları sessizce "#" dönüyordu; import eklendi
- **S-09/ruff — Ölü cache düzeltildi**: `stats_service.recent_activity` ve `upcoming_deadlines` içindeki `return`'ler `with` bloğunun içinde olduğundan cache SET satırları ölü koddu — iki fonksiyon da hiç cache'lenmiyordu; akış düzeltildi
- **S-05 — i18n**: 5 çakışan TRANSLATIONS anahtarı tekilleştirildi (sessizce eziliyorlardı); `get_current_language` artık process düzeyi cache'li (`set_language` invalidate ediyor) — her istekte gereksiz DB sorgusu kalktı

### 🧹 Geliştirici Deneyimi
- **S-06 — Sürüm tekil kaynağı**: `core/version.py` (`__version__ = "9.0.1"`); pyproject.toml dynamic-version ile okuyor, app.py banner'ı ve start.bat/start.sh aynı kaynaktan besleniyor (önce: 4.0.0/9.0/5.0 üçlüyü)
- **S-07 — ~495 KB ölü yük/istek kalktı**: "tailwind.min.css" aslında Tailwind Play CDN JavaScript'idir (451 KB, hiçbir kural uygulanamaz) — kaldırıldı; hiçbir template'te x-data olmayan Alpine.js (44 KB) kaldırıldı; template'lerde kullanılan 14 utility sınıfı (flex-1, ml-auto, grid-cols-2, btn-xs, cols-6, lg:grid-cols-2...) main.css utility katmanında resmileştirildi — bunlar Tailwind hiç çalışmadığı için zaten hiç stil almamıştı
- **S-08 — Linux/macOS başlatma**: `start.sh` (venv + bağımlılık + DB init + tarayıcı) start.bat ile eşdeğer; `integration_test.py`'deki yazar-makinesine özel mutlak yol `Path(__file__)` tabanlı hale geldi
- **S-09 — Bağımlılık hijyeni**: `requirements-dev.txt` (pytest/pytest-cov/ruff) ayrıldı; `requirements.lock` tam-pin kilit dosyası; ruff konfigürasyonu (E/F/W/I aktif, F821 gibi gerçek-bug kuralları dahil; F401/F841 bilinçli olarak M-05'e ertelendi ve belgelendi) — `ruff check .` temiz
- **S-10 — GitHub Actions CI**: Python 3.11+3.12 matrisi, ruff + pytest --cov (services/routes/core/models), push ve PR tetikleyicili, coverage artifact'lı — kalan 8 ayın tüm refactor'ları için güven ağı

---

## v9.0.0 — Series Bible / Seri Süreklilik Merkezi (2026-09-15)

📚 **"Kitaplarım artık birbirini tanıyor" sürümü** — v7.0'ın açtığı çoklu-kitap çalışma alanında her kitap katı bir adaydı: aynı karakteri ikinci kitapta elle yeniden yaratmak zorundaydınız, "bu aynı kişi" demenin yolu yoktu, kitaplar arası tutarlılık kontrolü hiç yoktu. v9.0 bu adaları köprüyle bağlıyor: **tek kadro listesi, tek dünya, tek süreklilik denetimi — tüm seri için**. 1748 test (1685 → 1748, +63 yeni).

### 🌉 Sütun 1 — Series Hub (`/series/`)
- **Kitap şeridi**: serideki tüm kitaplar renk kimlik şeritli kartlarda — tür, kelime sayısı, karakter/dünya sayıları, aktif kitap rozeti; karta tıkla → o kitaba geç
- **Seri istatistikleri**: kitap sayısı, seri toplam kelime, tüm kitaplardaki toplam karakter, paylaşılan kadro, paylaşılan dünya, süreklilik bulgusu sayısı — 6 istatistik kartı
- **👥 Series Cast sekmesi**: TÜM kitapların karakterleri tek listede, Türkçe-farkındalıklı (İ/i/I/ı) isim normalizasyonuyla gruplanmış — "Elara" ve "ELARA" aynı kişidir; her satır kitap bazlı çipler taşır (kitap rengi noktası + rol), 2+ kitaptaki isimler SHARED/LINKED rozetli
- **🌍 Shared World sekmesi**: dünya girdileri (tip + isim) bazında aynı gruplama — lokasyon, faction, species... hepsi serinin ortak hafızası olarak tek bakışta
- **Canlı filtre**: kadro ve dünya listelerinde anlık arama; sekme seçimi localStorage'da hatırlanır
- **Sidebar**: Workspace bölümünde "Series Hub" (5 dilde çevirisiyle); Ctrl+K komut paletine otomatik düşer (sidebar DOM senkronizasyonu)

### 🔗 Sütun 2 — Kitaplar Arası Bağlar (SeriesLink)
- **Yeni tablo `series_links`**: entity (karakter/dünya girdisi) → hedef kitap bildirimi; (entity, hedef kitap) tekil kısıtı çift bağlamayı engeller; create_all mevcut DB'lere zararsız eklenir
- **"＋ Series ▾" menüsü**: karakter ve dünya girdisi detay sayfalarında — hedef kitabı seç, bağlantı kurulur; per-kitap not alanı ("Üç yıl sonra, Kâhin olmuş")
- **Bağlantı anlamı**: varlık HER ZAMAN ana kitabında yaşar ve orada düzenlenir (tek doğruluk kaynağı); bağ, "bu kitapta da görünüyor" bildirimidir — hedef kitapta kopya olmadan da serinin kadrosunda sayılır
- **Detay sayfası Series kartı**: karakter/dünya sayfasında "appears in Kitap İki" çipleri + tek tıkla bağ koparma; Series Hub kısayolu
- **Links sekmesi**: tüm bağların yönetim tablosu (varlık → hangi kitap → not → ✕ kaldır)
- **İzolasyon sözleşmesi korunur**: bağ kurmak bir varlığı hedef kitabın normal listelerine SIZDIRMAZ (regresyon testiyle kanıtlı) — çapraz-kitap görünümler yalnızca Series Hub kapısından

### 🩺 Sütun 3 — Süreklilik Denetleyicisi (Series Doctor) + Seri Export
- **Rol kayması**: aynı isimli karakter farklı kitaplarda farklı rollerde (protagonist → antagonist) — kasıtlı gelişim mi, hata mı? warn seviyesi
- **Fiziksel çelişki**: göz/saç rengi ifadeleri fizik metinlerinden çıkarılır; kitaplar arası çelişki warn — "Elara's eye color differs: blue, green"
- **Dünya betimi kayması**: aynı isim+tip dünya girdisi kitaplarda çok farklı anlatılmışsa (%55 benzerlik altı) info — dünya gerçekleri kaymış olabilir
- **Bağlanmamış aynı-isim önerisi**: 2+ kitapta aynı isim ama seribağı yok → "link the versions" önerisi; açık bulgular Continuity sekmesinde önem rozetleriyle, her bulgu ilgili sayfaya atlar
- **✦ AI Seri Özeti**: tüm kitapların ad/tür/bölüm başlıklarından arka kapak tarzı seri Synopsis'i (AI kapalıysa 404 konvansiyonu, sağlayıcı hatası sayfayı çökertmez)
- **Seri Kutsal Kitabı export'u**: MD (kitap tablosu + kadro + dünya + bulgular) / JSON (yapılandırılmış, filtresiz tam veri) / PDF (Unicode-güvenli fontlar — Türkçe glifler v8.7 dersine uygun) / DOCX — tek tıkla tüm seri tek belgede

### 🧪 Kalite Güvencesi
- **63 yeni test** (`tests/test_v90_series.py`): model + tekil kısıt, overview sayımları, Türkçe İ/i gruplama, link CRUD (çift → 409, kendi kitabı → 400, bilinmeyen → 404), kopyasız bağ shared sayılır, süreklilik bulgu ailelerinin her biri + temiz seri sıfır bulgu, export 4 format şekli + Türkçe glif roundtrip, AI (kapalı → 404, mock → istemde kitap adları), rotalar + izolasyon sızma testi, UI kablolama (sidebar/i18n 5 dil/navMap/CSS/detay menüleri)
- Canlı doğrulama: agent-browser + mock AI ile Series Hub akışı, bağ kurma/koparma, süreklilik bulguları, export indirmeleri, VLM görsel onayı
- Tasarım hatası geliştirme sırasında yakalandı ve düzeltildi: bağın hedef kitapta kopyası yoksa grup rozeti görünmüyordu → bağlantılar books_count'a sayılır, hub ✦ çipleriyle gösterilir

---

## v8.9.0 — Review Loop / Beta Okuma Döngüsü (2026-09-09)

💬 **"Kitabımı yazdım, derledim — şimdi geri bildirim döngüsü" sürümü** — v8.5 Evrensel Export → v8.6 Evrensel Import → v8.7 Book Forge zincirinin doğal devamı: beta okuyucularını kitaba davet et, kim ne okuduğunu izle, gelen her yorumu tek bir aksiyon kutusundan yönet — çöz, Note'a çevir, Kanban görevine çevir veya **AI'dan somut bir düzeltme önerisi iste**. Beta okuma altyapısı ilk kez uçtan uca bir döngüye dönüştü. 1685 test (1635 → 1685, +50 yeni).

### 🧭 Sütun 1 — Beta Review Hub (`/beta/`)
- **Tek bakışta döngü durumu**: açık/çözülmüş yorum sayısı, çözüm oranı, toplam geri bildirim, aktif okuyucu sayısı, geri bildirim almış bölüm kapsamı, en az bir okuyucunun bitirdiği bölüm sayısı — 6 istatistik kartı
- **Okuyucu ilerleme kartları**: her beta okuyucusu için yorum sayısı + açık yorum + **okuduğu bölüm ilerleme çubuğu** ("Elif 12/30 bölüm okudu"); yalnızca ilerleme işaretleyen ama henüz yorum yazmamış okuyucular da görünür
- **Bölüm bazlı tablo**: her satırda okuyucu rozetleri, açık/çözülmüş/toplam sayaçları, kimler bitirdi, son etkinlik; "Yalnızca açık yorumu olan bölümler" anlık filtresi; Review ve Inbox kısayolları
- **Yazar yanıtları okuyucu sayılmaz**: yazarın kendi cevapları yorum sayısına girer ama okuyucu kartında ve okuyucu listesinde ayrı bir "okuyucu" olarak görünmez
- **Boş durumlar**: bölümü olmayan kitapta ve hiç etkinliği olmayan okuyucu listesinde yol gösteren CTA'lar

### 📖 Sütun 2 — Beta Reader 2.0 (sayfa sıfırdan)
- **Kitap boyunca okuma**: Önceki/Sonraki bölüm gezinme çubuğu + bölüm atlama menüsü + "Bölüm 3/30" konum rozeti — okuyucu artık tek bölümle hapsolmuyor; gezinme okuyucu kimliğini URL üzerinden taşır (`?reader=Elif`)
- **Okuyucu kimliği kalıcı**: URL parametresi → localStorage zinciri; ad bir kez girilir, sonraki bölümlerde ve oturumlarda hatırlanır
- **✓ Okundu işaretle**: okuyucu bölümü bitirdiğinde tek tıkla işaretler/kaldırır; Badge'de canlı ilerleme ("📖 5/30 bölüm okundu") — bu veri Hub'ın okuyucu kartlarını besler
- **İplikli yorumlar artık GERÇEKTEN görünür**: servis katmanında yıllardır duran cevap ipliği (thread) arayüzde hiç render edilmiyordu — artık yazar yanıtları "author" rozetiyle girintili gösterilir, cevap formu satır içinden açılır
- **Alıntı vurgulama**: yorumun alıntıladığı pasaj bölüm gövdesinde <mark> ile vurgulanır; hiçbir sayfa yenilemesi olmadan yorum ekle / çöz / yeniden aç / sil / cevapla — hepsi DOM içi güncelleme
- **Bölüm geri bildirimi dışa aktarımı**: MD / CSV / JSON — okuyucunun o bölümdeki tüm yorumları tek dosyada

### 📥 Sütun 3 — Feedback Inbox (`/beta/inbox`)
- **Kitap genelinden tek liste**: aktif kitabın TÜM yorumları bölüm sırasıyla tek sayfada; her kartta okuyucu, durum, bölüm bağlantısı, alıntı, cevap sayısı, göreli zaman
- **4 filtre ekseni**: durum (açık/çözülmüş), okuyucu, bölüm, serbest metin araması (yorum VE alıntı içinde) — filtreler dışa aktarımlara da uygulanır
- **Aksiyon kutusu**: ✓ Çöz / ↺ Yeniden Aç, → **Note** (todo kategorisinde, bölüme BAĞLI not — links alanı dolu gelir), → **Görev** (Kanban panosuna "planned" kolonunda, bölüme bağlı, alıntı + yorum açıklamalı), ✦ **AI fix**
- **✦ AI düzeltme önerisi**: tek tıkla o yorum için somut revizyon önerisi — istem Story Context Engine ile zenginleştirilir (karakterler, dünya, olay örgüsü hafızası + bölüm sonu kesiti), öneri kartta açılır panelden okunur/kopyalanır; AI kapalıysa anlaşılır hata, sağlayıcı hatasında sayfa çökmez
- **Dışa aktarım**: MD (bölüm başlıklarıyla gruplu, alıntı bloklu) / CSV (düz tablo) / JSON (yapılandırılmış, filtre kayıtlı) — kitap geneli veya tek bölüm kapsamı

### 🔗 Bağlamalar
- Sidebar: "Beta Review" (Export & Publish bölümünde, 5 dilde çevirisiyle); Ctrl+K komut paletinde Beta Review Hub + Feedback Inbox girişleri
- Bölüm detay sayfasındaki Beta Reader butonu artık **açık yorum sayısı rozeti** taşıyor (N open) — yazarın feedback'li bölümleri tek bakışta bulması için
- Yeni tablo `beta_read_progress` (chapter_id + reader_name tekil) — create_all ile mevcut DB'lere zarar vermeden otomatik eklenir
- Çoklu-kitap güvenliği: Hub, Inbox ve dışa aktarımlar yalnızca **aktif kitabın** bölümlerini okur (başka projeye sızma testi var)

## v8.8.0 — Performance Lab / Performans Laboratuvarı (2026-09-08)

⚡ **"Veritabanım büyüyor, performansım düşüyor mu?" sorusunun ölçülmüş cevabı** — Storage & Health sayfası artık iki sekmeli: mevcut **Depolama** sekmesinin yanına **Performance Lab** eklendi. Artık uygulamada gerçekten kullanılan sorgular canlı veriniz üzerinde **zamanlanıyor**, sorgu planları **EXPLAIN** ile denetleniyor, indeks kapsamı, FTS senkronu ve dosya parçalanması **tanılanıyor**; "eşik değeri nedir?" sorusu somut sayılarla ve sınıf-sınıf eşik tablosuyla yanıtlanıyor. 1635 test (1609 → 1635, +26 yeni).

### ⏱️ Sütun 1 — Sorgu Benchmark'ı (`services/perf_service.py`)
- **Gerçek uygulama sorguları ölçülür**: kontrol paneli bölüm listesi, editörün en büyük bölümü açması, her kayıtta çalışan son-versiyon araması, FTS5 arama, World Library tip filtresi, karakter listesi, aktivite akışı, toplam el yazması taraması, LIKE fallback araması ve **yazma gecikmesi** (WAL commit yolu — TEMP tablo probu; bağlantı havuzuna sıfır iz bırakır)
- **Sıcak-önbellek medyanı**: her sorgu 1 ısıtma + 5 ölçüm koşusu; soğuk disk I/O'nun yanıltmaması için ilk koşu sayılmaz; her ölçüm **sınıfına göre eşiklerle hüküm alır** (lookup: ≤5ms hızlı / ≤25ms ok / >150ms kritik; scan: ≤50/250ms; write: ≤5/20ms)
- **0-100 puan + harf notu** (A-F) + hüküm dağılımı; sonuç **ayarlar arasında saklanır** — sonraki koşuda **trend okları** (▼ daha hızlı / ▲ daha yavaş / — kararlı) önceki koşumla deltayı gösterir; bağlam çipleri (kaç bölüm, kaç versiyon, kaç MB) ölçümün hangi veri boyutunda yapıldığını belgeler
- **"Boyut performansı etkiler mi?" cevabı sınıf-sınıf**: indeksli aramalar boyuttan neredeyse etkilenmez (B-tree derinliği log(n) büyür — 500 MB dosyada bile mikrosaniyeler); asıl boyutla büyüyen **tam taramalar, FTS rebuild, VACUUM, yedekleme** — benchmark her iki sınıfı AYRI ölçer, tek dosya boyutu sayısından tahmin yürütmez

### 🩺 Sütun 2 — Sağlık Tanılama (`report()`)
- **Dosya parçalanması**: `page_count`/`freelist_count` sayfa matematiğiyle **gerçek VACUUM geri kazanım tahmini** ("~X MB boş sayfa") — %15+ veya >50MB boş sayfada uyarı, %5-15 bilgi, altı temiz
- **İndeks kapsamı kontrol listesi**: 7 sıcak sorgu indeksi denetlenir (composite versiyon indeksi, project_id'ler, tip filtresi, sahne-chapter, chat oturum+mesaj, aktivite zaman damgası); **eski DB'ler ALTER TABLE ile göçtüğünde create_all indeksleri geri doldurmaz** — eksik olanlar listelenir, tek tıkla **＋ Create missing** ile geri kurulur; farklı adlı ama aynı öncül-kolonlu indeksler de tanınır (yanlış alarm yok)
- **FTS5 parite tespiti**: external-content FTS'te tetikleyicileri atlayan yazmalar (toplu import, eski DB'ler, manuel SQL) **aramayı sessizce bozar**. `COUNT(*)`'ın FTS tablosunda her zaman CONTENT tablosunu okuduğu ve SQLite'ın kendi `integrity-check` komutunun bu drift'i external-content'te yakalamadığı **deneysel olarak kanıtlandı** — gerçek sinyal `%_docsize` gölge tablosudur (kaynak satır vs gerçekten indekslenmiş satır); drift varsa **⟳ Rebuild FTS** kaynak tablolardan geri kurar
- **Sorgu planları**: benchmark sorgularının EXPLAIN QUERY PLAN çıktıları — büyük tablolarda (>5.000 satır) SCAN kırmızı bayrak, küçüklerde bilgilendirme; "boyutun bekleme süresine döndüğü yer tam olarak burası"
- **Runtime yapılandırması**: journal_mode / synchronous / wal_autocheckpoint / cache_size / foreign_keys anlık görüntüsü + **🛡 Integrity check** (PRAGMA quick_check) butonu
- **İki gizli v8.4 hatası düzeltildi**: Storage raporunda yanlış tablo adları ("scenes", "glossary", "inspiration", "milestones", "voice_notes") — bu satırlar **hiç görünmüyordu**; artık gerçek tablolar raporlanıyor (scene_cards, glossary_entries, saved_inspirations, milestone_celebrations, character_voices) ve karakter metin kolonları doğrulandı (voice_notes → voice + notes)

### 🔧 Sütun 3 — Optimizasyon + Otomatik Bakım
- **Yeni aksiyonlar**: `rebuild_fts` (parite geri yükleme, önce/sonra sayılarla), `add_missing_indexes` (geri doldurma, ms cinsinden süre), `integrity_check`, `benchmark` — hepsi `/storage/action` kapısından, önce/sonra sayılarıyla döner
- **Otomatik bakım**: açılışta, en fazla N günde bir (varsayılan 7, ayarlardan 0-365, 0=kapalı) arka planda `PRAGMA optimize` + `wal_checkpoint(TRUNCATE)` — **asla açılışı bloklamaz** (daemon thread), VACUUM otomatik asla çalışmaz (dosyayı baştan yazmaktan manuel Depolama çağrısı olarak kalır); son çalışma zamanı sayfada görünür
- **Eşik referans tablosu**: "Boyut ne zaman gerçekten acıtır?" — 5 operasyon sınıfı için hızlı/kabul edilebilir/endişe bantları ve NEDEN'leri; UI'da "honest answer" kartı
- **UI**: sekmeli Storage & Health (📦 Depolama | ⚡ Performance Lab); benchmark tablosu ölçek çubukları + hüküm çipleri + trend sütunu; puan/harf rozeti; sağlık kartları ızgarası; mobil 375px'te tek kolon, taşma yok

## v8.7.0 — Book Forge / Kitap Üretim Hattı (2026-09-07)

📚 **"El yazmasından kitaba" sürümü** — Compile Wizard artık gerçek bir **baskıya hazır PDF kitap** ve **yayına hazır EPUB 3 e-kitap** üretiyor; indirmeden önce **Publishing Preflight** el yazmanızın kalite kapısından geçmesini sağlıyor. Bu sürümde ayrıca tüm uygulamadaki PDF'lerde sessizce var olan **Türkçe karakter bozulması** kökten düzeltildi. 1609 test (1550 → 1609, +59 yeni).

### 🖨️ Sütun 1 — Baskıya Hazır Kitap PDF'i (`compile_service._compiled_to_pdf`)
- **Gerçek kitap tipografisi**: 6×9 / 5.5×8.5 digest / A5 / A4 / Letter baskı boyutları; **ayna kenar boşlukları** (ciltleme tarafı recto/verso sayfalarda dönüşür — kapak sayfası tam-kenar full-bleed); **koşu başlıkları** (verso'da kitap adı, recto'da bölüm adı) + alt-orta sayfa numaraları; bölüm açılış sayfalarında başlık bastırılır (gerçek kitap geleneği)
- **İçindekiler gerçek sayfa numaralarıyla**: reportlab multiBuild — bölümler ilerledikçe sayfa numaraları iki geçişte yakınsar, nokta çizgileriyle (dot leaders) yazılır, **tıklanabilir** (TOC girdileri + PDF yer imi/outline ağacı)
- **Türkçe glif güvenliği**: yeni `services/pdf_fonts.py` — DejaVu/Liberation/Noto/Windows/macOS TTF'lerini bulur ve gömer (regular/bold/italic aileleri); hiç TTF yoksa yerleşik Type1'e düşer. Artık "Boğaz" PDF'te "Boğaz" olarak görünür — **eski tüm PDF export'larında "Boğaz"→"Bonaz" oluyordu** (Type1/WinAnsi glif eksikliği; bu sürümde 9 PDF üretici düzeltildi: bölüm, tam el yazması, karakter sayfası, dünya inceli, dünya koleksiyonu, dünya kitabı, tam proje, karşılaştırma, derleme)
- Kapak görseli varsa **tam sayfa full-bleed kapak**; yoksa tipografik başlık sayfası; telif/ithaf/epigraf/teşekküler sayfaları kitap düzeninde konumlanır

### 📖 Sütun 2 — Yayına Hazır EPUB 3 E-Kitabı (`compile_service._compiled_to_epub`)
- **Doğru e-kitap zarfı**: mimetype ilk kayıt + uncompressed (specs gereği), OPF içinde `dc:title / dc:creator / dc:language / dc:date / urn:uuid` tanımlayıcı; kitap dili arayüz dilinden ya da "Book Identity"den
- **Kapak**: yüklenen görsel gerçek EPUB kapak sayfası olur (cover + cover.xhtml); görsel yoksa tipografik kapak sayfası üretilir
- **nav.xhtml + ncx** içindekiler (okuyucu cihazın kendi menüsünde görünür) + ayrıca tıklanabilir contents.xhtml sayfası; bölümler ayrı XHTML dosyaları, sahne kesme işaretleri (`* * *`) ayrı stil sınıfıyla, ilk paragraf girintisiz — e-okuyucu tipografisi
- **Gömülü kitap CSS'i**: serif gövde, 1.55 satır aralığı, paragraf girintisi, hizalama — EPUB okuyucularda tutarlı görünüm

### ️ Sütun 3 — Publishing Preflight (`services/preflight_service.py`)
- **İndirmeden önce kalite kapısı**: tek tıkla (🛫 Preflight) aktif kitabın tam analizi — **0-100 puan + harf notu** + "READY TO PUBLISH" rozeti
- **Kontrol aileleri**: taslak/revised bölümler (warn), tamamen boş bölümler (error), çok kısa bölümler (<150 kelime), **editoryal kalıntı işaretleri** (TODO/FIXME/XXX/TK/[placeholder]/[note:]/???) (error), dengesiz çift tırnaklar (diyalog riski), tek yıldız sayısı (vurgu hatası), başlıksız bölümler, e-okuyucu için fazla uzun paragraflar (>600 kelime), hedef kelimeye ilerleme
- Her sorun **bölüm bağlantılı** — tıkla, bölümü düzeltmeye git; Türkçe `TK` deseninde yanlış pozitif yok (Türkçe kelimelerdeki "tk" tetiklemez: `(?![a-zçğıöşü])` negatif ileri bakış)
- Compile Wizard sayfasına entegre panel: puan, renk kodlu önem rozetleri (⛔/⚠️/ℹ️), sorun listesi

### 🪪 Book Identity + Kapak Yönetimi
- **Aktif kitap başlığı düzeltmesi**: derleme artık başlığı **aktif kitabın adından** alır (önce global `story_title` her kitapta gösteriliyordu — çoklu kitap hatası); yazar adı "Book Identity"den geçersiz kılınabilir
- **Dil farkındalıklı etiketler**: İçindekiler/Teşekkürler/Bölüm/Bölüm N — tr/en/es/fr/de; kitap dili EPUB metadata'sına da işler
- **Kapak yükleme API'si**: `/compile/api/cover` (PNG/JPG/WEBP ≤10MB, magic-byte doğrulaması, veri dizini dışına çıkış engelli — `/media/covers/` altına güvenli yazım) + kaldırma; yükleme anında PDF ve EPUB'da kullanılır

### 🧪 Kalite Güvencesi
- **59 yeni test** (`tests/test_v87_book_forge.py`): font çözümleyici (kayıt, eşleme, stil sayfası yeniden bağlama, TTF yoksa yerleşik yedek, idempotens), kitap PDF'i (magic, 3 baskı boyutu, metadata, TOC gerçek sayfa numarası yakınsaması — her bölümün GERÇEK sayfası TOC'da, Türkçe glif roundtrip + FontFile2 gömme kanıtı, boş sayfa yok, full-bleed kapak, sahne kesme, dil etiketleri, PDF outline), EPUB (mimetype ilk+stored, OPF dc alanları, spine sırası kapak→nav, bölüm dosyaları+contents.xhtml, Türkçe içerik+scene-break+first sınıfları, CSS, metin ve görsel kapak, ithaf sayfası), Preflight (temiz kitap 100/A/ready, her kontrol ailesi, TK yanlış pozitif yok, harf notu eşikleri, skor taban), kapak API'si (yükleme/kaldırma/400 yolları/magic uyumsuzluğu/yol güvenliği), rota + UI kablolaması, config doğrulama (boyut kilitleme, string-boolean), kimlik (yazar geçersiz kılma, aktif kitap başlığı, tr etiketleri, ui_language varsayılanı), Türkçe bozulma düzeltmesi regresyonu (karakter sayfası, bölüm PDF'i, karşılaştırma PDF'i)
- **Canlı doğrulama**: agent-browser ile tam akış — Compile Wizard sayfası, kapak yükleme, Preflight paneli, PDF/EPUB gerçek indirmeleri; üretilen PDF sayfaları VLM ile satır satır okunarak içindekiler, koşu başlıkları, Türkçe glifler ve full-bleed kapak doğrulandı
- Geliştirmede yakalananlar: (1) `_Cover` Flowable'ının modül seviyesinde tanımlanıp fonksiyon içi importla patlaması; (2) TOC'dan sonra çifte PageBreak → boş sayfa; (3) reportlab 5.0.1'de `TableOfContents`'in yeni import yolu; (4) `EpubHtml`'e `uid` geçirilmeyince ebooklib'in `chapter_N` otomatik id'leri ataması (spine idrefs yanlış isimleniyordu); (5) FK ekleme sırası (ORM ilişkisi tanımlı olmadığında unit-of-work tabloları alfabetik sıralıyor — proje+aynı-transaction bölüm ekleme patlıyordu)

---

## v8.6.0 — Evrensel Import (2026-08-29)
## v8.6.0 — Evrensel Import (2026-08-29)

📥 **"Her export'u geri oku" sürümü** — v8.5'in açtığı kapı kapatıldı: artık **v8.5+'ın yazabildiği her JSON'u v8.6 geri okuyabiliyor**. Karakter sayfası, tüm karakterler kitabı, tek bir lokasyon/species dosyası, tip-filtreli dünya koleksiyonu, sahne kartları, sözlük, referanslar — hepsi Import Center'ın yeni "ASM Export Bundle" kartına bırakılır; tür otomatik tanınır, çakışmalar önceden gösterilir, tek satır yazılmadan önce her şey gözden geçirilir. 1550 test (1508 → 1550, +42 yeni).

### 🧠 Sütun 1 — Akıllı Tanıma + Önizleme Motoru (`services/import_service.py`)
- **`detect_payload()`**: Dosyanın ne olduğunu kendisi anlar — koleksiyon zarfları (`{"collection": "characters"...}`, `{"collection": "species"...}`), tek varlık sayfaları (karakter dosyası, dünya girdisi), çıplak diziler, ve tam proje yedeği (asm-v4…v7.5) → 7 tür; tanınmayan dosya dostça hata verir
- **`preview_import()` (dry-run)**: Tek bir satır yazılmadan — kaç öğe yeni, kaçı zaten var (doğal anahtarlarla: karakter→ad, dünya→tip+ad, sahne→başlık+bölüm, sözlük→terim, referans→başlık+yazar); her satır için durum (yeni/var/kopya) + not ("parent: Boğaz Kıyısı" gibi)
- **`execute_import()` atomiktir**: Tüm payload TEK transaction'da — ortada hata olursa her şey geri alınır (yarıda kalmış import yok)
- **Çakışma stratejileri**: `skip` (varsayılan, güvenli — mevcutlar dokunulmaz) · `overwrite` (mevcutlar dosyadaki dolu alanlarla güncellenir; dünya girdilerinde **üzerine yazmadan ÖNCE versiyon anlık görüntüsü** alınır — manuel düzenlerle aynı güvenlik ağı) · `duplicate` (her zaman yeni kopya)
- **Varlık bazlı seçim**: Önizleme tablosundaki her satır tek tek işaretlenebilir (exclude) — "şu üç lokasyonu alma, gerisini al" mümkün

### 🌍 Sütun 2 — Kayıpsız Gidiş-Dönüş (round-trip sadakati)
- **Dünya girdileri**: Hiyerarşi (ebeveyn-çocuk zinciri **topolojik sırayla** kurulur), ilişkiler (giden/gelen — hedef isimden çözümlenir), metadata, harita iğnesi, kategori, içerik, notlar — hepsi geri gelir. **ID remap**: ithal kopyalar HER ZAMAN yeni id alır (PK çakışması imkânsız); kopya çocuk, kopya ebeveyne bağlanır; dosyada olmayan hedef isimle mevcut DB kaydına çözümlenir; ilişki çift yönlü dosyada hem out hem in olarak duruyorsa **tek kez** yazılır (dedupe)
- **Döngü güvenliği**: El yapımı bir dosyada ebeveyn döngüsü (A→B→A) import'u kilitlemez — döngü kökte kırılır, girdiler yine de iner
- **Karakterler**: Tüm dosya alanları (fizik, psikoloji, felsefe, ünlü alıntılar, takma adlar, ses...) + geçersiz rol "supporting"'e düşer
- **Sahne kartları**: Bölüm başlığa göre eşleşir (bulunamazsa bağımsız sahne + not), POV karakteri isimden çözümlenir, durum/mod/gün-zamanı/etiketler/kelime sayısı taşınır
- **Sözlük**: Kabul edilen + YASAK varyantlar, case_sensitive bayrağı dahil
- **Referanslar**: Alıntılar (sayfa no), etiketler, puan, okuma durumu — bibliyografya bilgisi tam
- **Tam proje JSON'u** aynı kapıdan girer → v7.5 transfer servisine devredilir (idempotent)

### 🖥️ Sütun 3 — Import Center 2.0
- **Yeni "ASM Export Bundle" kartı** (🧩 NEW rozetli): Import Center'a 4. kart olarak eklendi — "One JSON file · smart detect" akışı
- **Önizleme paneli**: Tür rozeti + özet çipleri (kaç yeni / kaç var) + strateji seçici (Skip/Update/Copy) + satır başına onay kutulu tablo; **strateji değişince durumlar canlı yenilenir** (sunucuya tekrar dry-run)
- **Sonuç paneli**: N ithal / N güncellendi / N atlandı + her satır için tıklanabilir "open →" bağlantısı (karakter/dünya sayfasına); çözülemeyen hedefler için notlar
- Import sonrası önizleme otomatik tazelenir — "şimdi hepsi var" durumunu anında görürsünüz

### 🧪 Kalite Güvencesi
- **42 yeni test** (`tests/test_v86_universal_import.py`): tanıma matrisi (10 şekil + çöp), önizleme (strateji-duyarlı durumlar), gidiş-dönüş sadakati (dünya/hiyerarşi/ilişki/metadata/map pin, karakter alıntıları, sahne POV+bölüm çözümleme, sözlük yasakları, referans alıntıları), strateji davranışları (overwrite anlık görüntü kanıtı dahil), ID remap kanıtı (kopya çocuk → kopya ebeveyn), ilişki dedupe, döngü güvenliği, exclude, 8 rota testi (400 yolları dahil), tam proje delegasyonu, BOM toleranslı JSON parsing, sayfa kablolaması
- **Canlı doğrulama**: temiz DB'de tarayıcı üzerinden tam akış — kart seçimi → dosya bırakma → önizleme tablosu → strateji değişimi → ithalat → sonuç bağlantıları; VLM görsel onayı
- Geliştirme sırasında yakalananlar: aynı adlı kayıtlarda `scalar_one_or_none` patlaması (tüm eşleştirme sorguları `limit(1)` desenine çevrildi — kopya stratejisiyle tekrar import artık güvenli), test temizliğinde FK silme sırası (versiyonlar girdilerden önce)

---

## v8.5.0 — Evrensel Export (2026-08-29)

📤 **"Her şeyi her formatta dışa aktar" sürümü** — Kullanıcının talebi ("karakterleri export edebiliyorum ama lokasyonları, speciesleri edemiyorum — onları da export edebilmek istiyorum") kökten çözüldü: artık **tek bir dünya girdisinden tüm koleksiyonlara kadar her şey** yazara uygun formatlarda dışa aktarılabilir. Karakter sayfasındaki "Export ▾" deseni tüm uygulamaya yayıldı. 1508 test (1461 → 1508, +47 yeni).

### 🌍 Sütun 1 — Dünya Girdisi Export (lokasyonlar, speciesler, fraksiyonlar...)
- **Tek girdi sayfası export'u** (`/world/<id>/export/<fmt>`): Her dünya girdisi (lokasyon, species, faction, lore, magic system, culture, technology + özel tipler) karakter sayfası gibi 5 formatta dışa aktarılabilir — **TXT / Markdown / PDF Sheet / DOCX / JSON**. World Library'deki her detay sayfasında artık "↧ Export ▾" menüsü var
- **İçerik sadakati**: Export dosyası sadece ad+açıklama değil; **metadata tablosu** (bölge, iklim, yaşam süresi...), **hiyerarşi** (üst konum zinciri + alt konumlar), **ilişkiler** (giden/gelen oklarla: "→ home_of → Suirler"), **harita iğnesi** koordinatları ve içerik+notlar tam olarak taşınır. JSON'da id/parent_id round-trip için dahil
- **Tip-bazlı toplu export** (`/export/collection/world/<fmt>?type=location`): "Tüm lokasyonları tek dosyada ver" — World Library sekmesindeki her tip (Locations, Species, Factions, Lore, Magic Systems, Cultures, Technologies + özel tipler) tek dosyaya derlenir. **Filtre sadakati**: World Library sayfasındaki "Export View" butonu mevcut tip sekmesi + arama + kategori filtresini export sorgusuna taşır — ne görüyorsan onu alırsın
- **Doğru çoğullaştırma**: location → "Locations", species → "Species" (çift-s yok!), magic_system → "Magic Systems", technology → "Technologies"
- **World Bible'e MD formatı eklendi**: type=all tüm dünya kitabını Markdown olarak da verir (önceden TXT/PDF/DOCX/JSON vardı)

### 👥 Sütun 2 — Karakterler Toplu + Araç Sayfaları Export
- **Karakterler toplu export** (`/export/collection/characters/<fmt>`): Tüm karakter dosyaları tek belgede — TXT/MD/**PDF (karakter başına sayfa)/DOCX/JSON**. Fizik, psikoloji, felsefe, ünlü alıntılar dahil tam kadro kitabı. Characters sayfasında "↧ Export All ▾" menüsü
- **Sahne Kartları** (`/export/collection/scenes/<fmt>`): Tüm sahneler bölüme göre gruplu, POV karakteri/lokasyon/gün-zaman/mod/durum/kelime sayısı metadata'sıyla — TXT/MD/**CSV (tablolar için)**/JSON. Scenes sayfasında menü eklendi
- **Sözlük & Stil Sayfası** (`/export/collection/glossary/<fmt>`): Kanonik terimler + tanımlar + kabul edilen varyantlar + **YASAK varyantlar** (CSV'de case_sensitive dahil) — TXT/MD/CSV/JSON. Glossary sayfasında menü
- **Araştırma & Referanslar** (`/export/collection/references/<fmt>`): **Bibliyografya formatında** (Yazar. (Yıl). Başlık [tip]) + alıntılar sayfa numarasıyla + puan yıldızları + okuma durumu — TXT/MD/CSV/JSON. References sayfasında menü

### 🗂 Sütun 3 — Export Center 2.0
- **Yeni "Collections" bölümü** (`/export/`): Tüm koleksiyonlar tek bakışta — Characters, World by Type, Scene Cards, Glossary, References kartları; her kart kendi format butonlarıyla
- **World by Type çip seçici**: Location/Lore/Faction/Glossary/Magic System/Species/Culture/Technology + özel tipler çipleri; çipe tıkla → 5 format butonu o tipe göre güncellenir (JS ile anında)
- **Keşfedilebilirlik API'si**: `GET /export/collections` — koleksiyonlar + formatları + mevcut dünya tipleri (JSON) — programatik erişim için

### 🧪 Kalite Güvencesi
- **47 yeni test** (`tests/test_v85_universal_export.py`): tek girdi 5 format sadakati (metadata/hiyerarşi/ilişki/harita iğnesi), toplu export çoğullaştırma regresyonları (Speciess yok!), arama/kategori filtre izolasyonu, tüm route'lar (24 URL), attachment header'ları, 404 yolları, 7 sayfada UI kablolaması, eski export'lar (karakter sayfası, world bible, manuscript) bozulmadı
- **Canlı doğrulama**: tarayıcıdan gerçek indirme (Suirler.pdf 2.4 KB geçerli PDF, doğru Content-Disposition); species sekmesi filtresinin export linkine taşınması; çip etkileşimi; mobil 375px taşma yok; VLM görsel onayı (4 ekran)
- Geliştirme sırasında yakalananlar: SceneCard sorgusunda parantez hatası (Select.all), f-string iç içe tırnak (Python 3.11 uyumsuzluğu — paket kullanıcısı 3.11+ olabileceği için düzeltildi), world entry JSON'unda id/parent_id eksikliği

---

## v8.4.0 — Performans & Depolama Sağlığı (Ölçülmüş) (2026-08-29)

⚡ **"Veriyle kanıtlanmış hız ve kontrol" sürümü** — Kullanıcının sorusu ("veritabanı dosya boyutu performansı etkiliyor mu?") ölçümlü cevaplandı: 3 ölçekte sentetik kütüphane (5 MB / 39 MB / 243 MB) benchmark'ı yazıldı (`scripts/bench_db.py`), darboğazlar sayısal olarak tespit edildi ve düzeltildi. En çarpıcı bulgu: **DB dosya boyutunun kendisi değil, sorguların tam metin yüklemesi + sınırsız versiyon birikimi + asla küçülmeyen WAL** yavaştı. 1460 test (1439 → 1460, +21 yeni).

### 📊 Ölçüm (kullanıcının sorusunun cevabı)
- **Benchmark harness** (`scripts/bench_db.py`): S1 tek kitap (40 bölüm/100k kelime) · S2 seri (120 bölüm/360k) · S3 ağır kasa (300 bölüm/900k + 40 versiyon/bölüm + sohbet/notlar) — 9 kritik işlem ölçülür: bölüm listesi, dashboard, 3 analytics taraması, FTS5 arama, kayıt+versiyon, versiyon listesi, yedekleme
- **Bulgu 1 — SQLite okumaları ölçekle Sorun DEĞİL**: FTS5 arama 243 MB'da bile 0.5 ms; bölüm listesi 7 ms. B-tree indeksli erişim dosya boyutundan etkilenmez. **Asıl darboğaz Python tarafında**: tüm el yazısını string'e yığan analytics (610 ms), liste sayfalarının tam bölüm metni yüklemesi, ve 2.5 saniyeye uzayan yedekleme
- **Bulgu 2 — versiyon tablosu = kasanın %87'si**: S3'te 900k kelimelik el yazması ~6 MB metin ama 12.000 versiyon satırı DB'yi 243 MB'a şişiriyor. Her kayıt bölümün TAM metnini anlık görüntü olarak biriktiriyordu, sonsuza dek
- **Bulgu 3 — WAL kâbusu**: -wal dosyası DB ile beraber büyüyüp 246 MB'a ulaşıyordu (asla küçülmüyor); açılışı ve yedekleri yavaşlatıyordu

### ⚡ Sütun 1 — Ertelenmiş İçerik Yükleme (deferred content)
- `list_chapters(with_content=False)` varsayılan: bölüm **metni artık SQLite'ta kalır** — liste sayfaları, seçiciler, istatistikler sadece başlık/durum/kelime sayısı/synopsis çeker (300 bölümlük kütüphanede liste %36 hızlandı: 7.4 → 4.7 ms). İçerik gerçekten gereken 3 çağıran (Okuma Modu API, EPUB oluşturma, tutarlılık kontrolü) `with_content=True` iletir
- Karakter-görünüm sorguları (heatmap + bölüm-başına-karakter) `load_only` ile sadece `character_ids` çeker — tüm el yazısını yükleyip sadece JSON listesini okuyan eski desen bitti
- Analytics tam-taramaları akışlı hale geldi: `manuscript_summary` ve `top_words` artık dev tek string biriktirmek yerine bölüm-bölüm akıtır (~%23 hızlanma + ~%50 bellek tasarrufu; token regex'i aynı → sonuçlar bit düzeyinde aynı, regresyon testiyle sabitlendi)

### 🧹 Sütun 2 — Versiyon Tutma Politikası (retention)
- **`version_history_limit`** ayarı (varsayılan 25, 0 = sınırsız/eski davranış): her kayıttan sonra otomatik budama — en yeni N versiyon + **her zaman v1 orijinal taslak** + **sabitlenen (pin) versiyonlar** korunur; güvenlik ağı bozulmaz
- Bölüm başına 40+ versiyon biriken ağır kasada: **4200 satır budandı, VACUUM ile 243.65 → 161.03 MB (-34%)** (`scripts/bench_maintenance_demo.py` ile kanıtlandı); canlı kayıtlarla hiçbir zaman oraya varılmaz — sınırbaşına bir COUNT maliyetiyle tablo sınırda tutulur
- İç-işlem güvenliği: buda, kaydın KENDİ transaction'ı içinde çalışır (iç içe write_transaction'ın dış oturumu uçurduğu v8.3 fixture hatasının üretim formu yapısal olarak engellendi)

### 📦 Sütun 3 — Depolama & Sağlık Panosu (yeni sayfa `/storage/`)
- **Ölçülen sayılar**: DB + WAL dosya boyutu, tablo-bazında satır + metin byte dökümü (pay çubuklu "baytlar nerede yaşıyor" tablosu), versiyon istatistikleri (toplam/ortalama/maks/budanabilir tahmin), yedek sayısı + toplam boyut + tutma sınırı
- **Sağlık ipuçları**: WAL > 32 MB uyarısı, budanabilir versiyon, retention aşımı, dev DB önerisi — hepsi tek bakışta
- **Bakım eylemleri** (tek tık, before/after geri bildirimli): 💾 Checkpoint WAL · 🧹 Versiyon Budama · 🔄 Yedek Budama · ⚡ Optimize (VACUUM + istatistik tazeleme + çift checkpoint); retention ayarları (versiyon limiti + yedek sayısı) sayfadan düzenlenir
- Sidebar System bölümünde "Storage & Health" + Ctrl+K palet girişi + yeni `database` ikonu

### 🔒 Sütun 4 — Yedekleme Doğruluğu (sessiz veri kaybı düzeltmesi)
- **KÖK HATA DÜZELTİLDİ**: WAL modunda son işlenen veriler -wal dosyasında olabilir; yedek zip'i SADECE ana DB dosyasını kopyalıyordu → **yedekler sessizce bayat/eksik olabiliyordu**. Artık zip'lemeden önce `wal_checkpoint(TRUNCATE)` çalışır — yedek her zaman tam (test: yedek zip'ten çıkarılan DB'de son yazılan bölüm satır satır doğrulanıyor)
- **Yedek tutma**: `backup_retention_count` (varsayılan 14, 0 = sınırsız) — her yedekten sonra en eskiler silinir; 6 saatlik otomatik yedek artık DB değişmediyse atlanır (200 MB'lık değişmemiş dosyayı tekrar tekrar ziplemek bitti)
- **WAL sınırı**: `PRAGMA journal_size_limit=64 MB` — WAL bir daha asla DB ile yarışacak kadar büyüyemez (ölçülen 246 MB → 0-64 MB bandında)

### 🗂 Diğer
- `chapter_versions(chapter_id, version_number DESC)` composite indeksi — her kaydın "son versiyonu bul" sorgusu artık sıralama yapmadan indeksten çözülür (eski DB'lerde otomatik oluşturulur; create_all mevcut tablolara indeks eklemediği için ayrı DDL)
- Benchmark + bakım demo scriptleri teslim edildi (`scripts/bench_db.py`, `scripts/bench_maintenance_demo.py`) — kullanıcı kendi kütüphanesinde kendi sayılarını ölçebilir
- SW VERSION v8.3.0 → v8.4.0; app banner + sidebar footer v8.4

### 🧪 Kalite
- 21 yeni test (`test_v84_perf.py`): defer kanıtı (DetachedInstanceError ile "metin hiç çıkmadı" isnatı), with_content yolu, liste meta-verisi bütünlüğü, okuma API'si içerik regresyonu, budama (limit+v1+pinned+limit=0), retention varsayılanları, storage sayfası/API/eylemler (vacuum/checkpoint/kayıt/400), yedek retention + **WAL içeriği yedekte kanıtı** + değişmediyse atlama, composite indeks + journal_size_limit pragmaları, analytics akış semantiği (ASCII regex dahil — eski davranışla bit düzeyinde aynı)
- Tam paket 1460/1460 (1439 → 1460) geliştirme ortamında; inline-JS korumasına /storage/ eklendi

---

## v8.3.0 — Prose Lab (Style Coach 2.0) + AI Rewrite Stüdyosu + Hikâye Kronolojisi (2026-08-29)

🎭 **"Kelimeden hikâyeye derinlik" sürümü** — Üç sütun: Türkçe-farkındalıklı derin üslup analizi (v8.2'ye kadar show-don't-tell kontrolü SADECE İngilizce kelimeleri sayıyordu — Türkçe metinde sıfır bulgu), tespit edilen sorun cümleleri AI ile yeniden yazma stüdyosu, ve yazılmış el yazmasını hikâye zamanına oturtan görsel kronoloji. 1439 test (1390 → 1439, +49 yeni).

### 🎭 Sütun 1 — Style Coach 2.0 (Türkçe-farkındalıklı üslup laboratuvarı)
- **KÖK HATA DÜZELTİLDİ**: eski analiz "felt"/"was angry"/"saw" gibi İngilizce kelimeler arıyordu → Türkçe roman **0 telling, 0 sensory** skoru alıyordu, oran anlamsızdı (v7.7'de lint/pacing/spellcheck'te düzeltilen İngilizce-merkezlilik sınıfının üslup analizindeki son temsilcisi). Artık `lang_service`'te TR/EN üslup sözlükleri var: telling gövdeleri (korktu, hisset, üzgün, öfkelendi…), duyusal kökler (kalb, nefes, hışırtı, koku, ışık…) + deyim kalıpları (kalbi hızlandı, eli titredi…), filtre kelimeleri (gördü, duydu, fark et, baktı…), klişe radarı (derin bir nefes aldı, zaman durmuş gibi…)
- **Yeni ölçümler**: cümle ritmi (uzunluk profili + varyasyon katsayısı + SVG sparkline — tekdüzelik tespiti), kelime çeşitliliği (stopword'süz benzersiz oran), okunabilirlik (Flesch İngilizce için; Türkçe için KALİBRE EDİLMİŞ model — ham Flesch, yapıştır eklerle 2.7 hece/kelime tutan Türkçeyi hep 0'a sıkıştırıyordu), en uzun cümle, paragraf sayısı, diyalog oranı (tipografik tırnaklar dahil)
- **Örnek cümle çıkarımı**: her kategori (telling/filter/sensory/cliché) SAYI + en sık geçen girdiler + örnek cümleler + hangi kelimelerin tetiklediği listeler
- **Style Coach sayfası 2.0**: dil rozeti (🇹🇷/🇬🇧), 6 metrik kartı, ritim sparkline'ı, kategorize kartlar (telling kırmızı / filter turuncu / sensory yeşil / klişe kırmızı üst şeritli) — hepsi örnek cümleli
- **Keşfedilebilirlik düzeltildi**: Style Coach sayfası v8.2'ye kadar UI'da HİÇBİR yerden bağlanmıyordu (URL elle yazmak gerekiyordu!) — Story Lint sayfasına bölüm çipli başlatıcı kartı eklendi

### ✦ Sütun 2 — AI Rewrite Stüdyosu (sorunu bul → AI ile yaz)
- Style Coach raporundaki en kötü cümleler (telling/filter/klişe) **rewrite hedefi** olur (8'e kadar); her hedef için ✦ Rewrite butonu
- **`/lint/style-rewrite-stream` (SSE)**: cümle + sorun kategorisi + bölüm bağlamı (RAG Context Engine) → akıcı yeniden yazım; prompt talimatı DİLE göre (Türkçe bölüm → Türkçe "göster, anlatma" talimatı); ai_service düşünme-blok filtresi devralınır
- **`/lint/style-rewrite-apply`**: sunucu tarafında GÜVENLİ değiştirme — birebir eşleşme zorunlu (eski cümle bulunamazsa 409), boyut sınırları, boş değişiklik reddi; `update_chapter(create_version=True)` üzerinden uygulanır → **önceki içerik versiyon anlık görüntüsü olarak saklanır** (undo güvenli); kelime deltası döner
- **UI**: hedef başına satır içi panel — akan imleçle canlı akış, Stop, Apply to chapter, Copy; uygulayınca hedef yeşil kenarlıklı "done" durumuna geçer; AI kapalıyken stüdyo tümüyle gizli
- v7.5 statik-JS mimarisi (`style_coach.js`): Jinja-JS çarpışması yapısal olarak imkânsız, tek delegeli tıklama dinleyicisi, veri data-* attribute'larından

### 🕰 Sütun 3 — Hikâye Kronolojisi (el yazması zaman ekseninde)
- **Yeni sayfa `/chronology/`** (sidebar Story bölümü + Ctrl+K paleti): yazılmış BÖLÜMLER hikâye zamanına göre yatay eksende kart olarak dizilir; PLAN olayları eksende iğnelerle üstüne bindirilir (yeşil=yazılmışa bağlı, mor=planlanmış)
- **Üç konum modu (otomatik)**: gerçek tarihler (2026-03-01, Temmuz 2026…) / "Gün N"/"Day N" işaretleri / hiç zaman bilgisi yoksa okuma sırası şeridi — modu BÖLÜMLER belirler (plan olayları değil — geliştirme sırasında yakalanan hata: tarihli plan olayları Gün-modlu bölümleri eksenden tamamen dışarı atıyordu)
- **Çatışma tespiti**: sıra-tarih çelişkisi (out-of-order) kırmızı "!" rozetli; ölçek-farkındalıklı zaman boşlukları kesikli turuncu şerit + "N-gün boşluk" etiketi; tarihsiz bölümler ayrı çip listesinde
- **"Kim sahnede?"**: karakter/alias isim geçişi taraması (kelime-sınırı — "Alinya", "Ali" sayılmaz) → karakter çipleri bölüm kartlarını soluklaştırır/parlatır
- **İstatistik kartları**: bölüm sayısı + tarihli yüzdesi, hikâye aralığı (gün), plan olayı + yazılan yüzdesi, boşluk sayısı, sıra-tarih çelişkisi sayısı; yakınlaştırma (−/+/Fit) + yatay kaydırma; etkinlik iğneleri tooltip'li; v8.0 JSON-etiket veri deseni (`|safe` + `<` kaçışı — canlı testte yakalanan autoescape hatası)
- `chronology_service.build_timeline()`: tekAlternasyon regex ile karakter taraması (bölüm başına TEK geçiş), `timeline_check_service` tarih ayrıştırıcısı yeniden kullanılır; `/chronology/api/timeline` JSON API

### 🧪 Kalite
- 49 yeni test (`test_v83_prose.py` 26 + `test_v83_chronology.py` 22): sözlük eşleşmeleri TR/EN + cümle-bütünlüğü regresyonu ("was angry" iki kelimeye BÖLÜNMEZ — .split() tuzağı) + "etraF/etki" yanlış-pozitif koruması, rapor şekli, okunabilirlik bantları, hedef tavanları, rota doğrulamaları (400/404/409 yolları dahil), versiyon anlık görüntüsü, kronoloji modları + çelişkiler + varlık + JSON kaçışı; inline-JS korumasına /chronology/ eklendi
- Canlı doğrulama (mock AI + tarayıcı): kronoloji 4 kart + 6 iğne + 3 karakter çipi + filtre etkileşimi (Kerem seçiliyken "Seur Kapıları" soluklaşır); Style Coach 🇹🇷 rozet + 11 çubuklu ritim + metrikler; AI Rewrite akışı → Apply → içerik değişti + 2 versiyon anlık görüntüsü; mobil 375px iki sayfada da taşma yok; VLM görsel onayı (hepsi "temiz, cilalı, glitch yok")
- SW VERSION v8.2.0 → v8.3.0; app banner + sidebar footer v8.3

---

## v8.2.0 — Çakışmasız UI (kökten) + Sohbet→Hikâye Köprüleri + Copilot 2.0 (2026-08-28)

🛠️ **"Raporlanan her şey düzeltildi + sohbet artık hikâyeye dönüşüyor" sürümü** — Kullanıcı dört hata bildirdi (app.js toLowerCase çökmesi, Spell Check 500, Reading Mode ok tuşları, tekrarlayan tuş çakışması — "bu çok sık oluyor, kökten çözmeni istiyorum") ve AI tarafını derinleştirmek istedi (Copilot + sunulan A/B/C seçenekleri). 1390 test (1348 → 1390, +42 yeni).

### 🐛 Sütun 1 — Bildirilen dört hata (dördü de canlı teşhis + düzeltme)
- **Spell Check 500 (KÖK NEDEN BULUNDU)**: v7.7'nin Türkçe dalı (`lang == "tr"`) sonuç sözlüğüne `flagged_count` KOYMUYORDU → `check_all_chapters()` `KeyError` → **Türkçe yazan her kullanıcıda /spellcheck/ her açılışta 500**. Türkçe bölüm tohumlayıp canlı olarak yeniden üretildi, düzeltildi: Türkçe dalı artık tüm anahtarları taşıyor; sayfada 🇹🇷 rozeti + açıklayıcı not; **sözlük terimleri artık gerçekten dahil** (docstring söz veriyordu ama kod CustomWord'lardan başka hiçbir şey okumuyordu — yakın-ıskala kontrolü şimdi sözlük terimlerini de kapsıyor, yani "Şimşektaşz" gibi yazım hataları yakalanıyor); performans: known-words + user-terms setleri tüm bölümler için BİR KEZ hesaplanıyor (eskiden her bölüm 3-4 DB oturumu açıyordu — 60 bölümlük kitapta sayfa gittikçe yavaşlıyordu)
- **app.js:342 `TypeError: Cannot read properties of undefined (reading 'toLowerCase')`**: bazı IME/sentetik/old-Android klavye olaylarında `e.key` tanımsız geliyordu ve 12 kısayol kontrolünün HER BİRİ çıkmadan önce tüm kısayol dinleyicisini öldürüyordu. Artık işleyicinin başında TEK SEFER normalleştirme var (`typeof e.key === "string"` guard, tek harfliler küçük harfe iner) + "g" akoru dinleyicisinde aynı guard
- **Reading Mode ok tuşları**: ↑/↓ artık bölüm değiştiriyor (ekrandaki ↑/↓ butonlarıyla tutarlı — eskiden sadece ←/→ çalışıyordu); PageUp/PageDown da aynı; buton ipuçları güncellendi. **Gizli ikinci hata**: "b" tuşu hem sidebar'ı HEM DE yer imleri panelini aynı anda açıyordu (iki document-level dinleyici yarışıyordu) — reading mode açıkken `data-reading-mode` gövde bayrağıyla global kısayollar (b/t/g/?//) geri çekiliyor
- **Full import'da kitap adı gelmiyordu (KÖK NEDEN)**: import idempotentti ve VAR OLAN proje satırını bütünüyle atlıyordu → aynı ID'li kitabı içe aktarırken ad/tür/hedef kelime/deadline asla güncellenmiyordu (bölümler giriyordu ama kitap adı eski kalıyordu). Artık **proje satırları UPSERT**: eşleşen ID'de kitap metaverisi (name/subtitle/genre/target_words/deadline/color) dosyadan güncellenir (`projects_updated` sayacı dönüyor), boş değerler mevcut alanları silmez, tekrar import yine çoğaltmaz; Import sayfasındaki davranış açıklaması güncellendi

### 🧲 Sütun 2 — Tuş çakışması KÖKTEN çözümü (kullanıcı: "çok sık oluyor")
- **Teşhis (canlı tarayıcıda kanıtlı)**: `.br-dock` **z-index 9950** idi — AI çekmecesi (z 80), yer imleri paneli (z 60), sayfa modalları (z 100) ve modal backdrop'ları (z 200) DAHİL her şeyin ÜSTÜNDE boyalıyordu → kullanıcı sohbet çekmecesini/paneli/modali açtığında + ve ↶↷ ve ↑↓ butonları üstte kalıp altındaki kontrollerin tıklamalarını çalıyordu (mobilde tam genişlik çekmecede + butonu chat'in Send butonunun TAM üstündeydi!)
- **Katman sistemi (dokümanteli CSS kuralı)**: dock artık **z-index 45** — sayfa içeriğinin (1-49) üstünde, TÜM overlay katmanlarının (60+) altında; `body.asm-overlay-open .br-dock { display:none !important }`
- **Overlay Watchdog ( geleceğe garanti)**: app.js'te MutationObserver tabanlı bekçi — bilinen overlay seçicileri + genel tarama (body'nin doğrudan çocukları arasında fixed konumlu, alt-sağ köşeyi kapsayan büyük öğeler) ile herhangi bir overlay açıldığında dock'u tamamen kaldırır; **animasyon-farkındal re-check** (350ms + 900ms) — kapanan çekmecenin kayma animasyonu sırasında tek seferlik kontrol yapıp sınıfı sonsuza dek açık bırakan yarış düzeltildi; canlı doğrulama: çekmece aç → dock gizlenir; kapat → geri gelir; mobil 375px'te Send butonu artık + FAB'ın ALTINDA DEĞİL, tıklanabilir
- Ayarlar sayfasının yapışkan kaydetme çubuğu sağdan 6.5rem pad'lendi (Save butonu dock kolonunun altına asla girmiyor); SW VERSION v8.1.0 → v8.2.0 (cache-first'in eski JS servis etmesi bitti)

### 🎬 Sütun 3 — Seçenek A: Sohbet → Sahne Taslağı
- Her karakter sohbetinde **🎬 Scene Draft** butonu: transkripti (röportaj veya grup sahnesi) düz nesire çevirir — röportaj sorularını keser, diyalogları doğallaştırır, beat + duyusal detay + alt-metin ekler, karakter sesine ve dünya gerçeklerine sadık kalır; ilk satır `TITLE:` başlığı
- Düzenlenebilir önizleme modalı → **📦 Save to Scenes**: taslak SceneCard olarak corkboard'a düşer (`from-chat` etiketli, bölüm çapası korunur); offline'da temizlenmiş transkripte düşer
- Canlı test: mock AI ile "Boğazda Bir Akşam" başlıklı sahne üretildi + Scenes'e kaydedildi

### ⇄ Sütun 4 — Seçenek B: Sohbet → Karakter Kartı Senkronu
- **⇄ Sync to Card** butonu: AI transkripti karakter kartına KARŞI analiz eder ve SADECE kartta olmayanı çıkarır — yeni özellikler / ses örnekleri (birebir alıntılar) / geçmiş revelations / konuşma desenleri / ilişki notları
- Onay modalı: her öğe checkbox'lı (yazar neyin geleceğine karar verir) → Apply → kartın ilgili alanlarına "Revealed in conversation (from chat, v8.2)" bloğu olarak EKLENİR (üzerine yazmaz); katılımcı seçici grup sohbetlerinde her karakter için ayrı analiz
- Canlı test: "Teknelerden korkuyor ama denizi seviyor — çelişkili cesaret" psychology alanına düştü

### 💡 Sütun 5 — Seçenek C: Röportaj Koçu
- **💡 Suggest Questions** butonu: hikâye bağlamı + şu ana kadarki konuşmayı okur, henüz sorulmamış DERİN sorular önerir (çelişkiler, anılar, sırlar, istekler, korkular — karakterin CEVAPLAYABİLECEĞİ sorular); tıklanan çip doğrudan gönderilir
- Offline fallback: kanıtlanmış 5 klasik röportaj sorusu

### ⚡ Sütun 6 — Copilot 2.0
- **Quick Story Actions** (metin GEREKTİRMEYEN altı eylem): 🔍 Find plot holes · 📖 Summarize the book · ➡️ Next scene (3 pitch) · 🎭 Consistency check · 💡 Brainstorm twists · 🌍 World gaps — hepsi RAG hikâye bağlamı + seçili bölümün son 1200 karakteriyle beslenir, streaming akar
- Sonuçlara **💾 Save as Note** (Copilot çıktısı Notes kasasına girer); sayfa 2.0 rozetiyle yenilendi
- Backend: `STORY_ACTIONS` tanım tablosu + `/api/story-actions` (liste) + `/api/story-action-stream` (SSE)

### ✅ Testler & Teslim
- **test_v82_fixes.py (42 yeni test)**: Spell Check Türkçe dalı (flagged_count + sayfa 200 + API 200 + sözlük yakın-ıskala + İngilizce regresyonu), import kitap adı (upsert + idempotent + yeni proje + boş-değer-koruması + multipart route), klavye düzeltmeleri (statik guard analizleri), çakışma kök çözümü (z-index 45 + watchdog CSS/JS + SW sürümü + savebar padding), A/B/C (üretim + kayıt + kart yazımı + hata yolları + UI kablolama), Copilot 2.0 (liste + 400 + sayfa render + SSE ilk olay)
- TAM PAKET **1390/1390** (1348 + 42); hem geliştirme hem temiz kurulumda geçti
- Sürüm damgaları: app.py banner v8.2, sidebar footer, test footer, SW VERSION v8.2.0

---

## v8.1.0 — AI Chat 2.0: Hafıza + Kalıcı Oturumlar + Grup Sahnesi (2026-08-28)

🧠 **"Konuşan Karakterler" sürümü** — Kullanıcı "AI chat kısmı çok ilkel kalmış, düzeltelim" dedi. Teşhis: karakter sohbetinde **bellek yoktu** (JS'teki `chatHistory` backend'e HİÇ gönderilmiyordu — her soru izole yanıtlanıyordu, karakter bir önceki soruyu unutuyordu!), sayfa yenilenince sohbet tamamen siliniyordu, tek düz bir konuşma vardı, mesaj aksiyonları yoktu; sidebar'daki genel "AI Chat" ise bir devam ettirme endpoint'ini (`/ai/continue`) sohbet gibi kullanıyordu — hikâye bağlamı (RAG) bağlı değildi, streaming yoktu, tam ekran loading UI'u bloklıyordu. 1348 test (1314 → 1348, +34 yeni).

### 🗄️ Sütun 1 — Kalıcı Sohbet Motoru (backend)
- **Yeni tablolar** `chat_sessions` + `chat_messages` (modeller `models/chat.py`): oturum başına mod (character/group/assistant), katılımcı karakterler, bölüm çapası, ayarlar (uzunluk/yaratıcılık/bağlam anahtarları), sabitleme, mesaj sayısı; mesajlar rol + konuşan karakter + bağlam istatistikleri + zaman damgasıyla saklanır — **sohbet artık yeniden başlatmalara, sayfa yenilemelerine ve yeniden boots'lara karşı ölümsüz**
- **`services/chat_service.py`**: oturum CRUD; otomatik başlık (ilk mesajdan); mesaj ekleme/silme (bir mesajı ve sonrasını sil); "regenerate" için son kullanıcı turundan sonrasını kesme; **hafıza oluşturucu `build_history()`** — karakter bütçeli (6000 karakter, min 6 tur) son konuşmalar her yeni isteme gömülür; transkript → Markdown; **nota aktarma** (`scene_idea` kategorisi + chat/kişi etiketleriyle Notes'a düşer); **arama** başlıkta VE mesaj gövdesinde
- **`routes/chat.py`** — birleşik API: oturum listesi/oluştur/getir/yama/sil, mesaj sil, Markdown export, nota export, `send` (SSE) ve `regenerate` (SSE). SSE protokolü v6.2 ile aynı (`context → chunk → done`) ama `done` artık kalıcı mesaj id'sini de taşır; AI hatasında kısmi metin yine de kaydedilir

### 💬 Sütun 2 — Character Chat 2.0 (sayfa baştan yazıldı)
- **Gerçek hafıza**: karakter artık "az önce sorduğun şeyi" hatırlar — konuşma her istemde yeniden oynatılır (bütçe sınırlı, en yakın turlar)
- **Oturum kenar çubuğu**: tüm konuşmalar listelenir (arama kutusu, sabitleme 📌, yeniden adlandırma, silme, otomatik başlıklar, mesaj sayısı + son aktivite) — "hangi konuşmada kalmıştım?" sorunu bitti
- **Grup Sahnesi / rejisör modu**: yeni konuşmada 2+ karakter seç → aynı odada konuşurlar; "Who answers" seçici (🤖 Auto — AI katılımcılar arasından en doğal konuşmacıyı seçer, veya sen seç); prompt diğer odadakileri ve "SADECE sen konuş" kuralını içerir — diyalog taslağı yazmanın yeni yolu
- **Mesaj aksiyonları** (hover'da görünür): kopyala ⧉, **yeniden üret ↻** (son AI yanıtı yeniden zar atılır), buradan-sil 🗑, kullanıcı mesajını düzenle-yeniden-gönder
- **Kontroller**: yanıt uzunluğu (Brief 1-2 cümle / Normal 2-5 / Expansive zengin paragraf → max_tokens 160/320/640), yaratıcılık kaydırıcısı (sıcaklık 0.2-1.4), bağlam anahtarları (Relations/World/Glossary/Plot açık-kapalı), bölüm çapası — oturumla birlikte kalıcı
- **Markdown-lite render**: kalın/italik/üstü-çizili, başlıklar, madde listeleri, satır içi + blok kod (önce tam kaçış → güvenli); streaming sırasında da çalışır
- **Yazıyor göstergesi** (zıplayan üç nokta) → ilk chunk'ta akan balon + imleç; Stop butonu akışı ortasında keser ve kısmi metni korur
- **Röportaj çipleri**: boş sohbette 6+ hazır soru paketi (Introduce/Biggest fear/Greatest desire/Childhood/Secret/Conflict + grup modunda "Scene!"); otomatik kaydırma takibi (yukarı kaydırınca durur)
- **Dışa aktarma**: transkripti Markdown olarak kopyala + "Save as note" (chat materyali hikâye kasasına girer)
- v7.5 statik-JS mimarisi (`static/js/character_chat.js`): karakter verisi `#ccCharacters` JSON etiketinden (`<` → `\u003c` kaçışlı), Jinja JS'e hiç dokunmaz

### ✨ Sütun 3 — Genel AI Chat Çekmecesi (her sayfada)
- Eski modal **sağdan kayan çekmeceyle** değiştirildi: gerçek **streaming** (token akışı + Stop), yazıyor göstergesi, markdown-lite
- **Hikâye bağlamı artık bağlı**: genel asistan da Context Engine (RAG) beslemesi alır — "🧠 👤 3 · 🌍 5" durum çubuğu ne bildiğini gösterir
- **Kalıcı oturum**: sayfalar arası gezinse de konuşma sürer (assistant modu); "＋" ile yeni konuşma, eskisi Character Chat oturumlarında durur
- Boş durumda hızlı çipler (Plot twist / Character / Setting); mobilde tam genişlik

### 🔧 Teknik
- Eski `/character-chat/api/chat` ve `/chat-stream` uçları **korumada** (API geriye dönük uyumluluk; v6.0/v6.2 testleri güncellendi ve hâlâ geçiyor)
- `create_session` artık id VE Character nesnesi kabul eder (savunmacı)
- Template `{% if %}` iç içe geçme hatası geliştirme sırasında yakalandı ve düzeltildi
- Testler: `tests/test_v81_chat.py` (34): servis (otomatik başlık, bütçe, truncate, arama, export, prompt derleyicileri) + rotalar (CRUD, SSE kalıcılık, AI hatasında kısmi kayıt, regenerate, grup konuşmacı seçimi fallback'i, istemci belirlenen konuşmacı, asistan bağlamı, **hafıza regresyonu: geçmiş turlar istemde**) + UI (yeni mimari, `</script>` kırılma güvenliği, çekmece varlığı)

---

## v8.0.0 — PWA "Her Yerde" + Duygu Yayı Motoru + Mobil Yazım Modu (2026-08-28)

🚀 **MAJOR SÜRÜM — "Everywhere"** — Kullanıcı v8'e geçmek istedi ve "v8'e yakışacak özellikler" istedi. Üç sütun teslim edildi: ASM artık kurulabilir GERÇEK bir uygulama (PWA + offline okuma), hikâyenin duygusal eğrisini görebilen bir analiz motoru (Duygu Yayı) ve telefonda gerçekten çalışan bir yazım deneyimi (v2 sidebar'daki gizli mobil kırılması kökünden düzeltildi). 1314 test (v7.8: 1258 + 55 yeni + 1 guard revizyonu → 1314).

### 📲 PWA — "Install App" + Offline Okuma (sütun 1)
- **Web App Manifest** (`/manifest.webmanifest`): standalone pencere, ASM kısa adı, tema rengi (#0b1020), kategoriler; 3 ikon girişi (192/512 any + 512 maskable)
- **Uygulama ikonları sıfırdan üretildi** (PIL, deterministik geometri): açık kitap + kıvılcım logosu — icon-192/512, maskable-512 (güvenli bölge %72), apple-touch-icon (180), favicon-32/16 — **ASM'nin İLK favicon'u** (v7.8'e kadar tarayıcı sekmesinde hiç ikon yoktu!)
- **Service Worker** (`static/js/sw.js`, kök kapsamdan servis edilir): sürüm damgalı üç önbellek (shell/pages/assets); aktivasyonda eski sürümler temizlenir; sayfa gezinmeleri network-first + önbellek yedeği (~40 sayfa LRU) + `/offline` düşüşü; statik varlıklar cache-first; **offline'dayken yazma istekleri dostane JSON 503 döner** (`{error: "offline", detail: "değişiklik KAYDEDİLMEDİ"}`) — sessiz ağ hatası duvarı yok
- **Offline sayfası** (`/offline`): nelerin çalıştığı/çalışmadığı kartları + bağlantı gelince otomatik yeniden yükleme; app shell ile önceden önbelleklenir
- **Güncelleme akışı**: yeni SW kurulunca tıklanabilir toast ("New version available → update & reload") → SKIP_WAITING → controllerchange ile tek tıkla güncelleme; `/sw.js` no-cache başlıklarıyla servis edilir (24 saatlik tarayıcı tazeliği gecikmesi yok)
- **Kurulum deneyimi**: sidebar'da "⬇ Install App" butonu (beforeinstallprompt gelmeden görünmez — iOS'ta doğal olarak gizli); kurulum sonrası tebrik toast'u
- **Bağlantı gözcüsü**: topbar'da nabız atan "● Offline" rozeti + online/offline toast'ları — kullanıcı hiçbir zaman "kaydetmedi mi?" şüphesinde kalmaz
- **Canlı doğrulama** (agent-browser + sunucu tamamen kapatılarak): ziyaret edilmiş sayfalar offline'da TAM içerikle açıldı; hiç ziyaret edilmemiş URL temiz offline sayfasına düştü; SW `activated`, kapsam `/`

### 🎭 Duygu Yayı Motoru — Emotion Arc (sütun 2)
- **Yeni sayfa `/emotions/`** (sidebar → Analytics → Emotion Arc, komut paletinde de var): bölüm seçici + 5 istatistik kartı (Ort. Duygu, Ort. Gerilim, Yay Şekli, Duygusal Aralık, Motor Dili) + SVG eğri + "Ana Duygu Anları" tablosu + "Koç Notları" + kitap geneli eğri
- **İki eksen**: VALENCE (-100..+100, umutsuzluk↔sevinç) ve TENSION (0..100, sakin↔patlayıcı); paragraf pencereleri (~25+ kelime, tek satırlık atlar eğriyi titretmez)
- **Yoğunluk bazlı ölçekleme**: leksikon isabetleri kelime yoğunluğuna göre ağırlıklanır — %15 duygu kelimesi içeren bir paragraf ~±65 okur (ilk denemede her şey ~±10'da sıkışan seyreltme hatası düzeltildi)
- **Kategori bazlı baskın duygu**: 7 kategori (joy/love/calm/sadness/anger/fear/neutral) isabet SAYIMLARIYLA belirlenir — v8.0 geliştirme sırasında yakalanan hata: seyreltilmiş ortalamalar nötr metni bile "fear" sınıyordu
- **Türkçe ek toleranslı sözlük** (~230 kök): "korku" → "korkusu/korkular/korkuya" önek eşleşmesi (≤4 ek karakteri, kök ≥5 harf); İngilizce ~230 kök tam eşleşme
- **Noktalama sinyalleri**: ünlem/soru işaretleri, üç nokta ve BÜYÜK HARF kelimeler gerilimi hafifçe yükseltir
- **Yay şekli sınıflandırıcı**: rising/falling/V-dip/peak/wave/stable — regresyon eğimi + orta üçlükteki ekstremum + işaret değişim sayısı
- **Koç notları**: kural tabanlı öneriler (düz eğri → "tersine çevirme ekle",sürekli karanlık → "bir sıcaklık anı karanlığı güçlendirir", gerilim zirvesi yok → "çatışma işaretleri eksik", uçurum finali → "sonraki bölüm nefes aldırsın"…)
- **Kitap eğrisi**: her bölümün ortalama gerilimi amber sütun + ort. valence indigo çizgi — karanlık bölümün yanındaki aydınlık bölümün gücü görünür
- **v7.5 statik-JS mimarisi**: `static/js/emotion.js` Jinja'dan geçmez; veri `<script type="application/json">` etiketlerinden akar (rota `</script>` kırılmasına karşı `<` → `\u003c` kaçışı yapar); bölüm seçici API'den çeker, sayfa yenilenmeden eğri değişir
- **Dil farkındalıklı**: v7.7 dil motorunu kullanır (auto/tür/ingilizce ayarı + otomatik tespit); AI gerekmez, offline çalışır
- Canlı doğrulama: "Küllerin Ardından" (ölüm + gece kovalamacası) → val -27, falling, fear baskın; "Fenerlerin Şarkısı" (zafer kutlaması) → val +64, joy baskın; "Yabancı Gemi" → -11 falling

### 📱 Mobil Yazım Modu (sütun 3)
- **KRİTİK KÖK HATA BULUNDU VE DÜZELTİLDİ**: `ui-v2.css`'teki `body[data-ui-version="v2"] .sidebar { position: sticky }` (özgünlük 0,2,1) main.css'in mobil `.sidebar { position: fixed }` kuralını (0,1,0) SUSTALIYORDU — **telefonda hamburger çekmecesi HİÇBİR ZAMAN gizlenmiyor, tüm ekranı kaplıyordu**. VLM görsel denetimi yakaladı; düzeltme v2 özgünlüğünde sabit konum kuralı + açılış durumu
- Dokunma hedefleri ≥40px (hamburger butonu, topbar butonları min-height 38px)
- Tablolar telefonda yatay kaydırılabilir (`display: block; overflow-x: auto`) — sıkışma yok
- Kitap değiştirici adı kesilir (ellipsis), topbar'da gereksiz "+ New Chapter" gizlenir (Quick Add kalır), BR-dock köşeye yaklaşır, editör araç çubukları sarar
- Kart ızgaraları (cols-2/3/4/5) telefonda tek kolona iner; Duygu Yayı SVG'i min-width 640px ile kaydırılabilir
- **Canlı denetim (375px)**: Dashboard (çekmece + overlay ✓), Chapters (taşma yok ✓), Editör (dock butonları 7px boşlukla dikey dizili ✓), Emotions ✓, Graph ✓ — hepsinde `scrollWidth == clientWidth`, VLM görsel onayı

### 🔧 Altyapı & Testler
- Yeni rotalar: `/manifest.webmanifest`, `/sw.js`, `/offline`, `/emotions/` + 3 API ucu — 64 blueprint (63 → 64)
- Yeni servis: `services/emotion_service.py`; yeni statik JS: `emotion.js`; yeni şablon dizini `templates/emotions/`
- İç-JS koruma testi `type="application/json"` VERİ bloklarını tanır hale geldi (kod değil veri — node --check yanlış pozitifi bitti) ve `/emotions/` korumalı sayfalar listesine eklendi
- Yeni testler: `test_v80_pwa.py` (14) + `test_v80_emotion.py` (26) + `test_v80_mobile.py` (15) = **55 yeni test**; tam paket 1314/1314

---

## v7.8.0 — Graph 2.0 + Çoklu Grup Üyeliği + Birleşik BR-Dock (2026-08-27)

🎨 **Graf & Dock Yeniden Yapılandırma Sürümü** — Kullanıcı iki şey istedi: (1) graf kısmında bir karakteri iki gruba ekleyememe ve gruplar arası bağlantı kuramama, (2) sağ altta save + geri/ileri + artı butonlarının üst üste binmesi (v7.7'de buton sol alttan sağ alta taşınınca undo-toolbar'ın yerine gelmişti — canlı geometri teşhisiyle doğrulandı). İkisi de KÖKTEN çözüldü. 1258 test (1219 → 1258).

### 🔧 Birleşik Sağ-Alt Dock (BR-Dock) — buton çakışması sonsuza dek bitti
- **Kök neden** (canlı tarayıcıda getBoundingClientRect ile ölüldü): `.undo-toolbar` (right:1.5rem/bottom:1.5rem, HER sayfada) ile `.qc-fab` (right:24px/bottom:24px) neredeyse tam üst üste binmişti; builder sayfalarında `.form-status-pill` (right:1rem/bottom:1rem), okuma modunda bölüm gezinme butonları da aynı köşeydi — dört bağımsız widget, tek köşe, sıfır koordinasyon
- **Mimari çözüm**: TEK sabit konteyner `#brDock` (base.html) — tüm sağ-alt widget'ları bunun flex kolon çocuğu; dikey sıralama CSS `order` ile (10 sayfa widget'ları → 20 durum hapi → 30 undo/redo → 40 AI butonu → 50 QC FAB); DOM/JS ekleme sırası önemsiz, çakışma YAPISAL olarak imkânsız
- `quick_capture.js` ve `form_progress.js` artık `#brDock`'a ekliyor; okuma modu ↑↓ butonları ve editör AI opener'ı `{% block br_dock %}` ile dock'a enjekte ediliyor; Focus Mode 2.0'da dock tamamen gizleniyor
- `body.qc-lock .qc-fab` artık `visibility: hidden` — besteci açıkken dock yüksekliği zıplamıyor

### 👥 Çoklu Grup Üyeliği (kullanıcı isteği №1)
- **Sorun**: gruplar sayfasındaki sürükle-bırak MOVE semantiğiydi — bir karakteri ikinci gruba sürüklemek onu ilkinden SİLİYORDU (DB zaten çok-çok destekliyordu, UI engelliyordu)
- **Yeni servisler**: `set_group_members` (bir grubun üye listesini senkronla — diğer gruplardaki üyelikler DOKUNULMAZ), `set_character_groups` (bir karakterin gruplarını senkronla), `assign_many_to_group` (toplu ekleme)
- **Gruplar sayfası**: her grup kartında "+ Members" seçicisi — aramalı, çoklu-seçimli onay kutusu listesi; üye başına "×" butonu (yalnızca O gruptan çıkarır); sürükle-bırak taşımaya devam ediyor
- **Karakter detay**: "+ Manage Groups" seçicisi — onay kutulu grup listesi, tek tıkla birkaç gruba üyelik; boş kart artık hep görünür ("No groups yet")
- Graf'ta çok gruplu karakter İKİ grup elipsine de turuncu kesik kenarla bağlanıyor; `stats.multi_group_chars` sayacı

### 🔗 Gruplar Arası Bağlantılar (kullanıcı isteği №2)
- **Sorun**: grup↔grup bağlantısı diye bir şey YOKTU — sadece üyelerin çapraz ilişkilerinden otomatik üretilen, düzenlenemeyen, silinemeyen sahte "group link" kenarları vardı
- **Artık gerçek ilişkiler**: gruplar sayfasında "Group Connections" bölümü — grup↔grup VEYA grup↔karakter bağlantısı oluştur/düzenle/sil (tür + açıklama + çift yönlü); graf'ta "+ Add Relationship" ile iki grup düğümüne tıklayarak da oluşturulur
- Otomatik `g2g-` kenar üretimi KALDIRILDI (gürültü bitti) — `graph/data` artık her gerçek kenara `rel_type`/`description`/`bidirectional`/`from_label`/`to_label` metadata'sı veriyor

### 🕸️ Graph 2.0
- **Kenar düzenleme**: kenara tıkla → popup'ta yeni "✎ Edit" — tür/açıklama/çift yönlü değiştir (`/relationships/<id>/update`); üyelik kenarları hariç her kenar için çalışır
- **PNG export**: "⤓ Export PNG" — vis-network canvas katmanları tek görüntüde birleştirilir, tek tıkla `character-graph.png` iner
- **Karakter arama**: filtre haplarının yanında arama kutusu — Enter/⌕ karakteri bulur, görünümü odaklar, diğer düğümleri soluklaştırır
- **İstatistik şeridi**: Karakter/Grup/İlişki (+grup seviyesi)/Çok gruplu/En bağlı (derece + ilk 3)/Yalnız karakter sayıları — grafın üstünde 6 kart
- **Grup konumu kalıcılığı**: grup elipsleri sürüklenince konum `character_groups.graph_x/graph_y` sütunlarına kaydedilir (karakter düğümleri gibi); `update_graph_position` artık `g-` önekli kimlikleri de anlıyor
- Grup popup'ı üye sayısını gösteriyor; ekleme modunda grup↔grup seçilince modal başlığı "New Group Connection" oluyor ve bağlam ipucu çıkıyor

### 🛡️ Mimari cila
- Gruplar sayfası + karakter detay grup yönetimi STATİK JS'e taşındı (`static/js/groups.js`, `static/js/char_groups.js` — v7.5 notes.js mimarisi): Jinja betiği bozamaz, veri `data-*` attribute'larından akar, document-seviyesi event delegation
- **Yakalanan tuzak**: Flask'ın `|tojson` filtresi çıktıyı Markup (güvenli) döndürür — ardına eklenen `|e` NO-OP'tur; çift tırnaklı HTML attribute içinde ham `"` değeri kesiyordu (canlı: `data-member-group-ids="["`). Çözüm: JSON route'ta `json.dumps` ile düz string olarak serialize + `|e` ile kaçış; regresyon testi eklendi
- Jinja'nın comprehension içinde dict literal desteklemediği keşfedildi — JSON payload'ları route'ta hesaplanıp şablona hazır geçiriliyor

## v7.7.0 — Türkçe Dil Motoru + Tek Yakalama Yüzeyi (2026-08-26)

🔧 **Araştırma Bulgusuna Dayalı Sürüm** — Kullanıcı "daha neleri geliştirebiliriz diye bir araştır" dedi. Uygulama genelinde yapılan araştırma, analiz motorunun tamamen İngilizce-merkezli olduğunu ortaya çıkardı: Türkçe yazan bir yazar için lint/tempo/kelime sıklığı/yazım denetimi ya boş ya yanlış sonuç veriyordu. Aynı araştırmada sol-alttaki + butonunun sidebar linklerini kapatması raporlandı. İkisi de bu sürümde kökten çözüldü. 1219 test (1174 → 1219, +45 yeni).

### 🇹🇷 Dil Farkındalıklı Analiz Motoru (`services/lang_service.py`)
- **Kök neden**: lint'in tekrar-kelime regex'i `\b[a-z]{3,}\b` ASCII-only idi → ç/ğ/ı/ö/ş/ü içeren Türkçe kelimeler GÖRÜNMEZDİ ("gölge" bir paragrafta 5 kez: sıfır bulgu). Gerilim sözlüğü İngilizce (fight/blood) → Türkçe romanda gerilim eğrisi hep düz sıfır. Kelime sıklığı stopword'leri İngilizce → ve/bir/bu/da/de her raporu domine ederdi. Yazım denetimi ~1000 kelimelik İngilizce liste → her Türkçe kelime "yanlış yazılmış" sanılırdı
- **Yeni `lang_service`**: hafif ve deterministik dil tespiti (diyakritik yoğunluğu + fonksiyon kelimesi skorlaması — harici NLP bağımlılığı yok); Türkçe/İngilizce stopword listeleri, gerilim sözlükleri (~180 Türkçe gerilim kelimesi: savaş, kılıç, korku, kaç, ihanet, canavar, büyü...), zarf listeleri, edilgen çatı desenleri (-ildi/-ıldı/-üldü/-uldı/-indi/-ındı/-ündü/-undu fiil gövdeleri), diyalog fiilleri (dedi, fısıldadı, bağırdı, mırıldandı...)
- **Unicode-güvenli tokenizer**: "Aylin'in kılıcı gölgede parıldadı" → doğru tokenler; kesme işareti sonrası ekler temizlenir
- **lint_service**: tekrar-kelime tespiti artık Türkçe kelimeleri görüyor + dile göre stopword filtresi; zarf yoğunluğu Türkçe zarflarla (sessizce, hızlıca, aniden...); edilgen çatı Türkçe eklerle; diyalog çeşitliliği Türkçe fiillerle ve Türkçe öneri metniyle
- **pacing_service**: gerilim puanı bölümün diline göre sözlük seçer; tipografik tırnak ("...") diyalog tespiti eklendi
- **word_freq_service**: stopword filtresi dile göre (Türkçe'de ve/bir/bu artık raporları domine etmiyor); tokenizer Türkçe-güvenli
- **spellcheck_service**: Türkçe bölüm tespit edilince İngilizce sözlük işaretlemesi tamamen atlanır (yanlış-pozitif yağmuru bitti); kullanıcı sözlüğü + sözlük terimlerine Levenshtein ≤1 yakınlık ile "kendi teriminin yazım hatası" yakalama; tokenizer Türkçe karakterleri bölmüyor ("Gölge" → "lge" parçalanması düzeltildi)
- **Ayarlar → Goals → Analysis Language**: Auto (bölüm başına tespit — karma kütüphaneler için) / Türkçe / İngilizge; bilinmeyen değerler reddedilir
- **Unicode tuzası düzeltmesi**: Python'da `"İ".lower()` → `"i" + U+0307` ayrışması, düz ASCII "i" harfini Türkçe harf sanıyordu → ≥2 "i" içeren İngilizce cümleler yanlışlıkla Türkçe algılanıyordu (algılama testiyle kapatıldı)

### ➕ Tek Yakalama Yüzeyi (kullanıcı raporu: "sol alttaki + butonu diğer tuşların üzerine geliyor")
- **Kök neden (canlı geometri kanıtıyla)**: eski `.fab-capture` butonu `bottom:1.5rem; left:1.5rem` konumundaydı — 240px sidebar'ın ayak izinin İÇİNDE. Bounding box'ı sidebar'ın son navigasyon linklerini (Kanban, Corkboard) ve alt bilgi panelini (Today 777/500 + sürüm) kapatıyordu
- **Mimari çözüm**: alt-sol buton tamamen kaldırıldı; v7.3'ün zengin bestecisi (4 tipli Not/Bölüm/Günlük/Parça) TEK yakalama yüzeyi oldu — `+` ikonlu FAB sağ altta (sidebar'a çakışma yapısal olarak imkânsız), tooltip her iki kısayolu gösterir
- **Ölü kod temizliği**: app.js'te İKİ document-seviyesi Ctrl+N dinleyicisi vardı — üstteki `/chapters/new`'e yönlendiriyordu ve `return` ile alttaki besteci dinleyicisini eziyordu (kısayol yardım modalı "Ctrl+N → Quick Note" derken gerçekte yeni bölüm sayfası açılıyordu!). Artık tek bağlama: Ctrl+N besteciyi açar; Ctrl+Shift+N quick_capture.js'e aittir (aç/kapat toggle) — ikisi de ayrı dinleyicide yarışamaz
- **Tüm giriş noktaları birleşti**: + FAB / Ctrl+N / Ctrl+Shift+N / Ctrl+P Quick Switch "quickNote" eylemi / başlık "+ New → ⚡ Quick Capture" menüsü — hepsi aynı `window.asmQuickCapture` API'sine gider (modül yüklenemezse eski not-modalı yedek olarak düşer)
- **CSS temizliği**: `.fab-capture` kuralları main.css/polish.css/ui-v2.css'ten kaldırıldı; v2 gradyan cila `.qc-fab`'a taşındı

### 🧪 Sistemik Koruma Testleri
- `tests/test_v77_fab_unification.py` (12 test): eski FAB butonu/idi/CSS'i yok, + ikonu, asmQuickCapture API export, tek Ctrl+N bağlaması, Ctrl+Shift+N sahipliği quick_capture.js'te, render edilmiş 4 çekirdek sayfada eski FAB yok, qc-fab sağ-altta (asla solda değil), kısayol modalı metinleri
- `tests/test_v77_language_engine.py` (34 test): dil tespiti (Türkçe diyakritik / İngilizce / diyakritiksiz Türkçe fonksiyon kelimeleri / ASCII-i regresyonu / açık geçersiz kılma), tokenizer, per-dil stopword-gerilim-zarf-edilgen kaynakları, lint Türkçe tekrar/zarf/diyalog, Türkçe stopword işaretlenmiyor, Türkçe metinde gerilim >0, tipografik tırnak diyalogu, word-freq tokenizer, İngilizce yollar değişmedi, Türkçe yazım denetimi yanlış-pozitifsiz + İngilizce'de çalışıyor, ayarlar UI + geçerli seçim kaydı + bilinmeyen değer reddi + sabitlenmiş dil lint'i kullanır

### 🔧 Sürüm Güncellemeleri
- app.py banner v7.7 + alt başlık "Turkish Language Engine · Unified Quick Capture", sidebar footer v7.7, test_v61 footer testi v7.7'ye güncellendi
- CHANGELOG v7.7 girişi (Türkçe detaylı), README v7.7 + test sayısı

---

## v7.6.0 — Derin İçgörüler + Hikaye Atlası + Okuyucu Modu 2.0 (2026-08-26)

🚀 **Üç Derinleşme Sürümü** — Kullanıcı "geliştirmeye ve derinleştirmeye devam edebiliriz" dedi. v7.5'in kökten çözümlenen mimarisinin üzerine üç yeni özellik: yazar içgörü panosu, hikaye atlası ve okuyucu modu yeniden tasarımı. 1174 test (1120 → 1174, +54 yeni).

### 📊 Yazım İçgörü Panosu 2.0 (`/insights/`)
- **Yıllık Aktivite Heatmap'i (GitHub-tarzı)** — 365 günlük takvim ısı haritası; her hücrenin renk yoğunluğu o gün yazılan kelime sayısını gösterir (0/1-99/100-499/500-999/1000+ → 5 seviye), hover ile tam tarih + kelime sayısı tooltip'i, bugünün hücresi vurgulu (accent outline), haftalık sutun düzeni (Pzt-Cum-Cmt-Paz etiketleri), yatay kaydırma. Hafta/sütun yapısı GitHub contributions sayfasıyla aynı
- **Bugünün Akıllı Kartı** — tek bakışta yazarın bugünkü durumu: (1) günlük hedefe ilerleme (SVG halka ile yüzde gösterimi), (2) mevcut seri (X gün üst üste yazım), (3) en verimli saat aralığı (son 30 günden hesaplanır), (4) **bağlamsal tek satırlık ipucu** — örn. "Çarşamba — en verimli günün. 20:00–22:00 arasında 750 kelime hedefle" veya "Günlük hedef tamamlandı! 3 günlük serini sürdür" (hedef tamamlandıysa farklı mesaj, seri yoksa başlatma teşviki, en verimli saatteysek "peak hour" bildirimi)
- **Hız Trendi (30 gün)** — Canvas ile çizilen sparkline grafiği (harici kütüphane yok, çizgi + gradient alan dolgu), günlük kelime sayısı X-ekseninde, ortalama/tepe/toplam istatistik kartları, son 7 gün önceki 7 günle karşılaştırması → ↗/↘/→ trend rozeti (renkli: yeşil/kırmızı/gri)
- **Çoklu Kitap İlerleme Paneli** — multi-book (v7.0) workspace'ler için her kitabın ayrı kartı: (1) kelime sayısı / hedef, (2) ilerleme çubuğu, (3) 30 günlük hız (kelime/gün), (4) bitiş tarihine kalan gün, (5) mevcut hızda tahmini tamamlanma tarihi, (6) durum rozeti (✓ Complete / ↗ Ahead / ● On track / ⚠ Behind / — No pace), (7) aktif kitap vurgusu (accent kutu). Genel toplam kartı (toplam kelime / toplam hedef / yüzde). Status çubuklu kart border'ı

### 🗺️ Hikaye Atlası (`/atlas/`)
- **İç içe lokasyon ağacı** — tüm location-türündeki dünya girdilerini parent_id ile özyinelemeli olarak gösterir; her düğümde (1) renk noktası (map_pin_color), (2) isim (link), (3) kategori rozeti, (4) o düğümde pin'lenen karakter sayısı (📍 N), (5) alt ağaçtaki toplam pin sayısı (↳ N), (6) harita resmi varsa 🗺️ rozeti, (7) "+ Pin" butonu (satır hover'da görünür). Derinlik göstergesi ile girinti. Tümünü aç/kapat butonları. v7.4'te eklenen parent_id zinciri tam kullanımda
- **Karakter-Lokasyon Pin Modeli** — yeni `character_location_pins` tablosu (project_id, character_id, location_id, kind, note, chapter_id opsiyonel). 5 pin türü: current_residence / origin / visiting / hiding / temporary. Her türün rengi ve etiketi ayrı (yeşil/mavi/turuncu/kırmızı/mor). Opsiyonel chapter_id ile zaman çizgili pin (X karakteri Y şehrinde bölüm 3'te) desteği — gelecekte kullanım için
- **Pin CRUD** — her ağaç düğümündeki "+ Pin" butonu pin modal'ı açar (karakter seçimi + lokasyon + tür + not), karakter listesi ve lokasyon listesi `/atlas/api/candidates`'ten yüklenir, pin ekleyince sayfa yenilenmeden ağaç + pin listesi güncellenir. Pin silme (× butonu). POST /atlas/api/pin + DELETE /atlas/api/pin/<id>
- **Pin Listesi Paneli** — lokasyona göre gruplanmış tüm pin'lerin görünümü: her grup başlığı lokasyon linki, her satırda (1) karakter renk noktası, (2) isim (link), (3) rol rozeti, (4) pin türü etiketi (renkli), (5) not, (6) sil butonu. Slide-out yerine sağ panel — sayfa ile birlikte görünür
- **Seyahat Rotaları Listesi** — `travel_routes` tablosundan tüm rotaları listeler: her satırda (1) rota rengi noktası, (2) rota adı, (3) karakter adı, (4) waypoint sayısı. `/atlas/api/routes` endpoint
- **İstatistik Şeridi** — 5 kart: Toplam Lokasyon / Pin'li Karakter / Toplam Pin / Maks Derinlik / Seyahat Rotası. Tek bakışta atlas'ın büyüklüğü
- **Tüm JS statik dosyada** (`static/js/atlas.js`) — v7.5 mimari kuralı: Jinja ile çarpışma yapısal olarak imkânsız. data-* attribute'ları üzerinden veri akışı. Event delegation ile çift-yerleşim dayanıklı

### 📖 Okuyucu Modu 2.0 (`/reading/`)
- **Kök mimari düzeltmesi (v7.5 mirası)** — mevcut reading.html'in 200+ satırlık inline `<script>` bloğu kaldırıldı; tüm JS `static/js/reading_mode.js`'e taşındı (335 satır). Jinja ile çarpışma riski sıfır. v7.5'in inline-JS guard testleri (23 sayfa node --check) otomatik koruma sağlar
- **Bookmark sistemi** — her bölüm başlığında bookmark toggle butonu (SVG i-bookmark ikonu, dolu/boş). **Ctrl+D / Cmd+D** → mevcut bölümü bookmark'lar. localStorage'a kaydeder (ts, scrollPct). Toplam bookmark sayısı üst barda rozet olarak görünür
- **Highlight sistemi** — metin seçimi → yüzen renk toolbar (4 renk: sarı/yeşil/mavi/pembe + sil). Tıklayınca seçimi `<mark class="reader-highlight">` ile sarar, localStorage'a kaydeder (chapterId, text, color, ts, chapterTitle). Sayfa yeniden render'da highlight'lar otomatik restore edilir (restoreHighlights — ağaç yürüyüşü ile metni bulup tekrar sarar). **Ctrl+Shift+H** → varsayılan sarı highlight uygular
- **Okuma süresi takibi** — IntersectionObserver ile her bölümde ne kadar süre kalındığını izler (saniye çözünürlükte). localStorage'a kaydeder (`asm:reading:chapter_times`). Sayfa blur olunca sayaç durur, focus olunca devam eder. Sayfa kapanırken kaydeder (beforeunload). Her bölüm başlığında meta satırda "⏱ 3m 12s" olarak gösterilir
- **Slide-out paneli** — sağ taraftan kayarak açılan 360px genişliğinde panel (**B** tuşu veya üst bardaki bookmark butonu). 3 sekme: (1) **Bookmarks** — tarihe göre sıralı liste, her satıra tıkla → ilgili bölüme kayar, × ile sil; (2) **Highlights** — en yeniden eskiye sıralı, snippet + lokasyon + tarih, × ile sil; (3) **Reading Time** — toplam okuma süresi + bu seans süresi (büyük kartlar) + her bölüm için ayrı süre listesi (mevcut bölüm vurgulu). Tüm kayıt localStorage'da — sunucu gerekmez
- **Yeni kısayollar** — Ctrl+D (bookmark), Ctrl+Shift+H (highlight), B (panel toggle), F (fullscreen), H (kontrol çubuğu gizle), ← → (bölümler arası)

### 🧪 Sistemik Koruma Testleri
- `tests/test_v76_insights.py` (14 test) — sayfa render + sidebar linki + statik JS doğrulama + 5 API (dashboard/heatmap/today/cross-book/velocity) + servis katmanı (_level, _streaks, _compose_tip) + node --check + Python slice taraması
- `tests/test_v76_atlas.py` (16 test) — sayfa render + 5 API (full/tree/pins/routes/candidates) + pin CRUD round-trip (seed'li karakter+lokasyon ile: create → verify pin listede + ağaç pin sayısı doğru → delete → verify kalktı) + validasyon (boş pin 400, yanlış kind 400, varolmayan sil 404) + nested parent-child zinciri + pin_kinds sabitleri + node --check + Python slice taraması
- `tests/test_v76_reading.py` (14 test) — sayfa render + statik JS doğrulama (eski inline fonksiyonlar yok) + yeni v7.6 widget'lar (highlightToolbar/bookmarksPanel/rbpBookmarks/rbpHighlights/rbpReadingTime) + chapter API + node --check + Python slice taraması + highlight/bookmark/time/keyboard/CSRF API varlığı + CSS stilleri var + şablon büyüklük kontrolü (artık <200 satır, eskiden 334)

### 🔧 Sürüm Güncellemeleri
- app.py banner v7.6 + alt başlık "Insights Dashboard · Story Atlas · Reading Mode 2.0"
- sidebar footer v7.6
- test_v61 footer testi v7.6'ya güncellendi
- README v7.6 + 1165 test + yeni Insights/Atlas/Reading 2.0 açıklamaları
- CHANGELOG v7.6 girişi (Türkçe detaylı)

### 🛡️ Teslimat Öncesi Yakalanan Regresyonlar
- **Atlas pin'leri export'ta taşınmıyordu** — v7.6'nın yeni `character_location_pins` tablosu v7.5'in 29 tabloluk `CONTENT_TABLES` listesine eklenmemişti. Bu, kullanıcının daha önce yaşadığı "full export kitap adını/notları taşımıyor" hatasının birebir aynı sınıfıydı (yeni tablo eklendi ama export güncellenmedi). Düzeltme: tablo listeye FK-sıralı eklendi (karakter/dünya/bölüm ebeveynlerinden sonra) → **30 içerik tablosu**; `test_round_trip_preserves_atlas_pins` regresyon testi eklendi (export→import round-trip + idempotent re-import); settings/settings_import/README metinleri 29→30 güncellendi
- **Dashboard, string saklanan günlük hedefte çöküyordu (canlı doğrulamada yakalandı)** — `Setting.set` string verildiğinde değeri JSON string olarak saklar (`"500"`); dashboard şablonu ise `stats.words_today / settings.get('daily_word_goal', 500)` ham aritmetiği yapıyordu → `TypeError: unsupported operand for /: 'int' and 'str'` → **ana sayfa HTTP 500**. Aynı kırılganlık `total_word_goal` (Story Health yüzdesi) ve haftalık hedef çarpımında (`"500" * 7` → JS'te string tekrarı) da vardı. Mevcut test `test_v73_focus_api_today_uses_daily_goal_setting` hedefi string olarak set ettiği için senaryo gerçekti. Düzeltme: şablonda tek normalizasyon noktası (`{% set daily_goal = ...|int or 500 %}` + `weekly_goal` + `total_goal`), tüm tüketiciler normalleştirilmiş int kullanır; `window.ASM_DAILY_GOAL` JS global'i de `|int` ile garanti edilir. `tests/test_v76_dashboard_goal.py` (6 test): string günlük/ toplam hedefle render, doğru değer çıktısı (750×7=5250, tekrar yok), JS global int, şablon normalizasyon noktası, Python okuyucularının savunmacı `int()` sarması

---

## v7.5.0 — Kökten Çözüm: Notlar Mimarisi + Tam Sadakatli Taşıma (2026-08-25)

🔧 **Kök Neden Düzeltme Sürümü** — Kullanıcı iki tekrarlayan hatayı bildirdi: (1) Notlar sayfasında hiçbir etkileşim çalışmıyor — "bu problem sürekli ortaya çıkıyor", (2) Full data export yeni sürüme taşındığında kitap adı ve notlar gelmiyor. İkisi de KÖKTEN çözüldü, semptom düzeltmesi değil. 1120 test (1069 → 1120).

### 🔧 Notlar Sayfası — Kaynak Seviyesinde Mimari Düzeltme
- **Kök neden teşhis edildi**: `templates/notes.html` içindeki ~320 satırlık inline `<script>` bloğunda, Jinja ifadesinden JS template literal'e kopyalanan **Python dilbilgisi** vardı: `n.created_at[:10]` (Python slice). JS'te geçersiz → tüm script bloğu SyntaxError ile parse edilemedi → sayfadaki TÜM fonksiyonlar (`openNewNoteModal`, `togglePin`, `exportAllNotes`...) tanımsız kaldı → hiçbir buton hiçbir şey yapmadı. Bu hata sınıfı daha önce de v7.2'de (Jinja macro çıktısının JS string'ini bozması) farklı yüzle karşımıza çıktı — her seferinde aynı mimari zafiyet: **Jinja ile işlenmiş dev inline script blokları**
- **Mimari çözüm (tekrar edemez)**:
  - Tüm not-sayfası JS'i `static/js/notes.js` statik dosyasına taşındı — Jinja bu dosyaya hiç dokunamaz, Jinja/JS çarpışması bu sayfada yapısal olarak imkânsız
  - Veri yalnızca `data-*` attribute'ları üzerinden akar (`data-note-data` JSON + `data-note-html` önceden render edilmiş markdown)
  - **Event delegation**: document seviyesinde TEK dinleyici tüm kart butonlarını ve gövde tıklamalarını yönetir — DOM değişimlerine dayanıklı, tek kartın hatası diğerlerini koparamaz
  - Her notun parse'ı try/catch içinde — tek bozuk kart tüm ızgarayı öldüremez
  - Tüm public fonksiyonlar `window.` üzerine açıkça export edildi
- **Global hata görünürlük ağı (app.js)**: `window.addEventListener("error")` + `unhandledrejection` dinleyicileri artık görünür kırmızı toast gösterir ("UI error (script): ... F12") — **hiçbir script hatası bir daha sessiz kalamaz**. Hata fırtınalarına karşı rate-limit'li
- **Sistemik koruma testleri (CI guard)**:
  - `tests/test_inline_js_guard.py` (23 test): 20 çekirdek sayfa (dashboard, chapters, notes, scenes, plans, journal, characters, world, hierarchy, outline, search, export, settings, analytics...) zorlu veriyle render edilir ve **her inline `<script>` bloğu `node --check` ile syntax doğrulanır** — herhangi bir şablon bir daha geçersiz JS üretirse CI tam sayfa+hata konumuyla düşer
  - `tests/test_notes_js.py` (15 test): şablonda büyük inline script yasağı, notes.js parse + window API export'ları + delegation varlığı + Python slice kalıntısı taraması + render edilmiş sayfada tüm inline scriptlerin parse'ı + data attribute bütünlüğü + API CRUD

### 💾 Full Data Export — Tam Sadakatli Taşıma
- **İkinci kök neden**: `/settings/export-json` hiçbir zaman `data["project"]` satırını yazmıyordu (kitap adı, tür, hedef kelime, son tarih, renk) ve notlar/jurnal/sahneler/sözlük/referanslar/planlar-maylstones/submissions tamamen dışarıdaydı. Import kodu proje satırını destekliyordu ama export yazmıyordu — eksik taraf hep export'tu
- **Yeni `services/project_transfer_service.py`**: tablo-güdümlü (table-driven) tam sadakatli taşıma servisi
  - **29 içerik tablosu** export+import: projeler (kitap adı + meta), bölümler + sürümleri + bağımlılıkları, sahneler, karakterler (gruplar/ilişkiler/arklar/modlar/sesler), planlar + alt görevler, dünya girdileri + sürümleri + ilişkileri (parent_id hiyerarşisi dahil), seyahat rotaları, **notlar**, jurnal, referanslar, sözlük, ilhamlar, milestone'lar, başarımlar, submissions, beta yorumları, yazım oturumları, özel sözlük kelimeleri
  - **Tüm kitaplar** export edilir (multi-book destekli), aktif olanın adı dosya adına gelir: `asm_project_Güneşin_Kızı.json`
  - Import **idempotent**: mevcut primary key'ler atlanır, tekrar import duplikasyon yapmaz
  - **Satır başına SAVEPOINT** (`begin_nested`): tek bozuk satır tüm import'u öldüremez — o satır log'lanıp atlanır
  - SQLAlchemy 2.x'in mapper-adı sıralı flush davranışı (Chapter, Project'ten önce!) SAVEPOINT anında flush ile aşıldı — yoksa yeni kitap + bölüm aynı transaction'da sahte FK hatası veriyordu
  - **Geriye dönük uyumluluk**: eski asm-v4 dosyaları (tekil `project` anahtarı, notlar yok) sorunsuz import edilir
  - **Güvenlik**: API anahtarı export'ta asla yazılmaz, import'ta boş değer mevcut anahtarı asla ezmez
- `routes/settings.py`: export/import yeni servise delege eder; ölü `_model_to_dict` ve 190 satırlık elle yazılmış import bloğu kaldırıldı

### 🧪 Test Altyapısı
- `tests/test_project_transfer.py` (12 test): gerçek boş-DB hedefine round-trip (kitap adı + notlar + hiyerarşi korunur), idempotent re-import, API anahtarı güvenliği, v4 legacy format, bozuk satır dayanıklılığı, servis seviyesi round-trip
- Toplam: 1069 → **1120 test** (51 yeni)

---

## v7.4.0 — Hiyerarşi Derinleştirme + Not Modalı + Yaratım Paneli Cilası (2026-08-24)

🌳 **Hiyerarşi & Etkileşim Derinleştirme Sürümü** — Location Tree artık tam drag-and-drop reparenting + breadcrumb + descendant sayıları + tip değiştirici + istatistiklerle. Not kartları tam markdown rendering + klavye navigasyonu + fullscreen okuma modu + tüm metadata görünümlü. Karakter/Dünya yaratım panelleri yapım aşaması göstergesi (progress bar) + yapışkan "unsaved changes" status pilli + inline ipuçları. 1057 test (1047 → 1057).

### 🌳 Location Tree — Gerçek Parent-Child Hiyerarşi
- **`get_hierarchy()` genişletildi**: artık her düğüm `depth`, `descendant_count`, `breadcrumb` (kök → bu düğüm yolu) döndürür
- **Tip parametresi**: `?type=location` / `?type=faction` / `?type=species` — herhangi bir tip için hiyerarşi ağacı
- **`list_possible_parents(entry_id=None, type_=...)`**: yeni servis metodu — yeni/düzenle formundaki parent-picker dropdown için aday parent listesi. Entry'nin kendisini + tüm descendant'larını (cycle önleme) otomatik hariç tutar
- **`reparent_entry(entry_id, new_parent_id)`**: yeni servis metodu — bir entry'yi yeni parent'a taşır. Validasyonlar:
  - Entry var mı
  - Yeni parent aynı tipte mi
  - Entry kendi parent'ı olamaz
  - Cycle önleme: yeni parent, entry'nin descendant'i olamaz (parent zincirini yukarı yürüyüp entry_id'ye rastlarsa reddeder)
  - Boş string → root'a taşı (parent_id = None)
- **Yeni endpoint**: `POST /world/<id>/reparent` (JSON: `{parent_id: "..." | ""}`)
- **Yeni endpoint**: `GET /world/api/parents?type=...&entry_id=...` — form için aday parent listesi (JSON)
- **Hierarchy şablonu yeniden yazıldı**:
  - Tip dropdown'u (Type picker) — her tip için ayrı ağaç
  - İstatistik rozetleri: 📊 total · 🌳 roots · 📐 depth
  - Her satırda `X descendants` rozeti
  - `+ Child` butonu (parent parametresiyle /world/new'e yönlendirir)
  - `⟲` butonu — entry'yi kök seviyeye taşır
  - **Drag-and-drop**: satırı sürükle, hedefin üzerine bırak → otomatik reparent. Sürükleme sırasında hedef vurgulanır (border + accent glow)
  - Drag-drop sonrası `confirmDialog` ile onay
- **`/world/new` şablonu — Parent Picker Dropdown**: `?parent=` parametresi yoksa artık interaktif bir dropdown gösterir; kullanıcı herhangi bir mevcut entry'yi parent olarak seçebilir. Tip değiştirdiğinde AJAX ile aday listesi yenilenir.
- **`/world/<id>/edit` şablonu — Parent Picker**: artık düzenle formunda da parent dropdown'u var; breadcrumb tooltip'leri, "selected" işareti, hierarchy ağacına link

### 📖 Note Cards — Modal Reading Experience
- **Server-rendered markdown**: not kartında `data-note-html` attribute'unda, sunucuda render edilmiş tam markdown HTML'i saklanır (JS regex yok, tüm markdown özellikleri desteklenir: headings, bold, italic, lists, code blocks, blockquotes, links)
- **Klavye navigasyonu**: ← / → tuşları ile önceki/sonraki nota geçiş. Pill buttonlarla da Prev/Next butonları.
- **Sayaç**: `1 / 12` biçiminde, tabular-nums ile hizalı
- **Fullscreen toggle**: `⛶` butonu veya `F` tuşu — modal genişler (95vw, 80vh), border-radius kalkar
- **Tüm metadata gösterilir**: tags (badge rozetleri), links (🔗 bağlamsal linkler), pinned/done rozetleri, renkli sol border (not rengiyle)
- **Pin/Done butonları modal içinde**: modalı kapatmadan pin/done toggle, sonra otomatik kapat
- **Edit shortcut**: modalda ✎ Edit butonu — modalı kapatıp edit modalını açar
- **Klavye yardımı**: altta `← → to navigate · f for fullscreen · Esc to close` ipucu
- **CSS iyileştirmeleri**: `asm-modal-in` keyframe tanımlandı (öncesi referans vardı ama tanım yoktu), `prose` içinde `p`, `code`, `blockquote`, `pre`, `a` stilleri; smooth max-width geçişi

### ✨ Creation Panels — Visual Refresh (functionality preserved)
- **`.form-progress-bar`**: formun üstünde yapışkan adım göstergesi — her `<details class="char-section">` için bir pill. Tamamlanan bölümler accent renkli + ✓ işaretli, tamamlanmamışlar gri. Tıklanınca o bölüme smooth scroll + flash highlight.
- **Progress yüzdesi**: sağda `0%` → `100%` tabular-nums sayaç. Arka planda `linear-gradient(90deg, accent-soft → transparent)` progress fill.
- **`.form-status-pill`**: ekranın sağ alt köşesinde yapışkan "Unsaved changes" pill. Sarı/warning renginde. Form submit edildiğinde "Saving…" → accent renk. `asm-pulse` animasyonu ile pulsing dot.
- **`.section-hint`**: her bölümün başlığının sağında italic ipucu (örn: "Who are they?", "What do they look like?"). `details[open]` olunca gizlenir (çünkü bölüm zaten açıksa ipucu gereksiz).
- **`.complete-check`**: bölüm summary'sinde ✓ rozeti — `data-section-fields` attribute'undaki tüm alanlar dolunca yeşil background'la gösterilir.
- **`form_progress.js`**: yeni modüler script. Otomatik olarak `form.char-builder` veya `form[data-form-progress]` bulur, bölümleri toplar, adımları oluşturur. `data-section-fields="name,role,..."` attribute'undan hangi alanların doldurulması gerektiğini okur. Formlara dahil etmek için tek satır: `<script src="/static/js/form_progress.js"></script>`.
- **Characters/new.html ve World/new.html** — her `<details>` elementine `data-section-key` ve `data-section-fields` eklendi, summary'lere `<span class="section-hint">` ve `<span class="complete-check">✓</span>` eklendi.

### 🛠️ Teknik
- **Yeni test dosyaları**: `tests/test_v74_hierarchy.py` (13 test), `tests/test_v74_routes.py` (10 test)
- **Güncellenmiş test**: `tests/test_v71_polish.py` → `test_new_route_without_parent_has_no_parent_field` artık v7.4 parent picker dropdown'unu yansıtıyor
- **Toplam test sayısı**: 1057 (1047 → 1057, +10 yeni)
- **Yeni dosyalar**:
  - `static/js/form_progress.js`
  - `tests/test_v74_hierarchy.py`
  - `tests/test_v74_routes.py`
- **Güncellenmiş dosyalar**:
  - `services/world_service.py` (+`list_possible_parents`, +`reparent_entry`, `get_hierarchy` genişletildi)
  - `routes/world.py` (+`/api/parents`, +`/<id>/reparent`, `hierarchy` ve `new`/`edit` rotaları genişletildi)
  - `templates/world/hierarchy.html` (tam yeniden yazım)
  - `templates/world/new.html` (parent picker dropdown)
  - `templates/world/edit.html` (parent picker dropdown)
  - `templates/characters/new.html` (section-key/fields + script include)
  - `templates/notes.html` (data-note-html, klavye navigasyonu, fullscreen)
  - `static/css/polish.css` (form-progress, status-pill, read-note modal genişletildi)

---

## 🗺️ v8.0 Roadmap — Yeni Özellik Fikirleri

Aşağıdaki fikirler v8.0+ sürümler için değerlendirme için listelenmiştir. Her biri somut bir ihtiyacı karşılar; uygulanabilirlik ve etki puanıyla (★/5) işaretlenmiştir.

### A. Yapısal Özellikler

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| A1 | **Manuscript Timeline Visualization** | Tüm bölümleri timeline üzerinde göster (chapter publication order × in-story time). Sentez axis:Publication vs Story Time. İçiçe flashback'ler görselleştirilir. | ★★★★★ |
| A2 | **Plot Thread Tracker** | Konu iplerini etiketle: her ipin ilk belirdiği bölüm, son çıktığı bölüm, "open/closed" durumu. Foreshadowing → payoff mapping. | ★★★★★ |
| A3 | **Multi-POV Chapter Splitter** | Bir bölümde birden fazla POV karakteri varsa, otomatik tespit edip her POV için ayrı draft oluştur ( scrub mode). | ★★★ |
| A4 | **Recurring Motif Tracker** | Tekrarlayan motifleri (su, ateş, belirli bir nesne, söz) işaretle; her bölümde kaç kez geçtiğini izle. | ★★★ |
| A5 | **Plot Template Wizard 2.0** | Save the Cat / Hero's Journey / Three-Act / Seven-Point'tan birini seç, chapter sayısı ver → otomatik chapter draft iskeleti oluştur. | ★★★★ |

### B. Yapay Zekâ Destekli

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| B1 | **Voice Consistency Checker** | Bir karakterin tüm diyaloglarını tara; AI her birinin "bu karaktere uygun mu" skorunu versin. Sapmalar vurgulansın. | ★★★★ |
| B2 | **Plot Hole Detector** | Manuscript'i tara; zaman çizgisi çelişkileri, kayıp karakter referansları, açılış kapanmaz öğeler. | ★★★★ |
| B3 | **Story Bible Auto-Generator** | Manuscript'ten otomatik bible çıkar: karakter listesi + ilişkileri + yerler + olay örgüsü + timeline. Yazara draft olarak verilir. | ★★★★★ |
| B4 | **Foreshadowing Suggestions** | AI, bölüm yazıldıkça "buraya şu ipin tohumunu ekleyebilirsin" önerisi verir (çıkış bir sonraki bölümde). | ★★★ |
| B5 | **Style Coach (Beta→Production)** | Manuscript'in bölümlerini genre benchmark'leriyle karşılaştır: pacing, sentence length variance, dialogue ratio, sensory verbs. | ★★★ |
| B6 | **Character Voice Sandbox** | Bir karakterin voice profile'unu kullanarak, verdiğin konuda örnek diyalog üret (AI). Düzenle, kaydet, sonra bölüme yapıştır. | ★★★★ |

### C. Yazma Deneyimi

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| C1 | **Voice Dictation Mode** | Web Speech API ile dikte; konuşulan yazıya dönür, otomatik noktalama. Eller serbest yazma. | ★★★★ |
| C2 | **Writer's Sprint / Pomodoro with Stats** | 25dk yaz + 5dk mola döngüsü. Sprint boyunca geri sayım, kelime hedefi. Haftalık sprint istatistikleri (toplam odak süresi, ortalama WPM). | ★★★ |
| C3 | **Reading Experience Simulator** | Manuscript'i "okuyucu gözünden" modunda aç: paragraflar tek tek, scroll değil tıklama ile. Okuma süresi ölçülür, geribildirim verirsin. | ★★★ |
| C4 | **Inline Research Sidepanel** | Yazarken sağda açılan araştırma paneli: bir Wikipedia/makale araması yap, notu kaydet, kopyala-yapıştır. Context switch yok. | ★★★ |
| C5 | **Multi-language Manuscript Export** | Bir bölümün farklı çevirilerini parallel tut; export ederken "orijinal + çeviri" sütunlu PDF. | ★★ |

### D. Dünya & Yer

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| D1 | **Geographic Calculator** | Map üzerinde iki nokta seç → aralarındaki tahmini seyahat süresi (yürüyüş/at/gemiyi seç, tepeyi hesaba kat). Story bible'da "X'ten Y'ye 3 gün" dediysen tutarlılık kontrolü. | ★★★★ |
| D2 | **Location Population Generator** | Bir şehir için: nüfus, demographics, major industries, districts, government type (rastgele tablo veya AI). One-click generate + edit. | ★★★ |
| D3 | **Cross-Reference Visualizer** | Bir karakter bir yerde geçtiyse, bir yer bir karakter tarafından ziyaret edildiyse — bunları otomatik bağla. vis-network grafik. | ★★★★ |
| D4 | **Calendar & Time System** | Hikâyenin kendi takvimini tanımla (13 ay, her ay 28 gün, vs). Bölümlere tarih damgası bas. Karakter yaşını doğru hesapla. | ★★★★ |

### E. Karakter & İlişki

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| E1 | **Character Relationship Timeline** | Karakter ilişkilerinin zaman içinde nasıl değiştiğini göster (chapter 1: düşman, chapter 5: müttefik). Her bölüm için bir ilişki "snapshot"ı. | ★★★★ |
| E2 | **Family Tree 2.0** | Mevcut family tree'yi genişlet: evlilikler, evlat edinmeler, ayrılıklar, ölümler. Yıllar geçtikçe değişen ağaç (toggle chapter). | ★★★ |
| E3 | **Character Arc Visualizer** | Karakter başına power/agency/wisdom 1-10 skorlarını her bölümde ver → SVG line chart. Düz çizgi = düz karakter, dalgalı = dinamik. | ★★★★ |
| E4 | **Character Voice Snippets Library** | Her karakter için "voice snippet" yaz (örnek diyaloglar). Daha sonra bölüme yapıştırırken voice'u hatırlatır. | ★★ |

### F. İş Akışı & İşbirliği

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| F1 | **Co-writing Mode** | İki yazar aynı manuscript'te çalışırsın: bölüm kilidi, yorum ipliği, sürüm farkı. Local-first (sync opsiyonel). | ★★★ |
| F2 | **Episodic Release Manager** | Serial fiction için: bölüm yayın programı, "next episode drops on" hatırlatması, yayın sonrası geribildirim tracker (Substack/Royal Road yorum çek). | ★★★★ |
| F3 | **Submission Tracker 2.0** | Gönderi: dergi/ajan/yrth. Statü: sent/rejected/accepted/revise. Yanıt süresi istatistiği. Otomatik hatırlatma: "X'ye gönderdiren 90 gün oldu, takip et". | ★★★★ |
| F4 | **Visual Storyboard** | Bölüm başına görsel/illüstrasyon ekle (upload). Corkboard görünümünde görsel kartlar. Mood board oluşturma. | ★★★ |
| F5 | **Version Snapshot Comparison** | Tüm manuscript'in haftalık snapshot'ı. "Geçen ay bu hafta nasıl gidiyordum" diff'i. | ★★★ |
| F6 | **Goal Calendar 2.0** | Mevcut hedef takvimine: sprint mode (ekim ayı boyunca günde 1000 kelime), heatmap (GitHub-style contribution graph), streak bonus. | ★★★ |

### G. Çıktı & Yayımlama

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| G1 | **Interactive EPUB 2.0** | Mevcut interaktif epub'a: branching (okur seçimleri farklı bölümlere gider), embedded character art, embedded map. | ★★★ |
| G2 | **Scrivener-style Compile 2.0** | Daha güçlü compile: bölüm başına farklı font, sahne arası süsler (***), ön/arka kapak otomatik, ISBN alanı, copyright sayfası. | ★★★★ |
| G3 | **Beta Reader Onboarding** | Beta okuyucu ekle → ona özel dashboard, okuma görevleri (her hafta 5 bölüm), okuma hızınızı takip et. Yorum/geribildirim toplama. | ★★★★ |
| G4 | **AI-assisted Cover Letter Generator** | Dergiye/ajana gönderi için cover letter taslağı üret. Manuscript meta (genre, word count, theme) çek. | ★★★ |

### H. Veri & Analitik

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| H1 | **Word Frequency Heatmap by Chapter** | Hangi bölümde hangi kelime çok geçiyor? Heatmap. "Su" kelimesi 7. bölümde 23 kez, 8. bölümde 3 kez — motif kırılması mı? | ★★★ |
| H2 | **Manuscript Health Dashboard** | Tüm manuscript sağlık metrikleri tek ekranda: pacing graph, word count growth curve, character screen time, dialogue:narration ratio, recurring locations. | ★★★★ |
| H3 | **Reading Speed Forecast** | Mevcut tempo (sprint istatistiklerinden) → manuscript ne kadar süre daha bitecek? "Günde 500 kelimeyle 12 Aralık'ta bitersin." Senaryo: +200 kelime → 5 Aralık. | ★★★★ |
| H4 | **Achievement System 2.0** | Yazma streak'leri, milestone'lar (10k/50k/100k words), genre completionist (one sci-fi + one fantasy + one mystery). Rozetler profil sayfasında. | ★★ |

### İ. Veri Girişi & OCR

| # | Özellik | Açıklama | Etki |
|---|---------|----------|------|
| İ1 | **Handwritten Notes OCR** | El yazısı fotoğrafı yükle → OCR ile note oluştur. Eski defterlerini dijitalleştir. | ★★ |
| İ2 | **Voice Memo Transcription** | Yolda ses kaydı al → otomatik transcript → note. Düşünceni yakala. | ★★★ |
| İ3 | **PDF Import Wizard** | Bir PDF yükle → bölümlere böl (yüksek başlık seviyesine göre). Kayıp el yazmasını kurtar. | ★★★ |

### Önerilen v8.0 Önceliği

**v8.0 — "Story Intelligence"** sürümü için önerilen ilk 5 öncelik:

1. **B3 — Story Bible Auto-Generator** ★★★★★ (yazara en büyük değer)
2. **A2 — Plot Thread Tracker + Foreshadowing Map** ★★★★★
3. **H2 — Manuscript Health Dashboard** ★★★★ (yazara "neredeyim" yanıtı)
4. **D1 — Geographic Calculator** ★★★★ (dünya tutarlılığı)
5. **B1 — Voice Consistency Checker** ★★★★ (en çok şikayet edilen sorun)

**v8.1** — C1 (Voice Dictation), F2 (Episodic Release manager), G3 (Beta Reader Onboarding)
**v8.2** — A5 (Plot Template Wizard 2.0), C2 (Pomodoro with Stats), E3 (Character Arc Visualizer)
**v8.3** — B2 (Plot Hole Detector), H3 (Reading Speed Forecast), D4 (Calendar & Time System)

---

## v7.3.0 — Derin Yazma Deneyimi (2026-08-24)

✍️ **Yazma Odaklı Sürüm** — Focus Mode 2.0 (daktilo + paragraf odağı + sentezlenmiş ortam sesleri), Corkboard Outline 2.0 (tüm el yazması tek panoda), Floating Quick Capture (Ctrl+Shift+N). 1047 test (1012 → 1047).

### 🎯 Focus Mode 2.0 — Dağıtıcıdan Arındırılmış Yazma
- **Daktilo modu** (Ctrl+Shift+T): imlecin bulunduğu satırı dikeyde ekranda ortalar — yazarken sayfa kaymaz
- **Paragraf odağı** (Ctrl+Shift+P): aktif paragraf vurgulu, diğer paragraflar soluk — tek paragrafa derin odak
- **Sentezlenmiş ortam sesleri**: yağmur / kafe / şömine / kütüphane — Web Audio API ile sentezlenir, hiç ses dosyası gerekmez, hacim kaydırıcısıyla
- **Günlük hedef halkası**: SVG dairesi, günün kelime sayısıyla dolan — hedefte yeşil, yoksa accent rengi, 30sn'de bir yenilenir
- **Milestone toastları**: 100 / 500 / 1000 / 2000 kelimede kutlama bildirimi
- **Quick chapter switcher**: üst barda dropdown, ← ile önceki bölüme
- **SVG ikonlar**: ▶ ⏹ ☰ emoji chrome kaldırıldı, sprite'tan i-play/i-square/i-headphones/i-type/i-circle-dot/i-cloud-rain/i-coffee/i-flame-2/i-library-2
- **Esc ile çıkış**, **Ctrl+Enter ile kaydet**
- **prefers-reduced-motion** desteği: tüm geçişler erişilebilirlik için devre dışı

### 📋 Corkboard Outline 2.0 — Tüm El Yazması Tek Pano
- **Yeni `/outline/` rotası**: tüm bölümleri tek kart panosu olarak gösterir (sahne kartlarından farklı)
- **Sürükle-bırak bölüm sıralama**: kartları sürükle, mevcut `/chapters/reorder` API'sini çağırır
- **Kart başına zengin bilgi**: bölüm numarası, başlık, sentez (3 satır kırpma), kelime sayısı, sahne sayısı, durum noktası, etiket rozetleri
- **Duruma göre renkli şerit**: draft → gri, revision → sarı, final → accent, published → yeşil
- **Filtre**: duruma ve etikete göre (etiket dropdown'u tüm etiketleri toplar)
- **Boş durum CTA**: "Your manuscript is empty" → Create First Chapter butonu
- **Sidebar'a eklendi**: Story bölümüne, Chapters'ın altına
- **i18n**: nav.outline anahtarı 5 dilde (en/tr/es/fr/de)

### ⚡ Floating Quick Capture — Her Yerden Hızlı Yakala
- **Global Ctrl+Shift+N** hotkey'i: uygulamada her yerden açılan yüzen besteci penceresi
- **Sağ altta FAB** (Floating Action Button): tıklayınca besteci açılır, açılınca gizlenir, pulse animasyonlu
- **4 tip**: Note / Chapter / Journal / Snippet — mevcut `/quick-capture/api/capture` endpoint'ini kullanır
- **Bağlamsal seçenekler**: Note/Chapter için kategori dropdown'u (Idea/Character/Plot/World/Dialogue/To-do/Research), Journal için mood dropdown'u (gerçek JOURNAL_MOODS ile hizalı: OK/Great/Good/Struggling/Blocked)
- **SVG ikonlar** (sprite'tan), **Esc ile kapat**, **Ctrl+Enter ile kaydet**
- **Body scroll lock**: besteci açıkken arka plan kilitli
- **Mobile tam ekran** (540px altında), **reduced-motion** desteği

### 🎨 Cila: scenes.html Emoji → SVG
- Scene Cards sayfasındaki 🎬 📍 🗑 ✎ UI chrome emoji kaldırıldı
- Sprite'tan i-clapperboard, i-map, i-pen, i-x, i-arrows ikonlarına geçildi

### 🛠️ Teknik
- Yeni blueprint: `routes/outline.py` (Corkboard Outline, `/outline/`)
- Yeni endpoint: `/focus/api/today` (günlük hedef halkası için words_today + daily_goal + percent + goal_met)
- Yeni script: `static/js/quick_capture.js` (besteci modülü, çift-başlatma korumalı)
- Yeni template: `templates/outline.html`
- Yeni ikonlar sprite'ta: i-headphones, i-coffee, i-volume, i-type, i-circle-dot, i-gauge, i-pause, i-play, i-square, i-cloud-rain, i-flame-2, i-library-2 (12 yeni)
- polish.css'e 3 yeni blok: `.focus-*`, `.outline-*`, `.qc-*` (+487 satır)
- 35 yeni test: `test_v73_focus.py` (9) + `test_v73_outline.py` (12) + `test_v73_quick_capture.py` (14)

---

## v7.2.0 — Dünya Oluşturucu + AI Otomatik Doldurma (2026-08-24)

🌍 **Yapımcı Sürümü** — Dünya oluşturma paneli yeniden tasarlandı, editörde AI otomatik doldurma. 1012 test (1000 → 1012).

### 🌍 Dünya Oluşturma Paneli — Yeniden Tasarım
- **Karakter paneliyle aynı desen**: iki sütun (sol = bölüm bazlı form, sağ = sabit canlı önizleme kartı)
- **3 bölüm**: Identity (tür/isim/kategori/açıklama) · Full content (uzun notlar + tip-bazlı metadata) · Private notes
- **7 hızlı şablon**: Kingdom / City / Dungeon / Region / Faction / Lore / Blank — her biri tür + kategori + açıklama + içerik başlıkları doldurur (## History, ## Government, ## Culture...)
- **Canlı önizleme**: tür ikonu (🌐/📜/⚔/📖), isim, tür rozeti, parent zinciri (nested ise), kategori + açıklama meta satırı, durum ipucu
- v7.1'den gelen parent_id desteği korundu (nested lokasyonlar hâlâ "Child of" kartıyla çalışır)

### ✨ Editörde AI Otomatik Doldurma
- **Synopsis alanında `✦ AI` butonu**: bölüm içeriğinden 1-2 cümlelik özet üretir, alanı doldurur, autosave tetikler
- **Tags alanında `✦ Suggest tags` butonu**: bölüm içeriğinden 3-5 etiket önerir, mevcut etiketlerle birleştirir
- Yalnızca AI etkinken görünür (AI kapalıysa butonlar gizli)
- Mevcut `/ai/summarize` ve `/ai/suggest-tags` endpoint'lerini kullanır — yeni backend gerekmez
- Buton state: çalışırken `⟳ Working…`, bitince `✦ AI` / `✦ Suggest tags` geri döner

### 🐛 Düzeltme (canlı testte yakalandı)
- **JS SyntaxError**: `{{ ic('sparkles') }}` macro'su SVG render edince içindeki `"` karakterleri JS string'ini bozuyordu → tüm script bloğu parse edilemiyordu → AI butonları çalışmıyordu. Buton içeriği artık sade `✦` text'iyle ayarlanıyor (SVG yok)
- **DOMContentLoaded çoktan tetiklenmiş**: script sayfanın sonunda çalıştığı için `DOMContentLoaded` dinleyicisi asla tetiklenmiyordu → IIFE ile direkt atama yapıldı

### Test
- 12 yeni test (`test_v72_builders.py`): dünya oluşturucu (iki sütun + canlı önizleme + 7 şablon + tüm alanlar korundu + parent_id + oluşturma), editör AI butonları (varlık/gizleme + endpoint çağrıları + mock ile synopsis/tags doldurma)
- Canlı doğrulama: kingdom şablonu → tür+kategori+içerik başlıkları otomatik doldu; canlı önizleme "Aurelia Krallığı" ismini anında gösterdi; AI synopsis → "Kapı çalındı ve Elara ürperdi." doldu; AI tags doldu; SyntaxError düzeltmesi sonrası typeof=function
- Tam paket **1012/1012** (806 + 206 routes)

---

## v7.1.0 — Detay Cilası (2026-08-23)

✨ **Kullanıcı Geri Bildirimi Sürümü** — Notlar artık önünüzde açılıyor, alt lokasyonlar derinlemesine oluşturulabiliyor, karakter oluşturma paneli yeniden tasarlandı. 1000 test (987 → 1000).

### 🗒️ Notlar — Okuma Modalı (kullanıcı isteği)
- **Tıklanınca inline uzamak yerine** temiz bir **okuma modalı** açılır: tam markdown render, kaydırılabilir gövde, başlık + kategori + tarih başlığında, **Esc / dış / Close** ile kapanır, **Edit** butonu doğrudan düzenleme modalına geçer
- Inline `maxHeight` hack'i kaldırıldı; kart gövdesi hâlâ kısa önizleme verir ama tıklama artık kartı uzatmak yerine önünüze gelir

### 🌳 Alt Lokasyon Oluşturma (kullanıcı isteği)
- Backend zaten `parent_id` destekliyordu ama **UI hiç bağlanmamıştı** — şimdi tamamlandı:
  - `world.new?parent=<id>` — parent lookup + "Child of" kartı + gizli `parent_id` alanı; type otomatik `location` seçili
  - **Location Tree'de her lokasyonda `+ Child` butonu** — tıklayınca child oluşturma formuna gider
  - **World detail sayfasında `+ Child Location` butonu** — herhangi bir lokasyondan alt lokasyon ekleyebilirsiniz (ör. A Gezegeni → B Şehri → Liman Bölgesi → Tuzlu Han)
  - Alt lokasyonlar hiyerarşide otomatik iç içe görünür

### 🧑 Yeni Karakter Oluşturma Paneli — Yeniden Tasarım
- **İki sütunlu layout**: sol = kaydırılabilir bölüm bazlı form; sağ = **sabit (sticky) canlı önizleme kartı** (avatar + isim + rol rozeti + meta + ipucu) — yazdıkça güncellenir
- **6 bölüm** (details/accordion): Identity · Appearance · Psychology · Background · Voice & Quirks · Private notes — açık/kapalı, ilk üçü varsayılan açık
- **Hızlı şablonlar**: 6 buton — Protagonist · Antagonist · Mentor · Loyal Ally · Mysterious Stranger · Blank; her biri role/renk/psikoloji/arkaplan doldurur (backend'e dokunmadan, sadece kolaylık)
- Canlı önizleme: isim → avatar harfi, renk → avatar arka planı, role → renk-kodlu rozet (protagonist yeşil, antagonist kırmızı, minor gri), age/gender → meta satırı
- Tüm orijinal alanlar korundu (backend uyumlu)

### Test
- 13 yeni test (`test_v71_polish.py`): not okuma modalı handler, karakter oluşturucu (iki sütun + canlı önizleme + şablonlar + tüm orijinal alanlar + oluşturma hâlâ çalışıyor), nested lokasyonlar (parent param + child oluşturma + hierarchy Child butonu + detail Child butonu + non-location gizleme + 3 seviyeli zincir)
- Canlı doğrulama: antagonist şablonu → canlı önizleme anında kırmızı oldu; "+ Child" → nested oluşturma formu (Child of kartı + parent_id); VLM görsel onayı (karakter oluşturucu "modern, cilalı")
- Tam paket **1000/1000** (794 + 206 routes) — ilk 4 haneli test sayısı

---

## v7.0.0 — Çoklu Kitap Çalışma Alanı (2026-08-23)

📚 **MAJOR SÜRÜM** — Gerçek çoklu kitap deneyimi: topbar'da kitap seçici, tek doğruluk kaynağı, Yazar Evi, onboarding. 987 test (964 → 987).

### 🎛️ Aktif Kitap Sistemi — Mimari
- **Topbar'da kitap seçici**: her sayfadan erişilebilen dropdown — tüm kitaplar (renk noktası + tür + kelime sayısıyla), aktif olan vurgulu; "New Book…" ve "Manage Books" eylemleri; dar ekranda ikon-only moda geçer
- **`story_title` artık tek doğruluk kaynağına bağlı**: aktif projenin adı. Export/Compile/Story Bible dahil her yerde tutarlı kitap adı (context processor aktif projeden okur; eski DB'ler için geriye dönük fallback)
- **Kitap geçişi anında yansır**: switch endpoint'i kitap adını döner, toast gösterir, dashboard'a yönlendirir

### 📚 Kitaplar Sayfası 2.0 (Books & Series Hub)
- **Yeni Project modeli meta verisi**: `genre` (tür), `target_words` (kitap hedefi), `deadline` (son tarih), `color` (renk) — mevcut DB'lere otomatik migration (ALTER TABLE)
- **Kitap kartları**: renkli sol şerit, tür rozeti, ACTIVE etiketi, Chapters/Words/Cast istatistik kutuları
- **Hedef ilerleme çubuğu**: target_words doluysa animasyonlu % çubuğu + "X / Y words"
- **Deadline geri sayımı**: "N days left" / "N days over" rozeti (14+ gün yeşil, yaklaştıkça sarı)
- **Zengin kitap formları**: yeni kitap + düzenleme modalları — ad, alt başlık, tür, hedef kelime, son tarih, 8 renk paleti; geçersiz tarih/hedef değerler güvenlice yok sayılır

### 🏠 Dashboard 2.0 — "Writer's Home"
- **Kitap kahramanı (hero)**: kitap adı + alt başlık + tür rozeti + deadline rozeti + 🔥 N-gün seri (streak) rozeti + Chapters/Words/Cast/World istatistikleri + kitap hedefi ilerleme çubuğu — hepsi aktif kitabın rengiyle
- **Günlük hedef ringi**: dairesel SVG gösterge (words_today / daily_word_goal) — hedefe ulaşınca yeşile döner ve "🎉 Daily goal reached!" gösterir
- Başlık "Story Cockpit" → "Writer's Home"

### 👋 Onboarding Sihirbazı
- İlk açılışta (bölüm yok + onboarded=false) karşılama modal'ı: kitap başlığı, günlük hedef (250/500/1000/1667 kelimelik hazır seçenekler), tür
- "Start Writing" → default kitabı adlandırır + hedefi kaydeder + bayrağı işaretler; "Skip" → sadece bayrak
- Bir kez gösterilir — bir bölüm yazıldıktan veya tamamlandıktan sonra bir daha görünmez

### Test
- 23 yeni test (`test_v70_multibook.py`): model kolonları, meta veriyle CRUD, geçersiz değerlerin yok sayımı, switcher render, story_title tek kaynak (aktif takip + geri dönüş), kitaplar sayfası (meta + ilerleme + deadline), hero (kitap + ring + streak gizleme + hedef çubuğu), kitaplar arası veri izolasyonu, onboarding (gösterim/gizleme/bayrak)
- Canlı doğrulama: onboarding akışı (form doldurma → kitap adı anında uygulandı), yeni kitap oluşturma + otomatik geçiş ("Yıldız Kaşifleri" aktif oldu), dropdown'dan geri geçiş, 3 kitaplı menü, VLM görsel onayı (dashboard + books sayfası)
- Bayat test güncellendi: dashboard başlığı "Story Cockpit" → "Writer's Home"

---

## v6.4.0 — Hikaye Doktoru: Tek Tıkla Sağlık Raporu (2026-08-23)

🩺 **Analiz Sürümü** — Dağınık analiz araçları tek bir sağlık panelinde birleşti, 964 test (946 → 964).

### 🩺 Story Doctor (`/story-doctor/`) — `services/story_doctor_service.py`
- **Tek tıkla tam muayene**: Style Lint (7 kontrol) + Kelime Sıklığı (aşırı kullanım + tekrar) + Sözlük tutarlılığı + Zaman çizelgesi denetimi + Tempo analizi + Yapı istatistikleri — hepsi tek sayfada
- **0-100 sağlık skoru**: ağırlıklı ceza sistemi (stil hatası > aşırı kelime > zaman çatışması > ...), kategori bazlı tavan limitleri (tek gürültülü kontrol tüm skoru domine edemez), A–E harf notu + renk kodu
- **Dairesel skor göstergesi**: animasyonlu SVG yay (stroke-dashoffset), not rengine göre kart kenarlığı (yeşil/sarı/kırmızı)
- **"Top score costs" çubukları**: puanı en çok yiyen sorunlar, animasyonlu barlarla
- **Reçeteler (Prescriptions)**: öncelik sıralı, uygulanabilir öneriler — her biri ilgili araca tek tık bağlantı (lint, word-freq, glossary scan, timeline-check...)
- **6 analiz kartı**: Style Lint (ilk bulgular + özet rozetleri), Repetition (aşırı kelimeler ×sayı rozetleri, tekrar eden ifadeler, leksikal çeşitlilik), Glossary (ihlal/near-miss), Timeline (çatışmalar), Pacing (gerilim/ritim/range), AI Deep Check (opsiyonel — mevcut /ai/consistency-check'e bağlanır, yalnızca AI etkinken görünür)
- **Boş durum**: bölüm yoksa dostça yönlendirme
- Tamamen yerel analiz — AI gerekmez (AI Deep Check hariç)
- Sidebar: Tools bölümünün başında yeni "Story Doctor" bağlantısı (kalp-nabız SVG ikonu) + 5 dilde çeviri

### 🔧 Araçlar
- Mock AI sunucusu (`scripts/mock_ai_server.py`) streaming + streaming-dışı istekleri ayırt eder (consistency check artık test edilebilir)

### Test
- 18 yeni test (`test_v64_story_doctor.py`): rapor şekli, tüm analizörler, skor sınırları, harf notu eşlemesi, sorunlu el yazması tespiti (özet eksik + kısa bölüm + tekrar), ceza tavanları, öneri sıralaması + URL doğrulaması, boş el yazması, sayfa render (dolu/boş), API, sidebar bağlantısı, ikon sprite'ı, CSS katmanı, i18n anahtarı
- Canlı doğrulama: skor 94/A hesaplandı, öneriler + maliyet çubukları görüntülendi, AI Deep Check (mock ile fallback yolu dahil), VLM görsel onayı ("tamamen işlevsel ve profesyonel")

---

## v6.3.0 — Editörde AI: Yazdığınız Yerde (2026-08-23)

✨ **Editör Entegrasyonu Sürümü** — AI artık bölüm editörünün içinde, 946 test (935 → 946).

### 🤖 Editör İçi AI Asistan Çekmecesi
- **Sağ taraftan kayan çekmece** (`/chapters/<id>/edit`): AI'yı yazdığınız yere getirdik — ayrı sayfaya gitmek yok. **Alt+A** ile açılır/kapanır, sağ alttaki bot butonuyla da
- **4 eylem**: Continue (imleç öncesi metinden devam — imleç baştaysa belge sonundan), Expand / Shorter / Dialogue (seçim varsa seçim üzerinde, yoksa tüm metin üzerinde)
- **Canlı streaming**: öneriler token token akar (v6.2 altyapısı); ■ Stop ile ortada kesilebilir, kısmi metin korunur
- **İmlece Ekle / Seçimi Değiştir / Kopyala**: öneriyi tek tıkla editöre taşıyın — CodeMirror API'siyle imleç konumuna eklenir, otomatik kayıt (autosave) tetiklenir
- **Bağlam toggle'ları** (karakter/ilişki/dünya/sözlük/olay örgüsü): hangi bölümdeyseniz AI o bölümün bağlamını otomatik bilir (chapter_id ile Context Engine)
- Odak (composition) modunda gizlenir; mobilde tam genişlik sayfa

### 🐛 Düzeltmeler
- **Fixed-konum bozulması (kritik)**: `.content`'in sayfa giriş animasyonu (`fill-mode: both`) bittikten sonra bile kimlik matrisi transform'u taşıyordu — bu, `position: fixed` torunları (yeni AI çekmecesi) görünüme değil içeriğe bağlıyordu; sayfa kaydırılınca çekmece ekrandan çıkıyordu. `both` → `backwards` ile düzeltildi (animasyon bitince transform tamamen temizlenir)
- Continue eylemi imleç belge başındayken (autofocus) boş metin gönderiyordu → belge sonu kuyruğuna fallback eklendi

### Test
- 11 yeni test (`test_v63_editor_ai.py`): çekmece render (AI açık/kapalı), 4 eylem + 5 bağlam toggle'ı, chapter_id kablolaması, footer aksiyonları, Alt+A kısayolu, CodeMirror insert + markDirty, composition-mode gizleme, diğer sayfalara sızmama, CSS katmanı
- Canlı doğrulama: mock AI ile tarayıcıda — çekmece açma, streaming, imlece ekleme (autosave "Saved · 19 words"), Alt+A aç/kapa, kaydırılmış sayfada sabit konum, VLM görsel onayı

---

## v6.2.0 — Writer's Flow: Canlı AI Akışı (2026-08-23)

🌊 **Yazma Akışı Sürümü** — AI önerileri artık token token canlı akıyor, 935 test (923 → 935).

### 🌊 Canlı Streaming (SSE)
- **`asmStream()` yardımcısı** (`app.js`): SSE okuyucu + `AbortController` ile Durdur desteği; `onStart/onContext/onChunk/onDone/onAbort/onError` olay zinciri; JSON-kodlu olaylar (yeni satırlar ağ üzerinden bozulmaz)
- **Copilot canlı akış** (`/ai-copilot/api/suggest-stream`): bağlam-farkındalıklı streaming — ilk olay bağlam istatistikleri, ardından token'lar, yanıp sönen imleç (caret) animasyonuyla; canlı kelime sayacı; **■ Stop butonu** akış sırasında görünür, kısmi metin korunur ve "(stopped)" olarak geçmişe kaydedilir
- **Character Chat canlı akış** (`/character-chat/api/chat-stream`): karakter yanıtları balonda token token akar; "typing…" bekleme ekranı kaldırıldı — yazı gözünün önünde oluşur
- **JSON olay protokolü**: `{"type": "context|chunk|done|error"}` — v6.1'deki `chunk.replace("\n", " ")` hatası giderildi (**paragraf yapısı artık korunur**); eski `/ai/continue-stream` de aynı protokole geçirildi
- Düşünme blokları (`<think>...`) streaming sırasında da stateful filtreyle ayıklanır — kullanıcı asla modelin iç sesini görmez

### 🐛 Düzeltmeler
- **Stop butonu çalışmıyordu** (canlı testte yakalandı): `_activeStream` ataması `await` sonrasına yapıldığı için akış sırasında Stop hiçbir isteği kesemiyordu → `onStart(handle)` olayı eklendi; handle fetch başlamadan bağlanır
- `/ai/continue-stream` yeni satır bozma hatası düzeltildi (satırlar boşluğa çevriliyordu — paragraflar birleşiyordu)

### ✍️ Editör Cilası
- **Kitap benzeri yazma yüzeyi**: CodeMirror artık Noto Serif, 1.75 satır yüksekliği; aktif satır yumuşak vurgusu (göz takibi)
- **Sprint bar**: hap (pill) tasarım, monospace sayaç, SVG uyumlu
- **Odak modu kontrolleri**: tek sıra hap düzeni
- Streaming caret animasyonu (`prefers-reduced-motion` ile otomatik kapatılır)

### Test
- 12 yeni test (`test_v62_streaming.py`): SSE olay dizisi (context→chunks→done), yeni satır korunumu regresyonu, hata olayı, chat streaming, JSON fallback endpoint'leri, onStart kablolama kontrolü
- Canlı doğrulama: mock OpenAI SSE sunucusu (11434) ile tarayıcıda gerçek akış testi — ortada durdurma, kısmi metin korunumu, paragraf yapısı, VLM görsel kontrolü

---

## v6.1.0 — Cilalı Arayüz: Profesyonel Tasarım Katmanı (2026-08-23)

🎨 **UI/UX Sürümü** — SVG ikon sistemi, katlanabilir sidebar, hareket dili, 923 test (911 → 923).

### 🎯 İkon Sistemi — Emoji'lere Veda
- **63 adet Lucide-tarzı çizgi SVG ikon** (`templates/components/icons.html`): tek gizli sprite, her yerden `<use>` ile referans — sıfır dış bağımlılık, sıfır ek HTTP isteği
- Sidebar'daki tüm emojiler (⬢ 📖 ⌕ ♛ 🕸...) profesyonel stroke ikonlara değiştirildi
- Topbar: menü/panel/arama ikonları; FAB yakalama butonu: SVG artı; tema düğmesi: güneş/ay (aktif temaya göre)
- Toast bildirimleri: türe göre renkli SVG ikonlar (başarı/tehlike/uyarı/bilgi)
- Komut paleti: sidebar'daki aynı SVG ikonları yeniden kullanılır + hızlı eylemler sprite'tan beslenir

### 📑 Sidebar Yenileme
- **Katlanabilir akordeon bölümler**: 9 bölüm başlığı tıklanabilir chevron; yumuşak grid-rows animasyonu; durum `localStorage`'da kalıcı; aktif sayfanın bölümü her zaman açık
- Aktif gösterge çubuğu artık gradyan; hover'da mikro kayma efekti
- "Today" kelime hedefi widget'ı: kart görünümü + gradyan ilerleme çubuğu
- Icon-only (daraltılmış) mod: ikonlar ortalanır ve büyütülür

### 🎨 polish.css — Tasarım Cilası Katmanı
- **Evrensel katman** (her iki UI modunda): ikon sistemi, akordeon, sayfa fade-in, toast slide-in/out, modal scale-in, odak halkaları, `::selection`, ince scrollbar'lar, `kbd` stili
- **V2 bileşen cilası**: butonlarda hiyerarşi + dokunsal basma efekti, gradient primary buton, yumuşak odak parlaması (inputlar + arama hapı), renk-kodlu badge'ler, halkalı avatar'lar, noktalı çerçeveli boş durumlar, tablo satır hover'ları, daha güçlü sayfa başlığı tipografisi
- **Erişilebilirlik**: `prefers-reduced-motion` — hareket duyarlılığı olan kullanıcılar için tüm animasyonlar kapatılır; `:focus-visible` odak halkaları; aria-label'lar

### 🚀 Modern UI Artık Varsayılan
- `ui_version` varsayılanı `legacy` → `v2`: rafine tipografi + cilalı bileşenler kutudan çıktığı gibi aktif
- Ayarlar: "Modern (v6.1 — default)" / "Legacy (classic look)" — tek tıkla geri dönüş mümkün

### 🌐 i18n Düzeltmeleri
- **Akordeon yapısını koruyan çeviri**: i18n betiği artık bölüm etiketinin `<span>`ine yazar (eskiden span'i silip düz metin yazıyordu — chevron/flex yapısını bozuyordu)
- 3 çevrilmemiş bölüm etiketi tamamlandı: Tools→Araçlar, Analytics→Analitik, Export & Publish→Dışa Aktar & Yayınla (5 dilde)

### 🐛 Düzeltmeler
- Komut paleti bölüm tespiti yeni `.nav-group` yapısıyla uyumlu hale getirildi (linkler artık grupta; `closest()` ile yukarı tırmanır)
- Toast ikonları sprite'tan SVG kullanır (yedek metin glifi korunur)
- Footer sürüm etiketi v6.1; bayat sürüm testi güncellendi

### Test
- 12 yeni test (`test_v61_ui.py`): sprite render, emoji kaldırma, polish.css, akordeon markup, günün widget'ı, sürüm dizesi, varsayılan UI, legacy seçeneği, i18n anahtarları (5 dil)
- Tam paket: **923/923 geçti**

---

## v6.0.0 — Story Context Engine: AI Artık Hikayenizi Tanıyor (2026-08-23)

🎉 **Major Release** — RAG tabanlı hikaye bağlamı, akıl yürütme modeli düzeltmeleri, komut paleti. 911 test (872 → 911).

### 🧠 Yeni: Story Context Engine (RAG) — `services/context_engine.py`
- **AI artık hikayenizi biliyor**: Her AI çağrısında, yazdığınız metindeki karakterler, dünyalar, sözlük terimleri ve önceki bölüm olayları otomatik tespit edilip AI'ya bağlam olarak gönderilir
- **Türkçe-farkındalıklı eşleştirme**: İ/i/I/ı noktalı-noktasız harf normalizasyonu ile isim tespiti (İpek ↔ ipek eşleşir, Elarax ↔ Elara eşleşmez — kelime sınırı korunur)
- **Karakter tespiti**: İsim + takma ad (alias) eşleştirme; bölüme bağlı karakterler + POV karakteri otomatik dahil
- **İlişki haritası**: Tespit edilen karakterler arasındaki ilişkiler (yönlü/çift yönlü) AI'ya iletilir
- **Dünya girdileri**: Metinde geçen lokasyon/lore/fraksiyonlar + bölümün lokasyonu eşleştirilir
- **Sözlük terimleri**: Terim + alternatif yazımlar eşleştirilir, "use these exact spellings" olarak iletilir
- **Olay örgüsü hafızası**: Önceki bölümlerin özetleri (sentetik kuyruk fallback'i ile); AI "daha önce ne oldu" bilir
- **Bütçe yönetimi**: ~7000 karakter bağlam bütçesi, öncelik sıralı bölüm limitleri (karakter > dünya > olay örgüsü)
- **Şeffaflık**: `context.stats()` ile UI, AI'ya tam olarak ne gönderildiğini gösterir
- **Sağlayıcı-bağımsız**: Tamamen yerel SQLite — embedding yok, her sağlayıcıyla (Ollama, OpenRouter, Groq...) çalışır

### 🔧 AI Servis Katmanı v2
- **Thinking temizleme v2**: `<reasoning>/<thought>/<analysis>/<scratchpad>/<internal>` blokları, `<antThinking>` (Anthropic), ```think fence'i, düz metin `Thinking:`/`Reasoning:` başlıkları, "Okay, let me think..." girişleri — hepsi temizlenir
- **`complete_json()`**: Sağlam JSON kurtarma hattı — kod çitleri, öncesinde/sonrasında düz yazı, çoklu blok, dengesiz parantezler, trailing comma, Python True/None → true/null onarımı
- **`_valid_name_line()`**: İsim doğrulayıcı — cümle, noktalama, numaralandırma, aşırı uzun satırlar reddedilir
- **Model yönlendirme**: Yeni `ai.model_fast` ayarı — isim üretimi/etiket gibi hafif görevler hızlı modele yönlendirilir (akıl yürütme modeli sorunlarına çözüm)
- **Kritik düzeltme**: "Sadece etiketleri kaldır" fallback'i kaldırıldı — düşünme metni artık asla UI'a sızmaz; net hata mesajı verilir
- **Name generator düzeltmesi**: `max_tokens` 30 → 400 (akıl yürütme modelleri bütçeyi düşünmede harcıyordu), prompt katı kurallar içerir, çöp yanıtlar asla cache'lenmez, `<5 geçerli isim = cache yok`

### 🤖 Bağlam-farkındalıklı AI Özellikleri
- **AI Editor Copilot** (`/ai-copilot/`): Bağlam toggle'ları (karakterler/ilişkiler/dünya/sözlük/olay örgüsü), "Preview what the AI sees" şeffaflık paneli, sonuç sonrası bağlam istatistik rozeti
- **Character AI Chat** (`/character-chat/`): Karakter artık ilişkilerini, dünyasını ve hikayedeki son olayları bilir; bölüm çapası ile "hangi andaki karakter" seçilebilir; "🧠 knows:" durum çubuğu
- **AI Assistant** (`/ai/continue-context`): Elle yazılmış bağlam kodu Context Engine ile değiştirildi; bağlam istatistikleri döner
- **Character Generator**: Yapılandırılmış JSON çıktısı (complete_json hattı ile), mevcut kadroyu bilir (isim tekrarı yok), dünya tonuna uyar; AI başarısız olursa zarifce rastgele fallback

### 🎨 UI/UX
- **Komut Paleti (Ctrl+K / ⌘+K)**: Tüm sayfalara + hızlı eylemlere (yeni bölüm, yeni karakter, tema değiştir...) bulanık arama ile erişim; sidebar DOM'unu okur → navigasyonla otomatik senkron; ↑↓ Enter Esc klavye desteği
- **Settings → AI**: 7 sağlayıcı ön ayarı (Ollama, OpenRouter, Groq, OpenAI, Z.ai, LM Studio, llama.cpp) tek tıkla URL doldurma; "Fast model" alanı; akıl yürütme modeli ipucu
- Kısayol hile sayfasına Ctrl+K eklendi

### 🐛 Düzeltmeler (gelen v5.1'deki gerçek bug'lar)
- **Bölüm kaydetme 500 hatası**: `update_chapter()` içinde if-bloğunda lokal `from datetime import datetime` importu tüm fonksiyonda `datetime`'ı lokal değişken yapıyordu → durum değişikliği olmadan kayıtta `UnboundLocalError`. 13 testi düzeltti (find_replace, undo, versioning, chapter lifecycle)
- **Yedekleme yanlış dosyayı alıyordu**: `create_backup()` statik `Config.DB_PATH` kullanıyordu; `ASM_DB_URI` ile DB taşındıysa yedek boş/wrong dosya içeriyordu. Artık canlı SQLAlchemy engine'den gerçek yol çözümlenir (`_resolve_db_path()`); restore da tutarlı hale getirildi
- **Bayat testler**: plot template sayısı 6 → 11, sidebar etiketi "Manuscript Forecast" → "Forecast" güncellendi

### 🏗️ Mimari
- **Blueprint otomatik keşif**: `app.py` içinde 60+ blueprint'in 3 kez tekrarlanan elle listesi (import + CSRF exempt + register ≈ 180 satır) `pkgutil.iter_modules()` tabanlı otomatik kayıtla değiştirildi — yeni özellik eklemek için app.py'ye dokunmaya gerek yok; import hatası artık tek modülü atlar, uygulamayı çökertmez
- 327 rota, 52 servis (+context_engine), 61 modül

### Test
- 39 yeni test (872 → 911): `test_context_engine.py` (10 — tespit, Türkçe isimler, bütçe, render, toggle'lar), `test_v60.py` (29 — thinking v2 desenleri, JSON kurtarma, isim üretimi, model yönlendirme, bağlam-farkındalıklı rotalar mock'lu, ayarlar, varlıklar)
- Gelen 17 başarısız testin tamamı düzeltildi

---

## v5.1.0 — New Tools & Bug Fixes (2026-07-21)

### Yeni Özellikler
- **Focus Mode Pro** (`/focus/`): Tam ekran yazma + Pomodoro timer + auto-save + özelleştirilebilir background/font/width
- **AI Editor Copilot** (`/ai-copilot/`): AI ile devam etme, genişletme, kısaltma, diyalog üretme. AI disabled iken gizlenir
- **Character AI Chat** (`/character-chat/`): Karakterinizle ses profilini kullanarak sohbet. AI disabled iken gizlenir
- **Character Generator** (`/character-generator/`): Rastgele karakter üretimi (fantasy/modern/scifi). AI opsiyonel (checkbox AI disabled iken disabled)
- **Family Tree Builder** (`/family-tree/`): vis-network ile aile ağacı. Parent/married relations
- **Web Serial Platform** (`/serial/`): Bölümleri seri olarak okuma. Temiz reader view, prev/next nav
- **Interactive EPUB** (`/interactive-epub/`): EPUB 3 export, gömülü karakter kartları, navigable TOC
- **Nested Sub-Maps**: Hiyerarşik haritalar (Galaksi → Güneş Sistemi → Dünya → Şehir). Breadcrumb navigation, per-level map images
- **i18n Çoklu Dil**: 5 dil (EN/TR/ES/FR/DE). Client-side JS ile sidebar çevirisi. Settings'den dil seçimi
- **World Map Pin Colors**: Pin koyarken 8 renk seçeneği
- **11 Plot Structure Templates**: Hero's Journey, Save the Cat, Three-Act, Seven-Point, Freytag, Kishōtenketsu + 5 yeni (Fichtean Curve, Heroine's Journey, Tragedy, Voyage & Return, Comedy)

### Düzeltmeler
- **Character Arc / Relationship Timeline 500 hatası**: Character nesneleri JSON serializable değildi — plain dict'e çevrildi
- **Word Frequency 500 hatası**: Jinja2'de `max()` fonksiyonu kullanılmış — Jinja2 filter ile değiştirildi
- **Session Timer 180dk başlama**: UTC timezone parsing hatası — ISO string'e `Z` eklenerek düzeltildi
- **Session Timer pause/resume**: Pause sırasında geçen süre de sayılıyordu — `started_at` resume'da sıfırlanıyor, `elapsed_seconds` accumulate ediliyor
- **Dashboard grafik**: Line chart → Bar chart, `max-height: 200px`, `max: Math.ceil(maxValue * 1.2)` ile sabit sınırlar
- **Scene Cards etkileşim**: `onclick` attribute JSON bozuyordu — `data-action` + `addEventListener` ile güvenli handling
- **Music Player seek**: Tıklanınca başa sarıyordu — `getBoundingClientRect` ile düzeltildi
- **Prompt Calendar tıklama**: `onclick` attribute JSON bozuyordu — `data-day` + `addEventListener` ile düzeltildi
- **Sidebar scroll**: CSS'de `overflow-y: auto` yoktu — eklendi, `sessionStorage` ile scroll position hatırlama
- **Spell Check dil seçeneği**: "Disabled — I write in another language" seçeneği eklendi
- **Theme Editor**: Preset değişince CSS üretilmiyordu — default config karşılaştırma düzeltildi
- **Sub-world map pin**: Alt haritada location yoksa "Create New Location" butonu eklendi
- **Port 3000**: Caddy reverse proxy 3000 bekliyordu, Flask 5555'te çalışıyordu — düzeltildi
- **Static file cache**: `SEND_FILE_MAX_AGE_DEFAULT = 0` ile cache devre dışı
- **Map inline JS**: `world_map.js` ayrı dosyada Jinja syntax içeriyordu — template içine inline taşındı
- **Graph group-char**: Group node ID'leri `g-` prefix ile — backend FK constraint kaldırıldı
- **Graph popup**: Draggable + smart positioning + Escape ile kapatma

### GitHub Hazırlık
- `.gitignore` eklendi (Python, venv, DB, backups, media, IDE, OS)
- `README.md` tamamen yeniden yazıldı (özellikler, quick start, tech stack, project structure)
- `CHANGELOG.md` güncellendi

---

## v5.0.0 — Analysis, Moods & Music (2026-07-15)

🎉 **v5.0 Milestone Release** — 51 blueprint, 872 test, 95+ HTML template

### Yeni Modüller
- **Word Frequency Analyzer** (`/word-freq/`): Kelime tekrar analizi. Top N words (stopwords excluded). **Overused words** tespiti (threshold: 1 per 200 words). Repeated 2-word ve 3-word phrases (3+ occurrences). **Character mention count** (name + aliases). Per-chapter breakdown (top 5 words per chapter). Lexical diversity (unique/total ratio). 120s cache.
- **Character Mood Tracker** (`/char-mood/`): Bölüm bazlı karakter duygu durumu. 8 mood (joyful/hopeful/neutral/determined/anxious/afraid/angry/sad) with score 1-5. 3 intensity (low/medium/high). Per-character horizontal mood timeline across chapters. Set/update/delete mood (upsert — bir karakter+bölüm için tek mood). Note per entry. Mood legend.
- **Writing Music Player** (`/music/`): Local audio file player. Upload MP3/OGG/WAV/M4A/FLAC to `data/media/music/`. HTML5 audio player (sticky). Track library with play/delete. File size display. No new model — files on disk only.

### İyileştirmeler
- `models/char_mood.py` — CharacterMood ORM modeli (models/ altında, dairesel import önlemek için)
- Sidebar'a 3 yeni link: Word Frequency (📊), Mood Tracker (😊), Music Player (🎵)

### Mimari
- 3 yeni blueprint: `word_freq`, `char_mood`, `music`
- 1 yeni model: `models/char_mood.py` (CharacterMood)
- 3 yeni service: `word_freq_service`, `char_mood_service`, `music_service`
- Toplam blueprint sayısı: 48 → 51

### Test
- 21 yeni odaklı test (851 → 872)
- tests/test_v50_focused.py — word freq (6), char mood (6), music (6), sidebar (3)
- Kritik yollar: analysis with content, repeated phrases, set/update/delete mood, upload audio, invalid extension, delete track

---

## v4.9.0 — Milestones, Relationships & Scrivener (2026-07-15)

### Yeni Modüller
- **Word Count Milestone Celebrations** (`/milestones/`): 12 word count milestone (1K → 1M). Her milestone: threshold, name, icon, description. Reached/locked status + progress bar. **One-time celebration** (persisted — yeni ulaşılan milestone'lar "newly_celebrated" olarak işaretlenir, tekrar kutlanmaz). Next milestone tracker with progress % ve words remaining. Celebration animation (CSS pulse).
- **Character Relationship Timeline** (`/rel-timeline/`): Karakter ilişkilerini takip et. Mevcut CharacterRelationship modelini kullanır. Relationship matrix (character×character grid). Add/remove relationship (from→to, type, description, bidirectional). Stats (total, bidirectional, types breakdown). Events list. 12 common relationship type suggestion datalist.
- **Export to Scrivener** (`/scrivener/`): `.scriv` format export. ZIP package: `Files/Binder/binder.xml` (project structure), `Files/Docs/*.scrtext` (per-chapter content with metadata headers), `Settings/projectsettings.xml`. Options: include synopsis, include tags, status filter. Her chapter .scrtext dosyası: Title/Synopsis/Keywords/Status/Words header + content. Scrivener import instructions.

### İyileştirmeler
- `models/milestone.py` — MilestoneCelebration ORM modeli (models/ altında, dairesel import önlemek için)
- Sidebar'a 3 yeni link: Milestones (🎉), Relationship Timeline (🕸), Scrivener Export (📦)

### Mimari
- 3 yeni blueprint: `milestones`, `rel_timeline`, `scrivener`
- 1 yeni model: `models/milestone.py` (MilestoneCelebration)
- 3 yeni service: `milestone_service`, `rel_timeline_service`, `scrivener_export_service`
- Toplam blueprint sayısı: 45 → 48

### Test
- 20 yeni odaklı test (831 → 851)
- tests/test_v49_focused.py — milestones (6), rel_timeline (6), scrivener (5), sidebar (3)
- Kritik yollar: milestone reached with words, celebration persists, add relationship, self-rel rejected, matrix, ZIP contains .scrtext + binder.xml

---

## v4.8.0 — Arcs, Forecast & Habits (2026-07-15)

### Yeni Modüller
- **Character Arc Tracker** (`/character-arcs/`): Karakter gelişim yayları. Her karakter için çoklu arc. Her arc'ta stages (JSON: name/description/status/chapter_ids). 4 stage status (planned/active/completed/skipped). Progress %, current stage, overall status. Stage CRUD (add/update/remove). Aggregate stats (total/completed/active/planned arcs + stages). Progress bar per arc.
- **Manuscript Forecast** (`/forecast/`): Tamamlanma tarihi tahmini. 3 pace window (7d/30d/90d): avg words/day, writing days, est. completion date. Daily goal pace ayrı hesaplanır. Milestone projections (30/60/90/180 gün sonra projected words + %). On-track indicator (50%+ complete AND pace ≥ daily goal). 120s cache.
- **Writing Habit Insights** (`/habits/`): En verimli gün/saat analizi. activity_log timestamp'lerinden: best day of week, best hour, day-of-week productivity ranking, hour ranking (top 8), **7×24 heatmap** (day×hour grid, 5 intensity level). Frequency: writing days vs skipped days, % writing days. Longest streak + current streak. 30/90/365 gün seçilebilir.

### İyileştirmeler
- `services/habits_service.py` — empty state için 7×24 heatmap döndürür (always consistent shape)
- Sidebar'a 3 yeni link: Character Arcs, Manuscript Forecast, Writing Habits

### Mimari
- 3 yeni blueprint: `character_arcs`, `forecast`, `habits`
- 0 yeni model (CharacterArc zaten v4.0'dan var, service yeni)
- 3 yeni service: `character_arc_service`, `forecast_service`, `habits_service`
- Toplam blueprint sayısı: 42 → 45

### Test
- 21 yeni odaklı test (810 → 831)
- tests/test_v48_focused.py — character arcs (8), forecast (5), habits (5), sidebar (3)
- Kritik yollar: create arc, add/update stage, progress calc, overall status, forecast paces, heatmap 7×24, insights with activity

---

## v4.7.0 — Threads, Prompts & Dependencies (2026-07-15)

### Yeni Modüller
- **Beta Reader Comment Threads** (`/beta/`): Yorumlara yanıt (reply) desteği. BetaComment modeline `parent_id` + `is_author_reply` alanları eklendi. Top-level comments + nested replies. resolve/reopen lifecycle (cascades to replies). `get_threaded()` dict yapısı. `stats()` aggregate (total/top_level/replies/open/resolved/author_replies). Author vs reader ayrımı.
- **Writing Prompts Calendar** (`/prompt-calendar/`): inspiration_service'deki deterministik günlük prompt'ları takvim görünümünde. Her gün için prompt category + text. Month grid (Mon-Sun). Prev/next navigation. Today's prompt highlight. Day click → modal with full prompt → save veya new chapter. inspiration_service'i reuse eder (no new model).
- **Chapter Dependency Tracker** (`/chapter-deps/`): Bölümler arası bağımlılık grafiği. "Chapter A depends on Chapter B" = B before A. Cycle detection (DFS). Ordering violation detection (dependent before prerequisite). Blocked chapters (unmet deps). Topological sort (Kahn's algorithm). vis-network graph (hierarchical LR layout). Add/remove dependency UI.

### İyileştirmeler
- `models/beta_comment.py` — parent_id + is_author_reply alanları eklendi (migration: DB silinip yeniden oluşturulmalı)
- `services/beta_service.py` — delete_comment artık flush yaparak FK constraint hatasını önler
- Sidebar'a 2 yeni link: Prompt Calendar, Chapter Deps

### Mimari
- 3 yeni blueprint: `prompt_calendar`, `chapter_deps` (beta threads mevcut beta blueprint'e eklendi)
- 1 yeni model: `models/chapter_deps.py` (ChapterDependency)
- 2 yeni service: `chapter_deps_service` (prompt_calendar mevcut inspiration_service'i reuse eder)
- Toplam blueprint sayısı: 40 → 42

### Test
- 17 yeni odaklı test (793 → 810)
- tests/test_v47_focused.py — beta threads (5), prompt calendar (5), chapter deps (5), sidebar (2)
- Kritik yollar: add/reply/resolve/reopen/delete cascade, month/day API, add/remove dep, self-dep rejected, reverse-dep rejected

---

## v4.6.0 — Focus & History (2026-07-15)

### Yeni Modüller
- **Writing Session Timer** (`/sessions/`): Pomodoro-style odaklı yazım oturumları. 5 session type (pomodoro 25min, short_focus 15min, long_focus 50min, sprint 10min, custom). Start/pause/resume/complete/abandon lifecycle. Otomatik word count delta (start vs end). Live timer (JS setInterval). WPM hesaplama. 30-day aggregate stats (total sessions, minutes, words, avg WPM). Tek active session constraint.
- **Manuscript Snapshot Diff** (`/snapshot-diff/`): İki tarih arası manuscript değişikliklerini karşılaştır. chapter_versions kullanarak geçmiş state'i reconstruct eder. Added/removed/modified chapters tespiti. Per-chapter word count delta + first differing line preview. Net word change. HTML download (styled). Date picker (available snapshot dates).
- **Quick Capture Widget** (dashboard): Tek widget'tan 4 tür hızlı yakalama — note, chapter, journal, snippet. Type selector + title + body + Ctrl+Enter. AJAX submit, toast feedback. Mevcut servisleri (note_service, chapter_service, journal_service, snippet_service) reuse eder — duplicate code yok.

### İyileştirmeler
- Dashboard'a Quick Capture widget'ı eklendi — açılışta hızlı fikir yakalama
- Sidebar'a 2 yeni link: Session Timer, Manuscript Diff
- **Test stratejisi değişikliği**: Bu sürümde sadece 24 odaklı test eklendi (önceki sürümler 90+). Kritik yollar ve edge case'ler üzerine odaklanıldı, exhaustive coverage değil.

### Mimari
- 3 yeni blueprint: `sessions`, `snapshot_diff`, `quick_capture`
- 1 yeni model: `models/session.py` (WritingSession)
- 2 yeni service: `session_service`, `snapshot_diff_service`
- Toplam blueprint sayısı: 37 → 40

### Test
- 24 yeni odaklı test (769 → 793)
- tests/test_v46_focused.py — sessions (5), snapshot_diff (5), quick_capture routes (7), session routes (4), snapshot_diff routes (3)
- Kritik yollar: start/end session, pause/resume, cannot-start-two-active, diff same date, capture all 4 types, empty body rejection

---

## v4.5.0 — Gamification & Reference (2026-07-15)

### Yeni Modüller
- **Achievements** (`/achievements/`): 18 rozet, 5 kategori (streak/words/chapters/cast/consistency). Streak rozetleri: 3/7/30/100 gün. Word milestone'ları: 1K/10K/50K/100K/250K. Chapter milestone'ları: 1/5/10/25. Cast & World: first character, 10 characters, 20 world entries. Consistency: full week, weekend warrior. Her achievement: check fonksiyonu + progress bar + progress label. Unlock'lar DB'de persisted (UnlockedAchievement). check_and_unlock() otomatik kontrol eder.
- **Goals Calendar** (`/goals/`): Aylık görsel takvim — her gün heatmap renkli (0-4 seviye, daily goal'a göre). Month stats: total words, writing days, goal-met days, best day, avg/writing day. **Year overview**: 12-month bar grid, year words, writing days, year goal %. Current progress: today/week/month/year against goals. Prev/next month navigation. 60s cache.
- **Story Bible Auto-Generator** (`/story-bible/`): Mevcut içerikten otomatik story bible derleme. 6 bölüm: Plot Summary (chapter synopses), Characters (tüm profil alanları), Character Relationships (from→to→type), World Entries (by type), Timeline (story_date sorted), Glossary. 4 format: HTML (styled, printable CSS), TXT, MD, JSON. Preview page + download. Stats grid: chapters/characters/world/timeline/glossary/total words.
- **Spell Check & Custom Dictionary** (`/spellcheck/`): Yerel spell check — bağımsızlık (no Hunspell/aspell dependency). ~500 bundled common word + writer'ın custom dictionary + character names + world entry names + glossary terms hepsi "known good". _tokenize (markdown/HTML strip, 2+ char filter), _levenshtein (max_dist early exit), _suggest (distance ≤ 2). Per-chapter: flagged words with count, context, suggestions. Custom dictionary CRUD: add word, add batch, delete by id/text. Click suggestion to add to dictionary.

### İyileştirmeler
- `models/achievement.py` ve `models/spellcheck.py` — model sınıfları models/ altında (service'te değil), dairesel import önlemek için
- `services/spellcheck_service.py` BUNDLED_WORDS — hero/villain/castle/sword/magic gibi yaygın fantastik kelimeler eklendi
- Sidebar'a 4 yeni link: Achievements, Goals Calendar, Story Bible, Spell Check

### Mimari
- 4 yeni blueprint: `achievements`, `goals_calendar`, `story_bible`, `spellcheck`
- 2 yeni model: `models/achievement.py` (UnlockedAchievement), `models/spellcheck.py` (CustomWord)
- 4 yeni service: `achievement_service`, `goals_calendar_service`, `story_bible_service`, `spellcheck_service`
- Toplam blueprint sayısı: 33 → 37

### Test
- 93 yeni test eklendi (676 → 769, hepsi yeşil)
- tests/test_achievement_service.py (13 test — definitions, context building, check/unlock, idempotency, progress bounds)
- tests/test_goals_calendar_service.py (11 test — month calendar, year overview, heat levels, progress)
- tests/test_story_bible_service.py (16 test — gather data, render HTML/TXT/MD/JSON, validation, escaping)
- tests/test_spellcheck_service.py (26 test — tokenize, levenshtein, known words, check chapter, suggestions, custom dict CRUD)
- tests/test_routes/test_v45_routes.py (27 test — tüm endpoint'ler + sidebar görünürlüğü)

---

## v4.4.0 — Cards, Journal & Compile (2026-07-15)

### Yeni Modüller
- **Scene Card Index** (`/scenes/`): Bölüm içeriğini otomatik sahne kartlarına böl (* * *, ---, 3+ newline). Corkboard görünümü: 7 mood (tense/calm/humorous/dark/hopeful/romantic/mysterious), 3 status, 8 kart rengi. POV character, location, time of day, tags. **Drag-drop reorder** (global sort_order). Move to chapter. Aggregate stats (cards per chapter, per mood, per status).
- **Daily Writing Journal** (`/journal/`): Tarihli yazım günlüğü. 5 mood (great/good/ok/struggling/blocked), 1-5 energy, word goal/actual (auto-pulled from settings + activity log). Wins, struggles, intentions, gratitude, notes. **Journal streak** (consecutive days). 30-day aggregate stats: avg mood score, avg energy, goals met count, mood distribution. One entry per day (unique date constraint).
- **Manuscript Compile Wizard** (`/compile/`): Publication-ready manuscript derleme. **Front matter**: title page, copyright, dedication, epigraph (with attribution), TOC, acknowledgments. **Chapter formatting**: 4 number formats (none/chapter/number/chapter_number), scene break marker, status filter. **Back matter**: author's note, about author, other books. Config persisted. Preview structure before download. Output: HTML (with print CSS), DOCX (page breaks, centered headings), TXT, MD.
- **Theme & CSS Editor** (`/theme/`): 7 preset tema (dark, light, sepia, forest, ocean, sunset, midnight-OLED). Per-variable color overrides (13 CSS variables). Font family override. Base font size override. **Custom CSS** (freeform, 10K char limit). Live preview pane. **CSS otomatik tüm sayfalara inject edilir** (`<style id="custom-theme-css">`).

### İyileştirmeler
- `services/scene_service.py` — `_split_into_scenes` 4 farklı scene break pattern destekler
- `services/theme_service.py` — `get_config` artık hem dict hem string JSON handle eder (Setting.get zaten parse ediyor)
- `services/compile_service.py` — aynı dict/string fix uygulandı
- `app.py` context processor — `custom_theme_css` her sayfaya inject edilir
- `templates/base.html` — `<style id="custom-theme-css">` bloğu eklendi
- Sidebar'a 4 yeni link: Scene Cards, Writing Journal, Compile Wizard, Theme Editor

### Mimari
- 4 yeni blueprint: `scenes`, `journal`, `compile`, `theme`
- 2 yeni model: `models/scene.py` (SceneCard), `models/journal.py` (JournalEntry)
- 4 yeni service: `scene_service`, `journal_service`, `compile_service`, `theme_service`
- Toplam blueprint sayısı: 29 → 33

### Test
- 107 yeni test eklendi (569 → 676, hepsi yeşil)
- tests/test_scene_service.py (21 test — split patterns, extract, CRUD, reorder, move, stats)
- tests/test_journal_service.py (18 test — CRUD, mood validation, streak, goal met, stats)
- tests/test_compile_service.py (19 test — config, compile with front/back matter, render HTML/TXT/MD, chapter number formats, status filter)
- tests/test_theme_service.py (15 test — config, save/reset, CSS generation, preset validation, color overrides)
- tests/test_routes/test_v44_routes.py (34 test — tüm endpoint'ler + sidebar görünürlüğü + theme injection)

---

## v4.3.0 — Reader, Voice & Plot Audit (2026-07-15)

### Yeni Modüller
- **Reading Mode** (`/reading/`): Tüm bölümleri tek sürekli akışta oku. Font ailesi (serif/Lora/sans/WenKai/mono), font boyu (14-28px), satır yüksekliği (1.2-2.2), max genişlik, ve 4 tema (auto/paper/sepia/dark/night) — hepsi localStorage'da kalıcı. Sticky progress bar, bölüm jump dropdown, IntersectionObserver ile otomatik bölüm takibi. Klavye kısayolları: ← → (bölüm nav), F (fullscreen), H (controls toggle). Okuma konumu otomatik kaydedilir.
- **Character Voice Profiles** (`/voice/`): Her karakter için konuşma profili. 3 verbosity (terse/moderate/verbose), 4 formality (informal/neutral/formal/archaic), 3 sentence length. Favorite words, avoided words, catchphrases, speech quirks, favorite/avoided topics, example dialogue. **Dialogue scanner** karakterin bulunduğu tüm bölümleri tarayıp: avoided word kullanımlarını yakalar, catchphrase hit sayısını sayar, gerçek ortalama cümle uzunluğunu declared style ile karşılaştırır. **consistency_summary()** — karakterin sesini doğal dilde özetler (AI prompt context için ideal).
- **Timeline Conflict Detection** (`/timeline-check/`): story_date'leri otomatik parse eder (ISO, "Month Day, Year", year-month, year-only, ve metin içinden yıl çıkarma). 5 çakışma türü tespit eder: out-of-order (kronolojik ≠ outline sırası), duplicate_date (aynı tarihte 2+ kritik event), large_gaps (>30 gün boşluk), character_double_booked (aynı karakter aynı gün farklı track'lerde), unparseable_date. Track bazlı filtreleme. Tüm event'ler kronolojik tabloda gösterilir.
- **Research & References** (`/references/`): Araştırma kütüphanesi — kitap, makale, web sitesi, video, röportaj, podcast, doküman. 8 kaynak tipi. Her kayıt: title, author, URL, publication date, publisher, ISBN/DOI, description, **quotes** (alıntılar with page numbers), tags, read status (unread/reading/read), priority (low/medium/high), 1-5 rating, notes. Filtreleme: tip/status/priority/tag/search. Aggregate stats: toplam, okunmuş, ortalama rating.

### İyileştirmeler
- `models/__init__.py` — voice ve reference modülleri eklendi
- Sidebar'a 4 yeni link: Reading Mode, Voice Profiles, Timeline Audit, Research & Refs
- Reading Mode tüm bölümleri tek API çağrısında yükler (lazy loading sonraki sürüm için)

### Mimari
- 4 yeni blueprint: `reading`, `voice`, `timeline_check`, `references`
- 2 yeni model: `models/voice.py` (CharacterVoice), `models/reference.py` (Reference)
- 3 yeni service: `voice_service`, `timeline_check_service`, `reference_service`
- Toplam blueprint sayısı: 25 → 29

### Test
- 82 yeni test eklendi (487 → 569, hepsi yeşil)
- tests/test_voice_service.py (17 test — CRUD, scan dialogue, catchphrase counting, length match, summary)
- tests/test_timeline_check_service.py (20 test — date parsing 10 format, conflict detection 5 tür, gap analysis, track filter)
- tests/test_reference_service.py (21 test — CRUD, filters, stats, priority sort, quotes/tags)
- tests/test_routes/test_v43_routes.py (24 test — tüm endpoint'ler + sidebar görünürlüğü)

---

## v4.2.0 — Consistency & Career (2026-07-15)

### Yeni Modüller
- **Glossary & Style Sheet** (`/glossary/`): Yazarın tutarlı terimler sözlüğü. 6 kategori (character/place/magic/item/style/other). Her entry: canonical term + acceptable alternates + forbidden variants + case-sensitivity. **Manuscript scanner** tüm bölümleri tarar, forbidden bulgularını ve Levenshtein distance ≤ 2 yakın-yazım hatalarını context ile birlikte listeler. Term presence tracking (hangi terim kaç bölümde geçiyor).
- **Bulk Find & Replace** (`/find-replace/`): Tüm bölümlerde regex destekli bul-değiştir. Plain text veya regex modu, case-sensitive, whole-word seçenekleri. Status veya chapter ID bazlı scope. **Her zaman preview önce** — her bölüm için ilk 10 match context ile gösterilir. Apply her bölüm için yeni version snapshot oluşturur (find_replace source etiketi ile).
- **Submission Tracker** (`/submissions/`): Dergi/ajan/yayınevi/yarışma takibi. 7 status (drafting/submitted/in_review/accepted/rejected/withdrawn/published), 6 market type. Otomatik days-to-respond hesaplama. Aggregate stats: toplam, kabul oranı, ortalama/median yanıt süresi. Markets listesi (her market için submission/accepted/rejected/pending sayıları). Chapter link opsiyonel.
- **Writing Analytics** (`/analytics/`): Dashboard'un ötesinde derin analiz. Per-chapter: word count, sentence/paragraph count, avg sentence length, **dialogue ratio** (tırnak içi metin oranı), **lexical diversity** (type-token ratio), reading time. Manuscript summary: en kısa/en uzun bölüm, total unique words, ortalama bölüm uzunluğu. **Top 30 words** (stopwords hariç) progress bar ile. **Character screen time**: her karakter manuscript'in yüzde kaçında görünüyor. İki Chart.js bar chart (word count distribution, dialogue ratio per chapter).

### İyileştirmeler
- `services/chapter_service.py:list_chapters` local `read_session` shadow bug düzeltildi (modül-level import artık kullanılıyor)
- `tests/conftest.py` artık her test öncesi `cache.clear()` çağırıyor — analytics testleri arası cache leak önlendi
- Sidebar'a 4 yeni link: Glossary & Style, Find & Replace, Submission Tracker, Writing Analytics

### Mimari
- 4 yeni blueprint: `glossary`, `find_replace`, `submissions`, `analytics`
- 2 yeni model dosyası: `models/glossary.py`, `models/submission.py`
- 4 yeni service: `glossary_service`, `find_replace_service`, `submission_service`, `analytics_service`
- Toplam blueprint sayısı: 21 → 25

### Test
- 101 yeni test eklendi (386 → 487, hepsi yeşil)
- tests/test_glossary_service.py (16 test — CRUD, scan, Levenshtein, near-miss detection)
- tests/test_find_replace_service.py (18 test — preview/apply, regex, scope, versioning)
- tests/test_submission_service.py (18 test — CRUD, stats, markets, days-to-respond)
- tests/test_analytics_service.py (16 test — per-chapter, manuscript, top words, screen time)
- tests/test_routes/test_v42_routes.py (33 test — tüm endpoint'ler + sidebar görünürlüğü)

---

## v4.1.0 — Inspiration & Structure (2026-07-15)

### Yeni Modüller
- **Inspiration Hub** (`/inspiration/`): 7 kategoride 70+ hand-curated yazım promptu (opening/conflict/character/setting/twist/dialogue/whatif). Tarih-bazlı deterministik günlük prompt. 5 parçalı (protagonist/setting/goal/obstacle/twist) senaryo üreticisi. Kaydet, pin'le, "used" işaretle, prompt'tan chapter'a dönüştür.
- **Plot Structure Templates** (`/plot-templates/`): 6 klasik kurgu yapısı — Hero's Journey (12 beat), Save the Cat (15 beat), Three-Act (7 beat), Seven-Point (7 beat), Freytag's Pyramid (5 beat), Kishōtenketsu (4 beat). "Apply" ile her beat için plan oluşturur, `plot:<key>` track'inde.
- **Notes & Ideas Inbox** (`/notes/`): 6 kategoride (idea/question/reminder/reference/scene_idea/todo) hızlı not yakalama. Pin/done, etiketler, arama, çapraz-referans linkleri (chapter/character/world_entry/plan). Notu chapter/snippet/plan'a promote et.
- **Keyboard Shortcuts Center**: `?` tuşu ile açılan cheatsheet modalı. Yeni kısayollar: `t` (tema), `b` (sidebar), `g` chord navigasyonu (g+d/c/k/p/w/s/n/i/t/e/x). Footer'da `?` butonu.

### İyileştirmeler
- `chapters/new` artık `?prompt=` query parametresi kabul ediyor — prompt'tan yeni bölüme otomatik geçiş
- `link_url` Jinja global'i eklendi (note cross-reference linkleri için)
- Footer versiyon etiketi v4.0 → v4.1

### Mimari
- `models/inspiration.py` ve `models/note.py` ayrı dosyalara taşındı (dairesel import önlemek için)
- 3 yeni blueprint: `inspiration`, `plot_templates`, `notes`
- Toplam blueprint sayısı: 18 → 21

### Test
- 98 yeni test eklendi (288 → 386, hepsi yeşil)
- tests/test_inspiration_service.py (19 test)
- tests/test_plot_template_service.py (14 test)
- tests/test_note_service.py (25 test)
- tests/test_routes/test_v41_routes.py (40 test — tüm yeni endpoint'ler + sidebar görünürlüğü)

---

## v4.0.0 — Final (2026-07-03)

### Temel Sürüm (İlk Kurulum)
- Flask 3.x + SQLAlchemy + Jinja2 + Tailwind + Alpine.js + SortableJS + vis-network + EasyMDE + Chart.js
- Tüm vendor asset'leri offline (CDN yok)
- SQLite WAL mode + FTS5 full-text search
- Dark/Light tema, responsive design
- 9 Blueprint: dashboard, chapters, characters, plans, world, search, export, settings, ai

### Modüller
- **Dashboard**: Story cockpit, ring chart, 30-gün word chart, 365-gün heatmap, streak, karakter appearance heatmap
- **Chapters**: CRUD, drag-reorder, upload (TXT/MD/DOCX/PDF/RTF/ODT/HTML/CSV), EasyMDE editor, cost-aware versioning, split/merge, diff
- **Characters**: Rich profiles, groups, relationships, vis-network graph (drag-save-position, click-to-create, filters), arcs, timeline, compare
- **Plans**: Kanban (SortableJS), outline (nested DnD), timeline (multi-track), subtasks, dependencies, deadlines
- **World**: Tab library, type-specific metadata, cross-references, hierarchy tree, interactive map, versioning
- **Search**: FTS5 + LIKE fallback, case-sensitive, regex, recent searches (localStorage)
- **Export**: TXT/MD/HTML/DOCX/PDF/EPUB/JSON, async progress, Scrivener compile presets
- **Settings**: Appearance, story metadata, goals, versioning, pagination, backup, import/export, AI, data health
- **AI (opt-in)**: Ollama/OpenAI-compatible, continue/summarize/tags/consistency-check/name-generator/dialogue/streaming

---

## Düzeltmeler ve Eklemeler (Kronolojik)

### Tur 1: İlk Sürüm
- Temel proje yapısı oluşturuldu (models/, services/, routes/, templates/, static/)
- Tüm modeller: projects, chapters, chapter_versions, characters, character_groups, character_relationships, character_arcs, plans, plan_subtasks, world_entries, world_entry_versions, world_entry_relations, activity_log, settings
- FTS5 virtual tables + sync triggers
- Tüm servisler: chapter, character, plan, world, stats, search, export, diff, versioning, validate, backup, ai
- Tüm route'lar (80+ URL)
- Tüm template'ler (36 HTML)
- Vendor script (offline asset indirme)
- Seed data (8 karakter, 5 bölüm, 6 plan, 10 world entry)

### Tur 2: Test ve Düzeltmeler
- **Düzeltme**: `cycleStatus` JS chapter'ı bozuyordu → ayrı endpoint eklendi
- **Düzeltme**: World map pin kaldırma çalışmıyordu → null koordinatlar desteklendi
- **Düzeltme**: Chapter service empty title koruması eklendi
- **Düzeltme**: Activity log dashboard linkleri düzeltildi
- **Düzeltme**: Cost-aware versioning mantığı düzeltildi (status change artık snapshot oluşturuyor)
- **Ekleme**: Character Timeline page
- **Ekleme**: Kanban subtask progress bar
- **Ekleme**: Outline nested reorder persist
- **Ekleme**: AI "✨ Assist" editor toolbar butonları
- **Ekleme**: AI activity log entegrasyonu
- **Test**: 129 pytest + 91 integration test = 220 test

### Tur 3: PROMPT_V4 Eksik Giderme
- **Ekleme**: Persistent undo sistemi (DB-backed, 100 entry cap, delete-with-undo)
- **Ekleme**: Chapter `versions/save`, `diff/export` endpoint'leri
- **Ekleme**: Character compare export (TXT + PDF)
- **Ekleme**: World version compare
- **Ekleme**: Custom world types CRUD
- **Ekleme**: JSON import/export (tam DB round-trip)
- **Ekleme**: Search case-sensitive + regex
- **Ekleme**: AI consistency check, streaming, rate limit (30/dk)
- **Ekleme**: AI first-enable disclosure modal
- **Ekleme**: Plan dependency warnings + overdue display + effort vs actual
- **Ekleme**: Character Groups page (drag-drop between groups)
- **Ekleme**: Corkboard view
- **Ekleme**: World Hierarchy tree
- **Ekleme**: Word-level diff highlighting + hunk navigation
- **Ekleme**: World map image upload + zoom/pan
- **Ekleme**: Timeline zoom controls (Day/Week/Month)
- **Ekleme**: Mobile responsive (tablet icon-only, mobile hamburger)
- **Ekleme**: Distraction-free editor mode
- **Ekleme**: Ctrl+E edit mode toggle
- **Ekleme**: Subtask inline edit
- **Ekleme**: Manuscript formatting settings
- **Test**: 181 pytest

### Tur 4: Altyapı Eksikleri
- **Ekleme**: `start.bat` Windows launcher (venv + requirements + flask run)
- **Ekleme**: 9 reusable component template (card, modal, badge, button, toast, progress_bar, form_input, tabs, dropdown)
- **Ekleme**: Vendor manifest startup kontrolü
- **Ekleme**: Ayrı JS dosyaları (world_map.js, charts.js, diff.js)
- **Ekleme**: Kanban dependency arrows (SVG overlay)
- **Ekleme**: Timeline event add/edit popup
- **Ekleme**: Search pagination
- **Ekleme**: 4 yeni test dosyası (export, diff, validate, backup)
- **Test**: 245 pytest

### Tur 5: AI + Cache + Pagination
- **Ekleme**: `ai.disclosure_accepted` setting (bir kez göster, sonra kaydet)
- **Ekleme**: `core/cache.py` — thread-safe in-memory cache (TTL + invalidate)
- **Ekleme**: Stats cache (11 fonksiyon, 60s TTL, write'da invalidate)
- **Ekleme**: Background export progress (async_export + status/download)
- **Ekleme**: Timeline track reorder (SortableJS + persist)
- **Ekleme**: Configurable pagination (chapters_per_page, world_per_page, search_results_per_module)
- **Ekleme**: World pagination
- **Düzeltme**: Manuscript line spacing 24pt (double-spaced) — settings'den okur
- **Test**: 272 pytest

### Tur 6: Kritik Bug Düzeltmeleri
- **Düzeltme**: `start.bat` NameError — `_verify_vendor_manifest` create_app'den önce taşındı
- **Ekleme**: Browser otomatik açılış (webbrowser.open + threading)
- **Ekleme**: `tests/test_versioning_service.py` (16 test)
- **Ekleme**: Toplu drag-drop import (çoklu TXT/PDF → chapters veya world entries)
- **Düzeltme**: Karakter "Invalid Response" — tüm form JS'leri FormData gönderiyor (JSON değil)
- **Ekleme**: `submitForm()` yardımcı fonksiyonu app.js'ye eklendi
- **Düzeltme**: 8 form template'inin JS'i sıfırdan yeniden yazıldı
- **Test**: 288 pytest

### Tur 7: CSRF Düzeltmesi
- **Düzeltme**: Tüm Blueprint'ler CSRF'den muaf tutuldu (local-first app)
- **Düzeltme**: 10 form template'ine CSRF hidden field eklendi
- **Düzeltme**: Browser double açma sorunu (use_reloader=False)
- **Düzeltme**: Bulk import FormData'ya csrf_token eklendi
- **Test**: 288 pytest

### Tur 8: P0/P1 Özellikler
- **Ekleme**: Quick Switch (Ctrl+P) — global command palette
- **Ekleme**: Canlı kelime sayacı + Writing Sprint Timer (25dk, WPM, pause/resume)
- **Ekleme**: Version diff live preview (toggle, canlı diff)
- **Ekleme**: Story Lint Engine (AI-free) — 7 kontrol: repeated words, name typos, sentence length, adverb overuse, passive voice, dialogue tags, attribute consistency
- **Test**: 288 pytest

### Tur 9: AI Context + Pacing
- **Ekleme**: AI Context-Aware Continuation (karakter+dünya+plot context ile)
- **Ekleme**: Pacing Analysis — tension curve, word count distribution, dialogue vs narration, rhythm assessment
- **Test**: 288 pytest

### Tur 10: Compile Presets + Horizontal Timeline
- **Ekleme**: Scrivener Compile Presets — 6 profil (Manuscript, Beta Reader, E-book, PDF Book, Blog, Workshop)
- **Ekleme**: Interactive Horizontal Timeline — vertical/horizontal toggle, zoom, renkli pin'ler
- **Test**: 288 pytest

### Tur 11: AI Dialogue + Multi-Book
- **Ekleme**: AI Dialogue Generator — karakter voice/psychology ile diyalog üret (8 duygu seçeneği)
- **Ekleme**: Series/Multi-Book UI — project switcher, create/edit/delete, per-book stats
- **Test**: 288 pytest

### Tur 12: Son Özellikler (Bu Sürüm)
- **Ekleme**: World Map Travel Routes — karakter seyahat rotaları (SVG overlay, create/update/delete)
- **Ekleme**: Beta Reader Mode — read-only chapter + yorum (text selection, resolve/delete)
- **Ekleme**: Composition Mode — tam ekran yazma + arka plan rengi, font boyutu, genişlik ayarı
- **Ekleme**: Scene/Beat Editing — bölüm içinde sahne tespiti ve önizleme (otomatik \n\n\n bölme)
- **Test**: 288 pytest

---

## İstatistikler

| Metric | Value |
|--------|-------|
| Python dosyası | 140 |
| HTML template | 91 |
| JS dosyası | 15 |
| CSS dosyası | 4 |
| Vendor asset | 12+ |
| Test sayısı | 872 |
| URL endpoint | 240+ |
| Blueprint | 51 |
| AI özelliği | 9 |
| Export format | 30+ kombinasyon |
| Milestone | 12 |
| Character mood | 8 |
| Toplam dosya | 325+ |

## Çalıştırma
```bash
# Windows: start.bat (browser otomatik açılır)
# Linux/Mac: python app.py
# Test: PYTHONPATH=. python -m pytest tests/ -v
```
