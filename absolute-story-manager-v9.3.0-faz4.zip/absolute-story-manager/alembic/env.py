"""Alembic environment for Absolute Story Manager.

URL resolution (v9.1.0, M-01):
1. A URL set programmatically by core/migrations.py (it passes the live
   engine's URL so tests with patched engines work transparently).
2. `ASM_DB_URI` env var / app default via config.Config — this makes the
   plain CLI (`alembic upgrade head`) work out of the box.
"""
from __future__ import annotations

import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

from alembic import context

# Make project root importable when alembic runs via CLI.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

config = context.config

# Alembic logging — only when an ini file with logging sections is used.
if config.config_file_name is not None:
    try:
        fileConfig(config.config_file_name, disable_existing_loggers=False)
    except Exception:  # noqa: BLE001 - logging setup must never break migrations
        pass


def _resolve_url() -> str:
    """Resolve the database URL for this run."""
    url = (config.get_main_option("sqlalchemy.url") or "").strip()
    if url:
        return url
    # Fall back to the application's own resolution (ASM_DB_URI or default).
    from config import Config
    return Config.SQLALCHEMY_DATABASE_URI


# Model metadata — enables `alembic revision --autogenerate`.
from models import Base  # noqa: E402

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (emit SQL to stdout)."""
    url = _resolve_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,  # SQLite-friendly ALTER TABLE batches
        compare_type=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode (live connection)."""
    url = _resolve_url()
    cfg = config.get_section(config.config_ini_section) or {}
    cfg["sqlalchemy.url"] = url
    # Pool settings irrelevant for one-shot migration runs.
    connectable = engine_from_config(
        cfg,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=True,  # SQLite: ALTERs need batch mode
            compare_type=True,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
