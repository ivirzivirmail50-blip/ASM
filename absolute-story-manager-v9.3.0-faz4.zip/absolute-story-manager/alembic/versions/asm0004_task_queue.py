"""v9.3.0 — F-05: dayanıklı görev kuyruğu tablosu

``background_tasks``: export/compile işlerinin disk üstündeki durumu.
Uygulama kapansa bile pending/running/done/failed + ilerleme kaybolmaz;
açılışta task_queue_service.recover_stale_running yarım işleri tekrar
kuyruğa alır. Tablo modelden (models/background_task.py) üretilir — CHECK
(status enum, progress 0-100) ve indeksler dahil.
"""
from __future__ import annotations

import logging
from typing import Sequence, Union

from sqlalchemy import text
from sqlalchemy.dialects import sqlite as sqlite_dialect
from sqlalchemy.schema import CreateIndex, CreateTable

from alembic import op

log = logging.getLogger("asm.migrations")

# revision identifiers, used by Alembic.
revision: str = "asm0004"
down_revision: Union[str, None] = "asm0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "background_tasks"


def upgrade() -> None:
    from sqlalchemy import inspect

    from models import Base

    bind = op.get_bind()
    dialect = sqlite_dialect.dialect()

    # Idempotent: the legacy-adopt path pre-creates every metadata table
    # (create_all gap-fill) before the chain runs, so asm0004 must skip
    # rather than collide. The pre-created shape IS the model DDL.
    if inspect(bind).has_table(_TABLE):
        log.info("asm0004: %s already present (legacy adopt) — skipping.",
                 _TABLE)
        return

    tbl = Base.metadata.tables[_TABLE]
    ddl = str(CreateTable(tbl).compile(dialect=dialect)).strip()
    bind.execute(text(ddl))
    existing_idx = {
        ix["name"] for ix in inspect(bind).get_indexes(_TABLE)
    }
    for ix in tbl.indexes:
        if ix.name in existing_idx:
            continue
        bind.execute(text(
            str(CreateIndex(ix).compile(dialect=dialect)).strip()))
    log.info("asm0004: created %s (durable task queue).", _TABLE)


def downgrade() -> None:
    op.drop_table(_TABLE)
