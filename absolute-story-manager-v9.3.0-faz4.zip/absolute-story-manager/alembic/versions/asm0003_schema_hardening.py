"""v9.3.0 — F-06: veri modeli sağlamlaştırma (FK/unique/CHECK/boolean)

SQLite ALTER TABLE bir tabloya FK / UNIQUE / CHECK kısıtı EKLEYEMEZ; kısıt
eklemek ancak tabloyu yeniden inşa etmekle mümkündür. Bu migration tam olarak
bunu yapar: ORM metadata (modeller) tek doğruluk kaynağıdır — her tablo için

    1. geçici isimle yeni DDL (kısıtlar dahil) oluştur,
    2. veriyi kolon adlarıyla kopyala,
    3. eski tabloyu bırak (indeksleri/trigger'ları da götürür),
    4. geçici tabloyu yeniden adlandır,

sonra metadata indekslerini ve FTS5 trigger'larını yeniden kurar.

upgrade()  -> katı şema (FK + ondelete, unique, CHECK, BOOLEAN tipler)
downgrade()-> gevşek şema (yalnız kolonlar + PK — asm0002 durumu)

Veri güvenliği (upgrade yolu):
  * NULL project_id -> 'default' geri dolgusu (NOT NULL kolonlar),
  * yetim satırlar ondelete kuralına göre temizlenir (CASCADE -> sil,
    SET NULL -> boşa çek); kendine-referanslı zincirler için döngü,
  * yeni unique anahtarlarda çiftler deterministik tekilleştirilir
    (rowid'i en küçük olan korunur),
  * boolean'a geçen kolonlar 0/1'e normalize edilir, geçersiz değerler
    klampelanır — böylece CHECK'ler kopya sırasında ihlal edilmez,
  * sonunda PRAGMA foreign_key_check boş olmak zorundadır (assert).

Kapsam (modellerde bildirildi):
  FK CASCADE : chapters/characters/world/plans/... project_id'leri +
               chapter_versions, chat_messages, chapter_checklists,
               beta_*, character_* çocukları, travel_routes, scene_cards,
               chapter_dependencies, series_links
  FK SET NULL: chapters.pov_character_id, submissions/chat_sessions/
               plans/scene_cards/writing_sessions .chapter_id, plans self-ref,
               world_entries.parent_id
  UNIQUE     : (project_id, term/word/name/entry_date/milestone_key/
                achievement_key), (chapter_id, reader_name),
                snippets (project_id, name)
  CHECK      : boolean IN (0,1) x14, negatif olmayan sayaçlar, energy 1-5,
               chat_messages.role + chat_sessions.mode enum'ları
Polimorfik tablolar (activity_log.entity_id, ai_history, undo_operations)
bilinçli olarak FK'sız kalır — varlık türü çalışma zamanında belirlenir.
"""
from __future__ import annotations

import logging
from typing import Sequence, Union

from sqlalchemy import Column, MetaData, Table, UniqueConstraint, text
from sqlalchemy.dialects import sqlite as sqlite_dialect
from sqlalchemy.schema import CreateIndex, CreateTable

from alembic import op

log = logging.getLogger("asm.migrations")

# revision identifiers, used by Alembic.
revision: str = "asm0003"
down_revision: Union[str, None] = "asm0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TEMP_SUFFIX = "__asm0003"

# CHECK kısıtlarına hazırlık: (tablo, kolon, atama, koşul).
# Koşul yalnız geçersiz satırları yakalar; NULL'lar CHECK'leri zaten geçer.
_VALUE_FIXES: tuple[tuple[str, str, str, str], ...] = (
    ("chapters", "word_count", "MAX(word_count, 0)", "word_count < 0"),
    ("chapters", "sort_order", "MAX(sort_order, 0)", "sort_order < 0"),
    ("chapters", "story_day", "NULL", "story_day < 1"),
    ("chapter_versions", "word_count", "MAX(word_count, 0)",
     "word_count < 0"),
    ("chapter_versions", "version_number", "MAX(version_number, 1)",
     "version_number < 1"),
    ("chapter_checklists", "sort_order", "MAX(sort_order, 0)",
     "sort_order < 0"),
    ("journal_entries", "word_count_goal", "MAX(word_count_goal, 0)",
     "word_count_goal < 0"),
    ("journal_entries", "word_count_actual", "MAX(word_count_actual, 0)",
     "word_count_actual < 0"),
    ("journal_entries", "energy", "NULL",
     "energy NOT BETWEEN 1 AND 5"),
    ("submissions", "days_to_respond", "NULL", "days_to_respond < 0"),
    ("chat_sessions", "message_count", "MAX(message_count, 0)",
     "message_count < 0"),
    ("chat_sessions", "mode", "'character'",
     "mode NOT IN ('character', 'group', 'assistant')"),
    ("milestone_celebrations", "threshold", "MAX(threshold, 0)",
     "threshold < 0"),
    ("writing_sessions", "words_written", "MAX(words_written, 0)",
     "words_written < 0"),
    ("writing_sessions", "elapsed_seconds", "MAX(elapsed_seconds, 0)",
     "elapsed_seconds < 0"),
    ("writing_sessions", "paused_seconds", "MAX(paused_seconds, 0)",
     "paused_seconds < 0"),
    ("chat_messages", "role", "'system'",
     "role NOT IN ('user', 'assistant', 'system')"),
)


def upgrade() -> None:
    _rebuild_all(hard=True)


def downgrade() -> None:
    _rebuild_all(hard=False)


# ---------------------------------------------------------------------------
# Çekirdek: metadata güdümlü tam yeniden inşa
# ---------------------------------------------------------------------------

def _rebuild_all(hard: bool) -> None:
    from models import Base

    bind = op.get_bind()
    dialect = sqlite_dialect.dialect()
    prep = dialect.identifier_preparer

    # Rebuild sırasında FK uygulaması kapalı olmalı (parent DROP'ları
    # güvenli). Migration bağlantısı zaten FK kapalı doğar (env.py kendi
    # motorunu kurar; pragma listener'ı yoktur) — yine de açıkça kapat.
    bind.execute(text("PRAGMA foreign_keys=OFF"))

    meta = Base.metadata

    # v9.3.0 (F-05 composable-chain fix): ONLY tables that already exist
    # are rebuilt. Future migrations (asm0004+) may add tables to the
    # metadata that did not exist when asm0003 ran — their constraints
    # arrive with their own creating migration instead.
    from sqlalchemy import inspect
    existing_tables = set(inspect(bind).get_table_names())

    if hard:
        _prepare_data(bind, meta, prep)

    for tbl in meta.sorted_tables:
        if tbl.name not in existing_tables:
            continue
        _rebuild_table(bind, dialect, prep, tbl, hard)

    _create_indexes(bind, dialect, meta, existing_tables)
    _reinstall_fts(bind)

    if hard:
        violations = bind.execute(text("PRAGMA foreign_key_check")).fetchall()
        if violations:
            raise RuntimeError(
                "asm0003: foreign_key_check failed after rebuild: "
                f"{[tuple(v) for v in violations][:10]}"
            )
    bind.execute(text("PRAGMA foreign_keys=ON"))
    log.info("asm0003: %s rebuild complete (%d tables).",
             "hard" if hard else "relaxed", len(meta.sorted_tables))


def _rebuild_table(bind, dialect, prep, tbl: Table, hard: bool) -> None:
    """Tek tabloyu metadata DDL'sinden yeniden inşa eder.

    v9.3.0 (F-10): kopya yalnız ESKİ tabloda VAR olan kolonları taşır.
    Metadata'da sonradan eklenen kolonlar (ör. asm0005'in stack'i) bu
    migration'dan sonra doğarlar — DDL server_default'ları değeri doldurur;
    kolonu ekleyen migration kendi geri dolgusunu yapar.
    """
    source = tbl if hard else _relaxed_table(tbl)
    ddl = str(CreateTable(source).compile(dialect=dialect)).strip()
    qname = prep.quote(tbl.name)
    qtemp = prep.quote(f"{tbl.name}{_TEMP_SUFFIX}")
    anchor = f"CREATE TABLE {qname} "
    if not ddl.startswith(anchor):
        raise RuntimeError(
            f"asm0003: unexpected DDL header for {tbl.name}: {ddl[:80]!r}")
    ddl = ddl.replace(anchor, f"CREATE TABLE {qtemp} ", 1)

    old_cols = {row[1] for row in
                bind.execute(text(f"PRAGMA table_info({qname})")).fetchall()}
    copy_cols = [c.name for c in tbl.columns if c.name in old_cols]
    if not copy_cols:  # teori: olmaz — metadata eski tabloyu kapsamalı
        copy_cols = [c.name for c in tbl.columns]
    cols = ", ".join(prep.quote(c) for c in copy_cols)
    bind.execute(text(ddl))
    bind.execute(text(
        f"INSERT INTO {qtemp} ({cols}) SELECT {cols} FROM {qname}"))
    bind.execute(text(f"DROP TABLE {qname}"))
    bind.execute(text(f"ALTER TABLE {qtemp} RENAME TO {qname}"))


def _relaxed_table(tbl: Table) -> Table:
    """downgrade için: kolonlar + PK, kısıtlar YOK (asm0002 şekli)."""
    cols = [
        Column(c.name, c.type, primary_key=c.primary_key,
               nullable=c.nullable)
        for c in tbl.columns
    ]
    return Table(tbl.name, MetaData(), *cols)


def _create_indexes(bind, dialect, meta: MetaData,
                    existing_tables: set[str]) -> None:
    """Yeniden inşa indeksleri düşürdü — metadata'dan geri kur."""
    for tbl in meta.sorted_tables:
        if tbl.name not in existing_tables:
            continue
        for ix in tbl.indexes:
            bind.execute(text(
                str(CreateIndex(ix).compile(dialect=dialect)).strip()))


def _reinstall_fts(bind) -> None:
    """Tablo rebuild'i chapters/characters/world_entries trigger'larını
    düşürdü. FTS5 tabloları + trigger'ları idempotent DDL ile geri kur
    (aynı bağlantı üzerinden — ek işlem gerekmez)."""
    from models.search import _FTS_DDL, _TRIGGERS_DDL

    for raw in _FTS_DDL.split(";"):
        stmt = "\n".join(
            line for line in raw.splitlines()
            if not line.strip().startswith("--")
        ).strip()
        if stmt:
            bind.execute(text(stmt))
    for raw in _TRIGGERS_DDL.split("END;"):
        stmt = "\n".join(
            line for line in raw.splitlines()
            if not line.strip().startswith("--")
        ).strip()
        if stmt:
            bind.execute(text(stmt + " END;"))


# ---------------------------------------------------------------------------
# Veri hazırlığı (yalnız upgrade)
# ---------------------------------------------------------------------------

def _prepare_data(bind, meta: MetaData, prep) -> None:
    from sqlalchemy import inspect
    insp = inspect(bind)
    existing_tables = set(insp.get_table_names())

    for tbl in meta.sorted_tables:
        if tbl.name not in existing_tables:
            continue
        # Tablo bu migration'dan SONRA eklendi (asm0004+): veri hazırlığı
        # yok — kısıtları kendi oluşturan migration'la gelir.
        _backfill_not_null_project(bind, tbl, prep)
        _normalize_booleans(bind, tbl, prep)
        _apply_value_fixes(bind, tbl.name, prep)

    # Yetim temizliği: kendine-referanslı zincirler (beta_comments.parent_id,
    # plans.parent_id) tek geçişte tam temizlenmeyebilir → sabitlenene kadar
    # döngü (üst sınır: 5 tur).
    for _ in range(5):
        affected = sum(
            _purge_orphans(bind, tbl, prep)
            for tbl in meta.sorted_tables
            if tbl.name in existing_tables
        )
        if affected == 0:
            break

    for tbl in meta.sorted_tables:
        if tbl.name in existing_tables:
            _dedupe_uniques(bind, tbl, prep)


def _backfill_not_null_project(bind, tbl: Table, prep) -> None:
    if "project_id" not in tbl.columns:
        return
    pid = tbl.columns["project_id"]
    if not pid.nullable:
        q = prep.quote(tbl.name)
        bind.execute(text(
            f"UPDATE {q} SET project_id = 'default' "
            "WHERE project_id IS NULL"))


def _normalize_booleans(bind, tbl: Table, prep) -> None:
    from sqlalchemy import Boolean
    q = prep.quote(tbl.name)
    for c in tbl.columns:
        if isinstance(c.type, Boolean):
            col = prep.quote(c.name)
            bind.execute(text(
                f"UPDATE {q} SET {col} = "
                f"CASE WHEN {col} IN (0, 1) THEN {col} ELSE 0 END "
                f"WHERE {col} IS NOT NULL AND {col} NOT IN (0, 1)"))


def _apply_value_fixes(bind, table_name: str, prep) -> None:
    q = prep.quote(table_name)
    for table, col, assign, cond in _VALUE_FIXES:
        if table == table_name:
            qc = prep.quote(col)
            bind.execute(text(
                f"UPDATE {q} SET {qc} = {assign} "
                f"WHERE {cond}"))


def _purge_orphans(bind, tbl: Table, prep) -> int:
    """Yetim FK değerlerini ondelete kuralına göre temizle.

    Dönen değer: etkilenen satır sayısı (döngü kontrolü için).
    """
    affected = 0
    q = prep.quote(tbl.name)
    for fkc in tbl.foreign_key_constraints:
        cols = list(fkc.columns)
        if len(cols) != 1:
            raise RuntimeError(
                f"asm0003: multi-column FK on {tbl.name} not supported")
        col = prep.quote(cols[0].name)
        fk = fkc.elements[0]
        if fk.column is None:
            continue  # hedef çözümlenemedi (teori: olmaz — metadata tam)
        ref = fk.column.table
        ref_col = fk.column.name
        cond = (f"{col} IS NOT NULL AND {col} NOT IN "
                f"(SELECT {prep.quote(ref_col)} FROM {prep.quote(ref.name)})")
        if fkc.ondelete == "SET NULL":
            result = bind.execute(
                text(f"UPDATE {q} SET {col} = NULL WHERE {cond}"))
        else:  # CASCADE (varsayılan: sil)
            result = bind.execute(
                text(f"DELETE FROM {q} WHERE {cond}"))
        affected += result.rowcount or 0
    return affected


def _dedupe_uniques(bind, tbl: Table, prep) -> None:
    """Unique anahtarlarda çiftleri tekilleştir (en düşük rowid korunur)."""
    q = prep.quote(tbl.name)
    groups: list[tuple[str, ...]] = [
        tuple(prep.quote(c.name) for c in fkc.columns)
        for fkc in tbl.constraints
        if isinstance(fkc, UniqueConstraint)
    ]
    for c in tbl.columns:
        if c.unique:
            groups.append((prep.quote(c.name),))
    for cols in groups:
        col_list = ", ".join(cols)
        bind.execute(text(
            f"DELETE FROM {q} WHERE rowid NOT IN "
            f"(SELECT MIN(rowid) FROM {q} GROUP BY {col_list})"))
