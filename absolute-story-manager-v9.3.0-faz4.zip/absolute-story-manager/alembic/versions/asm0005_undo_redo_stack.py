"""v9.3.0 — F-10: undo iki-yığın (undo/redo) kolonu

``undo_operations.stack``: 'u' (undoable) | 'r' (redoable). Yeni yıkıcı
eylem redo yığınını temizler (record_delete); undo_last tersini r'ye iter;
redo_last geri alıp u'ya döndürür.

Kolon, asm0003'ün metadata-güdümlü rebuild'i koşan veritabanlarında zaten
DDL'den (server_default='u') doğmuş olabilir — o durumda ADD COLUMN atlanır.
"""
from __future__ import annotations

import logging
from typing import Sequence, Union

from sqlalchemy import text

from alembic import op

log = logging.getLogger("asm.migrations")

revision: str = "asm0005"
down_revision: Union[str, None] = "asm0004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "undo_operations"
_COL = "stack"


def _has_column(bind, table: str, col: str) -> bool:
    rows = bind.execute(text(f"PRAGMA table_info({table})")).fetchall()
    return any(r[1] == col for r in rows)


def upgrade() -> None:
    bind = op.get_bind()
    if _has_column(bind, _TABLE, _COL):
        log.info("asm0005: %s.%s already present — backfill only.",
                 _TABLE, _COL)
    else:
        bind.execute(text(
            f"ALTER TABLE {_TABLE} ADD COLUMN {_COL} VARCHAR(1) "
            "NOT NULL DEFAULT 'u'"))
        log.info("asm0005: added %s.%s.", _TABLE, _COL)
    # Boş/NULL kalan satırlar (teori: yok — savunmacı)
    bind.execute(text(f"UPDATE {_TABLE} SET {_COL}='u' "
                      f"WHERE {_COL} IS NULL"))
    bind.execute(text(
        "CREATE INDEX IF NOT EXISTS ix_undo_operations_stack "
        f"ON {_TABLE} ({_COL})"))


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_undo_operations_stack")
    # SQLite DROP COLUMN (3.35+) — indekssiz, basit kolon: güvenli
    bind = op.get_bind()
    if _has_column(bind, _TABLE, _COL):
        op.execute(f"ALTER TABLE {_TABLE} DROP COLUMN {_COL}")
