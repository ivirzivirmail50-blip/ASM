"""v9.1.0 — chapter_versions latest-version composite index (M-01)

First REAL schema evolution managed by Alembic. Promotes the runtime
CREATE INDEX IF NOT EXISTS (core/db.py _PERF_INDEXES, added in v8.4) into a
versioned migration so future schema work is reproducible on every install.

Every chapter save runs:
    SELECT ... WHERE chapter_id = ? ORDER BY version_number DESC LIMIT 1
With only the single-column chapter_id index SQLite must sort all of a
chapter's versions; the composite resolves it directly.

`if_not_exists=True` keeps adoption safe: databases created by v8.4-v9.0.1
already have this index (runtime patch), so the legacy stamp path
(stamp asm0001 -> upgrade head) must not fail on it.

Revision ID: asm0002
Revises: asm0001
Create Date: 2026-09-19
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "asm0002"
down_revision: Union[str, None] = "asm0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_INDEX_NAME = "ix_chapter_versions_ch_vnum"


def upgrade() -> None:
    op.create_index(
        _INDEX_NAME,
        "chapter_versions",
        ["chapter_id", sa.text("version_number DESC")],
        unique=False,
        if_not_exists=True,
    )


def downgrade() -> None:
    op.drop_index(
        _INDEX_NAME,
        table_name="chapter_versions",
        if_exists=True,
    )
