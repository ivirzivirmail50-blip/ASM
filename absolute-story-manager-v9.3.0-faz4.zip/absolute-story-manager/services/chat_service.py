"""v8.1 — Chat 2.0 service: persistent conversations with real memory.

Before v8.1 the character chat page kept a JS-side `chatHistory` array that
was NEVER sent to the backend — every reply was generated in isolation, the
character forgot the previous question, and a page refresh destroyed the
conversation. This service fixes all three:

  * ChatSession/ChatMessage tables → conversations survive reloads & reboots
  * build_history() → the last turns (budget-limited) are folded into every
    prompt, so characters actually remember the conversation
  * transcript / search / export → conversations become story material
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import or_

from core.db import read_session, write_transaction
from core.errors import NotFoundError, ValidationError
from models.chat import ChatMessage, ChatSession
from services._common import (
    current_project_id,
    dump_json,
    load_json,
    log_activity,
    new_uuid,
    now_utc,
)

log = logging.getLogger("asm.chat")

MODES = ("character", "group", "assistant")

# How much of the conversation we replay into the prompt (characters).
HISTORY_BUDGET_CHARS = 6000
# Never send fewer than the most recent turns, even if they are long.
HISTORY_MIN_TURNS = 6

LENGTH_GUIDES = {
    "brief": "Answer briefly — 1-2 sentences, punchy, in your own voice.",
    "normal": "Answer in 2-5 sentences. Use your voice.",
    "expansive": "Answer richly — 4-8 sentences; you may ramble a little, "
                 "add sensory detail or an anecdote from your life.",
}


# --------------------------------------------------------------------------
# Sessions
# --------------------------------------------------------------------------

def list_sessions(*, mode: str | None = None, search: str | None = None,
                  limit: int = 100) -> list[dict[str, Any]]:
    """Sessions of the active project, newest activity first.

    When `search` is given, sessions also match if ANY message contains the
    query — the conversation body is searchable, not just the title.
    """
    with read_session() as s:
        pid = current_project_id(s)
        q = s.query(ChatSession).filter(ChatSession.project_id == pid)
        if mode:
            q = q.filter(ChatSession.mode == mode)
        if search:
            like = f"%{search}%"
            q = q.filter(or_(ChatSession.title.like(like),
                             ChatSession.character_ids.like(like)))
        rows = (q.order_by(ChatSession.pinned.desc(),
                           ChatSession.last_message_at.desc())
                .limit(limit).all())
        out = [session_dict(r) for r in rows]
        if search:
            # Message-content hits: sessions whose body mentions the query
            like = f"%{search}%"
            hits = (s.query(ChatMessage.session_id)
                    .filter(ChatMessage.content.like(like)).all())
            hit_ids = {h[0] for h in hits}
            known = {o["id"] for o in out}
            for sid in hit_ids - known:
                r = s.get(ChatSession, sid)
                if r is not None and r.project_id == pid:
                    out.append(session_dict(r))
            out.sort(key=lambda d: (d["pinned"], d["last_message_at"] or ""),
                     reverse=True)
    return out


def session_dict(r: ChatSession) -> dict[str, Any]:
    return {
        "id": r.id,
        "mode": r.mode,
        "title": r.title or "",
        "character_ids": r.participants,
        "chapter_id": r.chapter_id,
        "settings": load_json(r.settings, {}) or {},
        "pinned": bool(r.pinned),
        "message_count": r.message_count or 0,
        "last_message_at": (r.last_message_at.isoformat() + "Z")
        if r.last_message_at else None,
        "created_at": r.created_at.isoformat() + "Z" if r.created_at else None,
    }


def get_session(session_id: str) -> ChatSession:
    with read_session() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        return sess


def create_session(*, mode: str = "character",
                   character_ids: list[str] | None = None,
                   chapter_id: str | None = None,
                   settings: dict | None = None,
                   title: str = "") -> ChatSession:
    if mode not in MODES:
        raise ValidationError(f"mode must be one of {MODES}")
    # Accept both ids and Character objects (defensive — both are passed
    # around in callers/tests).
    ids = [getattr(c, "id", None) or str(c) for c in (character_ids or [])]
    ids = [c for c in ids if c]
    if mode in ("character", "group") and not ids:
        raise ValidationError("character chat needs at least one character")
    if mode == "character" and len(ids) > 1:
        mode = "group"  # 2+ characters is a group scene
    sid = new_uuid()
    with write_transaction() as s:
        sess = ChatSession(
            id=sid,
            project_id=current_project_id(s),
            mode=mode,
            title=(title or "")[:300],
            character_ids=",".join(ids),
            chapter_id=chapter_id,
            settings=dump_json(settings or {}),
            pinned=0,
            message_count=0,
        )
        s.add(sess)
        s.flush()
        return sess


def rename_session(session_id: str, title: str) -> ChatSession:
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        sess.title = (title or "").strip()[:300]
        s.flush()
        return sess


def set_pinned(session_id: str, pinned: bool) -> ChatSession:
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        sess.pinned = 1 if pinned else 0
        s.flush()
        return sess


def set_settings(session_id: str, settings: dict[str, Any]) -> ChatSession:
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        merged = load_json(sess.settings, {}) or {}
        merged.update({k: v for k, v in (settings or {}).items()})
        sess.settings = dump_json(merged)
        s.flush()
        return sess


def delete_session(session_id: str) -> None:
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        s.query(ChatMessage).filter(ChatMessage.session_id == session_id).delete()
        s.delete(sess)


def touch_session(session_id: str) -> None:
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if sess:
            sess.last_message_at = now_utc()


# --------------------------------------------------------------------------
# Messages
# --------------------------------------------------------------------------

def message_dict(m: ChatMessage) -> dict[str, Any]:
    return {
        "id": m.id,
        "session_id": m.session_id,
        "role": m.role,
        "speaker_id": m.speaker_id,
        "speaker_name": m.speaker_name,
        "content": m.content or "",
        "context_stats": load_json(m.context_stats, {}),
        "meta": load_json(m.meta, {}),
        "created_at": m.created_at.isoformat() + "Z" if m.created_at else None,
    }


def get_messages(session_id: str) -> list[dict[str, Any]]:
    with read_session() as s:
        rows = (s.query(ChatMessage)
                .filter(ChatMessage.session_id == session_id)
                .order_by(ChatMessage.created_at.asc(), ChatMessage.id.asc())
                .all())
        return [message_dict(m) for m in rows]


def add_message(session_id: str, *, role: str, content: str,
                speaker_id: str | None = None,
                speaker_name: str | None = None,
                context_stats: dict | None = None,
                meta: dict | None = None) -> dict[str, Any]:
    if role not in ("user", "assistant", "system"):
        raise ValidationError("role must be user/assistant/system")
    content = (content or "").strip()
    if not content:
        raise ValidationError("message content is empty")
    with write_transaction() as s:
        sess = s.get(ChatSession, session_id)
        if not sess:
            raise NotFoundError("Chat session not found.")
        m = ChatMessage(
            session_id=session_id,
            role=role,
            speaker_id=speaker_id,
            speaker_name=speaker_name,
            content=content,
            context_stats=dump_json(context_stats or {}),
            meta=dump_json(meta or {}),
        )
        s.add(m)
        sess.message_count = (sess.message_count or 0) + 1
        sess.last_message_at = now_utc()
        # Auto-title once: derive from the first user message
        if role == "user" and not (sess.title or "").strip():
            first = content.splitlines()[0][:80]
            sess.title = first
        s.flush()
        return message_dict(m)


def delete_message(message_id: int) -> int:
    """Delete a message AND everything after it in the same session.

    Returns how many messages were removed (for the toast)."""
    with write_transaction() as s:
        m = s.get(ChatMessage, message_id)
        if not m:
            raise NotFoundError("Message not found.")
        later = (s.query(ChatMessage)
                 .filter(ChatMessage.session_id == m.session_id,
                         ChatMessage.id >= m.id)
                 .all())
        count = len(later)
        for row in later:
            s.delete(row)
        sess = s.get(ChatSession, m.session_id)
        if sess:
            sess.message_count = max(0, (sess.message_count or 0) - count)
        return count


def last_ai_message(session_id: str) -> dict[str, Any] | None:
    """The most recent assistant turn — used by regenerate."""
    with read_session() as s:
        row = (s.query(ChatMessage)
               .filter(ChatMessage.session_id == session_id,
                       ChatMessage.role == "assistant")
               .order_by(ChatMessage.id.desc()).first())
        return message_dict(row) if row else None


def truncate_after_last_user(session_id: str) -> int:
    """Remove trailing assistant turns after the last user message.

    Used by “regenerate”: the user's question stays, the AI's answer is
    re-rolled from scratch. Returns how many messages were removed.
    """
    with write_transaction() as s:
        rows = (s.query(ChatMessage)
                .filter(ChatMessage.session_id == session_id)
                .order_by(ChatMessage.id.desc()).limit(10).all())
        rows = sorted(rows, key=lambda r: r.id, reverse=True)
        removed: list[ChatMessage] = []
        for r in rows:
            if r.role == "assistant" and not removed:
                removed.append(r)          # trailing AI reply(ies)
            elif r.role == "user":
                break                      # keep the question itself
            elif removed and r.role == "assistant":
                removed.append(r)
            else:
                break
        for r in removed:
            s.delete(r)
        sess = s.get(ChatSession, session_id)
        if sess:
            sess.message_count = max(0, (sess.message_count or 0) - len(removed))
        return len(removed)


# --------------------------------------------------------------------------
# History → prompt memory
# --------------------------------------------------------------------------

def build_history(session_id: str, *, speaker_names: dict[str, str] | None = None,
                  budget_chars: int = HISTORY_BUDGET_CHARS,
                  min_turns: int = HISTORY_MIN_TURNS) -> list[dict[str, Any]]:
    """Return the most recent turns that fit the budget, oldest first.

    THIS is the fix for the amnesia bug: the returned list is rendered into
    every new prompt, so the character remembers what was just said.
    """
    msgs = get_messages(session_id)
    turns = [m for m in msgs if m["role"] in ("user", "assistant") and m["content"]]
    picked: list[dict[str, Any]] = []
    total = 0
    for m in reversed(turns):
        cost = len(m["content"]) + 32
        if picked and total + cost > budget_chars and len(picked) >= min_turns:
            break
        picked.append(m)
        total += cost
    picked.reverse()
    return picked


def render_history(turns: list[dict[str, Any]],
                   speaker_names: dict[str, str] | None = None) -> str:
    """Render memory turns as a readable transcript block for the prompt."""
    names = speaker_names or {}
    lines: list[str] = []
    for m in turns:
        who = m["role"] == "user" and "User" or (m.get("speaker_name") or names.get(
            m.get("speaker_id") or "", "Character") or "Character")
        lines.append(f"{who}: {m['content']}")
    return "\n\n".join(lines)


# --------------------------------------------------------------------------
# Prompt assembly (character / group / assistant)
# --------------------------------------------------------------------------

def _char_block(char: Any, voice_summary: str = "") -> str:
    return (
        f"You ARE {char.name}, a {char.role or 'character'} in this story. "
        f"Answer as {char.name} would — first person, in character, never break the fourth wall.\n"
        f"CHARACTER BACKGROUND: {char.background or 'Unknown'}\n"
        f"PERSONALITY: {char.psychology or 'Complex'}\n"
        f"HOW YOU SPEAK: {voice_summary or char.voice or 'Speak naturally, in your own style'}"
    )


def build_character_prompt(*, char: Any, voice_summary: str,
                           context_block: str, history_block: str,
                           message: str, length: str = "normal") -> str:
    parts = [_char_block(char, voice_summary)]
    if context_block:
        parts.append(
            "=== STORY CONTEXT (you know all of this as {name}) ===\n{ctx}\n=== END CONTEXT ===".format(
                name=char.name, ctx=context_block))
    if history_block:
        parts.append(
            f"=== CONVERSATION SO FAR ===\n{history_block}\n=== END (stay consistent with it) ===")
    guide = LENGTH_GUIDES.get(length, LENGTH_GUIDES["normal"])
    parts.append(
        f"User says:\n\"{message}\"\n\n"
        f"Respond as {char.name}. {guide} "
        "Stay consistent with everything in the context and the conversation."
    )
    return "\n\n".join(parts)


def build_group_prompt(*, speaker: Any, others: list[Any],
                       voice_summary: str, context_block: str,
                       history_block: str, message: str,
                       length: str = "normal") -> str:
    """Director mode: one character answers, aware of who else is in the room."""
    others_desc = "; ".join(
        f"{o.name} ({o.role or 'character'})" for o in others) or "nobody else"
    parts = [
        _char_block(speaker, voice_summary),
        f"THIS IS A GROUP SCENE. Also present in the room: {others_desc}. "
        f"You may refer to them, agree or argue with what they said — "
        f"but ONLY you ({speaker.name}) speak in this reply. Never write "
        f"other characters' lines.",
    ]
    if context_block:
        parts.append(
            "=== STORY CONTEXT (you know all of this) ===\n{ctx}\n=== END CONTEXT ===".format(
                ctx=context_block))
    if history_block:
        parts.append(
            f"=== SCENE SO FAR ===\n{history_block}\n=== END (stay consistent) ===")
    guide = LENGTH_GUIDES.get(length, LENGTH_GUIDES["normal"])
    parts.append(
        f"User (the director) says:\n\"{message}\"\n\n"
        f"Reply as {speaker.name}. {guide}"
    )
    return "\n\n".join(parts)


ASSISTANT_SYSTEM = (
    "You are the AI Writing Assistant inside Absolute Story Manager — a sharp, "
    "encouraging co-writer. You know the story context below. Be concrete and "
    "useful: offer options, examples, and short samples when helpful. "
    "Answer in the user's language."
)


def build_assistant_prompt(*, context_block: str, history_block: str,
                           message: str) -> str:
    parts = [ASSISTANT_SYSTEM]
    if context_block:
        parts.append(f"=== STORY CONTEXT ===\n{context_block}\n=== END CONTEXT ===")
    if history_block:
        parts.append(
            f"=== CONVERSATION SO FAR ===\n{history_block}\n=== END (stay consistent) ===")
    parts.append(f"User: {message}\n\nAssistant:")
    return "\n\n".join(parts)


# --------------------------------------------------------------------------
# Transcript & export
# --------------------------------------------------------------------------

def session_to_markdown(session_id: str) -> str:
    """Full transcript as Markdown — used for copy & export-to-note."""
    sess = get_session(session_id)
    msgs = get_messages(session_id)
    title = sess.title or "Conversation"
    lines = [f"# {title}", ""]
    if sess.chapter_id:
        lines.append(f"_Anchored to chapter: {sess.chapter_id}_")
        lines.append("")
    for m in msgs:
        if m["role"] == "user":
            lines.append(f"**User:** {m['content']}")
        elif m["role"] == "assistant":
            who = m.get("speaker_name") or "AI"
            lines.append(f"**{who}:** {m['content']}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def export_to_note(session_id: str) -> dict[str, Any]:
    """Save the transcript as a Note so chat material joins the story vault."""
    from services.note_service import create_note
    sess = get_session(session_id)
    md = session_to_markdown(session_id)
    chars = ", ".join(sess.participants) if sess.participants else "assistant"
    note = create_note(
        title=f"Chat — {sess.title or 'conversation'}",
        body=md,
        category="scene_idea",  # chat material = story fuel
        tags=["chat", sess.mode] + ([chars] if chars != "assistant" else []),
    )
    with write_transaction() as s:
        log_activity(
            s, entity_type="note", entity_id=note.id,
            entity_title=note.title or "chat export", action="created",
            details={"source": "chat_export", "session": session_id},
        )
    return {"note_id": note.id, "title": note.title}


def count_messages(session_id: str) -> int:
    with read_session() as s:
        return (s.query(ChatMessage)
                .filter(ChatMessage.session_id == session_id).count())
