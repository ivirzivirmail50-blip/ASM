"""Storage & health service (v8.4).

Answers the question "how big is my data, and is it healthy?" with measured
numbers, and provides maintenance actions:
  - db_stats()      → file sizes, per-table row counts + bytes, version stats,
                      backup stats, health hints
  - vacuum()        → SQLite VACUUM (rebuilds file, reclaims free pages)
  - checkpoint()    → PRAGMA wal_checkpoint(TRUNCATE) (shrinks the -wal file)
  - optimize()      → PRAGMA optimize (refreshes planner statistics)
  - prune_versions()→ applies version_history_limit retention
  - prune_backups() → applies backup_retention_count

All actions return before/after numbers so the UI can show what happened.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from sqlalchemy import text

from config import Config
from core.db import engine, read_session, write_transaction
from models.settings import Setting
from services._common import now_utc

log = logging.getLogger("asm.storage")

# Default retention values (settings override these).
DEFAULT_VERSION_LIMIT = 25
DEFAULT_BACKUP_RETENTION = 14

# Tables whose text columns dominate DB size, with the columns to measure.
# v8.8 fix: "scenes"/"glossary"/"inspiration"/"milestones"/"voice_notes"
# were wrong table names — those rows silently never appeared in the report.
_TEXT_TABLES: dict[str, tuple[str, ...]] = {
    "chapters": ("content", "synopsis"),
    "chapter_versions": ("content",),
    "notes": ("body",),
    "chat_messages": ("content",),
    "characters": ("psychology", "background", "physical", "voice",
                   "notes"),
    "world_entries": ("content", "description"),
    "scene_cards": ("summary", "full_text"),
    "glossary_entries": ("definition",),
    "journal_entries": ("content",),
}

# Tables reported with row counts only.
_COUNT_TABLES: tuple[str, ...] = (
    "chat_sessions", "plans", "activity_log", "ai_history",
    "saved_inspirations", "milestone_celebrations", "beta_comments",
    "submissions", "references", "character_voices",
)


def _fmt_mb(n: float) -> float:
    return round(n / (1024 * 1024), 2)


def _db_path() -> Path:
    url = Config.SQLALCHEMY_DATABASE_URI
    if url.startswith("sqlite:///"):
        return Path(url.removeprefix("sqlite:///"))
    return Config.DB_PATH


def _file_size(p: Path) -> int:
    try:
        return p.stat().st_size
    except OSError:
        return 0


def version_limit(session) -> int:
    """Configured max versions kept per chapter (0 = unlimited)."""
    try:
        return int(Setting.get(session, "version_history_limit",
                                str(DEFAULT_VERSION_LIMIT)))
    except (TypeError, ValueError):
        return DEFAULT_VERSION_LIMIT


def backup_retention(session) -> int:
    """Configured max backups kept (0 = unlimited)."""
    try:
        return int(Setting.get(session, "backup_retention_count",
                                str(DEFAULT_BACKUP_RETENTION)))
    except (TypeError, ValueError):
        return DEFAULT_BACKUP_RETENTION


def db_stats() -> dict[str, Any]:
    """Collect storage statistics + health hints. Read-only, safe to call
    on the UI thread."""
    db_path = _db_path()
    wal_path = db_path.with_name(db_path.name + "-wal")
    shm_path = db_path.with_name(db_path.name + "-shm")

    stats: dict[str, Any] = {
        "generated_at": now_utc().isoformat(),
        "db": {
            "path": str(db_path),
            "bytes": _file_size(db_path),
            "mb": _fmt_mb(_file_size(db_path)),
        },
        "wal": {
            "bytes": _file_size(wal_path),
            "mb": _fmt_mb(_file_size(wal_path)),
        },
        "shm": {"bytes": _file_size(shm_path)},
        "tables": [],
        "versions": {},
        "backups": {},
        "hints": [],
    }

    with read_session() as s:
        # --- Per-table sizes -------------------------------------------
        for table, cols in _TEXT_TABLES.items():
            try:
                expr = " + ".join(
                    f"COALESCE(SUM(LENGTH({c})),0)" for c in cols
                )
                row = s.execute(text(
                    f"SELECT COUNT(*), {expr} FROM {table}"  # noqa: S608
                )).one()
                stats["tables"].append({
                    "table": table,
                    "rows": row[0],
                    "text_bytes": int(row[1] or 0),
                    "text_mb": _fmt_mb(int(row[1] or 0)),
                    "measured": True,
                })
            except Exception:
                # Table missing (e.g. older DB) — report rows only.
                try:
                    cnt = s.execute(text(
                        f"SELECT COUNT(*) FROM {table}"  # noqa: S608
                    )).scalar()
                    stats["tables"].append({
                        "table": table, "rows": cnt or 0,
                        "text_bytes": 0, "text_mb": 0.0, "measured": False,
                    })
                except Exception:
                    continue
        for table in _COUNT_TABLES:
            try:
                cnt = s.execute(text(
                    f"SELECT COUNT(*) FROM {table}"  # noqa: S608
                )).scalar()
                if cnt:
                    stats["tables"].append({
                        "table": table, "rows": cnt,
                        "text_bytes": 0, "text_mb": 0.0, "measured": False,
                    })
            except Exception:
                continue

        # --- Version stats ----------------------------------------------
        try:
            row = s.execute(text(
                "SELECT COUNT(*), COALESCE(SUM(LENGTH(content)),0), "
                "COALESCE(AVG(cnt),0), COALESCE(MAX(cnt),0) FROM ("
                "  SELECT content, COUNT(*) OVER (PARTITION BY chapter_id) "
                "    AS cnt FROM chapter_versions)"
            )).one()
            total_versions, version_bytes, avg_per_ch, max_per_ch = row
        except Exception:
            total_versions = version_bytes = avg_per_ch = max_per_ch = 0
        limit = version_limit(s)
        stats["versions"] = {
            "total": int(total_versions or 0),
            "text_bytes": int(version_bytes or 0),
            "text_mb": _fmt_mb(int(version_bytes or 0)),
            "avg_per_chapter": round(float(avg_per_ch or 0), 1),
            "max_per_chapter": int(max_per_ch or 0),
            "limit": limit,
            "prunable_estimate": _prunable_estimate(s, limit),
        }

        # --- Backups -----------------------------------------------------
        from services import backup_service
        backups = backup_service.list_backups()
        total_backup_bytes = sum(b["size"] for b in backups)
        stats["backups"] = {
            "count": len(backups),
            "total_bytes": total_backup_bytes,
            "total_mb": _fmt_mb(total_backup_bytes),
            "newest": backups[0]["mtime"] if backups else None,
            "oldest": backups[-1]["mtime"] if backups else None,
            "retention": backup_retention(s),
        }

    # --- Health hints ----------------------------------------------------
    db_mb = stats["db"]["mb"]
    wal_mb = stats["wal"]["mb"]
    if wal_mb > 32:
        stats["hints"].append({
            "level": "warn",
            "key": "wal_large",
            "message": (f"WAL file is {wal_mb} MB. Run 'Checkpoint WAL' to "
                        "shrink it — a large WAL slows startup and backups."),
        })
    if limit and stats["versions"]["prunable_estimate"] > 0:
        stats["hints"].append({
            "level": "info",
            "key": "versions_prunable",
            "message": (f"{stats['versions']['prunable_estimate']} old "
                        "chapter versions can be pruned."),
        })
    if (stats["backups"]["retention"]
            and stats["backups"]["count"] > stats["backups"]["retention"]):
        stats["hints"].append({
            "level": "info",
            "key": "backups_prunable",
            "message": (f"{stats['backups']['count']} backups exceed the "
                        f"retention limit of {stats['backups']['retention']}."),
        })
    if db_mb > 200:
        stats["hints"].append({
            "level": "info",
            "key": "db_large",
            "message": (f"Database is {db_mb} MB. Consider pruning versions "
                        "and running VACUUM to reclaim space."),
        })
    if not stats["hints"]:
        stats["hints"].append({
            "level": "ok", "key": "healthy",
            "message": "All storage health checks passed.",
        })
    return stats


def _prunable_estimate(session, limit: int) -> int:
    """How many version rows would be deleted by prune_versions().

    Per chapter: count - limit - 1 (the -1 accounts for version #1, which is
    always kept). Pinned rows make this a slight overestimate — it's a hint,
    not an invoice.
    """
    if not limit:
        return 0
    try:
        return int(session.execute(text(
            "SELECT COALESCE(SUM(c - :lim), 0) FROM ("
            "  SELECT chapter_id, COUNT(*) AS c FROM chapter_versions "
            "  GROUP BY chapter_id HAVING c > :lim)"
        ), {"lim": limit + 1}).scalar() or 0)
    except Exception:
        return 0


def vacuum() -> dict[str, Any]:
    """Run VACUUM — rebuilds the DB file, reclaiming free pages.

    Cannot run inside a transaction; runs on a raw connection.
    Returns before/after sizes.
    """
    db_path = _db_path()
    before = _file_size(db_path)
    with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
        # Flush WAL into the main file first so VACUUM sees everything.
        conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
        conn.execute(text("VACUUM"))
        # VACUUM itself writes through the WAL — checkpoint again so the
        # user doesn't trade file size for journal size.
        conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
        conn.execute(text("PRAGMA optimize"))
    after = _file_size(db_path)
    log.info("VACUUM: %.1f MB → %.1f MB", before / 1e6, after / 1e6)
    return {
        "before_bytes": before, "after_bytes": after,
        "before_mb": _fmt_mb(before), "after_mb": _fmt_mb(after),
        "reclaimed_mb": _fmt_mb(max(0, before - after)),
    }


def checkpoint() -> dict[str, Any]:
    """Checkpoint + truncate the WAL file. Returns before/after WAL size."""
    wal_path = _db_path().with_name(_db_path().name + "-wal")
    before = _file_size(wal_path)
    with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
        conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
    after = _file_size(wal_path)
    return {
        "before_bytes": before, "after_bytes": after,
        "before_mb": _fmt_mb(before), "after_mb": _fmt_mb(after),
    }


def _prune_versions_in_session(s, *, chapter_id: str | None = None) -> dict[str, Any]:
    """Retention logic on an EXISTING session (no own transaction).

    This is the form chapter_service.update_chapter() calls — opening a
    nested write_transaction() there would commit/remove the caller's
    session mid-flight (the v8.3 fixture bug, in production form).
    """
    # v9.1.0 (M-03): the caller adds the new ChapterVersion via s.add()
    # WITHOUT flushing. The old Setting.get() query used to autoflush it as
    # an accidental side effect; with the settings snapshot serving reads
    # without a query, that autoflush disappeared and the prune SELECT saw
    # a stale version list (one extra version survived every save). Flush
    # explicitly — retention must not depend on another query's side effect.
    s.flush()

    limit = version_limit(s)
    if not limit:
        return {"deleted": 0, "reclaimed_mb": 0.0, "limit": 0}

    if chapter_id:
        rows = s.execute(text(
            "SELECT id, version_number, LENGTH(content), is_pinned "
            "FROM chapter_versions WHERE chapter_id = :cid "
            "ORDER BY version_number DESC"
        ), {"cid": chapter_id}).all()
        groups: dict[str, list] = {chapter_id: [tuple(r) for r in rows]}
    else:
        rows = s.execute(text(
            "SELECT chapter_id, id, version_number, LENGTH(content), "
            "is_pinned FROM chapter_versions "
            "ORDER BY chapter_id, version_number DESC"
        )).all()
        groups = {}
        for r in rows:
            groups.setdefault(r[0], []).append(tuple(r[1:]))

    deleted = 0
    freed = 0
    for _, versions in groups.items():
        kept = 0
        for (vid, vnum, clen, pinned) in versions:
            # versions are ordered newest → oldest
            if vnum == 1 or pinned:
                continue  # always keep originals + pinned
            kept += 1
            if kept > limit:
                deleted += 1
                freed += int(clen or 0)
                s.execute(text(
                    "DELETE FROM chapter_versions WHERE id = :vid"
                ), {"vid": vid})
    return {
        "deleted": deleted,
        "reclaimed_mb": _fmt_mb(freed),
        "limit": limit,
    }


def prune_versions(*, chapter_id: str | None = None) -> dict[str, Any]:
    """Apply version retention (own transaction — for routes/tests).

    Keeps, per chapter:
      - the newest `version_history_limit` versions
      - version #1 (the original draft) — the author's safety net
      - any pinned version
    Returns deleted row count + estimated reclaimed bytes.
    """
    with write_transaction() as s:
        result = _prune_versions_in_session(s, chapter_id=chapter_id)
    if result["deleted"]:
        log.info("Version prune: %d rows, ~%.1f MB reclaimed",
                 result["deleted"], result["reclaimed_mb"])
    return result


def prune_backups(*, keep: int | None = None) -> dict[str, Any]:
    """Delete oldest backups beyond the retention count. Returns stats."""
    from services import backup_service
    with read_session() as s:
        keep_n = keep if keep is not None else backup_retention(s)
    if not keep_n:
        return {"deleted": 0, "freed_mb": 0.0, "keep": 0}
    backups = backup_service.list_backups()  # newest first
    victims = backups[keep_n:]
    freed = 0
    for b in victims:
        try:
            Path(b["path"]).unlink()
            freed += b["size"]
        except OSError:
            continue
    return {
        "deleted": len(victims),
        "freed_mb": _fmt_mb(freed),
        "keep": keep_n,
    }
