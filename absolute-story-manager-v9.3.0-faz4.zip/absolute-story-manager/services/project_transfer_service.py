"""Project transfer service — full-fidelity JSON export/import (v7.5).

WHY THIS EXISTS
---------------
The old ``/settings/export-json`` route exported only a subset of tables and
NEVER exported the project row itself — so a user moving their data to a new
version lost their **book name** (genre, target words, deadline, color) and
**all notes**. v7.5 replaces it with this table-driven service:

* Exports EVERY user-content table (projects, chapters, scenes, characters,
  world, notes, journal, glossary, references, plans, milestones,
  achievements, submissions, beta comments, writing sessions, ...).
* Exports settings with the AI API key stripped.
* Generic, column-driven serialisation — a new model only has to be added to
  ``CONTENT_TABLES`` to become portable.
* Import is idempotent (rows are matched by primary key, existing rows are
  kept), backward compatible with v4 exports (``"version": "asm-v4"``),
  and never blanks the stored API key.

Deliberately NOT exported (machine-generated / ephemeral):
``undo_operations``, ``activity_log``, ``ai_history``, FTS shadow tables.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import Date, DateTime

log = logging.getLogger("asm.project_transfer")

EXPORT_SCHEMA_VERSION = "asm-v7.5"

# Ordered — parents before children so an import never breaks FK order.
# (key in JSON, model class)
CONTENT_TABLES: list[tuple[str, Any]] = []

def _build_content_tables() -> list[tuple[str, Any]]:
    from models.achievement import UnlockedAchievement
    from models.beta_comment import BetaComment
    from models.chapter import Chapter, ChapterVersion
    from models.chapter_deps import ChapterDependency
    from models.char_location_pin import CharacterLocationPin
    from models.char_mood import CharacterMood
    from models.character import (
        Character,
        CharacterArc,
        CharacterGroup,
        CharacterGroupMember,
        CharacterRelationship,
    )
    from models.glossary import GlossaryEntry
    from models.inspiration import SavedInspiration
    from models.journal import JournalEntry
    from models.milestone import MilestoneCelebration
    from models.note import Note
    from models.plan import Plan, PlanSubtask
    from models.project import Project
    from models.reference import Reference
    from models.scene import SceneCard
    from models.session import WritingSession
    from models.spellcheck import CustomWord
    from models.submission import Submission
    from models.travel_route import TravelRoute
    from models.voice import CharacterVoice
    from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion

    return [
        ("projects", Project),                       # ← book names/metadata (the v7.4 bug)
        ("chapters", Chapter),
        ("chapter_versions", ChapterVersion),
        ("chapter_dependencies", ChapterDependency),
        ("scenes", SceneCard),
        ("characters", Character),
        ("character_groups", CharacterGroup),
        ("character_group_members", CharacterGroupMember),
        ("character_relationships", CharacterRelationship),
        ("character_arcs", CharacterArc),
        ("character_moods", CharacterMood),
        ("character_voices", CharacterVoice),
        ("plans", Plan),
        ("plan_subtasks", PlanSubtask),
        ("world_entries", WorldEntry),
        ("world_entry_versions", WorldEntryVersion),
        ("world_relations", WorldEntryRelation),
        ("travel_routes", TravelRoute),
        # v7.6 Story Atlas pins — FKs to characters/world_entries/chapters,
        # so it must sit AFTER all three parents in this order.
        ("character_location_pins", CharacterLocationPin),
        ("notes", Note),                             # ← notes (the v7.4 bug)
        ("journal_entries", JournalEntry),
        ("references", Reference),
        ("glossary_entries", GlossaryEntry),
        ("saved_inspirations", SavedInspiration),
        ("milestone_celebrations", MilestoneCelebration),
        ("unlocked_achievements", UnlockedAchievement),
        ("submissions", Submission),
        ("beta_comments", BetaComment),
        ("writing_sessions", WritingSession),
        ("custom_words", CustomWord),
    ]


CONTENT_TABLES = _build_content_tables()

# v4 export keys → current model, so old files keep importing.
_LEGACY_KEY_MAP = {
    "chapter_versions": "chapter_versions",
    "world_entry_versions": "world_entry_versions",
    "world_relations": "world_relations",
}


def _row_to_dict(obj) -> dict:
    """Serialise a model row using its column names."""
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


def _coerce_value(column, value):
    """Convert an imported JSON scalar back to the column's Python type."""
    if value is None:
        return None
    if isinstance(column.type, DateTime):
        if isinstance(value, datetime):
            return value
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    if isinstance(column.type, Date):
        if isinstance(value, date) and not isinstance(value, datetime):
            return value
        try:
            return date.fromisoformat(str(value)[:10])
        except (ValueError, TypeError):
            return None
    if isinstance(value, bool) and column.type.python_type is int:
        return int(value)
    return value


def export_all() -> dict:
    """Build the complete portable project-data dict."""
    from core.db import read_session
    from models.settings import Setting

    data: dict[str, Any] = {
        "version": EXPORT_SCHEMA_VERSION,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "settings": {},
    }
    with read_session() as s:
        data["settings"] = Setting.all_settings(s)
        # Never ship the API key.
        data["settings"]["ai.api_key"] = ""
        for key, model in CONTENT_TABLES:
            rows = [_row_to_dict(r) for r in s.query(model).all()]
            data[key] = rows
    # v9.0.1 (S-03) — media manifest: binary media files can't ride inside
    # the JSON transfer file, so we list them here and ship them separately
    # via export_media_bundle(). import_all() ignores this key gracefully.
    data["media_files"] = media_manifest()
    return data


def media_manifest() -> list[dict[str, Any]]:
    """S-03: describe every file under data/media/ (path, size, mtime)."""
    from config import Config

    files: list[dict[str, Any]] = []
    if not Config.MEDIA_DIR.exists():
        return files
    for f in sorted(Config.MEDIA_DIR.rglob("*")):
        if f.is_file():
            try:
                st = f.stat()
            except OSError:
                continue
            files.append({
                "path": str(f.relative_to(Config.MEDIA_DIR)).replace("\\", "/"),
                "size": st.st_size,
            })
    return files


def export_media_bundle(dest_path=None) -> Path:
    """S-03: write a ZIP of data/media/ for full-project transfer.

    Binary media (map images, avatars, music) can't live inside the JSON
    export; this bundle is the companion artefact. Arcnames are relative to
    ``media/`` so an import on any OS lands in the same layout.
    """
    import zipfile

    from config import Config

    if dest_path is None:
        dest_path = Config.EXPORT_DIR / "asm_media_bundle.zip"
    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(dest_path, "w", zipfile.ZIP_DEFLATED) as zf:
        if Config.MEDIA_DIR.exists():
            for f in sorted(Config.MEDIA_DIR.rglob("*")):
                if f.is_file():
                    zf.write(f, arcname=str(
                        f.relative_to(Config.MEDIA_DIR)).replace("\\", "/"))
                    count += 1
    log.info("Media bundle written: %s (%d files)", dest_path, count)
    return dest_path


def import_media_bundle(zip_path) -> dict:
    """S-03: extract a media bundle ZIP into data/media/.

    Returns {"imported": n, "skipped": m} — entries attempting to escape
    data/media/ (path traversal) are skipped and logged.
    """
    import zipfile

    from config import Config

    p = Path(zip_path)
    if not p.exists():
        raise FileNotFoundError(p)
    imported = skipped = 0
    media_root = Config.MEDIA_DIR.resolve()
    with zipfile.ZipFile(p, "r") as zf:
        for member in zf.namelist():
            if member.endswith("/"):
                continue  # directory entry
            target = (Config.MEDIA_DIR / member).resolve()
            if not str(target).startswith(str(media_root)):
                log.warning("import_media_bundle: skipping traversal: %s", member)
                skipped += 1
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as dst:
                dst.write(src.read())
            imported += 1
    log.info("Media bundle imported: %s (imported=%d skipped=%d)",
             p, imported, skipped)
    return {"imported": imported, "skipped": skipped}


def _update_project_metadata(existing, row: dict) -> bool:
    """v8.2: apply book metadata (name/subtitle/genre/target/deadline/color)
    from an import file onto an existing project row.

    Returns True when at least one field actually changed. Empty/None values
    in the file do NOT blank fields that are already set — the goal is to
    carry the book name forward, not to erase metadata.
    """
    changed = False
    col_types = {c.name: c for c in existing.__table__.columns}
    for col in ("name", "subtitle", "genre", "target_words", "deadline", "color"):
        new_val = row.get(col)
        if new_val in (None, ""):
            continue
        try:
            new_val = _coerce_value(col_types.get(col), new_val)
        except Exception:
            pass
        if new_val in (None, ""):
            continue
        old_val = getattr(existing, col, None)
        if old_val != new_val:
            try:
                setattr(existing, col, new_val)
                changed = True
            except Exception:  # pragma: no cover — defensive
                pass
    return changed


def import_all(data: dict, *, skip_settings: bool = False) -> dict:
    """Import a portable project-data dict.

    * Creates missing projects / rows; existing primary keys are kept
      (idempotent — re-importing never duplicates).
    * Settings are merged; a blank ``ai.api_key`` never overwrites a stored
      key.
    Returns per-table counts of *newly created* rows.
    """
    from core.db import write_transaction
    from models.settings import Setting

    counts: dict[str, int] = {}

    # Legacy v4 files carry the project as a singular dict — normalise.
    if "projects" not in data and isinstance(data.get("project"), dict):
        data = dict(data)
        data["projects"] = [data["project"]]

    with write_transaction() as s:
        # ---- settings -------------------------------------------------------
        if not skip_settings and isinstance(data.get("settings"), dict):
            for k, v in data["settings"].items():
                if k == "ai.api_key" and not v:
                    continue  # never blank the stored key
                Setting.set(s, k, v)

        # ---- content tables --------------------------------------------------
        for key, model in CONTENT_TABLES:
            rows = data.get(key)
            if rows is None:
                # legacy v4 files used slightly different key sets — try map
                rows = data.get(_LEGACY_KEY_MAP.get(key, key), [])
            if not isinstance(rows, list):
                continue
            created = 0
            pk_cols = [c.name for c in model.__table__.primary_key.columns]
            for row in rows:
                if not isinstance(row, dict):
                    continue
                try:
                    pk_vals = tuple(row.get(pk) for pk in pk_cols)
                    if any(v is None for v in pk_vals):
                        continue
                    existing = s.get(model, *pk_vals)
                    if existing is not None:
                        # v8.2: the file is the source of truth for BOOK
                        # METADATA. Previously an existing project row was
                        # skipped wholesale, so importing a full export into
                        # a database that already had the same project id
                        # silently kept the OLD book name/genre/target —
                        # "the book name never comes through the import".
                        # Only user-facing metadata columns are touched;
                        # chapters/characters/etc. stay idempotent (merged).
                        if key == "projects":
                            updated = _update_project_metadata(existing, row)
                            if updated:
                                counts.setdefault("projects_updated", 0)
                                counts["projects_updated"] += 1
                        continue
                    kwargs = {}
                    for col in model.__table__.columns:
                        if col.name not in row:
                            continue
                        kwargs[col.name] = _coerce_value(col, row[col.name])
                    if not kwargs:
                        continue
                    # Per-row SAVEPOINT: one bad row (bad type, orphan FK,
                    # constraint violation) rolls back only itself instead of
                    # aborting the whole import. It also flushes immediately,
                    # which guarantees the parent-first ordering of
                    # CONTENT_TABLES actually holds against FK checks.
                    obj = model(**kwargs)
                    try:
                        with s.begin_nested():
                            s.add(obj)
                        created += 1
                    except Exception as exc:
                        try:  # make sure the failed object is fully discarded
                            s.expunge(obj)
                        except Exception:
                            pass
                        log.warning("import_all: skipped bad %s row (id=%s): %s",
                                    key, row.get("id"), exc)
                except Exception as exc:  # malformed row structure
                    log.warning("import_all: skipping malformed %s row (%s): %s",
                                key, str(row)[:120], exc)
            counts[key] = created

    return counts


def export_summary(data: dict) -> dict:
    """Human-readable summary of an export payload (for toasts/tests)."""
    return {
        key: len(data.get(key) or [])
        for key, _model in CONTENT_TABLES
    }
