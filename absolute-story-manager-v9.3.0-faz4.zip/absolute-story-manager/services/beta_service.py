"""Beta reader comment service — with threaded replies."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import func, select

from core.db import read_session, write_transaction
from core.errors import NotFoundError, ValidationError
from models.beta_comment import BetaComment

log = logging.getLogger("asm.beta")


def list_comments(chapter_id: str) -> list[BetaComment]:
    with read_session() as s:
        return list(s.scalars(
            select(BetaComment).where(BetaComment.chapter_id == chapter_id)
            .order_by(BetaComment.position.asc(), BetaComment.created_at.asc())
        ).all())


def list_top_level(chapter_id: str) -> list[BetaComment]:
    """Return only top-level comments (no parent), ordered by position."""
    with read_session() as s:
        return list(s.scalars(
            select(BetaComment).where(
                BetaComment.chapter_id == chapter_id,
                BetaComment.parent_id.is_(None),
            ).order_by(BetaComment.position.asc(), BetaComment.created_at.asc())
        ).all())


def list_replies(parent_id: int) -> list[BetaComment]:
    """Return all replies to a given comment, ordered chronologically."""
    with read_session() as s:
        return list(s.scalars(
            select(BetaComment).where(BetaComment.parent_id == parent_id)
            .order_by(BetaComment.created_at.asc())
        ).all())


def get_comment(comment_id: int) -> BetaComment:
    with read_session() as s:
        c = s.get(BetaComment, comment_id)
        if not c:
            raise NotFoundError("Comment not found.")
        return c


def add_comment(chapter_id: str, comment: str, *, reader_name: str = "Beta Reader",
                selected_text: str = "", position: int = 0) -> BetaComment:
    with write_transaction() as s:
        c = BetaComment(
            chapter_id=chapter_id, reader_name=reader_name,
            comment=comment, selected_text=selected_text,
            position=position, status="open",
        )
        s.add(c)
        s.flush()
        return c


def add_reply(parent_id: int, comment: str, *, reader_name: str = "Author",
              is_author_reply: bool = True) -> BetaComment:
    """Add a reply to an existing comment."""
    if not comment.strip():
        raise ValidationError("Reply text required.")
    with write_transaction() as s:
        parent = s.get(BetaComment, parent_id)
        if not parent:
            raise NotFoundError("Parent comment not found.")
        reply = BetaComment(
            chapter_id=parent.chapter_id,
            reader_name=reader_name,
            comment=comment,
            selected_text="",  # replies don't have their own selection
            position=parent.position,  # inherit parent's position
            status="open",
            parent_id=parent_id,
            is_author_reply=is_author_reply,
        )
        s.add(reply)
        s.flush()
        return reply


def resolve_comment(comment_id: int) -> BetaComment:
    """Resolve a comment and all its replies."""
    with write_transaction() as s:
        c = s.get(BetaComment, comment_id)
        if not c:
            raise NotFoundError("Comment not found.")
        c.status = "resolved"
        # Also resolve all replies
        replies = list(s.scalars(
            select(BetaComment).where(BetaComment.parent_id == comment_id)
        ))
        for r in replies:
            r.status = "resolved"
        s.flush()
        return c


def reopen_comment(comment_id: int) -> BetaComment:
    """Reopen a resolved comment."""
    with write_transaction() as s:
        c = s.get(BetaComment, comment_id)
        if not c:
            raise NotFoundError("Comment not found.")
        c.status = "open"
        s.flush()
        return c


def delete_comment(comment_id: int) -> None:
    """Delete a comment and all its replies."""
    with write_transaction() as s:
        c = s.get(BetaComment, comment_id)
        if c:
            # Delete all replies first (flush to avoid FK constraint issues)
            replies = list(s.scalars(
                select(BetaComment).where(BetaComment.parent_id == comment_id)
            ))
            for r in replies:
                s.delete(r)
            s.flush()  # ensure replies are deleted before parent
            s.delete(c)


def count_open(chapter_id: str) -> int:
    with read_session() as s:
        return s.query(BetaComment).filter_by(
            chapter_id=chapter_id, status="open"
        ).count()


def count_all(chapter_id: str) -> int:
    with read_session() as s:
        return s.query(BetaComment).filter_by(
            chapter_id=chapter_id
        ).count()


def to_dict(c: BetaComment, *, include_replies: bool = False) -> dict[str, Any]:
    d = {
        "id": c.id,
        "chapter_id": c.chapter_id,
        "reader_name": c.reader_name,
        "selected_text": c.selected_text or "",
        "comment": c.comment,
        "position": c.position or 0,
        "status": c.status,
        "parent_id": c.parent_id,
        "is_author_reply": bool(c.is_author_reply),
        "is_top_level": c.parent_id is None,
        "created_at": c.created_at.isoformat() if c.created_at else None,
    }
    if include_replies and c.parent_id is None:
        replies = list_replies(c.id)
        d["replies"] = [to_dict(r) for r in replies]
        d["reply_count"] = len(replies)
    return d


def get_threaded(chapter_id: str) -> list[dict[str, Any]]:
    """Return comments as threaded structure: top-level comments with nested replies."""
    top_level = list_top_level(chapter_id)
    return [to_dict(c, include_replies=True) for c in top_level]


def stats(chapter_id: str) -> dict[str, Any]:
    """Aggregate stats for a chapter's comments."""
    all_comments = list_comments(chapter_id)
    top_level = [c for c in all_comments if c.parent_id is None]
    replies = [c for c in all_comments if c.parent_id is not None]
    open_count = sum(1 for c in all_comments if c.status == "open")
    resolved_count = sum(1 for c in all_comments if c.status == "resolved")
    author_replies = sum(1 for c in all_comments if c.is_author_reply)
    return {
        "total": len(all_comments),
        "top_level": len(top_level),
        "replies": len(replies),
        "open": open_count,
        "resolved": resolved_count,
        "author_replies": author_replies,
    }


# ============================================================================
# v8.9 — Review Loop: Beta Hub · Read Progress · Feedback Inbox · AI assist
# ============================================================================

def _project_chapters(s) -> list:
    """Chapters of the ACTIVE project, in sort order (for project-scoped views)."""
    from models.chapter import Chapter
    from services._common import current_project_id
    pid = current_project_id(s)
    return list(s.scalars(
        select(Chapter).where(Chapter.project_id == pid)
        .order_by(Chapter.sort_order.asc())
    ))


def _rel_time(dt) -> str:
    """Small human 'x min ago / x h ago / date' helper for hub + inbox."""
    if not dt:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - dt
    secs = int(delta.total_seconds())
    if secs < 60:
        return "just now"
    if secs < 3600:
        return f"{secs // 60}m ago"
    if secs < 86400:
        return f"{secs // 3600}h ago"
    if secs < 86400 * 7:
        return f"{secs // 86400}d ago"
    return dt.strftime("%Y-%m-%d")


def hub_data() -> dict[str, Any]:
    """Everything the Beta Review Hub page needs (chapters, readers, progress)."""
    from models.beta_comment import BetaReadProgress
    from models.chapter import Chapter

    with read_session() as s:
        chapters = _project_chapters(s)
        ids = [ch.id for ch in chapters]
        comments: list[BetaComment] = []
        progress: list[BetaReadProgress] = []
        if ids:
            comments = list(s.scalars(
                select(BetaComment).where(BetaComment.chapter_id.in_(ids))
            ))
            progress = list(s.scalars(
                select(BetaReadProgress).where(
                    BetaReadProgress.chapter_id.in_(ids))
            ))

        # ---- per-chapter rows ----
        rows = []
        for ch in chapters:
            cc = [c for c in comments if c.chapter_id == ch.id]
            open_n = sum(1 for c in cc if c.status == "open")
            resolved_n = sum(1 for c in cc if c.status == "resolved")
            # author replies are content, not a reader identity
            readers = sorted({c.reader_name for c in cc
                              if not c.is_author_reply})
            read_by = sorted({p.reader_name for p in progress
                              if p.chapter_id == ch.id})
            last = max((c.created_at for c in cc), default=None)
            rows.append({
                "id": ch.id,
                "title": ch.title,
                "index": ch.sort_order,
                "word_count": ch.word_count or 0,
                "total": len(cc),
                "open": open_n,
                "resolved": resolved_n,
                "readers": readers,
                "read_by": read_by,
                "last_activity": _rel_time(last),
                "url": f"/beta/{ch.id}",
            })

        # ---- per-reader cards (author replies are not beta readers) ----
        reader_map: dict[str, dict] = {}
        for c in comments:
            if c.is_author_reply:
                continue
            r = reader_map.setdefault(c.reader_name, {
                "name": c.reader_name, "comments": 0, "open": 0,
                "chapters_touched": set(),
            })
            r["comments"] += 1
            if c.status == "open":
                r["open"] += 1
            r["chapters_touched"].add(c.chapter_id)
        for name in list(reader_map.keys()):
            reader_map[name]["chapters_touched"] = len(
                reader_map[name]["chapters_touched"])
        # reading progress per reader (chapters finished)
        progress_map: dict[str, set] = {}
        for p in progress:
            progress_map.setdefault(p.reader_name, set()).add(p.chapter_id)
        readers_out = []
        for name in sorted(reader_map.keys()):
            r = dict(reader_map[name])
            done = len(progress_map.get(name, set()))
            r["read_count"] = done
            r["read_percent"] = round(done * 100 / len(chapters)) if chapters else 0
            readers_out.append(r)
        # readers who only marked progress (no comments yet) still shown
        for name in sorted(progress_map.keys()):
            if name not in reader_map:
                done = len(progress_map[name])
                readers_out.append({
                    "name": name, "comments": 0, "open": 0,
                    "chapters_touched": 0, "read_count": done,
                    "read_percent": round(done * 100 / len(chapters))
                    if chapters else 0,
                })
        readers_out.sort(key=lambda r: (-r["read_count"], -r["comments"]))

        total = len(comments)
        open_total = sum(1 for c in comments if c.status == "open")
        resolved_total = total - open_total
        return {
            "chapters_total": len(chapters),
            "chapters_with_feedback": sum(1 for r in rows if r["total"]),
            "chapters_fully_read": sum(1 for r in rows if r["read_by"]),
            "total_comments": total,
            "open": open_total,
            "resolved": resolved_total,
            "resolution_rate": round(resolved_total * 100 / total) if total else 0,
            "author_replies": sum(1 for c in comments if c.is_author_reply),
            "chapters": rows,
            "readers": readers_out,
        }


# ---- Read progress ----

def mark_read(chapter_id: str, reader_name: str) -> dict[str, Any]:
    """Upsert a read-progress row for (chapter, reader). Returns progress info."""
    from models.beta_comment import BetaReadProgress
    from services._common import now_utc
    reader_name = (reader_name or "").strip() or "Beta Reader"
    with write_transaction() as s:
        row = s.scalar(select(BetaReadProgress).where(
            BetaReadProgress.chapter_id == chapter_id,
            BetaReadProgress.reader_name == reader_name,
        ))
        if row:
            row.completed_at = now_utc()
        else:
            row = BetaReadProgress(chapter_id=chapter_id,
                                   reader_name=reader_name,
                                   completed_at=now_utc())
            s.add(row)
        s.flush()
        chapters = _project_chapters(s)
        done = s.scalar(select(func.count(BetaReadProgress.id)).where(
            BetaReadProgress.reader_name == reader_name))
        return {"reader": reader_name, "chapter_id": chapter_id,
                "read_count": int(done or 0),
                "chapters_total": len(chapters)}


def mark_unread(chapter_id: str, reader_name: str) -> dict[str, Any]:
    """Remove a read-progress row for (chapter, reader)."""
    from sqlalchemy import func

    from models.beta_comment import BetaReadProgress
    reader_name = (reader_name or "").strip()
    with write_transaction() as s:
        row = s.scalar(select(BetaReadProgress).where(
            BetaReadProgress.chapter_id == chapter_id,
            BetaReadProgress.reader_name == reader_name,
        ))
        if row:
            s.delete(row)
            s.flush()
        chapters = _project_chapters(s)
        done = s.scalar(select(func.count(BetaReadProgress.id)).where(
            BetaReadProgress.reader_name == reader_name))
        return {"reader": reader_name, "chapter_id": chapter_id,
                "read_count": int(done or 0),
                "chapters_total": len(chapters)}


def read_progress(reader_name: str) -> dict[str, Any]:
    """Which chapters has this reader finished (for the reader 2.0 view)."""
    from models.beta_comment import BetaReadProgress
    with read_session() as s:
        chapters = _project_chapters(s)
        ids = [ch.id for ch in chapters]
        done_ids: set = set()
        if ids:
            rows = list(s.scalars(select(BetaReadProgress).where(
                BetaReadProgress.chapter_id.in_(ids),
                BetaReadProgress.reader_name == reader_name,
            )))
            done_ids = {r.chapter_id for r in rows}
        return {
            "reader": reader_name,
            "read_count": len(done_ids),
            "chapters_total": len(chapters),
            "read_ids": sorted(done_ids),
        }


# ---- Feedback Inbox ----

def list_all(*, status: str | None = None, reader: str | None = None,
             chapter_id: str | None = None, q: str | None = None) -> list[dict]:
    """Flat list of ALL comments across the active project's chapters.

    Returns top-level comments with reply counts + chapter context, newest
    first (fallback: chapter order). Powers the Feedback Inbox.
    """
    with read_session() as s:
        chapters = _project_chapters(s)
        title_map = {ch.id: (ch.title, i + 1) for i, ch in enumerate(chapters)}
        ids = list(title_map.keys())
        if not ids:
            return []
        stmt = select(BetaComment).where(
            BetaComment.chapter_id.in_(ids),
            BetaComment.parent_id.is_(None),
        )
        if status and status in ("open", "resolved"):
            stmt = stmt.where(BetaComment.status == status)
        if reader:
            stmt = stmt.where(BetaComment.reader_name == reader)
        if chapter_id:
            stmt = stmt.where(BetaComment.chapter_id == chapter_id)
        comments = list(s.scalars(stmt))
        # Reply counts for each top-level comment
        replies = list(s.scalars(select(BetaComment).where(
            BetaComment.parent_id.is_not(None))))
        reply_counts: dict[int, int] = {}
        for r in replies:
            if r.parent_id:
                reply_counts[r.parent_id] = reply_counts.get(r.parent_id, 0) + 1

        out = []
        for c in comments:
            if q and q.lower() not in (c.comment or "").lower() \
                    and q.lower() not in (c.selected_text or "").lower():
                continue
            ch_title, ch_index = title_map.get(c.chapter_id, ("?", 0))
            out.append({
                "id": c.id, "chapter_id": c.chapter_id,
                "chapter_title": ch_title, "chapter_index": ch_index,
                "reader": c.reader_name, "status": c.status,
                "selected_text": c.selected_text or "",
                "comment": c.comment, "position": c.position or 0,
                "reply_count": reply_counts.get(c.id, 0),
                "is_author_reply": bool(c.is_author_reply),
                "created_at": c.created_at,
                "created_rel": _rel_time(c.created_at),
            })
        # Chapter order, then oldest first within a chapter
        out.sort(key=lambda d: (d["chapter_index"],
                                d["created_at"] or datetime.min.replace(tzinfo=timezone.utc)))
        return out


def list_readers() -> list[str]:
    """Distinct beta reader names across the active project (filter dropdowns).

    Author replies don't count — the author is not a beta reader.
    """
    with read_session() as s:
        ids = [ch.id for ch in _project_chapters(s)]
        if not ids:
            return []
        comments = list(s.scalars(
            select(BetaComment.reader_name).where(
                BetaComment.chapter_id.in_(ids),
                BetaComment.is_author_reply.is_(False)).distinct()))
        return sorted({r for r in comments if r})


# ---- Feedback export ----

def export_feedback(fmt: str, *, chapter_id: str | None = None,
                    status: str | None = None, reader: str | None = None,
                    q: str | None = None) -> tuple[bytes, str, str]:
    """Export feedback as MD / CSV / JSON.

    chapter_id=None exports the whole active project's feedback.
    """
    import csv as _csv
    import io as _io
    import json as _json

    from models.settings import Setting
    from services._common import current_project_id

    fmt = (fmt or "").lower()
    if fmt not in ("md", "csv", "json"):
        raise ValidationError("Format must be one of: md, csv, json.")

    if chapter_id:
        from services.chapter_service import get_chapter
        ch = get_chapter(chapter_id)
        book_title = ch.title
    else:
        with read_session() as s:
            pid = current_project_id(s)
            from models.project import Project
            proj = s.get(Project, pid)
            book_title = (proj.name if proj else None) or "Story"

    items = list_all(status=status, reader=reader,
                     chapter_id=chapter_id, q=q)

    def _slug(t: str) -> str:
        import re as _re
        s = _re.sub(r"[^a-zA-Z0-9]+", "-", (t or "story").lower()).strip("-")
        return s[:60] or "story"

    if fmt == "md":
        lines = [f"# Beta Feedback — {book_title}", ""]
        if status or reader:
            scope = []
            if status:
                scope.append(f"status: {status}")
            if reader:
                scope.append(f"reader: {reader}")
            lines.append(f"*Filtered ({', '.join(scope)})*")
            lines.append("")
        cur_ch = None
        for it in items:
            if it["chapter_id"] != cur_ch:
                cur_ch = it["chapter_id"]
                lines.append(f"## {it['chapter_index']}. {it['chapter_title']}")
                lines.append("")
            lines.append(f"**{it['reader']}** · {it['status']}"
                         f" · {it['created_at'].strftime('%Y-%m-%d %H:%M') if it['created_at'] else ''}")
            if it["selected_text"]:
                quote = it["selected_text"].replace("\n", " ")
                if len(quote) > 200:
                    quote = quote[:200] + "…"
                lines.append(f"> {quote}")
            lines.append("")
            lines.append(it["comment"] or "")
            if it["reply_count"]:
                lines.append(f"*({it['reply_count']} repl"
                             f"{'ies' if it['reply_count'] > 1 else 'y'})*")
            lines.append("")
        content = "\n".join(lines).encode("utf-8")
        return content, "text/markdown; charset=utf-8", f"feedback-{_slug(book_title)}.md"

    if fmt == "csv":
        buf = _io.StringIO()
        w = _csv.writer(buf)
        w.writerow(["id", "chapter", "reader", "status", "quote",
                    "comment", "replies", "created_at"])
        for it in items:
            w.writerow([it["id"], it["chapter_title"], it["reader"],
                        it["status"], (it["selected_text"] or "")[:300],
                        it["comment"], it["reply_count"],
                        it["created_at"].isoformat() if it["created_at"] else ""])
        content = buf.getvalue().encode("utf-8")
        return content, "text/csv; charset=utf-8", f"feedback-{_slug(book_title)}.csv"

    # json
    payload = {
        "kind": "beta_feedback",
        "book": book_title,
        "filters": {"status": status, "reader": reader, "q": q},
        "count": len(items),
        "comments": [dict(it, created_at=(it["created_at"].isoformat()
                                          if it["created_at"] else None))
                     for it in items],
    }
    content = _json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    return content, "application/json; charset=utf-8", f"feedback-{_slug(book_title)}.json"


# ---- Convert feedback → actionable items ----

def to_note(comment_id: int):
    """Convert a beta comment into a Note (category: todo, linked to chapter)."""
    c = get_comment(comment_id)
    from services.chapter_service import get_chapter
    ch = get_chapter(c.chapter_id)
    quote = (c.selected_text or "").strip()
    body_lines = []
    if quote:
        q = quote.replace("\n", " ")
        if len(q) > 300:
            q = q[:300] + "…"
        body_lines.append(f"> {q}")
        body_lines.append("")
    body_lines.append(c.comment or "")
    body_lines.append("")
    body_lines.append(f"— {c.reader_name}, on chapter "
                      f"\"{ch.title}\" (beta feedback)")
    from services.note_service import create_note
    return create_note(
        title=f"Beta: {(c.comment or '')[:60]}",
        body="\n".join(body_lines),
        category="todo",
        tags=["beta"],
        links=[{"entity_type": "chapter", "entity_id": ch.id,
                "entity_title": ch.title}],
    )


def to_plan(comment_id: int):
    """Convert a beta comment into a Kanban task (status: planned)."""
    c = get_comment(comment_id)
    from services.chapter_service import get_chapter
    ch = get_chapter(c.chapter_id)
    desc_lines = [f"Beta feedback from {c.reader_name}:"]
    if c.selected_text:
        q = c.selected_text.replace("\n", " ")
        if len(q) > 300:
            q = q[:300] + "…"
        desc_lines.append(f"Quote: \"{q}\"")
    desc_lines.append(c.comment or "")
    from services.plan_service import create_plan
    title = f"Fix: {(c.comment or '')[:80]}"
    return create_plan(
        title=title,
        description="\n".join(desc_lines),
        status="planned",
        chapter_id=ch.id,
        tags=["beta"],
    )


# ---- AI assist ----

def suggest_fix(comment_id: int) -> str:
    """Ask the AI for a concrete revision suggestion for one beta comment.

    Grounds the request in the Story Context Engine (characters, world,
    plot memory) + the chapter tail, so suggestions respect continuity.
    """
    from core.errors import AiDisabledError
    from services import ai_service
    from services.chapter_service import get_chapter
    from services.context_engine import build_context

    c = get_comment(comment_id)
    ch = get_chapter(c.chapter_id)

    tail = (ch.content or "")[-4000:]
    try:
        ctx = build_context(tail, chapter_id=ch.id)
        context_block = ctx.render()
    except Exception:  # context is a nicety, never a blocker
        context_block = ""

    quote = (c.selected_text or "").strip().replace("\n", " ")
    prompt = [
        "You are a revision assistant for a novelist.",
        "A beta reader left feedback on a chapter. Respond with a concrete,",
        "actionable revision suggestion.",
        "",
        f"BETA READER: {c.reader_name}",
        f"FEEDBACK: {c.comment or ''}",
    ]
    if quote:
        prompt.append(f"QUOTED PASSAGE: \"{quote}\"")
    if context_block:
        prompt.append("")
        prompt.append("STORY CONTEXT (for continuity):")
        prompt.append(context_block)
    if tail:
        excerpt = tail[-1500:]
        prompt.append("")
        prompt.append("CHAPTER EXCERPT (the ending):")
        prompt.append(excerpt)
    prompt.append("")
    prompt.append(
        "Write: 1) the problem restated in one sentence, 2) a specific fix "
        "(2-4 sentences), 3) if useful, one sample rewritten line. "
        "Plain text only, no headings."
    )
    return ai_service.generate("\n".join(prompt), max_tokens=450,
                               temperature=0.6)
