"""Emotion Arc Engine (v8.0) — "Duygu Yayı".

Deterministic, language-aware emotional curve analysis for chapters and
whole books. Two axes per paragraph window:

  * VALENCE  (-100..+100)  — mood: despair … joy
  * TENSION  (0..100)      — arousal / stakes: calm … explosive

Scaling: lexicon hits are weighted by word-count DENSITY (a paragraph that
is 15% emotion words at average charge reads ~±65). Dominant emotion comes
from per-category hit counts, never from diluted averages. Turkish entries
match with tolerant suffix stripping (rich morphology: "korku" must also
match "korkusu"). Punctuation signals (!, ?, …, CAPS) nudge arousal.
No AI required — works fully offline, consistent with the v7.7
language-engine philosophy.
"""
from __future__ import annotations

import logging
import re
from collections import Counter
from typing import Any

from core.db import read_session
from models.chapter import Chapter
from models.settings import Setting
from services.lang_service import resolve_language, tokenize_words

log = logging.getLogger("asm.emotion")

# --------------------------------------------------------------------------
# Lexicons: word -> (valence -1..+1, arousal 0..1, category)
# --------------------------------------------------------------------------
_TR_LEXICON: dict[str, tuple[float, float, str]] = {
    # joy — positive, energetic
    "sevinç": (0.9, 0.7, "joy"), "sevindi": (0.8, 0.6, "joy"),
    "mutlu": (0.8, 0.5, "joy"), "mutluluk": (0.85, 0.5, "joy"),
    "neşe": (0.8, 0.6, "joy"), "gülümsedi": (0.6, 0.35, "joy"),
    "güldü": (0.7, 0.5, "joy"), "kahkaha": (0.85, 0.7, "joy"),
    "zafer": (0.8, 0.8, "joy"), "başarı": (0.75, 0.6, "joy"),
    "umut": (0.7, 0.45, "joy"), "umutlu": (0.7, 0.45, "joy"),
    "heyecan": (0.55, 0.8, "joy"), "coşku": (0.7, 0.8, "joy"),
    "kutlama": (0.75, 0.6, "joy"), "özgürlük": (0.7, 0.5, "joy"),
    "kurtuldu": (0.7, 0.6, "joy"), "kurtuluş": (0.7, 0.6, "joy"),
    "ışık": (0.4, 0.3, "joy"), "güneş": (0.5, 0.4, "joy"),
    "bahar": (0.5, 0.3, "joy"), "gül": (0.5, 0.3, "joy"),
    # love — positive, warm
    "aşk": (0.8, 0.55, "love"), "sevgi": (0.8, 0.4, "love"),
    "sevdi": (0.7, 0.4, "love"), "öpücük": (0.75, 0.5, "love"),
    "sarıl": (0.7, 0.45, "love"), "kalbi": (0.2, 0.3, "love"),
    "tatlı": (0.5, 0.3, "love"), "sevgili": (0.7, 0.4, "love"),
    "sevda": (0.65, 0.45, "love"),
    # calm — positive, low arousal
    "huzur": (0.7, 0.1, "calm"), "huzurlu": (0.7, 0.1, "calm"),
    "sükunet": (0.65, 0.05, "calm"), "dingin": (0.6, 0.1, "calm"),
    "sessizce": (0.1, 0.1, "calm"), "rahat": (0.5, 0.15, "calm"),
    "rahatladı": (0.6, 0.2, "calm"), "güven": (0.55, 0.2, "calm"),
    "güvende": (0.6, 0.2, "calm"), "barış": (0.65, 0.15, "calm"),
    "uyku": (0.3, 0.05, "calm"), "uyudu": (0.3, 0.05, "calm"),
    "hoş": (0.45, 0.2, "calm"), "güzeldi": (0.5, 0.25, "calm"),
    # sadness — negative, low arousal
    "üzgün": (-0.6, 0.2, "sadness"), "üzüntü": (-0.7, 0.2, "sadness"),
    "hüzün": (-0.7, 0.15, "sadness"), "keder": (-0.7, 0.15, "sadness"),
    "gözyaşı": (-0.7, 0.35, "sadness"), "ağladı": (-0.75, 0.4, "sadness"),
    "yalnız": (-0.6, 0.15, "sadness"), "yalnızlık": (-0.7, 0.15, "sadness"),
    "kayıp": (-0.7, 0.3, "sadness"), "kaybetti": (-0.75, 0.35, "sadness"),
    "ölüm": (-0.85, 0.45, "sadness"), "öldü": (-0.9, 0.5, "sadness"),
    "mezar": (-0.8, 0.3, "sadness"), "cenaze": (-0.8, 0.35, "sadness"),
    "yas": (-0.75, 0.25, "sadness"), "pişman": (-0.6, 0.25, "sadness"),
    "vicdan": (-0.3, 0.2, "sadness"), "gurbet": (-0.5, 0.2, "sadness"),
    "hasret": (-0.6, 0.25, "sadness"), "özlem": (-0.45, 0.2, "sadness"),
    "terk": (-0.7, 0.3, "sadness"), "terketti": (-0.75, 0.35, "sadness"),
    "çaresiz": (-0.7, 0.3, "sadness"), "umutsuz": (-0.8, 0.3, "sadness"),
    "yıpranmış": (-0.5, 0.2, "sadness"), "kırıldı": (-0.6, 0.3, "sadness"),
    "kırgın": (-0.55, 0.25, "sadness"), "ağıt": (-0.75, 0.3, "sadness"),
    # anger — negative, high arousal
    "öfke": (-0.7, 0.85, "anger"), "öfkeli": (-0.7, 0.85, "anger"),
    "kızdı": (-0.6, 0.8, "anger"), "kızgın": (-0.65, 0.8, "anger"),
    "sinir": (-0.5, 0.75, "anger"), "bağırdı": (-0.55, 0.9, "anger"),
    "kükredi": (-0.7, 0.9, "anger"), "hiddet": (-0.75, 0.85, "anger"),
    "öfkeyle": (-0.7, 0.9, "anger"), "hakaret": (-0.7, 0.75, "anger"),
    "vurdu": (-0.5, 0.85, "anger"), "yumruk": (-0.55, 0.85, "anger"),
    "kin": (-0.7, 0.6, "anger"), "intikam": (-0.75, 0.85, "anger"),
    "ceza": (-0.4, 0.6, "anger"), "öldürdü": (-0.85, 0.9, "anger"),
    # fear / tension — negative, very high arousal
    "korku": (-0.75, 0.9, "fear"), "korktu": (-0.75, 0.9, "fear"),
    "korkunç": (-0.8, 0.85, "fear"), "dehşet": (-0.85, 0.95, "fear"),
    "ürktü": (-0.7, 0.9, "fear"), "titredi": (-0.6, 0.8, "fear"),
    "panik": (-0.75, 0.95, "fear"), "kaçtı": (-0.5, 0.9, "fear"),
    "kaçış": (-0.55, 0.9, "fear"), "tehlike": (-0.7, 0.8, "fear"),
    "tehdit": (-0.7, 0.8, "fear"), "silah": (-0.5, 0.8, "fear"),
    "kılıç": (-0.45, 0.8, "fear"), "gölge": (-0.35, 0.5, "fear"),
    "karanlık": (-0.4, 0.45, "fear"), "sessizlik": (-0.2, 0.35, "fear"),
    "fısıltı": (-0.25, 0.5, "fear"), "gergin": (-0.5, 0.75, "fear"),
    "gerilim": (-0.5, 0.8, "fear"), "şüphe": (-0.35, 0.5, "fear"),
    "sır": (-0.2, 0.5, "fear"), "ihanet": (-0.8, 0.75, "fear"),
    "tuzak": (-0.65, 0.8, "fear"), "canavar": (-0.7, 0.85, "fear"),
    "yaratık": (-0.55, 0.75, "fear"), "vahşi": (-0.5, 0.8, "fear"),
    "çığlık": (-0.7, 0.95, "fear"), "çatırdadı": (-0.4, 0.7, "fear"),
    "kapandı": (-0.3, 0.5, "fear"), "yaralı": (-0.6, 0.5, "fear"),
    "savaş": (-0.6, 0.9, "fear"), "kan": (-0.5, 0.8, "fear"),
    "düşman": (-0.6, 0.7, "fear"),
}

_EN_LEXICON: dict[str, tuple[float, float, str]] = {
    # joy
    "joy": (0.9, 0.7, "joy"), "happy": (0.8, 0.5, "joy"),
    "happiness": (0.85, 0.5, "joy"), "delight": (0.8, 0.6, "joy"),
    "smiled": (0.6, 0.35, "joy"), "grinned": (0.65, 0.5, "joy"),
    "beamed": (0.7, 0.55, "joy"), "laughed": (0.7, 0.6, "joy"),
    "laughter": (0.85, 0.7, "joy"), "triumph": (0.8, 0.8, "joy"),
    "victory": (0.8, 0.8, "joy"), "hope": (0.7, 0.45, "joy"),
    "hopeful": (0.7, 0.45, "joy"), "excitement": (0.55, 0.8, "joy"),
    "celebration": (0.75, 0.65, "joy"), "freedom": (0.7, 0.5, "joy"),
    "escaped": (0.6, 0.7, "joy"), "light": (0.4, 0.3, "joy"),
    "sun": (0.5, 0.4, "joy"), "spring": (0.5, 0.3, "joy"),
    "cheerful": (0.7, 0.5, "joy"), "joyful": (0.85, 0.6, "joy"),
    # love
    "love": (0.8, 0.55, "love"), "loved": (0.75, 0.5, "love"),
    "kiss": (0.75, 0.55, "love"), "kissed": (0.75, 0.55, "love"),
    "embrace": (0.7, 0.45, "love"), "heart": (0.2, 0.3, "love"),
    "sweet": (0.5, 0.3, "love"), "beloved": (0.7, 0.4, "love"),
    "tender": (0.6, 0.3, "love"), "warmth": (0.55, 0.3, "love"),
    # calm
    "peace": (0.7, 0.1, "calm"), "calm": (0.65, 0.1, "calm"),
    "serene": (0.65, 0.05, "calm"), "tranquil": (0.65, 0.05, "calm"),
    "quietly": (0.1, 0.1, "calm"), "relaxed": (0.6, 0.15, "calm"),
    "relief": (0.6, 0.2, "calm"), "safe": (0.6, 0.2, "calm"),
    "safety": (0.6, 0.2, "calm"), "slept": (0.3, 0.05, "calm"),
    "rest": (0.4, 0.1, "calm"), "comfort": (0.55, 0.2, "calm"),
    "cozy": (0.6, 0.15, "calm"), "peaceful": (0.7, 0.1, "calm"),
    # sadness
    "sad": (-0.6, 0.2, "sadness"), "sadness": (-0.7, 0.2, "sadness"),
    "sorrow": (-0.75, 0.2, "sadness"), "sorrowful": (-0.7, 0.25, "sadness"),
    "grief": (-0.8, 0.3, "sadness"), "tears": (-0.7, 0.35, "sadness"),
    "cried": (-0.75, 0.4, "sadness"), "wept": (-0.75, 0.35, "sadness"),
    "lonely": (-0.6, 0.15, "sadness"), "loneliness": (-0.7, 0.15, "sadness"),
    "loss": (-0.7, 0.3, "sadness"), "lost": (-0.55, 0.3, "sadness"),
    "death": (-0.85, 0.45, "sadness"), "died": (-0.9, 0.5, "sadness"),
    "grave": (-0.8, 0.3, "sadness"), "funeral": (-0.8, 0.35, "sadness"),
    "mourning": (-0.75, 0.25, "sadness"), "regret": (-0.6, 0.25, "sadness"),
    "guilt": (-0.5, 0.3, "sadness"), "exile": (-0.5, 0.25, "sadness"),
    "longing": (-0.5, 0.2, "sadness"), "abandoned": (-0.75, 0.35, "sadness"),
    "helpless": (-0.7, 0.3, "sadness"), "hopeless": (-0.8, 0.3, "sadness"),
    "despair": (-0.85, 0.35, "sadness"), "misery": (-0.75, 0.25, "sadness"),
    "broken": (-0.6, 0.3, "sadness"), "hurt": (-0.55, 0.35, "sadness"),
    "weary": (-0.45, 0.2, "sadness"), "exhausted": (-0.5, 0.25, "sadness"),
    # anger
    "anger": (-0.7, 0.85, "anger"), "angry": (-0.7, 0.85, "anger"),
    "fury": (-0.8, 0.9, "anger"), "rage": (-0.8, 0.9, "anger"),
    "shouted": (-0.55, 0.9, "anger"), "yelled": (-0.55, 0.9, "anger"),
    "roared": (-0.7, 0.9, "anger"), "snarled": (-0.7, 0.85, "anger"),
    "growled": (-0.6, 0.85, "anger"), "insult": (-0.7, 0.75, "anger"),
    "struck": (-0.5, 0.85, "anger"), "fist": (-0.55, 0.85, "anger"),
    "hatred": (-0.75, 0.7, "anger"), "enemy": (-0.6, 0.7, "anger"),
    "revenge": (-0.75, 0.85, "anger"), "punishment": (-0.4, 0.6, "anger"),
    "killed": (-0.85, 0.9, "anger"), "slam": (-0.4, 0.8, "anger"),
    "slammed": (-0.45, 0.85, "anger"), "crash": (-0.4, 0.8, "anger"),
    "shatter": (-0.5, 0.85, "anger"), "smashed": (-0.55, 0.85, "anger"),
    # fear / tension
    "fear": (-0.75, 0.9, "fear"), "afraid": (-0.75, 0.85, "fear"),
    "terrified": (-0.85, 0.95, "fear"), "horror": (-0.85, 0.95, "fear"),
    "dread": (-0.8, 0.85, "fear"), "dreadful": (-0.8, 0.85, "fear"),
    "trembled": (-0.6, 0.8, "fear"), "panic": (-0.75, 0.95, "fear"),
    "fled": (-0.5, 0.9, "fear"), "danger": (-0.7, 0.8, "fear"),
    "threat": (-0.7, 0.8, "fear"), "gun": (-0.5, 0.8, "fear"),
    "sword": (-0.45, 0.8, "fear"), "shadow": (-0.35, 0.5, "fear"),
    "darkness": (-0.45, 0.5, "fear"), "silence": (-0.2, 0.35, "fear"),
    "whisper": (-0.25, 0.5, "fear"), "tense": (-0.5, 0.75, "fear"),
    "tension": (-0.5, 0.8, "fear"), "suspicion": (-0.35, 0.5, "fear"),
    "secret": (-0.2, 0.5, "fear"), "betrayal": (-0.8, 0.75, "fear"),
    "betrayed": (-0.8, 0.75, "fear"), "trap": (-0.65, 0.8, "fear"),
    "monster": (-0.7, 0.85, "fear"), "creature": (-0.55, 0.75, "fear"),
    "savage": (-0.5, 0.8, "fear"), "scream": (-0.7, 0.95, "fear"),
    "screamed": (-0.7, 0.95, "fear"), "shriek": (-0.7, 0.9, "fear"),
    "war": (-0.6, 0.9, "fear"), "blood": (-0.5, 0.8, "fear"),
    "wound": (-0.6, 0.5, "fear"), "wounded": (-0.6, 0.5, "fear"),
}

# Turkish prefix-match stems: len>=5. Matched as word.startswith(stem) with
# at most 4 extra suffix chars (korku → korkusu / korkular / korkuya).
_TR_PREFIX_STEMS = {w for w in _TR_LEXICON if len(w) >= 5}

_VAL_SCALE = 500.0    # density→score: 15% hits at avg |v| .65 ≈ ±65
_TEN_SCALE = 400.0    # same idea for arousal
_MIN_DENOM = 8.0      # short windows don't explode

_PARA_SPLIT_RE = re.compile(r"\n\s*\n+")
_SENT_END_RE = re.compile(r"[!?…]+")
_ELLIPSIS_RE = re.compile(r"(\.\.\.|…)")


def _lookup(word: str, lang: str) -> tuple[float, float, str] | None:
    """Lexicon lookup with Turkish suffix tolerance."""
    if lang == "tr":
        hit = _TR_LEXICON.get(word)
        if hit:
            return hit
        if len(word) >= 5:
            for stem in _TR_PREFIX_STEMS:
                if word != stem and word.startswith(stem) and len(word) - len(stem) <= 4:
                    return _TR_LEXICON[stem]
        return None
    return _EN_LEXICON.get(word)


def _paragraphs(text: str) -> list[str]:
    paras = [p.strip() for p in _PARA_SPLIT_RE.split(text or "")]
    return [p for p in paras if p]


def _window_scores(paras: list[str], lang: str) -> list[dict[str, Any]]:
    """Score paragraph windows. Small paragraphs merge so the curve doesn't
    strobe on one-line beats (target >= 25 words/window)."""
    windows: list[list[str]] = []
    cur: list[str] = []
    cur_words = 0
    for p in paras:
        w = len(p.split())
        cur.append(p)
        cur_words += w
        if cur_words >= 25:
            windows.append(cur)
            cur, cur_words = [], 0
    if cur:
        if windows and cur_words < 12:
            windows[-1].extend(cur)
        else:
            windows.append(cur)

    out: list[dict[str, Any]] = []
    for i, win in enumerate(windows):
        joined = "\n".join(win)
        words = [w.lower() for w in tokenize_words(joined)]
        n = max(_MIN_DENOM, float(len(words) or _MIN_DENOM))
        val_sum = 0.0
        aro_sum = 0.0
        cat_counts: Counter = Counter()
        hits: list[str] = []
        for w in words:
            hit = _lookup(w, lang)
            if hit:
                val_sum += hit[0]
                aro_sum += hit[1]
                cat_counts[hit[2]] += 1
                if w not in hits:
                    hits.append(w)
        # punctuation arousal nudges (small, capped)
        excl = len(_SENT_END_RE.findall(joined))
        ell = len(_ELLIPSIS_RE.findall(joined))
        caps = sum(1 for w in words if len(w) >= 4 and w.isupper())
        aro_sum += min(3, excl) * 0.3 + min(3, ell) * 0.12 + min(3, caps) * 0.35

        valence = max(-100, min(100, round(val_sum / n * _VAL_SCALE)))
        tension = max(0, min(100, round(aro_sum / n * _TEN_SCALE)))
        dominant = cat_counts.most_common(1)[0][0] if cat_counts else "neutral"
        out.append({
            "index": i,
            "paragraph": i + 1,
            "valence": valence,
            "tension": tension,
            "words": len(words),
            "dominant": dominant,
            "hits": hits[:6],
            "excerpt": (win[0][:160] + ("…" if len(win[0]) > 160 else "")),
        })
    return out


def _arc_shape(curve: list[int]) -> str:
    """Classify the shape of a valence curve."""
    if len(curve) < 3:
        return "short" if curve else "empty"
    n = len(curve)
    xs = list(range(n))
    mx = sum(xs) / n
    my = sum(curve) / n
    denom = sum((x - mx) ** 2 for x in xs) or 1.0
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, curve)) / denom
    rng = max(curve) - min(curve)
    if rng < 12:
        return "stable"
    mid_lo, mid_hi = n // 3, max(n // 3 + 1, (2 * n) // 3)
    mid = curve[mid_lo:mid_hi]
    edges = curve[:mid_lo] + curve[mid_hi:]
    if mid and edges and min(mid) < min(edges) - 8:
        return "dip"
    if mid and edges and max(mid) > max(edges) + 8:
        return "peak"
    diffs = [curve[i + 1] - curve[i] for i in range(n - 1)]
    signs = [1 if d > 4 else (-1 if d < -4 else 0) for d in diffs]
    sign_changes = sum(1 for i in range(len(signs) - 1) if signs[i] and signs[i + 1] and signs[i] != signs[i + 1])
    if sign_changes >= 3:
        return "wave"
    if slope > 0.9:
        return "rising"
    if slope < -0.9:
        return "falling"
    return "mixed"


def _suggestions(avg_v: float, max_t: float, rng: float, start: int, end: int,
                 shape: str) -> list[str]:
    tips: list[str] = []
    if rng < 12:
        tips.append("Emotionally flat: the valence curve barely moves. Consider a "
                    "reversal, a reveal, or a moment of doubt to give the chapter shape.")
    if avg_v < -35:
        tips.append("Relentlessly dark: a short moment of calm or warmth makes the "
                    "darkness hit harder when it returns.")
    if avg_v > 40:
        tips.append("Uniformly bright: tension needs something at stake — even happy "
                    "chapters benefit from a small worry.")
    if max_t < 15:
        tips.append("No tension peaks detected: conflict markers (threat, danger, "
                    "time pressure) are missing from this chapter.")
    if end - start < -25:
        tips.append("Ends much darker than it opens — effective for cliffhangers; "
                    "make sure the next chapter gives the reader air.")
    if start - end < -25:
        tips.append("A strong upward climb — check that the win is earned, not sudden.")
    if shape == "wave":
        tips.append("Emotional rollercoaster: many quick reversals. Give key beats "
                    "room to land before the next turn.")
    if not tips:
        tips.append("Healthy emotional range — the curve has shape and the stakes "
                    "peak where it matters.")
    return tips


def analyze_text(text: str, lang: str | None = None) -> dict[str, Any]:
    """Analyze one text. Language resolved via settings when not given."""
    setting = None
    try:
        with read_session() as s:
            setting = Setting.get(s, "analysis_language")
    except Exception:
        setting = None
    language = lang or resolve_language(text or "", setting)
    paras = _paragraphs(text or "")
    windows = _window_scores(paras, language)
    curve = [w["valence"] for w in windows]
    tension = [w["tension"] for w in windows]
    avg_v = round(sum(curve) / len(curve)) if curve else 0
    shape = _arc_shape(curve)
    peaks: list[dict[str, Any]] = []
    for i, w in enumerate(windows):
        shift = (curve[i] - curve[i - 1]) if i else 0
        score = max(abs(w["valence"]), abs(shift) * 0.8, w["tension"] * 0.6)
        peaks.append({**w, "shift": shift, "score": round(score, 1)})
    peaks.sort(key=lambda p: p["score"], reverse=True)
    return {
        "ok": bool(windows),
        "language": language,
        "windows": windows,
        "curve": curve,
        "tension_curve": tension,
        "avg_valence": avg_v,
        "avg_tension": round(sum(tension) / len(tension)) if tension else 0,
        "max_tension": max(tension) if tension else 0,
        "range": (max(curve) - min(curve)) if curve else 0,
        "start": curve[0] if curve else 0,
        "end": curve[-1] if curve else 0,
        "shape": shape,
        "peaks": peaks[:4],
        "suggestions": _suggestions(avg_v, max(tension) if tension else 0,
                                    (max(curve) - min(curve)) if curve else 0,
                                    curve[0] if curve else 0,
                                    curve[-1] if curve else 0, shape),
    }


def analyze_chapter(chapter_id: str) -> dict[str, Any] | None:
    with read_session() as s:
        ch = s.get(Chapter, chapter_id)
        if not ch:
            return None
        result = analyze_text(ch.content or "")
        result["chapter_id"] = ch.id
        result["chapter_title"] = ch.title
        result["word_count"] = ch.word_count or len((ch.content or "").split())
        return result


def book_curve() -> dict[str, Any]:
    """Chapter-by-chapter emotional curve for the whole book."""
    with read_session() as s:
        chapters = (s.query(Chapter)
                    .order_by(Chapter.sort_order.asc())
                    .all())
        points = []
        for ch in chapters:
            r = analyze_text(ch.content or "")
            if not r["ok"]:
                continue
            points.append({
                "chapter_id": ch.id,
                "title": ch.title,
                "order": ch.sort_order or 0,
                "avg_valence": r["avg_valence"],
                "avg_tension": r["avg_tension"],
                "shape": r["shape"],
                "range": r["range"],
                "word_count": ch.word_count or len((ch.content or "").split()),
            })
    return {"ok": bool(points), "chapters": points}


def chapters_with_emotions() -> list[dict[str, Any]]:
    """Lightweight chapter list for the selector (no window payloads)."""
    with read_session() as s:
        chapters = (s.query(Chapter)
                    .order_by(Chapter.sort_order.asc())
                    .all())
        out = []
        for ch in chapters:
            text = ch.content or ""
            r = analyze_text(text)
            out.append({
                "id": ch.id,
                "title": ch.title,
                "sort_order": ch.sort_order or 0,
                "avg_valence": r["avg_valence"],
                "avg_tension": r["avg_tension"],
                "shape": r["shape"],
                "language": r["language"],
                "words": ch.word_count or len(text.split()),
            })
    return out
