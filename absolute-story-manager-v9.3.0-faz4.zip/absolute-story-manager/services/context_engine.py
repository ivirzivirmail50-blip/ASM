"""Story Context Engine — the RAG heart of ASM v6.0.

Gathers the story knowledge an AI needs BEFORE generating anything:
- Characters mentioned in the text (name + alias matching, Turkish-aware)
- Their relationships, voice profiles, and arcs
- World entries (locations/lore/factions) mentioned or linked
- Glossary terms with definitions
- Plot memory: synopses of preceding chapters + tail of the previous chapter

Everything is assembled under a character budget with clear priorities,
rendered as structured prompt sections, and reported back to the UI so the
writer can SEE what the AI is being told (transparency).

Provider-agnostic: works with Ollama, OpenRouter, Groq, or any other
provider — retrieval is pure local SQLite, no embeddings required.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

from core.db import read_session
from models.chapter import Chapter
from models.character import Character, CharacterRelationship
from models.glossary import GlossaryEntry
from models.world import WorldEntry
from services._common import current_project_id, load_json

log = logging.getLogger("asm.context")

# v9.1.0 (M-03): plot-memory queries load full chapter CONTENT by default
# (hundreds of KB per chapter) though only synopsis/title is needed. defer()
# keeps content out of the SELECT; it lazy-loads only in the rare no-synopsis
# fallback path.
from sqlalchemy.orm import defer  # noqa: E402,I001
_PLOT_QUERY_OPTIONS = (defer(Chapter.content),)

# Budgets (chars). Roughly 4 chars = 1 token for Latin scripts.
DEFAULT_BUDGET_CHARS = 7000
_SECTION_LIMITS = {
    "characters": 2400,
    "relationships": 800,
    "world": 1600,
    "glossary": 900,
    "plot": 1800,
    "style": 400,
}

# Words that are too generic to count as a "match" for world entries.
_GENERIC_NAME_RE = re.compile(
    r"^(the|a|an|chapter|scene|part|book|story|day|night|morning|evening)$",
    re.IGNORECASE,
)


# ----------------------------------------------------------------------------
# Normalization helpers (Turkish-aware)
# ----------------------------------------------------------------------------

_TR_LOWER_MAP = str.maketrans("İI", "iı")


def _norm(text: str) -> str:
    """Lowercase for matching purposes, handling Turkish dotted/dotless I."""
    if not text:
        return ""
    return text.translate(_TR_LOWER_MAP).casefold()


def _word_boundary_pattern(name: str) -> re.Pattern | None:
    """Compile a word-boundary regex for a NORMALIZED name.

    The pattern is meant to be searched against _norm(text) so that Turkish
    dotted/dotless I (İ/i/I/ı) and case differences match reliably.
    Uses lookarounds so Unicode word chars (ş, ğ, ü...) count as word chars.
    """
    cleaned = _norm((name or "").strip())
    if len(cleaned) < 2:
        return None
    if _GENERIC_NAME_RE.match(cleaned):
        return None
    escaped = re.escape(cleaned)
    try:
        return re.compile(r"(?<![\w])" + escaped + r"(?![\w])", re.UNICODE)
    except re.error:
        return None


# ----------------------------------------------------------------------------
# Entity detection
# ----------------------------------------------------------------------------

def detect_characters(text: str, characters: list[Character]) -> list[Character]:
    """Return characters whose name or alias appears in the text.

    Matching is Turkish-aware: both text and names are normalized via _norm
    (İ→i, I→ı, casefold) before word-boundary matching.
    Sorted: direct name hits first (longest name first), then alias hits.
    """
    if not text or not characters:
        return []
    norm_text = _norm(text)
    direct: list[tuple[int, Character]] = []
    alias: list[tuple[int, Character]] = []
    for ch in characters:
        name_pat = _word_boundary_pattern(ch.name or "")
        if name_pat and name_pat.search(norm_text):
            direct.append((len(ch.name), ch))
            continue
        matched_alias = False
        for alias_name in load_json(ch.aliases, []) or []:
            if not isinstance(alias_name, str):
                continue
            ap = _word_boundary_pattern(alias_name)
            if ap and ap.search(norm_text):
                alias.append((len(alias_name), ch))
                matched_alias = True
                break
        if not matched_alias and norm_text:
            # Substring fallback (boundary-checked) for very short forms
            n = _norm(ch.name or "")
            if n and len(n) >= 3:
                fb = re.compile(r"(?<![\w])" + re.escape(n) + r"(?![\w])", re.UNICODE)
                if fb.search(norm_text):
                    alias.append((len(n), ch))
    direct.sort(key=lambda t: -t[0])
    alias.sort(key=lambda t: -t[0])
    seen: set[str] = set()
    out: list[Character] = []
    for _, ch in direct + alias:
        if ch.id not in seen:
            seen.add(ch.id)
            out.append(ch)
    return out


def detect_world_entries(text: str, entries: list[WorldEntry]) -> list[WorldEntry]:
    """Return world entries mentioned in the text (Turkish-aware name match)."""
    if not text or not entries:
        return []
    norm_text = _norm(text)
    matched: list[tuple[int, WorldEntry]] = []
    for e in entries:
        pat = _word_boundary_pattern(e.name or "")
        if pat and pat.search(norm_text):
            matched.append((len(e.name or ""), e))
    matched.sort(key=lambda t: -t[0])
    seen: set[str] = set()
    out: list[WorldEntry] = []
    for _, e in matched:
        if e.id not in seen:
            seen.add(e.id)
            out.append(e)
    return out


def detect_glossary(text: str, entries: list[GlossaryEntry]) -> list[GlossaryEntry]:
    """Return glossary terms mentioned in the text (term + alternates)."""
    if not text or not entries:
        return []
    norm_text = _norm(text)
    out: list[GlossaryEntry] = []
    for e in entries:
        terms = [e.term] + [
            a for a in (load_json(e.alternates, []) or [])
            if isinstance(a, str)
        ]
        for term in terms:
            pat = _word_boundary_pattern(term)
            if pat and pat.search(norm_text):
                out.append(e)
                break
    return out


# ----------------------------------------------------------------------------
# Context bundle
# ----------------------------------------------------------------------------

@dataclass
class ContextBundle:
    """Assembled story context, renderable as a prompt block."""

    characters: list[dict] = field(default_factory=list)
    relationships: list[dict] = field(default_factory=list)
    world: list[dict] = field(default_factory=list)
    glossary: list[dict] = field(default_factory=list)
    plot: list[dict] = field(default_factory=list)   # [{title, summary}]
    style_notes: list[str] = field(default_factory=list)
    budget_chars: int = DEFAULT_BUDGET_CHARS
    chars_used: int = 0
    # v9.1.0 (M-02): the project this bundle was assembled from — surfaced
    # in stats() so the UI can show WHICH book the AI is being told about.
    project_id: str | None = None

    # --- Rendering ---------------------------------------------------------

    def _render_characters(self) -> str:
        if not self.characters:
            return ""
        lines = ["CHARACTERS RELEVANT TO THIS SCENE:"]
        for c in self.characters:
            bits = []
            if c.get("role"):
                bits.append(str(c["role"]))
            if c.get("age"):
                bits.append(f"age {c['age']}")
            lines.append(f"- {c.get('name', '?')}" + (f" ({', '.join(bits)})" if bits else ""))
            for label, key, limit in (
                ("Appearance", "physical", 160),
                ("Personality", "psychology", 160),
                ("Background", "background", 200),
                ("Voice", "voice", 120),
                ("Notes", "notes", 120),
            ):
                val = (c.get(key) or "").strip()
                if val:
                    lines.append(f"    {label}: {val[:limit]}")
        return "\n".join(lines)

    def _render_relationships(self) -> str:
        if not self.relationships:
            return ""
        lines = ["RELATIONSHIPS BETWEEN THEM:"]
        for r in self.relationships:
            desc = (r.get("description") or "").strip()
            extra = f" — {desc[:100]}" if desc else ""
            arrow = "↔" if r.get("bidirectional") else "→"
            lines.append(
                f"- {r.get('from_name', '?')} {arrow} {r.get('to_name', '?')}: "
                f"{r.get('type', 'related')}{extra}"
            )
        return "\n".join(lines)

    def _render_world(self) -> str:
        if not self.world:
            return ""
        lines = ["WORLD / SETTING:"]
        for w in self.world:
            desc = (w.get("description") or w.get("content") or "").strip()
            lines.append(f"- {w.get('name', '?')} ({w.get('type', 'entry')}): {desc[:180]}")
        return "\n".join(lines)

    def _render_glossary(self) -> str:
        if not self.glossary:
            return ""
        lines = ["GLOSSARY (use these exact spellings):"]
        for g in self.glossary:
            d = (g.get("definition") or "").strip()
            lines.append(f"- {g.get('term', '?')}: {d[:140]}")
        return "\n".join(lines)

    def _render_plot(self) -> str:
        if not self.plot:
            return ""
        lines = ["WHAT HAPPENED BEFORE (plot memory):"]
        for p in self.plot:
            summary = (p.get("summary") or "").strip()
            lines.append(f"- {p.get('title', '?')}: {summary[:260]}")
        return "\n".join(lines)

    def _render_style(self) -> str:
        if not self.style_notes:
            return ""
        return "STYLE NOTES:\n" + "\n".join(f"- {s}" for s in self.style_notes)

    def render(self) -> str:
        """Render the bundle as a compact prompt block (may be empty)."""
        sections = [
            ("plot", self._render_plot()),
            ("characters", self._render_characters()),
            ("relationships", self._render_relationships()),
            ("world", self._render_world()),
            ("glossary", self._render_glossary()),
            ("style", self._render_style()),
        ]
        out: list[str] = []
        used = 0
        for key, rendered in sections:
            if not rendered:
                continue
            limit = _SECTION_LIMITS.get(key, 1000)
            if used + len(rendered) > self.budget_chars:
                remaining = self.budget_chars - used
                if remaining < 200:
                    break
                rendered = rendered[:remaining] + "\n…"
            out.append(rendered[:limit])
            used += len(out[-1])
        self.chars_used = used
        return "\n\n".join(out)

    def stats(self) -> dict[str, Any]:
        return {
            "characters": len(self.characters),
            "relationships": len(self.relationships),
            "world": len(self.world),
            "glossary": len(self.glossary),
            "plot": len(self.plot),
            "chars_used": self.chars_used,
            # v9.1.0 (M-02): active book transparency for the context panel.
            "project_id": self.project_id,
        }


# ----------------------------------------------------------------------------
# Character → compact dict
# ----------------------------------------------------------------------------

def _character_dict(ch: Character) -> dict:
    return {
        "id": ch.id,
        "name": ch.name,
        "role": ch.role,
        "age": ch.age,
        "physical": ch.physical,
        "psychology": ch.psychology,
        "background": ch.background,
        "voice": ch.voice,
        "notes": ch.notes,
    }


# ----------------------------------------------------------------------------
# Main entry point
# ----------------------------------------------------------------------------

def build_context(
    text: str,
    *,
    chapter_id: str | None = None,
    include: dict[str, bool] | None = None,
    budget_chars: int = DEFAULT_BUDGET_CHARS,
    extra_characters: list[str] | None = None,
    plot_depth: int = 3,
    project_id: str | None = None,
) -> ContextBundle:
    """Assemble story context relevant to the given text.

    Args:
        text: The text the AI will work on (chapter tail, scene, message...).
        chapter_id: Optional chapter — used for linked characters, previous
            chapters (plot memory), and location.
        include: Per-section toggles. Defaults all True:
            {"characters": True, "relationships": True, "world": True,
             "glossary": True, "plot": True}
        extra_characters: Character IDs to always include (e.g. chat target).
        plot_depth: How many preceding chapters to summarize.
        project_id: v9.1.0 (M-02) — the book to assemble from. When omitted,
            the ACTIVE project (settings.active_project_id) is used. Every
            query is project-scoped: characters, world, glossary, plot
            memory, and the anchor chapter itself.
    """
    opts = {
        "characters": True, "relationships": True, "world": True,
        "glossary": True, "plot": True,
    }
    if include:
        opts.update({k: v for k, v in include.items() if k in opts})

    bundle = ContextBundle(budget_chars=budget_chars)

    with read_session() as s:
        # v9.1.0 (M-02): resolve the active book once, then scope EVERY
        # query below to it. Previously all entities from ALL books leaked
        # into the prompt (and plot memory mixed chapters across books).
        pid = project_id or current_project_id(s)
        bundle.project_id = pid

        # ---- Load entities once (project-scoped) ------------------------------
        all_chars: list[Character] = list(
            s.query(Character)
            .filter(Character.project_id == pid)
            .order_by(Character.name)
            .all()
        )
        all_world: list[WorldEntry] = list(
            s.query(WorldEntry).filter(WorldEntry.project_id == pid).all()
        )
        all_gloss: list[GlossaryEntry] = list(
            s.query(GlossaryEntry).filter(GlossaryEntry.project_id == pid).all()
        )

        chapter: Chapter | None = None
        if chapter_id:
            # A chapter id from ANOTHER project must not leak details into
            # this bundle — the project filter keeps it None.
            chapter = (
                s.query(Chapter)
                .filter(Chapter.id == chapter_id,
                        Chapter.project_id == pid)
                .first()
            )

        # ---- Characters --------------------------------------------------------
        if opts["characters"]:
            detected = detect_characters(text or "", all_chars)
            selected_ids = {c.id for c in detected}

            # Characters linked to this chapter + POV
            if chapter is not None:
                linked = load_json(chapter.character_ids, []) or []
                selected_ids.update(cid for cid in linked if isinstance(cid, str))
                if chapter.pov_character_id:
                    selected_ids.add(chapter.pov_character_id)

            # Explicit extras (e.g. character chat target)
            for cid in (extra_characters or []):
                selected_ids.add(cid)

            by_id = {c.id: c for c in all_chars}
            chosen = []
            # Detected characters first (they matter most), then the rest
            for c in detected:
                chosen.append(c)
                selected_ids.discard(c.id)
            for cid in selected_ids:
                if cid in by_id:
                    chosen.append(by_id[cid])
            bundle.characters = [_character_dict(c) for c in chosen[:10]]

            # ---- Relationships among chosen characters -----------------------
            if opts["relationships"] and bundle.characters:
                chosen_ids = {c["id"] for c in bundle.characters}
                name_by_id = {c["id"]: c["name"] for c in bundle.characters}
                rels = (
                    s.query(CharacterRelationship)
                    .filter(
                        CharacterRelationship.from_character_id.in_(chosen_ids),
                        CharacterRelationship.to_character_id.in_(chosen_ids),
                    )
                    .limit(20)
                    .all()
                )
                bundle.relationships = [
                    {
                        "from_name": name_by_id.get(r.from_character_id, "?"),
                        "to_name": name_by_id.get(r.to_character_id, "?"),
                        "type": r.relationship_type,
                        "description": r.description,
                        "bidirectional": bool(r.is_bidirectional),
                    }
                    for r in rels
                ]

        # ---- World -------------------------------------------------------------
        if opts["world"]:
            detected_world = detect_world_entries(text or "", all_world)
            selected_world_ids = {w.id for w in detected_world}
            # Chapter location by name
            if chapter is not None and chapter.location:
                loc_norm = _norm(chapter.location)
                for w in all_world:
                    if _norm(w.name) == loc_norm:
                        selected_world_ids.add(w.id)
            by_id = {w.id: w for w in all_world}
            chosen_world = [by_id[i] for i in selected_world_ids if i in by_id]
            # If nothing matched, include up to 3 short entries for flavor
            if not chosen_world:
                chosen_world = sorted(
                    (w for w in all_world if (w.description or w.content)),
                    key=lambda w: len(w.description or w.content or ""),
                )[:3]
            bundle.world = [
                {
                    "id": w.id, "name": w.name, "type": w.type,
                    "description": (w.description or w.content or "")[:300],
                }
                for w in chosen_world[:8]
            ]

        # ---- Glossary ------------------------------------------------------------
        if opts["glossary"]:
            detected_gloss = detect_glossary(text or "", all_gloss)
            bundle.glossary = [
                {"term": g.term, "definition": (g.definition or "")[:200]}
                for g in detected_gloss[:10]
            ]

        # ---- Plot memory ---------------------------------------------------------
        if opts["plot"] and chapter is not None:
            ordered = (
                s.query(Chapter)
                .options(*_PLOT_QUERY_OPTIONS)  # M-03: skip content blob
                .filter(Chapter.project_id == pid)
                .order_by(Chapter.sort_order)
                .all()
            )
            idx = next((i for i, c in enumerate(ordered) if c.id == chapter_id), -1)
            if idx > 0:
                for prev in ordered[max(0, idx - plot_depth):idx]:
                    summary = (prev.synopsis or "").strip()
                    if not summary:
                        # Fall back to the tail of the previous chapter
                        tail = (prev.content or "").strip()[-400:]
                        summary = f"(no synopsis) …{tail}" if tail else "(empty)"
                    bundle.plot.append({
                        "title": prev.title,
                        "summary": summary,
                        "sort_order": prev.sort_order,
                    })
        elif opts["plot"] and not chapter_id:
            # No anchor chapter — use the last `plot_depth` chapters' synopses
            ordered = (
                s.query(Chapter)
                .options(*_PLOT_QUERY_OPTIONS)  # M-03: skip content blob
                .filter(Chapter.project_id == pid)
                .order_by(Chapter.sort_order.desc())
                .limit(plot_depth)
                .all()
            )
            for prev in reversed(ordered):
                summary = (prev.synopsis or "").strip() or (prev.title or "")
                if summary:
                    bundle.plot.append({"title": prev.title, "summary": summary})

    return bundle


# ----------------------------------------------------------------------------
# Prompt assembly helper
# ----------------------------------------------------------------------------

def build_prompt(
    instruction: str,
    text: str,
    *,
    chapter_id: str | None = None,
    include: dict[str, bool] | None = None,
    budget_chars: int = DEFAULT_BUDGET_CHARS,
    extra_characters: list[str] | None = None,
    tail_chars: int = 1500,
    project_id: str | None = None,
) -> tuple[str, ContextBundle]:
    """Build a full prompt: instruction + story context + working text.

    Returns (prompt, bundle) so callers can report bundle.stats() upstream.
    """
    bundle = build_context(
        text, chapter_id=chapter_id, include=include,
        budget_chars=budget_chars, extra_characters=extra_characters,
        project_id=project_id,
    )
    context_block = bundle.render()
    parts: list[str] = []
    if instruction:
        parts.append(instruction)
    if context_block:
        parts.append("=== STORY CONTEXT (for consistency — do not repeat it verbatim) ===")
        parts.append(context_block)
        parts.append("=== END CONTEXT ===")
    parts.append("TEXT TO WORK ON:")
    parts.append((text or "")[-tail_chars:])
    return "\n\n".join(parts), bundle
