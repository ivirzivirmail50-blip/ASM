"""Durable background task queue (F-05, v9.3.0).

Export/compile işleri artık bellek-içi core.cache'te değil,
``background_tasks`` tablosunda (SQLite) yaşar:

  * ``enqueue`` → pending satırı
  * worker ``claim_next`` → atomik pending→running geçişi
  * ``update_progress`` / ``complete`` / ``fail`` → durum diskte
  * uygulama çökerse: açılışta ``recover_stale_running`` running→pending
    (görev kaybolmaz, yeniden koşar)
  * ``purge_finished`` tablo büyümesini sınırlar

Durum şekli ``get_export_status`` API'siyle uyumlu:
    {"status": "pending|running|done|failed", "progress": 0-100,
     "stage": str, "filename": ..., "mime": ..., "size": ...}

Worker: tek daemon thread (tek kullanıcılı yerel uygulama — ayrı süreç
gerekmez). ``start_worker`` create_app içinde TESTING dışında çağrılır.
F-04 SSE kanalı ``subscribe`` pub/sub'undan ilerlemeleri iter.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable

from sqlalchemy import select, update

from core.db import new_bg_session, write_transaction
from models.background_task import BackgroundTask

log = logging.getLogger("asm.tasks")

# Worker'ı uyandırmak için olay (poll'a ek olarak anında uyanır)
_wake_event = threading.Event()
_shutdown = threading.Event()

# F-04: görev olaylarını SSE hub'ına yayınla (import döngüsünü önlemek için lazy)
_publishers: list[Callable[[dict[str, Any]], Any]] = []


def register_publisher(fn: Callable[[dict[str, Any]], Any]) -> None:
    """SSE hub kaydı — task olaylarını iter (F-04)."""
    if fn not in _publishers:
        _publishers.append(fn)


def _publish(event: dict[str, Any]) -> None:
    for fn in list(_publishers):
        try:
            fn(event)
        except Exception:  # noqa: BLE001 - yayın asla yürütmeyi bozmasın
            pass


# ---------------------------------------------------------------------------
# Temel kuyruk işlemleri
# ---------------------------------------------------------------------------

def enqueue(kind: str, payload: dict[str, Any] | None = None) -> BackgroundTask:
    """Görevi kuyruğa ekle (pending). DB satırı hemen kalıcıdır."""
    import uuid

    tid = uuid.uuid4().hex[:12]
    with write_transaction() as s:
        t = BackgroundTask(
            id=tid, kind=kind, status="pending",
            payload=json.dumps(payload or {}), progress=0,
            stage="Queued", created_at=_now(),
        )
        s.add(t)
    _publish({"event": "task.enqueued", "task_id": tid, "kind": kind})
    _wake_event.set()
    row = get_task(tid)  # detach edilmiş satır dön
    assert row is not None  # az önce ekledik — teori: yok
    return row


def claim_next() -> BackgroundTask | None:
    """En eski pending görevi running'a al (tek yazmac — atomik).

    İki ardışık claim asla aynı görevi dönemez: write_transaction içinde
    SELECT+UPDATE tek yazma kilidi altında koşar.
    """
    from core.db import _write_lock

    with _write_lock:
        with new_bg_session() as s:
            row = s.execute(
                select(BackgroundTask).where(BackgroundTask.status == "pending")
                .order_by(BackgroundTask.created_at.asc())
                .limit(1)
            ).scalars().first()
            if row is None:
                return None
            s.execute(
                update(BackgroundTask)
                .where(BackgroundTask.id == row.id)
                .values(status="running", started_at=_now(), progress=0,
                        stage="Starting...")
            )
            s.commit()
            return get_task(row.id)


def update_progress(task_id: str, progress: int, stage: str = "") -> None:
    progress = max(0, min(100, int(progress)))
    with new_bg_session() as s:
        s.execute(
            update(BackgroundTask)
            .where(BackgroundTask.id == task_id)
            .values(progress=progress, stage=stage or None)
        )
        s.commit()
    _publish({"event": "task.progress", "task_id": task_id,
              "progress": progress, "stage": stage})


def complete(task_id: str, result: dict[str, Any]) -> None:
    from datetime import datetime, timezone

    with new_bg_session() as s:
        s.execute(
            update(BackgroundTask)
            .where(BackgroundTask.id == task_id)
            .values(status="done", progress=100, result=json.dumps(result),
                    finished_at=datetime.now(timezone.utc),
                    stage="Done")
        )
        s.commit()
    _publish({"event": "task.done", "task_id": task_id, "result": result})


def fail(task_id: str, error: str) -> None:
    from datetime import datetime, timezone

    with new_bg_session() as s:
        s.execute(
            update(BackgroundTask)
            .where(BackgroundTask.id == task_id)
            .values(status="failed", error=str(error)[:2000],
                    finished_at=datetime.now(timezone.utc))
        )
        s.commit()
    _publish({"event": "task.failed", "task_id": task_id, "error": str(error)})


def get_task(task_id: str) -> BackgroundTask | None:
    from core.db import read_session

    with read_session() as s:
        t = s.get(BackgroundTask, task_id)
        if t is not None:
            s.expunge(t)
        return t


def list_recent(limit: int = 50) -> list[BackgroundTask]:
    from core.db import read_session

    with read_session() as s:
        rows = list(s.scalars(
            select(BackgroundTask)
            .order_by(BackgroundTask.created_at.desc())
            .limit(limit)
        ).all())
        for r in rows:
            s.expunge(r)
        return rows


def recover_stale_running() -> int:
    """Çöküş sonrası: running'de takılan görevleri tekrar kuyruğa al.

    Dayanıklılık sözleşmesinin kalbi — uygulama kapansa da durum kaybolmaz;
    açılışta yarım kalan işler yeniden koşar. Dönen değer: kurtarılan adet.
    """
    with new_bg_session() as s:
        res = s.execute(
            update(BackgroundTask)
            .where(BackgroundTask.status == "running")
            .values(status="pending", progress=0, stage="Requeued after restart")
        )
        s.commit()
        n = int(getattr(res, "rowcount", 0) or 0)
    if n:
        log.info("Recovered %d stale running task(s) after restart.", n)
        _publish({"event": "task.recovered", "count": n})
    return n


def purge_finished(older_than_days: int = 7, keep_rows: int = 200) -> int:
    """Büyüme denetimi: bitmiş görev satırlarını sil (dosyalar değil).

    Kural (yaş önce, taban sonra):
      1. cutoff'tan eski her done/failed satırı silinir (yaş kuralı).
      2. Yaş kuralından kurtulan ``done/failed`` sayısı ``keep_rows``'u
         aşıyorsa en eski taşma da silinir (taban kuralı).
    """
    from datetime import datetime, timedelta

    # SQLite DATETIME kolonları naive'dir — karşılaştırma da naive olmalı.
    cutoff = datetime.utcnow() - timedelta(days=older_than_days)
    with new_bg_session() as s:
        rows = list(s.scalars(
            select(BackgroundTask)
            .where(BackgroundTask.status.in_(("done", "failed")))
            .order_by(BackgroundTask.created_at.desc())
        ).all())
        to_delete: set[str] = set()
        recent: list[str] = []
        for r in rows:  # en yeni → en eski
            if r.created_at and r.created_at < cutoff:
                to_delete.add(r.id)
            else:
                recent.append(r.id)
        if len(recent) > keep_rows:
            to_delete.update(recent[keep_rows:])
        if not to_delete:
            return 0
        s.query(BackgroundTask).filter(
            BackgroundTask.id.in_(to_delete)).delete(synchronize_session=False)
        s.commit()
        log.info("Purged %d finished task row(s).", len(to_delete))
        return len(to_delete)


def task_to_dict(t: BackgroundTask) -> dict[str, Any]:
    """API temsili — get_export_status şekliyle uyumlu."""
    return {
        "task_id": t.id,
        "kind": t.kind,
        "status": t.status,
        "progress": t.progress or 0,
        "stage": t.stage or "",
        "payload": json.loads(t.payload) if t.payload else {},
        "result": json.loads(t.result) if t.result else None,
        "error": t.error,
        "created_at": t.created_at.isoformat() if t.created_at else None,
        "started_at": t.started_at.isoformat() if t.started_at else None,
        "finished_at": t.finished_at.isoformat() if t.finished_at else None,
    }


def status_dict(task_id: str) -> dict[str, Any] | None:
    """export_service.get_export_status uyumlu sözlük (None = bulunamadı).

    Kelime dağarı bilinçli olarak ESKİ (cache-öncesi) UI sözleşmesi:
    pending/running → "processing", failed → "error", done → "done" —
    templates/export.html "done"/"error" dallarını yoklar.
    Ham DB durumu /tasks/<id> endpoint'inden görülür.
    """
    t = get_task(task_id)
    if t is None:
        return None
    d = task_to_dict(t)
    legacy = {"pending": "processing", "running": "processing",
              "failed": "error"}.get(t.status, t.status)
    out: dict[str, Any] = {
        "status": legacy,
        "progress": d["progress"],
        "stage": d["stage"],
        "task_id": t.id,
        "kind": t.kind,
    }
    if t.result:
        r = d["result"] or {}
        out["filename"] = r.get("filename")
        out["mime"] = r.get("mime")
        out["size"] = r.get("size")
    return out


def _now() -> "datetime":
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Çalıştırıcı (executor)
# ---------------------------------------------------------------------------

def execute_one() -> bool:
    """Kuyruktan bir görev al ve çalıştır. True = görev koştu.

    Testler worker thread'i olmadan bunu senkron çağırır.
    """
    t = claim_next()
    if t is None:
        return False
    payload = json.loads(t.payload) if t.payload else {}
    log.info("Task %s (%s) started.", t.id, t.kind)
    try:
        result = _dispatch(t.id, t.kind, payload)
        complete(t.id, result)
        log.info("Task %s done: %s", t.id, result)
    except Exception as exc:  # noqa: BLE001 - kuyruk asla düşmemeli
        log.exception("Task %s failed", t.id)
        fail(t.id, f"{type(exc).__name__}: {exc}")
    return True


def _dispatch(task_id: str, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    if kind == "export":
        return _execute_export(task_id, payload)
    raise ValueError(f"Unknown task kind: {kind!r}")


def _execute_export(task_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Export görevini koştur — export_service'ün saf fonksiyonlarını kullanır."""
    from config import Config
    from services import export_service

    entity_type = payload.get("entity_type", "")
    fmt = payload.get("fmt", "txt")
    entity_id = payload.get("entity_id")

    update_progress(task_id, 10, "Preparing export...")
    if entity_type == "manuscript":
        update_progress(task_id, 30, "Gathering chapters...")
        content, mime, filename = export_service.export_manuscript(fmt)
    elif entity_type == "world_bible":
        update_progress(task_id, 30, "Gathering world entries...")
        content, mime, filename = export_service.export_world_bible(fmt)
    elif entity_type == "full_project":
        update_progress(task_id, 20, "Gathering all data...")
        content, mime, filename = export_service.export_full_project(fmt)
    elif entity_type == "chapter" and entity_id:
        update_progress(task_id, 30, "Exporting chapter...")
        content, mime, filename = export_service.export_chapter(entity_id, fmt)
    elif entity_type == "character" and entity_id:
        update_progress(task_id, 30, "Generating character sheet...")
        content, mime, filename = export_service.export_character_sheet(entity_id, fmt)
    else:
        from core.errors import NotFoundError

        raise NotFoundError(f"Unknown export type: {entity_type}")

    update_progress(task_id, 80, "Finalizing file...")
    export_dir = Config.EXPORT_DIR / task_id
    export_dir.mkdir(parents=True, exist_ok=True)
    file_path = export_dir / filename
    file_path.write_bytes(content)
    # v9.3.0 (F-12): export sonrası eklenti kancası.
    try:
        from core import hooks

        hooks.fire("after_export", {
            "task_id": task_id, "entity_type": entity_type, "fmt": fmt,
            "filename": filename, "size": len(content),
        })
    except Exception:  # noqa: BLE001
        pass
    return {"filename": filename, "mime": mime, "size": len(content)}


# ---------------------------------------------------------------------------
# Worker thread
# ---------------------------------------------------------------------------

# Worker thread durumu (F-11: tipli)
_worker_lock = threading.Lock()
_worker_thread: threading.Thread | None = None


def start_worker() -> None:
    """Daemon worker'ı başlat (TESTING modunda çağrılmaz)."""
    global _worker_thread
    with _worker_lock:
        t = _worker_thread
        if t is not None and t.is_alive():
            return
        # Açılış bakımı: yarım işleri kurtar, eski kayıtları temizle.
        try:
            recover_stale_running()
        except Exception:  # noqa: BLE001 - bakım hataları başlatmayı bloklamasın
            log.exception("Startup task recovery failed")
        try:
            purge_finished()
        except Exception:  # noqa: BLE001
            log.exception("Startup task purge failed")
        th = threading.Thread(target=_worker_loop, name="asm-task-worker",
                              daemon=True)
        _worker_thread = th
        th.start()
        log.info("Background task worker started.")


def stop_worker() -> None:
    """Worker'ı durdur (test temizliği)."""
    _shutdown.set()
    _wake_event.set()


def _worker_loop() -> None:
    while not _shutdown.is_set():
        try:
            ran = execute_one()
            if not ran:
                _wake_event.wait(timeout=1.0)
                _wake_event.clear()
        except Exception:  # noqa: BLE001 - worker asla ölmesin
            log.exception("Worker loop error")
            time.sleep(1.0)
