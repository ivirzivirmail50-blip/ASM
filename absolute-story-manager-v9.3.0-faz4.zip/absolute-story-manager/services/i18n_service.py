"""Internationalization (i18n) — multi-language UI support.

Supports: English (default), Turkish, Spanish, French, German.
Language is stored in settings as 'ui_language'.

Usage in templates:
  {{ t('dashboard.title') }}
  {{ t('chapters.new') }}

v9.2.0 (F-02): translations live in JSON files under ``translations/``
(one flat key → string file per language) instead of an inline Python
dict, so they diff cleanly and translators can edit them without touching
code. ``get_translation_dict`` is cached per language and invalidated by
``set_language``.

Missing keys fall back to English, then to the key itself.
"""
from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Any

from core.db import read_session
from models.settings import Setting

log = logging.getLogger("asm.i18n")

SUPPORTED_LANGUAGES = {
    "en": {"label": "English", "icon": "🇬🇧"},
    "tr": {"label": "Türkçe", "icon": "🇹🇷"},
    "es": {"label": "Español", "icon": "🇪🇸"},
    "fr": {"label": "Français", "icon": "🇫🇷"},
    "de": {"label": "Deutsch", "icon": "🇩🇪"},
}

_TRANSLATIONS_DIR = Path(__file__).resolve().parent.parent / "translations"

# key → {lang: translation}; loaded once from the JSON files (F-02).
TRANSLATIONS: dict[str, dict[str, str]] = {}

_load_lock = threading.Lock()


def _load_translations() -> dict[str, dict[str, str]]:
    """Load all translations/*.json into the TRANSLATIONS shape."""
    data: dict[str, dict[str, str]] = {}
    for lang in SUPPORTED_LANGUAGES:
        path = _TRANSLATIONS_DIR / f"{lang}.json"
        if not path.exists():
            log.warning("Translation file missing: %s", path)
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("Failed to load %s: %s", path, exc)
            continue
        for key, value in payload.items():
            data.setdefault(key, {})[lang] = str(value)
    return data


def _ensure_loaded() -> dict[str, dict[str, str]]:
    global TRANSLATIONS
    if TRANSLATIONS:
        return TRANSLATIONS
    with _load_lock:
        if not TRANSLATIONS:
            TRANSLATIONS = _load_translations()
    return TRANSLATIONS


def reload_translations() -> None:
    """Test hook: force a fresh read of the JSON files on next access."""
    global TRANSLATIONS
    with _load_lock:
        TRANSLATIONS = {}
    _dict_cache.clear()


def translation_file(lang: str) -> Path:
    """Path of the JSON file for a language (used by tests/CI audits)."""
    return _TRANSLATIONS_DIR / f"{lang}.json"


# S-05 — process-level language cache; ``set_language`` invalidates it.
_lang_cache: dict[str, str | None] = {"value": None}

# F-02 — flat per-language dict cache (key → string), invalidated by
# set_language / reload_translations.
_dict_cache: dict[str, dict[str, str]] = {}


def get_current_language() -> str:
    """Get the current UI language from settings.

    v9.0.1 (S-05): the value is cached per-process and invalidated by
    ``set_language``. Previously EVERY ``translate()`` call (and the
    context processor injected into EVERY template render) opened a fresh
    DB session just to read one row that almost never changes.
    """
    cached = _lang_cache.get("value")
    if cached is not None:
        return cached
    with read_session() as s:
        lang = Setting.get(s, "ui_language", "en")
        if isinstance(lang, str) and lang in SUPPORTED_LANGUAGES:
            _lang_cache["value"] = lang
            return lang
    return "en"


def set_language(lang: str) -> None:
    """Set the UI language (and invalidate the S-05/F-02 caches)."""
    if lang not in SUPPORTED_LANGUAGES:
        lang = "en"
    from core.db import write_transaction
    with write_transaction() as s:
        # v9.1.0 (M-03): Setting.set also invalidates the settings snapshot.
        Setting.set(s, "ui_language", lang)
    _lang_cache["value"] = lang
    _dict_cache.clear()


def invalidate_language_cache() -> None:
    """Test hook: forget the cached language (next read hits the DB)."""
    _lang_cache["value"] = None


def translate(key: str, lang: str | None = None) -> str:
    """Translate a key to the given language (or current language)."""
    if not lang:
        lang = get_current_language()
    table = _ensure_loaded()
    translations = table.get(key)
    if translations:
        if lang in translations:
            return translations[lang]
        # Fallback to English
        if "en" in translations:
            return translations["en"]
    # Key not found — return the key itself
    return key


def get_translation_dict(lang: str | None = None) -> dict[str, str]:
    """Return all translations for the given language as a flat dict.

    v9.2.0 (F-02): result is cached per language — the context processor
    calls this on EVERY template render, and building the flat dict from
    ~90 keys each time was pure waste.
    """
    if not lang:
        lang = get_current_language()
    cached = _dict_cache.get(lang)
    if cached is not None:
        return cached
    table = _ensure_loaded()
    result: dict[str, str] = {}
    for key, translations in table.items():
        if lang in translations:
            result[key] = translations[lang]
        elif "en" in translations:
            result[key] = translations["en"]
        else:
            result[key] = key
    _dict_cache[lang] = result
    return result


def missing_translations() -> dict[str, list[str]]:
    """Audit hook for CI: keys lacking a translation in any language.

    Returns {lang: [keys missing]}. English is the fallback language, so
    a key missing ONLY in e.g. Turkish still renders (English), but the
    audit makes the gap visible — a new t('nav.x') usage in a template
    must be accompanied by keys in the translation files.
    """
    table = _ensure_loaded()
    report: dict[str, list[str]] = {}
    keys = sorted(table.keys())
    for lang in SUPPORTED_LANGUAGES:
        gaps = [k for k in keys if lang not in table[k]]
        if gaps:
            report[lang] = gaps
    return report


def used_template_keys() -> set[str]:
    """Scan templates for {{ t('...') }} / t('...') usages (audit helper)."""
    import re
    templates_dir = Path(__file__).resolve().parent.parent / "templates"
    pattern = re.compile(r"\bt\(\s*['\"]([a-zA-Z0-9_.\-]+)['\"]\s*\)")
    found: set[str] = set()
    for path in templates_dir.rglob("*.html"):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        found.update(pattern.findall(text))
    return found


def _unused_compat(**_: Any) -> None:  # pragma: no cover
    """Placeholder keeping the import surface stable for legacy callers."""
