"""Story Chronology — the manuscript mapped onto story time (v8.3).

Complements the existing planning tools:
  * plans.timeline   — PLAN EVENTS on multi-track lanes (what you intend)
  * timeline_check   — conflict AUDIT of plan dates (what's inconsistent)
  * chronology (this) — the WRITTEN MANUSCRIPT on one time axis, with plan
    events overlaid, story-time gaps, out-of-order chapter flags, and
    per-chapter character presence (who is on stage when).

Positioning modes (auto-detected by coverage):
  date  — real parseable dates (2026-07-15, July 2026, …)
  day   — "Day 14" / "Gün 3" markers extracted from freeform story_date
  order — no time info at all: chapters laid out in sort order (still
          useful as a compact strip with character filtering)

Everything is computed server-side into a position model the client can
map to pixels (t = timeline value; None for undated).
"""
from __future__ import annotations

import logging
import re
from typing import Any

from sqlalchemy import select

from core.db import read_session
from models.chapter import Chapter
from models.character import Character
from models.plan import Plan
from services._common import current_project_id, load_json
from services.timeline_check_service import parse_story_date

log = logging.getLogger("asm.chronology")

_DAY_RE = re.compile(r"\b(?:day|gün)\s*#?\s*(\d{1,5})\b", re.IGNORECASE)
_MIN_DATED_FOR_MODE = 2
_DEFAULT_GAP_DAYS = 30


def _day_marker(raw: str | None) -> int | None:
    if not raw:
        return None
    m = _DAY_RE.search(raw)
    if m:
        return int(m.group(1))
    # bare integers ("14") also read as day markers in "day" mode —
    # but ONLY when the string is nothing but digits, so real years
    # (2026) stay dates for parse_story_date.
    s = raw.strip()
    if s.isdigit() and len(s) <= 4 and not (1000 <= int(s) <= 2199):
        return int(s)
    return None


def _status_color(status: str | None) -> str:
    return {
        "draft": "var(--text-mute)",
        "revision": "var(--warning, #f59e0b)",
        "final": "var(--accent, #6366f1)",
        "published": "var(--success, #22c55e)",
    }.get((status or "draft").lower(), "var(--text-mute)")


def build_timeline() -> dict[str, Any]:
    """Assemble the full chronology payload for the current project."""
    with read_session() as s:
        pid = current_project_id(s)
        chapters = list(s.scalars(
            select(Chapter).where(Chapter.project_id == pid)
            .order_by(Chapter.sort_order.asc())
        ).all())
        events = list(s.scalars(
            select(Plan).where(Plan.project_id == pid)
        ).all())
        characters = list(s.scalars(
            select(Character).where(Character.project_id == pid)
        ).all())

    # ---- character presence: one alternation regex, one pass per chapter
    name_to_char: dict[str, dict] = {}
    for c in characters:
        names = [c.name] + [a for a in (load_json(c.aliases, []) or []) if a]
        entry = {"id": c.id, "name": c.name, "aliases": names[1:]}
        for n in names:
            if n and len(n) >= 2:
                name_to_char[n.lower()] = entry
    presence: dict[str, list[str]] = {}
    if name_to_char:
        pattern = re.compile(
            r"\b(?:" + "|".join(
                re.escape(n) for n in sorted(name_to_char, key=len, reverse=True)
            ) + r")\b",
            re.IGNORECASE,
        )
        for ch in chapters:
            found: dict[str, None] = {}
            for m in pattern.finditer(ch.content or ""):
                entry = name_to_char.get(m.group(0).lower())
                if entry:
                    found[entry["id"]] = None
            presence[ch.id] = sorted(found.keys())

    # ---- extract timeline values
    # Mode is decided by CHAPTERS (the manuscript is the primary object):
    # events only break a tie when chapters carry no time info at all.
    dated_ch: list[float] = []
    dayed_ch: list[int] = []
    for ch in chapters:
        d = parse_story_date(ch.story_date or "")
        if d:
            dated_ch.append(d.toordinal())
        else:
            dm = _day_marker(ch.story_date)
            if dm is not None:
                dayed_ch.append(dm)
    dated_ev: list[float] = []
    dayed_ev: list[int] = []
    for ev in events:
        d = parse_story_date(ev.story_date or "")
        if d:
            dated_ev.append(d.toordinal())
        else:
            dm = _day_marker(ev.story_date)
            if dm is not None:
                dayed_ev.append(dm)

    if len(dated_ch) >= _MIN_DATED_FOR_MODE and len(dated_ch) >= len(dayed_ch):
        mode = "date"
    elif len(dayed_ch) >= _MIN_DATED_FOR_MODE:
        mode = "day"
    elif (
        not chapters
        and len(dated_ev) >= _MIN_DATED_FOR_MODE
        and len(dated_ev) >= len(dayed_ev)
    ):
        mode = "date"  # empty manuscript, planned events still mappable
    elif not chapters and len(dayed_ev) >= _MIN_DATED_FOR_MODE:
        mode = "day"
    else:
        mode = "order"

    def t_of(raw: str | None) -> float | None:
        """Timeline value for a raw story_date under the active mode."""
        if not raw:
            return None
        if mode == "date":
            d = parse_story_date(raw)
            return float(d.toordinal()) if d else None
        if mode == "day":
            dm = _day_marker(raw)
            return float(dm) if dm is not None else None
        return None

    # ---- chapters
    chapter_rows: list[dict] = []
    for idx, ch in enumerate(chapters):
        chapter_rows.append({
            "id": ch.id,
            "num": idx + 1,
            "title": ch.title,
            "status": ch.status or "draft",
            "status_color": _status_color(ch.status),
            "word_count": ch.word_count or len((ch.content or "").split()),
            "story_date_raw": ch.story_date,
            "t": t_of(ch.story_date),
            "sort_order": ch.sort_order,
            "characters": presence.get(ch.id, []),
        })

    # ---- plan events
    chapter_ids = {ch.id for ch in chapters}
    event_rows: list[dict] = []
    for ev in events:
        linked = bool(ev.chapter_id) and ev.chapter_id in chapter_ids
        event_rows.append({
            "id": ev.id,
            "title": ev.title,
            "track": ev.track,
            "event_type": ev.event_type,
            "story_date_raw": ev.story_date,
            "t": t_of(ev.story_date),
            "linked": linked,
        })
    events_written = sum(1 for e in event_rows if e["linked"])

    # ---- out-of-order flags (adjacent contradiction between sort and time)
    oop_ids: set[str] = set()
    timed = [c for c in chapter_rows if c["t"] is not None]
    for a, b in zip(timed, timed[1:]):
        if b["t"] < a["t"]:
            oop_ids.add(b["id"])

    # ---- gaps (dated chapters only, scale-aware threshold)
    gaps: list[dict] = []
    dated_chapters = [c for c in chapter_rows if c["t"] is not None]
    t_values = [c["t"] for c in dated_chapters]
    if t_values:
        span = max(t_values) - min(t_values)
        threshold = max(_DEFAULT_GAP_DAYS, span / 12.0)
        for a, b in zip(dated_chapters, dated_chapters[1:]):
            delta = b["t"] - a["t"]
            if delta > threshold:
                gaps.append({
                    "from_title": a["title"],
                    "to_title": b["title"],
                    "delta": delta,
                    "t1": a["t"],
                    "t2": b["t"],
                })

    dated_count = len(dated_chapters)
    story_days = (
        round(max(t_values) - min(t_values)) if len(t_values) >= 2 else 0
    )

    def _iso(raw: str | None) -> str | None:
        if not raw:
            return None
        d = parse_story_date(raw)
        return d.isoformat() if d else None

    undated = [
        {"id": c["id"], "title": c["title"], "num": c["num"]}
        for c in chapter_rows if c["t"] is None
    ]
    if mode == "order":
        # everything sits on the strip in reading order — the 'undated' list
        # would duplicate the whole manuscript and say nothing useful.
        undated = []

    char_options = [
        {"id": c.id, "name": c.name} for c in characters
    ]

    return {
        "ok": True,
        "mode": mode,
        "chapters": chapter_rows,
        "events": event_rows,
        "gaps": gaps,
        "undated": undated,
        "oop_ids": sorted(oop_ids),
        "stats": {
            "total_chapters": len(chapters),
            "dated_chapters": dated_count,
            "coverage_pct": round(dated_count / max(len(chapters), 1) * 100, 1),
            "story_days": story_days,
            "earliest": _iso(min(dated_chapters, key=lambda c: c["t"])["story_date_raw"]) if dated_count else None,
            "latest": _iso(max(dated_chapters, key=lambda c: c["t"])["story_date_raw"]) if dated_count else None,
            "events_total": len(event_rows),
            "events_written": events_written,
            "gap_count": len(gaps),
            "oop_count": len(oop_ids),
        },
        "character_options": char_options,
    }
