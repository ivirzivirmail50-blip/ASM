"""Manuscript Compile Wizard — build a publication-ready manuscript with front matter.

Distinct from export_service.export_manuscript() (which is a simple
chapter concatenation). The Compile Wizard lets the writer configure:

- Front matter: title page, copyright notice, dedication, epigraph,
  acknowledgments, table of contents
- Chapter formatting: include chapter numbers, scene break markers,
  drop caps, chapter separators
- Back matter: author note, about the author, other books
- Output format: txt, md, html, docx, pdf (typeset print book),
  epub (publication-grade EPUB 3 ebook) — v8.7 "Book Forge"

The compile config is persisted as a Setting so the writer doesn't have
to re-configure each time.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from sqlalchemy import select

from core.db import read_session, write_transaction
from core.errors import NotFoundError, ValidationError
from models.chapter import Chapter
from models.settings import Setting
from services._common import (
    SAFE_FILENAME_SLUG,
    current_project_id,
    dump_json,
    load_json,
    md_to_html_minimal,
    safe_filename,
)

log = logging.getLogger("asm.compile")


DEFAULT_COMPILE_CONFIG: dict[str, Any] = {
    # Front matter
    "include_title_page": True,
    "include_copyright": True,
    "copyright_text": "© 2026 by Author Name. All rights reserved.",
    "include_dedication": False,
    "dedication_text": "For those who believed in this story before it existed.",
    "include_epigraph": False,
    "epigraph_text": "",
    "epigraph_attribution": "",
    "include_acknowledgments": False,
    "acknowledgments_text": "",
    "include_toc": True,
    # Chapter formatting
    "chapter_number_format": "chapter",  # none / chapter / number / chapter_number
    "chapter_title_prefix": "",
    "scene_break_marker": "* * *",
    "include_synopsis": False,  # only for writer reference, not publication
    # Back matter
    "include_author_note": False,
    "author_note_text": "",
    "include_about_author": False,
    "about_author_text": "",
    "include_other_books": False,
    "other_books_text": "",
    # Chapter selection
    "chapter_status_filter": "all",  # all / draft / revised / final
    # Book identity (v8.7)
    "author_name": "",          # override; blank -> settings story_author
    "book_language": "",        # blank -> current UI language (en/tr/…)
    "cover_image": "",          # /media/covers/… public path (uploaded)
    # Print layout (v8.7 — PDF only)
    "pdf_page_size": "6x9",     # 6x9 / digest / a5 / a4 / letter
    "pdf_font_size": 10.5,      # body font size in pt
    "pdf_line_height": 1.5,     # body leading multiplier
    "pdf_mirrored": True,       # mirrored margins (binding side alternates)
    # Ebook layout (v8.7 — EPUB only)
    "epub_justify": True,       # justified paragraph text
    # Output
    "format": "html",  # txt / md / html / docx / pdf / epub
}

# Language-aware book labels (front/back matter + chapter numbering).
_BOOK_LABELS: dict[str, dict[str, str]] = {
    "en": {
        "toc": "Table of Contents", "acknowledgments": "Acknowledgments",
        "author_note": "Author's Note", "about_author": "About the Author",
        "other_books": "Other Books by the Author", "chapter": "Chapter",
        "by": "by", "copyright": "Copyright",
    },
    "tr": {
        "toc": "İçindekiler", "acknowledgments": "Teşekkürler",
        "author_note": "Yazardan Notlar", "about_author": "Yazar Hakkında",
        "other_books": "Yazarın Diğer Kitapları", "chapter": "Bölüm",
        "by": "", "copyright": "Telif",
    },
    "es": {
        "toc": "Índice", "acknowledgments": "Agradecimientos",
        "author_note": "Nota del Autor", "about_author": "Sobre el Autor",
        "other_books": "Otros Libros del Autor", "chapter": "Capítulo",
        "by": "de", "copyright": "Copyright",
    },
    "fr": {
        "toc": "Table des Matières", "acknowledgments": "Remerciements",
        "author_note": "Note de l'Auteur", "about_author": "À propos de l'Auteur",
        "other_books": "Autres Livres de l'Auteur", "chapter": "Chapitre",
        "by": "par", "copyright": "Copyright",
    },
    "de": {
        "toc": "Inhaltsverzeichnis", "acknowledgments": "Danksagung",
        "author_note": "Notiz des Autors", "about_author": "Über den Autor",
        "other_books": "Weitere Bücher des Autors", "chapter": "Kapitel",
        "by": "von", "copyright": "Copyright",
    },
}


def _book_label(lang: str, key: str) -> str:
    """Translate a book-part label; falls back to English."""
    return _BOOK_LABELS.get(lang, {}).get(key) or _BOOK_LABELS["en"][key]


def get_config() -> dict[str, Any]:
    """Load the compile config from settings, merged with defaults."""
    with read_session() as s:
        raw = Setting.get(s, "compile_config", "")
    if not raw:
        return dict(DEFAULT_COMPILE_CONFIG)
    # Setting.get already parses JSON, so raw is usually a dict.
    # Handle both dict and string for safety.
    if isinstance(raw, str):
        try:
            saved = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return dict(DEFAULT_COMPILE_CONFIG)
    elif isinstance(raw, dict):
        saved = raw
    else:
        return dict(DEFAULT_COMPILE_CONFIG)
    merged = dict(DEFAULT_COMPILE_CONFIG)
    merged.update(saved)
    return merged


def save_config(config: dict[str, Any]) -> dict[str, Any]:
    """Persist the compile config."""
    merged = dict(DEFAULT_COMPILE_CONFIG)
    merged.update(config)
    # Validate
    if merged["chapter_number_format"] not in ("none", "chapter", "number", "chapter_number"):
        raise ValidationError("chapter_number_format must be none/chapter/number/chapter_number")
    if merged["format"] not in ("txt", "md", "html", "docx", "pdf", "epub"):
        raise ValidationError("format must be txt/md/html/docx/pdf/epub")
    if merged["chapter_status_filter"] not in ("all", "draft", "revised", "final"):
        raise ValidationError("chapter_status_filter must be all/draft/revised/final")
    if merged["pdf_page_size"] not in ("6x9", "digest", "a5", "a4", "letter"):
        raise ValidationError("pdf_page_size must be 6x9/digest/a5/a4/letter")
    try:
        fs = float(merged.get("pdf_font_size") or 10.5)
    except (TypeError, ValueError):
        raise ValidationError("pdf_font_size must be a number")
    merged["pdf_font_size"] = min(max(fs, 8.0), 14.0)
    try:
        lh = float(merged.get("pdf_line_height") or 1.5)
    except (TypeError, ValueError):
        raise ValidationError("pdf_line_height must be a number")
    merged["pdf_line_height"] = min(max(lh, 1.0), 2.0)
    def _to_bool(val: Any, default: bool) -> bool:
        if isinstance(val, str):
            return val.strip().lower() not in ("", "false", "0", "off", "no")
        if val is None:
            return default
        return bool(val)

    merged["pdf_mirrored"] = _to_bool(merged.get("pdf_mirrored", True), True)
    merged["epub_justify"] = _to_bool(merged.get("epub_justify", True), True)
    if not isinstance(merged.get("author_name", ""), str):
        merged["author_name"] = str(merged.get("author_name") or "")
    if not isinstance(merged.get("book_language", ""), str):
        merged["book_language"] = str(merged.get("book_language") or "")
    merged["book_language"] = merged["book_language"].lower()[:2]
    if not isinstance(merged.get("cover_image", ""), str):
        merged["cover_image"] = str(merged.get("cover_image") or "")
    with write_transaction() as s:
        # v9.1.0 (M-03): route through Setting.set so the settings snapshot
        # and cached template globals are invalidated on write.
        Setting.set(s, "compile_config", merged)
    return merged


def _filter_chapters(config: dict[str, Any]) -> list[Chapter]:
    """Return chapters matching the status filter, in sort order."""
    status_filter = config.get("chapter_status_filter", "all")
    with read_session() as s:
        q = select(Chapter).where(Chapter.project_id == current_project_id(s))
        if status_filter != "all":
            q = q.where(Chapter.status == status_filter)
        chapters = list(s.scalars(q.order_by(Chapter.sort_order.asc())))
        return chapters


def _resolve_book_lang(config: dict[str, Any]) -> str:
    """Book language: explicit config override, else current UI language."""
    lang = (config.get("book_language") or "").strip().lower()
    if lang:
        return lang[:2]
    try:
        from services.i18n_service import get_current_language
        return (get_current_language() or "en")[:2]
    except Exception:  # noqa: BLE001 — settings may be unavailable in tests
        return "en"


def _format_chapter_title(ch: Chapter, idx: int, config: dict[str, Any],
                          lang: str = "en") -> str:
    """Format the chapter title according to config (language-aware)."""
    fmt = config.get("chapter_number_format", "chapter")
    prefix = config.get("chapter_title_prefix", "")
    chap_word = _book_label(lang, "chapter")
    parts: list[str] = []
    if fmt == "chapter":
        parts.append(f"{chap_word} {idx}")
        if ch.title:
            parts.append(ch.title)
    elif fmt == "number":
        parts.append(str(idx))
        if ch.title:
            parts.append(ch.title)
    elif fmt == "chapter_number":
        parts.append(f"{chap_word} {idx}: {ch.title}" if ch.title else f"{chap_word} {idx}")
    else:  # none
        if ch.title:
            parts.append(ch.title)
    title = " — ".join(parts)
    if prefix and fmt != "none":
        return f"{prefix}{title}"
    return title


def compile_manuscript(config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Compile the manuscript with front matter.

    Returns a dict with: title, author, sections (list of {type, heading, body, html}),
    total_words, chapter_count.
    """
    config = config or get_config()
    chapters = _filter_chapters(config)
    lang = _resolve_book_lang(config)
    # v8.7 — book identity: title from the ACTIVE book (multi-book fix;
    # before, compile always showed the global story_title even when the
    # chapters came from another book), author from config override.
    from models.project import Project
    with read_session() as s:
        title = Setting.get(s, "story_title", "My Story")
        author_fallback = Setting.get(s, "story_author", "Author")
        pid = current_project_id(s)
        proj = s.get(Project, pid)
        if proj is not None and proj.name:
            title = proj.name
    author = (config.get("author_name") or "").strip() or author_fallback
    sections: list[dict[str, Any]] = []

    # ---- Front matter ----
    if config.get("include_title_page"):
        by = _book_label(lang, "by")
        by_line = f"{by} {author}".strip()
        sections.append({
            "type": "title_page",
            "heading": "",
            "body": f"{title}\n{by_line}",
            "html": f"<div class='title-page'><h1>{_esc(title)}</h1><p class='author'>{_esc(by_line)}</p></div>",
        })
    if config.get("include_copyright"):
        ct = config.get("copyright_text", "")
        sections.append({
            "type": "copyright",
            "heading": "",
            "body": ct,
            "html": f"<div class='copyright'><p>{_esc(ct).replace(chr(10), '<br>')}</p></div>",
        })
    if config.get("include_dedication"):
        dt = config.get("dedication_text", "")
        sections.append({
            "type": "dedication",
            "heading": "",
            "body": dt,
            "html": f"<div class='dedication'><p><em>{_esc(dt).replace(chr(10), '<br>')}</em></p></div>",
        })
    if config.get("include_epigraph"):
        et = config.get("epigraph_text", "")
        ea = config.get("epigraph_attribution", "")
        body = et + (f"\n— {ea}" if ea else "")
        sections.append({
            "type": "epigraph",
            "heading": "",
            "body": body,
            "html": f"<div class='epigraph'><blockquote>{_esc(et).replace(chr(10), '<br>')}</blockquote>{f'<p>— {_esc(ea)}</p>' if ea else ''}</div>",
        })
    if config.get("include_toc"):
        toc_lines: list[str] = []
        toc_html: list[str] = ["<ul class='toc'>"]
        for i, ch in enumerate(chapters, start=1):
            ct = _format_chapter_title(ch, i, config, lang)
            toc_lines.append(f"{ct}")
            toc_html.append(f"<li>{_esc(ct)}</li>")
        toc_html.append("</ul>")
        sections.append({
            "type": "toc",
            "heading": _book_label(lang, "toc"),
            "body": "\n".join(toc_lines),
            "html": "".join(toc_html),
        })
    if config.get("include_acknowledgments"):
        at = config.get("acknowledgments_text", "")
        label = _book_label(lang, "acknowledgments")
        sections.append({
            "type": "acknowledgments",
            "heading": label,
            "body": at,
            "html": f"<div class='acknowledgments'><h2>{_esc(label)}</h2><p>{_esc(at).replace(chr(10), '<br>')}</p></div>",
        })

    # ---- Chapters ----
    total_words = 0
    for i, ch in enumerate(chapters, start=1):
        ct = _format_chapter_title(ch, i, config, lang)
        content = ch.content or ""
        # Apply scene break marker if set
        marker = config.get("scene_break_marker", "")
        if marker:
            # Replace 3+ newlines with the marker
            import re
            content = re.sub(r"\n{3,}", f"\n\n{marker}\n\n", content)
        wc = len(content.split()) if content else 0
        total_words += wc
        sections.append({
            "type": "chapter",
            "heading": ct,
            "body": content,
            "html": f"<div class='chapter'><h2>{_esc(ct)}</h2><div class='chapter-content'>{md_to_html_minimal(content)}</div></div>",
            "word_count": wc,
            "chapter_id": ch.id,
        })

    # ---- Back matter ----
    if config.get("include_author_note"):
        an = config.get("author_note_text", "")
        label = _book_label(lang, "author_note")
        sections.append({
            "type": "author_note",
            "heading": label,
            "body": an,
            "html": f"<div class='author-note'><h2>{_esc(label)}</h2><p>{_esc(an).replace(chr(10), '<br>')}</p></div>",
        })
    if config.get("include_about_author"):
        aa = config.get("about_author_text", "")
        label = _book_label(lang, "about_author")
        sections.append({
            "type": "about_author",
            "heading": label,
            "body": aa,
            "html": f"<div class='about-author'><h2>{_esc(label)}</h2><p>{_esc(aa).replace(chr(10), '<br>')}</p></div>",
        })
    if config.get("include_other_books"):
        ob = config.get("other_books_text", "")
        label = _book_label(lang, "other_books")
        sections.append({
            "type": "other_books",
            "heading": label,
            "body": ob,
            "html": f"<div class='other-books'><h2>{_esc(label)}</h2><p>{_esc(ob).replace(chr(10), '<br>')}</p></div>",
        })

    return {
        "title": title,
        "author": author,
        "language": lang,
        "sections": sections,
        "total_words": total_words,
        "chapter_count": len(chapters),
        "config": config,
    }


def render_compiled(compiled: dict[str, Any], fmt: str | None = None) -> tuple[bytes, str, str]:
    """Render the compiled manuscript into the requested format.

    Returns (content_bytes, mime_type, filename).
    """
    fmt = (fmt or compiled["config"].get("format", "html")).lower()
    title = compiled["title"]
    author = compiled["author"]
    sections = compiled["sections"]
    safe_title = safe_filename(title, **SAFE_FILENAME_SLUG)

    if fmt == "txt":
        parts: list[str] = []
        for sec in sections:
            if sec["heading"]:
                parts.append(f"\n{'=' * 60}\n{sec['heading']}\n{'=' * 60}\n\n")
            else:
                parts.append(f"\n{sec['body']}\n\n")
        return "".join(parts).encode("utf-8"), "text/plain", f"{safe_title}.txt"

    if fmt == "md":
        parts = [f"# {title}\n\n*by {author}*\n\n"]
        for sec in sections:
            if sec["heading"]:
                parts.append(f"\n## {sec['heading']}\n\n")
            parts.append(f"{sec['body']}\n\n---\n")
        return "".join(parts).encode("utf-8"), "text/markdown", f"{safe_title}.md"

    if fmt == "html":
        css = """
        body { font-family: Georgia, serif; max-width: 720px; margin: 2rem auto; padding: 1rem; line-height: 1.7; color: #1a1a1a; }
        .title-page { text-align: center; padding: 6rem 0; page-break-after: always; }
        .title-page h1 { font-size: 2.5rem; margin-bottom: 1rem; }
        .title-page .author { font-size: 1.2rem; color: #555; }
        .copyright { text-align: center; font-size: 0.85rem; color: #555; page-break-after: always; padding: 4rem 0; }
        .dedication { text-align: center; font-style: italic; padding: 4rem 0; page-break-after: always; }
        .epigraph { text-align: center; padding: 3rem 0; page-break-after: always; }
        .epigraph blockquote { font-style: italic; }
        .toc { page-break-after: always; }
        .toc li { margin: 0.5rem 0; }
        .chapter { page-break-before: always; }
        .chapter h2 { text-align: center; border-bottom: 1px solid #ccc; padding-bottom: 0.5rem; margin-bottom: 2rem; }
        .acknowledgments, .author-note, .about-author, .other-books { page-break-before: always; }
        """
        parts = [f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{_esc(title)}</title>
<style>{css}</style></head><body>"""]
        for sec in sections:
            parts.append(sec["html"])
        parts.append("</body></html>")
        return "".join(parts).encode("utf-8"), "text/html", f"{safe_title}.html"

    if fmt == "docx":
        return _compiled_to_docx(compiled), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{safe_title}.docx"

    if fmt == "pdf":
        return _compiled_to_pdf(compiled), "application/pdf", f"{safe_title}.pdf"

    if fmt == "epub":
        return _compiled_to_epub(compiled), "application/epub+zip", f"{safe_title}.epub"

    raise ValidationError(f"Compile format '{fmt}' not supported. Use txt/md/html/docx/pdf/epub.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _esc(s: str) -> str:
    """HTML-escape a string."""
    if not s:
        return ""
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;").replace("'", "&#39;"))


def _compiled_to_docx(compiled: dict[str, Any]) -> bytes:
    """Convert the compiled manuscript to a DOCX file."""
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt, RGBColor
    except ImportError:
        raise NotFoundError("python-docx not installed. Run: pip install python-docx")

    doc = Document()
    # Set default style
    style = doc.styles["Normal"]
    style.font.name = "Georgia"
    style.font.size = Pt(12)

    for sec in compiled["sections"]:
        stype = sec["type"]
        if stype == "title_page":
            doc.add_paragraph()
            doc.add_paragraph()
            h = doc.add_paragraph(compiled["title"])
            h.alignment = WD_ALIGN_PARAGRAPH.CENTER
            h.runs[0].font.size = Pt(28)
            a = doc.add_paragraph(f"by {compiled['author']}")
            a.alignment = WD_ALIGN_PARAGRAPH.CENTER
            a.runs[0].font.size = Pt(14)
            doc.add_page_break()
        elif stype == "copyright":
            p = doc.add_paragraph(sec["body"])
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.runs[0].font.size = Pt(9)
            doc.add_page_break()
        elif stype == "dedication":
            p = doc.add_paragraph(sec["body"])
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.runs[0].font.italic = True
            doc.add_page_break()
        elif stype == "epigraph":
            p = doc.add_paragraph(sec["body"])
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.runs[0].font.italic = True
            doc.add_page_break()
        elif stype == "toc":
            doc.add_heading("Table of Contents", level=1)
            for line in sec["body"].split("\n"):
                if line.strip():
                    doc.add_paragraph(line.strip())
            doc.add_page_break()
        elif stype == "acknowledgments":
            doc.add_heading("Acknowledgments", level=1)
            doc.add_paragraph(sec["body"])
            doc.add_page_break()
        elif stype == "chapter":
            h = doc.add_heading(sec["heading"], level=1)
            h.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for para in sec["body"].split("\n\n"):
                if para.strip():
                    doc.add_paragraph(para.strip())
            doc.add_page_break()
        elif stype == "author_note":
            doc.add_heading("Author's Note", level=1)
            doc.add_paragraph(sec["body"])
            doc.add_page_break()
        elif stype == "about_author":
            doc.add_heading("About the Author", level=1)
            doc.add_paragraph(sec["body"])
            doc.add_page_break()
        elif stype == "other_books":
            doc.add_heading("Other Books by the Author", level=1)
            doc.add_paragraph(sec["body"])

    import io
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# v8.7 — BOOK FORGE: cover helpers
# ---------------------------------------------------------------------------

def cover_media_path(config: dict[str, Any]) -> Path | None:
    """Resolve the configured cover image to a real file path (or None).

    The config stores the public /media/covers/<name> URL; we map it back
    to Config.MEDIA_DIR and refuse anything that escapes the covers dir.
    """
    from config import Config
    url = (config.get("cover_image") or "").strip()
    if not url:
        return None
    rel = url.removeprefix("/media/").lstrip("/")
    if not rel.startswith("covers/"):
        return None
    candidate = Config.MEDIA_DIR / rel
    try:
        candidate = candidate.resolve()
        root = (Config.MEDIA_DIR / "covers").resolve()
        if root not in candidate.parents:
            return None
    except OSError:
        return None
    if candidate.is_file():
        return candidate
    return None


def set_cover_image(public_path: str) -> dict[str, Any]:
    """Point the compile config at an uploaded cover (public /media path)."""
    cfg = get_config()
    cfg["cover_image"] = public_path or ""
    return save_config(cfg)


def remove_cover_image() -> dict[str, Any]:
    """Drop the cover reference (file removal handled by the route)."""
    cfg = get_config()
    if cfg.get("cover_image"):
        cfg["cover_image"] = ""
        cfg = save_config(cfg)
    return cfg


# ---------------------------------------------------------------------------
# v8.7 — BOOK FORGE: typeset print PDF
# ---------------------------------------------------------------------------

_PDF_MARGIN_INNER = 0.85 * 72   # binding side
_PDF_MARGIN_OUTER = 0.60 * 72   # edge side
_PDF_MARGIN_TOP = 0.75 * 72
_PDF_MARGIN_BOTTOM = 0.85 * 72  # leaves room for the folio


def _page_size(name: str) -> tuple[float, float]:
    """Named trim sizes (points)."""
    from reportlab.lib.pagesizes import A4, A5, letter
    sizes = {
        "6x9": (6 * 72, 9 * 72),
        "digest": (5.5 * 72, 8.5 * 72),
        "a5": A5,
        "a4": A4,
        "letter": letter,
    }
    return sizes.get(name, sizes["6x9"])


def _compiled_to_pdf(compiled: dict[str, Any]) -> bytes:
    """Typeset the compiled manuscript into a print-ready book PDF.

    - Real trim sizes (6x9 default) with mirrored binding margins
    - Running headers (book title on verso, chapter on recto)
    - TOC with live page numbers (multiBuild) + PDF outline bookmarks
    - Unicode-safe embedded fonts (services.pdf_fonts)
    """
    import io

    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_RIGHT
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import (
        BaseDocTemplate,
        Flowable,
        Frame,
        PageBreak,
        PageTemplate,
        Paragraph,
        Spacer,
    )
    from reportlab.platypus.tableofcontents import TableOfContents

    from services import pdf_fonts

    config = compiled["config"]
    lang = compiled.get("language", "en")
    title = compiled["title"]
    author = compiled["author"]
    pw, ph = _page_size(config.get("pdf_page_size", "6x9"))
    body_size = float(config.get("pdf_font_size", 10.5))
    body_leading = body_size * float(config.get("pdf_line_height", 1.5))
    mirrored = bool(config.get("pdf_mirrored", True))
    marker = (config.get("scene_break_marker") or "").strip()

    serif_r, serif_b, serif_i, _serif_bi = pdf_fonts.font_faces("serif")
    sans_r = pdf_fonts.body_font("sans")
    ink = colors.HexColor("#141210")
    mute = colors.HexColor("#6b6560")

    # --- styles -----------------------------------------------------------
    st_title = ParagraphStyle(
        "ASMTitleTitle", fontName=serif_b, fontSize=30, leading=36,
        alignment=TA_CENTER, textColor=ink, spaceAfter=18,
    )
    st_author = ParagraphStyle(
        "ASMTitleAuthor", fontName=serif_r, fontSize=14, leading=20,
        alignment=TA_CENTER, textColor=mute,
    )
    st_small_center = ParagraphStyle(
        "ASMSmallCenter", fontName=serif_r, fontSize=9, leading=13,
        alignment=TA_CENTER, textColor=mute,
    )
    st_dedication = ParagraphStyle(
        "ASMDedication", fontName=serif_i, fontSize=12.5, leading=19,
        alignment=TA_CENTER, textColor=ink,
    )
    st_epigraph = ParagraphStyle(
        "ASMEpigraph", fontName=serif_i, fontSize=11.5, leading=17.5,
        alignment=TA_CENTER, textColor=ink,
    )
    st_epigraph_attr = ParagraphStyle(
        "ASMEpigraphAttr", fontName=serif_r, fontSize=10, leading=14,
        alignment=TA_RIGHT, textColor=mute, spaceBefore=8,
    )
    st_chapter = ParagraphStyle(
        "ASMChapterTitle", fontName=serif_b, fontSize=17, leading=22,
        alignment=TA_CENTER, textColor=ink, spaceBefore=56, spaceAfter=26,
    )
    st_body = ParagraphStyle(
        "ASMBody", fontName=serif_r, fontSize=body_size, leading=body_leading,
        alignment=TA_JUSTIFY, textColor=ink, spaceAfter=body_size * 0.55,
        firstLineIndent=body_size * 1.4,
    )
    st_body_first = ParagraphStyle(
        "ASMBodyFirst", parent=st_body, firstLineIndent=0,
    )
    st_scene = ParagraphStyle(
        "ASMSceneBreak", fontName=serif_r, fontSize=10, leading=12,
        alignment=TA_CENTER, textColor=mute, spaceBefore=14, spaceAfter=14,
    )
    st_back_head = ParagraphStyle(
        "ASMBackHead", fontName=serif_b, fontSize=14, leading=18,
        alignment=TA_CENTER, textColor=ink, spaceBefore=48, spaceAfter=20,
    )
    st_back_body = ParagraphStyle(
        "ASMBackBody", fontName=serif_r, fontSize=body_size, leading=body_leading,
        alignment=TA_JUSTIFY, textColor=ink, spaceAfter=body_size * 0.55,
    )
    st_toc_title = ParagraphStyle(
        "ASMTocTitle", fontName=serif_b, fontSize=15, leading=20,
        alignment=TA_CENTER, textColor=ink, spaceAfter=24,
    )
    st_toc_l0 = ParagraphStyle(
        "ASMTocLevel0", fontName=serif_r, fontSize=10.5, leading=17,
        leftIndent=6, textColor=ink,
    )

    # --- document template with mirrored templates + TOC notify ----------
    class BookDoc(BaseDocTemplate):
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            self._plain_pages: set[int] = set()   # no header, no folio
            self._openers: set[int] = set()       # folio only (chapter starts)
            self._current_chapter: str = ""

        def handle_documentBegin(self):
            # reset per multiBuild pass — page numbers shift between passes
            self._plain_pages = set()
            self._openers = set()
            self._current_chapter = ""
            self._handle_documentBegin()

        def afterFlowable(self, flowable):
            name = getattr(getattr(flowable, "style", None), "name", "")
            if name == "ASMChapterTitle":
                text = flowable.getPlainText()
                key = "ch-%d" % self.page
                self.canv.bookmarkPage(key)
                self.notify("TOCEntry", (0, text, self.page, key))
                try:
                    self.canv.addOutlineEntry(text[:120], key, level=0, closed=False)
                except Exception:  # noqa: BLE001 — outline is best-effort
                    pass
                self._openers.add(self.page)
                self._current_chapter = text
            elif name in ("ASMTitleTitle", "ASMSmallCenter", "ASMDedication",
                          "ASMEpigraph"):
                self._plain_pages.add(self.page)
            elif name == "ASMBackHead":
                text = flowable.getPlainText()
                key = "bm-%d" % self.page
                self.canv.bookmarkPage(key)
                self.notify("TOCEntry", (0, text, self.page, key))
                self._current_chapter = text

        def handle_pageBegin(self):
            self._handle_pageBegin()
            # alternate recto/verso for the page AFTER the current one
            if mirrored:
                nxt = "verso" if (self.page % 2 == 1) else "recto"
                self._handle_nextPageTemplate(nxt)
            else:
                self._handle_nextPageTemplate("uniform")

    def _frame(odd: bool) -> Frame:
        inner = _PDF_MARGIN_INNER if odd else _PDF_MARGIN_OUTER
        outer = _PDF_MARGIN_OUTER if odd else _PDF_MARGIN_INNER
        return Frame(
            outer, _PDF_MARGIN_BOTTOM, pw - inner - outer,
            ph - _PDF_MARGIN_TOP - _PDF_MARGIN_BOTTOM,
            leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
            id=("recto" if odd else "verso") + "-frame",
        )

    class _Cover(Flowable):
        """Full-bleed cover image (drawn inside a zero-margin frame)."""

        def __init__(self, image_path: Path):
            super().__init__()
            self._path = image_path

        def wrap(self, availWidth, availHeight):
            # reportlab contract: wrap() must STORE the size it will draw at
            self.width = availWidth
            self.height = availHeight
            return availWidth, availHeight

        def draw(self):
            from reportlab.lib.utils import ImageReader
            img = ImageReader(str(self._path))
            iw, ih = img.getSize()
            w, h = self.width, self.height
            scale = max(w / iw, h / ih)  # cover-fill, center-crop
            dw, dh = iw * scale, ih * scale
            self.canv.drawImage(
                img, (w - dw) / 2, (h - dh) / 2, dw, dh,
                preserveAspectRatio=False, mask="auto",
            )

    def _furniture(canvas, doc: BookDoc, odd: bool):
        """Running header + folio, drawn at page END (after flowables)."""
        page = doc.page
        if page in doc._plain_pages:
            return
        canvas.saveState()
        if page not in doc._openers:
            text = title if (page % 2 == 0) else (doc._current_chapter or title)
            canvas.setFont(sans_r, 7.6)
            canvas.setFillColor(mute)
            canvas.drawCentredString(pw / 2, ph - _PDF_MARGIN_TOP + 22, text[:70])
        canvas.setFont(serif_r, 9)
        canvas.setFillColor(mute)
        canvas.drawCentredString(pw / 2, _PDF_MARGIN_BOTTOM - 26, str(page))
        canvas.restoreState()

    doc = BookDoc(
        io.BytesIO(), pagesize=(pw, ph),
        title=title, author=author,
        leftMargin=_PDF_MARGIN_OUTER, rightMargin=_PDF_MARGIN_OUTER,
        topMargin=_PDF_MARGIN_TOP, bottomMargin=_PDF_MARGIN_BOTTOM,
    )

    cover_tpl = PageTemplate(
        id="cover", frames=[Frame(0, 0, pw, ph, leftPadding=0, rightPadding=0,
                                  topPadding=0, bottomPadding=0, id="cover-frame")],
        onPageEnd=lambda c, d: None,
    )
    recto_tpl = PageTemplate(
        id="recto", frames=[_frame(odd=True)],
        onPageEnd=lambda c, d: _furniture(c, d, odd=True),
    )
    verso_tpl = PageTemplate(
        id="verso", frames=[_frame(odd=False)],
        onPageEnd=lambda c, d: _furniture(c, d, odd=False),
    )
    uniform_tpl = PageTemplate(
        id="uniform", frames=[_frame(odd=True)],
        onPageEnd=lambda c, d: _furniture(c, d, odd=True),
    )
    if mirrored:
        doc.addPageTemplates([cover_tpl, recto_tpl, verso_tpl])
    else:
        doc.addPageTemplates([cover_tpl, uniform_tpl])

    # --- story ------------------------------------------------------------
    story: list[Any] = []

    cover_path = cover_media_path(config)
    if cover_path is not None:
        story.append(_Cover(cover_path))
        story.append(PageBreak())
    else:
        doc._firstPageTemplateIndex = 1  # skip the cover template

    toc = TableOfContents()
    toc.levelStyles = [st_toc_l0]
    toc.dotsMinLevel = 0

    def _body_paras(text: str, first_style: ParagraphStyle):
        """Split raw text into book paragraphs (scene breaks styled apart)."""
        out = []
        for raw in text.split("\n\n"):
            para = raw.strip()
            if not para:
                continue
            if marker and para == marker:
                out.append(Paragraph(_esc(para), st_scene))
                continue
            flat = _esc(" ".join(para.splitlines()))
            out.append(Paragraph(flat, first_style))
            first_style = st_body
        return out

    for sec in compiled["sections"]:
        stype = sec["type"]
        if stype == "title_page":
            story.append(Spacer(1, ph * 0.30))
            story.append(Paragraph(_esc(title), st_title))
            story.append(Paragraph(_esc(_byline(lang, author)), st_author))
            story.append(PageBreak())
        elif stype == "copyright":
            story.append(Spacer(1, ph * 0.72))
            for line in (sec["body"] or "").splitlines():
                if line.strip():
                    story.append(Paragraph(_esc(line.strip()), st_small_center))
            story.append(PageBreak())
        elif stype == "dedication":
            story.append(Spacer(1, ph * 0.38))
            for line in (sec["body"] or "").splitlines():
                if line.strip():
                    story.append(Paragraph(_esc(line.strip()), st_dedication))
            story.append(PageBreak())
        elif stype == "epigraph":
            story.append(Spacer(1, ph * 0.30))
            for line in (sec["body"] or "").splitlines():
                if line.strip():
                    style = st_epigraph_attr if line.strip().startswith("—") else st_epigraph
                    story.append(Paragraph(_esc(line.strip()), style))
            story.append(PageBreak())
        elif stype == "toc":
            story.append(Paragraph(_esc(sec["heading"] or _book_label(lang, "toc")), st_toc_title))
            story.append(toc)
            # NOTE: no PageBreak here — the next section always breaks at
            # its own start; a break here would leave a blank page between
            # the TOC and the following section.
        elif stype == "chapter":
            story.append(PageBreak())
            if sec["heading"]:
                story.append(Paragraph(_esc(sec["heading"]), st_chapter))
            story.extend(_body_paras(sec["body"] or "", st_body_first))
        elif stype in ("acknowledgments", "author_note", "about_author", "other_books"):
            story.append(PageBreak())
            story.append(Paragraph(_esc(sec["heading"]), st_back_head))
            for raw in (sec["body"] or "").split("\n\n"):
                flat = _esc(" ".join(raw.split()))
                if flat:
                    story.append(Paragraph(flat, st_back_body))

    # If no cover page consumed the first template, start on recto.
    doc.multiBuild(story)
    out = doc.filename if isinstance(doc.filename, io.BytesIO) else None
    if out is None:  # pragma: no cover — should not happen
        raise NotFoundError("PDF buffer lost")
    return out.getvalue()


def _byline(lang: str, author: str) -> str:
    by = _book_label(lang, "by")
    return (f"{by} {author}").strip()


# ---------------------------------------------------------------------------
# v8.7 — BOOK FORGE: publication-grade EPUB 3
# ---------------------------------------------------------------------------

_EPUB_CSS = """\
body { font-family: Georgia, "Times New Roman", serif; line-height: 1.55;
       margin: 0.4em 1.0em; color: #141210; }
h1 { font-size: 1.55em; text-align: center; margin: 2.2em 0 0.5em; }
h2 { font-size: 1.3em; text-align: center; margin: 2.4em 0 1.2em; font-weight: 600; }
p { margin: 0; text-indent: 1.35em; }
p.first { text-indent: 0; }
p.scene-break { text-align: center; text-indent: 0; color: #6b6560;
                margin: 1.1em 0; letter-spacing: 0.35em; }
p.no-indent { text-indent: 0; }
div.title-page { text-align: center; margin-top: 22%; }
div.title-page h1 { font-size: 2.1em; margin: 0 0 0.4em; }
div.title-page p.author { font-size: 1.05em; color: #4a443f; text-indent: 0; }
div.copyright-page { margin-top: 65%; font-size: 0.78em; color: #6b6560;
                     text-align: center; }
div.dedication-page { text-align: center; margin-top: 32%; font-style: italic; }
div.epigraph-page { text-align: center; margin-top: 26%; }
div.epigraph-page p.attr { font-style: normal; font-size: 0.9em; color: #4a443f; }
ul.book-toc { list-style: none; padding: 0; }
ul.book-toc li { margin: 0.55em 0; text-indent: 0; }
"""


def _epub_paragraphs(text: str, marker: str, justify: bool) -> str:
    """Raw chapter text -> XHTML paragraphs (scene breaks styled apart)."""
    parts: list[str] = []
    first = True
    for raw in text.split("\n\n"):
        para = raw.strip()
        if not para:
            continue
        if marker and para == marker:
            parts.append('<p class="scene-break">%s</p>' % _esc(para))
            first = True  # scene restart: next paragraph un-indented
            continue
        flat = _esc(" ".join(para.splitlines()))
        cls = []
        if first:
            cls.append("first")
        if not justify:
            cls.append("no-indent")
        cls_attr = (' class="%s"' % " ".join(cls)) if cls else ""
        parts.append("<p%s>%s</p>" % (cls_attr, flat))
        first = False
    return "".join(parts)


def _compiled_to_epub(compiled: dict[str, Any]) -> bytes:
    """Build a publication-grade EPUB 3 ebook from the compiled manuscript.

    - dc: title / creator / language / unique identifier / date
    - Cover: uploaded image (real cover page) or typographic title cover
    - nav.xhtml + ncx TOC, clickable TOC page
    - Front matter / chapters / back matter as separate XHTML docs
    - Embedded book typography stylesheet
    """
    import io
    import uuid as _uuid
    from datetime import datetime, timezone

    from ebooklib import epub

    config = compiled["config"]
    lang = compiled.get("language", "en")
    title = compiled["title"]
    author = compiled["author"]
    marker = (config.get("scene_break_marker") or "").strip()
    justify = bool(config.get("epub_justify", True))

    book = epub.EpubBook()
    book.set_identifier("urn:uuid:" + str(_uuid.uuid4()))
    book.set_title(title)
    book.set_language(lang)
    book.add_author(author)
    book.add_metadata("DC", "date", datetime.now(timezone.utc).strftime("%Y-%m-%d"))

    css = epub.EpubItem(
        uid="book-css", file_name="style/book.css",
        media_type="text/css", content=_EPUB_CSS,
    )
    book.add_item(css)

    def _doc(uid: str, fname: str, doc_title: str, body_html: str,
             spine_linear: bool = True) -> epub.EpubHtml:
        item = epub.EpubHtml(uid=uid, title=doc_title, file_name=fname, lang=lang)
        item.content = (
            "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" "
            "xml:lang=\"%s\" lang=\"%s\">\n<head><meta charset=\"utf-8\" />"
            "<title>%s</title></head>\n<body>%s</body>\n</html>"
            % (lang, lang, _esc(doc_title), body_html)
        )
        item.add_item(css)
        book.add_item(item)
        return item

    spine: list[Any] = ["nav"]
    toc: list[Any] = []

    # ---- cover -----------------------------------------------------------
    cover_path = cover_media_path(config)
    if cover_path is not None:
        content = cover_path.read_bytes()
        ext = cover_path.suffix.lower().lstrip(".")
        mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                "webp": "image/webp"}.get(ext, "image/png")
        book.set_cover("cover." + (ext or "png"), content, create_page=True)
        spine.insert(0, "cover")  # cover first, then nav
    else:
        by = _book_label(lang, "by")
        by_line = (by + " " + author).strip()
        cover_body = (
            "<div class=\"title-page\"><h1>%s</h1>"
            "<p class=\"author\">%s</p></div>"
            % (_esc(title), _esc(by_line))
        )
        cover_doc = _doc("cover-page", "cover.xhtml", title, cover_body)
        spine.insert(0, cover_doc)

    # ---- sections --------------------------------------------------------
    ch_no = 0
    for sec in compiled["sections"]:
        stype = sec["type"]
        if stype == "title_page":
            body = ("<div class=\"title-page\"><h1>%s</h1><p class=\"author\">%s</p></div>"
                    % (_esc(title), _esc(_byline(lang, author))))
            d = _doc("title-page", "title.xhtml", title, body)
            spine.append(d)
        elif stype == "copyright":
            lines = "<br/>".join(_esc(l.strip()) for l in (sec["body"] or "").splitlines()
                                 if l.strip())
            d = _doc("copyright-page", "copyright.xhtml",
                     _book_label(lang, "copyright"),
                     "<div class=\"copyright-page\">%s</div>" % lines)
            spine.append(d)
        elif stype == "dedication":
            d = _doc("dedication-page", "dedication.xhtml", title,
                     "<div class=\"dedication-page\">%s</div>" % _esc(sec["body"] or ""))
            spine.append(d)
        elif stype == "epigraph":
            d = _doc("epigraph-page", "epigraph.xhtml", title,
                     "<div class=\"epigraph-page\">%s</div>" % _esc(sec["body"] or ""))
            spine.append(d)
        elif stype == "toc":
            # separate clickable TOC page (nav.xhtml is auto-generated too)
            items = []
            seen = 0
            for other in compiled["sections"]:
                if other["type"] == "chapter":
                    seen += 1
                    label = other["heading"] or ("Chapter %d" % seen)
                    items.append('<li><a href="ch%03d.xhtml">%s</a></li>'
                                 % (seen, _esc(label)))
            body = "<h1>%s</h1><ul class=\"book-toc\">%s</ul>" % (
                _esc(sec["heading"] or _book_label(lang, "toc")), "".join(items))
            d = _doc("toc-page", "contents.xhtml",
                     sec["heading"] or _book_label(lang, "toc"), body)
            spine.append(d)
        elif stype == "chapter":
            ch_no += 1
            heading = sec["heading"] or ("Chapter %d" % ch_no)
            body = "<h2>%s</h2>%s" % (
                _esc(heading),
                _epub_paragraphs(sec["body"] or "", marker, justify),
            )
            d = _doc("ch%03d" % ch_no, "ch%03d.xhtml" % ch_no, heading, body)
            spine.append(d)
            toc.append(d)
        elif stype in ("acknowledgments", "author_note", "about_author", "other_books"):
            body = "<h2>%s</h2>%s" % (
                _esc(sec["heading"]),
                _epub_paragraphs(sec["body"] or "", marker, justify),
            )
            d = _doc(stype, "%s.xhtml" % stype, sec["heading"] or stype, body)
            spine.append(d)
            toc.append(d)

    # ---- nav / ncx / spine ------------------------------------------------
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    book.toc = toc
    book.spine = spine

    buf = io.BytesIO()
    epub.write_epub(buf, book)
    return buf.getvalue()
