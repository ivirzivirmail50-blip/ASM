"""Story Lint Engine — AI-free automated consistency checks.

Scans chapters for:
- Repeated words (same word 5+ times in a paragraph)
- Character name typos (fuzzy match against known names)
- Sentence length outliers (very long or very short sentences)
- Passive voice overuse (basic heuristic)
- Adverb overuse (words ending in -ly)
- Dialogue tag variety (too many "said" vs. other tags)
- Character attribute mentions (eye color, hair color consistency)
"""
from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict
from typing import Any

from sqlalchemy import select

from core.db import read_session
from models.chapter import Chapter
from models.character import Character
from models.settings import Setting
from models.world import WorldEntry
from services._common import current_project_id, load_json
from services.lang_service import (
    adverbs_in,
    find_prose_hits,
    passive_hits,
    resolve_language,
    stopwords_for,
    tokenize_words,
)

log = logging.getLogger("asm.lint")

# Common words to ignore in repetition checks
_STOP_WORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "of",
    "is", "was", "are", "were", "be", "been", "being", "have", "has",
    "had", "do", "does", "did", "will", "would", "could", "should",
    "may", "might", "must", "can", "shall", "it", "its", "he", "she",
    "his", "her", "they", "them", "their", "there", "here", "this",
    "that", "these", "those", "with", "from", "by", "as", "for", "not",
    "no", "so", "if", "then", "than", "too", "very", "just", "also",
    "about", "into", "through", "during", "before", "after", "above",
    "below", "up", "down", "out", "off", "over", "under", "again",
    "further", "once", "i", "you", "we", "me", "my", "your", "our",
})


def lint_all() -> dict[str, Any]:
    """Run all lint checks across all chapters.

    Returns {findings: [...], summary: {total, by_severity, by_type}}.
    """
    findings: list[dict] = []

    with read_session() as s:
        pid = current_project_id(s)
        lang_setting = Setting.get(s, "analysis_language", "auto")
        chapters = list(s.scalars(
            select(Chapter).where(Chapter.project_id == pid)
            .order_by(Chapter.sort_order.asc())
        ).all())
        characters = list(s.scalars(
            select(Character).where(Character.project_id == pid)
        ).all())

    # Build character name lookup
    char_names: dict[str, dict] = {}
    for c in characters:
        char_names[c.name.lower()] = {
            "id": c.id, "name": c.name,
            "aliases": load_json(c.aliases, []),
            "physical": c.physical or "",
        }
        for alias in load_json(c.aliases, []):
            char_names[alias.lower()] = char_names[c.name.lower()]

    # v7.7: language-aware analysis. "auto" detects per-chapter from the
    # text itself (a workspace can hold books in different languages);
    # an explicit "tr"/"en" setting pins all analyzers to one language.
    all_content = " ".join((ch.content or "") for ch in chapters)
    workspace_lang = resolve_language(all_content, lang_setting)

    for ch in chapters:
        content = ch.content or ""
        if not content.strip():
            continue
        lang = (
            workspace_lang
            if (lang_setting or "auto") in ("tr", "en")
            else resolve_language(content, "auto")
        )

        # 1. Repeated words
        findings.extend(_check_repeated_words(ch, content, lang))

        # 2. Character name fuzzy match (typos)
        findings.extend(_check_name_typos(ch, content, char_names))

        # 3. Sentence length outliers
        findings.extend(_check_sentence_length(ch, content))

        # 4. Adverb overuse
        findings.extend(_check_adverb_overuse(ch, content, lang))

        # 5. Passive voice (basic)
        findings.extend(_check_passive_voice(ch, content, lang))

        # 6. Dialogue tag variety
        findings.extend(_check_dialogue_tags(ch, content, lang))

    # 7. Cross-chapter: character attribute consistency
    findings.extend(_check_attribute_consistency(chapters, char_names))

    # Summary
    by_severity = Counter(f["severity"] for f in findings)
    by_type = Counter(f["type"] for f in findings)

    return {
        "findings": findings,
        "summary": {
            "total": len(findings),
            "errors": by_severity.get("error", 0),
            "warnings": by_severity.get("warning", 0),
            "info": by_severity.get("info", 0),
            "by_type": dict(by_type),
        },
    }


def _check_repeated_words(chapter, content: str, lang: str = "en") -> list[dict]:
    """Check for words repeated 5+ times in a single paragraph.

    v7.7: unicode-aware tokenizer (Turkish ç/ğ/ı/ö/ş/ü preserved — the old
    ``\\b[a-z]{3,}\\b`` regex made them invisible) + per-language stopwords.
    """
    findings = []
    stops = stopwords_for(lang)
    paragraphs = content.split("\n\n")
    for i, para in enumerate(paragraphs):
        words = [w.lower() for w in tokenize_words(para)]
        word_counts = Counter(w for w in words if w not in stops and len(w) >= 3)
        for word, count in word_counts.most_common(3):
            if count >= 5:
                findings.append({
                    "severity": "warning",
                    "type": "repeated_word",
                    "chapter_id": chapter.id,
                    "chapter_title": chapter.title,
                    "location": f"Paragraph {i+1}",
                    "message": f"'{word}' used {count} times in one paragraph. Consider varying your vocabulary.",
                    "suggestion": "Replace some instances with synonyms.",
                })
    return findings


def _check_name_typos(chapter, content: str, char_names: dict) -> list[dict]:
    """Check for potential character name typos using fuzzy matching."""
    findings = []
    if not char_names:
        return findings

    # Find all capitalized words that might be names
    words = re.findall(r'\b([A-Z][a-z]{2,})\b', content)
    known_names = set(char_names.keys())

    for word in set(words):
        word_lower = word.lower()
        if word_lower in known_names:
            continue
        # Check if it's close to a known name (Levenshtein distance ≤ 2)
        for known in known_names:
            if _levenshtein(word_lower, known) <= 2 and len(word_lower) >= 4:
                findings.append({
                    "severity": "info",
                    "type": "name_typo",
                    "chapter_id": chapter.id,
                    "chapter_title": chapter.title,
                    "location": f"'{word}'",
                    "message": f"'{word}' might be a typo of '{char_names[known]['name']}'.",
                    "suggestion": f"Did you mean '{char_names[known]['name']}'?",
                })
                break
    return findings


def _levenshtein(a: str, b: str) -> int:
    """Compute Levenshtein distance between two strings."""
    if len(a) < len(b):
        return _levenshtein(b, a)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j+1]+1, curr[j]+1, prev[j]+(ca != cb)))
        prev = curr
    return prev[-1]


def _check_sentence_length(chapter, content: str) -> list[dict]:
    """Check for very long or very short sentences."""
    findings = []
    sentences = re.split(r'[.!?]+', content)
    for i, sent in enumerate(sentences):
        sent = sent.strip()
        if not sent:
            continue
        words = sent.split()
        wc = len(words)
        if wc > 50:
            findings.append({
                "severity": "info",
                "type": "long_sentence",
                "chapter_id": chapter.id,
                "chapter_title": chapter.title,
                "location": f"Sentence {i+1} ({wc} words)",
                "message": f"Very long sentence ({wc} words). Consider breaking it up.",
                "suggestion": "Split into shorter sentences for readability.",
            })
    return findings


def _check_adverb_overuse(chapter, content: str, lang: str = "en") -> list[dict]:
    """Check for adverb overuse (-ly in English; common Turkish adverbs)."""
    findings = []
    words = [w.lower() for w in tokenize_words(content)]
    adverbs = adverbs_in(words, lang)
    total_words = len(content.split())
    if total_words > 100:
        ratio = len(adverbs) / total_words * 100
        if ratio > 3.0:  # more than 3% adverbs
            findings.append({
                "severity": "info",
                "type": "adverb_overuse",
                "chapter_id": chapter.id,
                "chapter_title": chapter.title,
                "location": f"{len(adverbs)} adverbs in {total_words} words ({ratio:.1f}%)",
                "message": f"High adverb density ({ratio:.1f}%). Consider using stronger verbs.",
                "suggestion": "Replace 'ran quickly' with 'sprinted', 'said softly' with 'whispered', etc.",
            })
    return findings


def _check_passive_voice(chapter, content: str, lang: str = "en") -> list[dict]:
    """Passive voice detection — English: was/were/been + participle;
    Turkish: -ildi/-ıldı/-üldü/-uldı/-indi/-ındı/-ündü/-undu verb stems."""
    findings = []
    matches = passive_hits(content, lang)
    total_sentences = len(re.split(r'[.!?]+', content))
    if total_sentences > 10 and len(matches) > total_sentences * 0.25:
        findings.append({
            "severity": "info",
            "type": "passive_voice",
            "chapter_id": chapter.id,
            "chapter_title": chapter.title,
            "location": f"{len(matches)} passive constructions",
            "message": f"High passive voice usage ({len(matches)} instances). Active voice is more engaging.",
            "suggestion": "Change 'The door was opened by Elara' to 'Elara opened the door'.",
        })
    return findings


# v7.7: per-language dialogue tag vocabularies (Turkish tag verbs included).
_TR_DIALOGUE_TAGS = {"dedi", "diye", "fısıldadı", "bağırdı", "sordu", "yanıtladı",
                    "mırıldandı", "hırladı", "patladı", "homurdandı", "ekledi", "söyledi"}
_EN_DIALOGUE_TAGS = {"said", "whispered", "shouted", "asked", "replied", "muttered",
                     "growled", "snapped", "murmured", "declared", "stated", "added"}
_PLAIN_TAGS = {"en": "said", "tr": "dedi"}


def _check_dialogue_tags(chapter, content: str, lang: str = "en") -> list[dict]:
    """Check dialogue tag variety — too many plain tags ('said'/'dedi') is
    monotonous. v7.7: recognizes Turkish tag verbs (dedi, fısıldadı, ...)."""
    findings = []
    vocab = _TR_DIALOGUE_TAGS if lang == "tr" else _EN_DIALOGUE_TAGS
    plain = _PLAIN_TAGS.get(lang, "said")
    # Find dialogue tags: "word," said/whispered/etc. (unicode-aware \w)
    tags = re.findall(r'[,"]\s*([\wçğıöşüÇĞİŞÖÜ]+)\s*(?:\.|,|$)', content)
    tag_counts = Counter(t.lower() for t in tags if t.lower() in vocab)
    total_tags = sum(tag_counts.values())
    if total_tags > 10:
        said_count = tag_counts.get(plain, 0)
        if said_count / total_tags > 0.7:
            findings.append({
                "severity": "info",
                "type": "dialogue_tags",
                "chapter_id": chapter.id,
                "chapter_title": chapter.title,
                "location": f"{said_count}/{total_tags} tags are '{plain}'",
                "message": f"'{plain}' accounts for {said_count}/{total_tags} dialogue tags. Consider more variety.",
                "suggestion": (
                    "Fısıldadı, mırıldandı, hırladı gibi çeşitli fiiller ya da eylem cümleleri deneyin."
                    if lang == "tr" else
                    "Try: whispered, muttered, snapped, growled, murmured, or use action beats."
                ),
            })
    return findings


def _check_attribute_consistency(chapters: list, char_names: dict) -> list[dict]:
    """Check if character attributes (eye color, hair color) are mentioned consistently."""
    findings = []
    # Extract physical attributes from character profiles
    attr_patterns = {
        "eye": r"(blue|green|brown|hazel|gray|grey|amber|violet|black|gold)\s+eye",
        "hair": r"(black|brown|blonde|red|white|gray|grey|silver|auburn)\s+hair",
    }

    for char_name_lower, char_data in char_names.items():
        if char_name_lower != char_data["name"].lower():
            continue  # skip aliases
        physical = char_data.get("physical", "").lower()

        # Find stated attributes in the character profile
        stated_attrs: dict[str, str] = {}
        for attr, pattern in attr_patterns.items():
            match = re.search(pattern, physical)
            if match:
                stated_attrs[attr] = match.group(1)

        if not stated_attrs:
            continue

        # Check chapters for conflicting mentions
        for ch in chapters:
            content = (ch.content or "").lower()
            for attr, stated_value in stated_attrs.items():
                pattern = attr_patterns[attr]
                # Find all mentions of this attribute in the chapter
                mentions = re.findall(pattern, content)
                for mention in mentions:
                    if mention != stated_value:
                        findings.append({
                            "severity": "warning",
                            "type": "attribute_conflict",
                            "chapter_id": ch.id,
                            "chapter_title": ch.title,
                            "location": f"{attr} color",
                            "message": f"{char_data['name']}'s {attr} is '{stated_value}' in profile but '{mention}' appears in this chapter.",
                            "suggestion": "Check if this is intentional or an error.",
                        })
    return findings



# ---------------------------------------------------------------------------
# v8.3 — Style Coach 2.0: deep, language-aware prose analysis
# ---------------------------------------------------------------------------

_SENT_SPLIT_RE = re.compile(r'[^.!?\n…]+[.!?…]+["\u201d\u2019)]?\s*|[^.!?\n…]+\n+|$')
_MAX_EXAMPLES = 4
_MAX_TARGETS = 8
_MAX_SENT_SNIPPET = 240


def _split_sentences(content: str) -> list[dict]:
    """Split into sentences with char offsets: [{text, start, end}]."""
    out: list[dict] = []
    for m in _SENT_SPLIT_RE.finditer(content):
        text = m.group(0).strip()
        if not text:
            continue
        out.append({"text": text, "start": m.start(), "end": m.start() + len(m.group(0))})
    return out


def _sentence_words(sentence: str) -> int:
    return len(sentence.split())


def _category_examples(
    content: str,
    sentences: list[dict],
    hits: list[dict],
) -> dict:
    """Group raw hits into counts + example sentences.

    Returns {"count": int, "entries": [(entry, n), ...],
             "examples": [{"sentence", "entries": [...]}, ...]}.
    """
    entry_counts: Counter = Counter(h["entry"] for h in hits)
    examples: list[dict] = []
    used: set[int] = set()
    for h in hits:
        sent = next(
            (s for s in sentences if s["start"] <= h["offset"] < s["end"]),
            None,
        )
        if sent is None or id(sent) in used:
            continue
        used.add(id(sent))
        sent_hits = [
            x["entry"] for x in hits if sent["start"] <= x["offset"] < sent["end"]
        ]
        snippet = sent["text"]
        if len(snippet) > _MAX_SENT_SNIPPET:
            snippet = snippet[:_MAX_SENT_SNIPPET].rstrip() + "…"
        examples.append({"sentence": snippet, "entries": sent_hits})
        if len(examples) >= _MAX_EXAMPLES:
            break
    return {
        "count": len(hits),
        "entries": entry_counts.most_common(8),
        "examples": examples,
    }


def _syllables_tr(word: str) -> int:
    """Turkish syllable count — phonetic language: count vowel letters."""
    return max(1, sum(1 for ch in word.lower() if ch in "aeıioöuüâîû"))


def _syllables_en(word: str) -> int:
    """English syllable heuristic (vowel-group counting, silent-e trim)."""
    w = word.lower().strip(".,;:!?\"'()")
    groups = re.findall(r"[aeiouy]+", w)
    n = max(1, len(groups))
    if w.endswith("e") and n > 1 and not w.endswith(("le", "ee", "ye")):
        n -= 1
    return n


_READABILITY_BANDS = (
    (90, "very easy", "success"),
    (70, "easy", "success"),
    (50, "moderate", "info"),
    (30, "hard", "warning"),
    (0, "very hard", "danger"),
)


def _readability(avg_sent_len: float, avg_syll: float, lang: str) -> dict:
    """Reading ease estimate, calibrated per language.

    English: classic Flesch Reading Ease. Turkish: Flesch's 84.6 syllable
    coefficient assumes ~1.5 syllables/word — agglutinative Turkish runs
    ~2.2-2.8, so raw Flesch scores ALL Turkish prose near zero. We use a
    calibrated baseline model instead (comfortable TR prose ≈ 12-word
    sentences at 2.35 syllables/word).
    """
    if lang == "tr":
        sent_pen = max(0.0, avg_sent_len - 12.0) * 2.2
        syll_pen = max(0.0, avg_syll - 2.35) * 60.0
        score = 100.0 - min(100.0, sent_pen + syll_pen)
    else:
        score = 206.835 - 1.015 * avg_sent_len - 84.6 * avg_syll
    score = max(0.0, min(100.0, round(score, 1)))
    for threshold, label, tone in _READABILITY_BANDS:
        if score >= threshold:
            band, tone_out = label, tone
            break
    else:  # pragma: no cover — bands cover 0..100
        band, tone_out = "very hard", "danger"
    return {"score": score, "label": band, "tone": tone_out}


def style_coach(chapter_id: str) -> dict:
    """Deep, language-aware prose analysis for a single chapter (v8.3).

    Everything the old report had, plus: detected language, filter-word
    distance, cliché radar, sentence-rhythm profile with sparkline data,
    word variety, and a Flesch readability estimate. Turkish text is
    analyzed with Turkish lexicons (the v8.2-and-earlier report counted
    English words only and scored Turkish prose as empty).
    """
    with read_session() as s:
        ch = s.get(Chapter, chapter_id)
        if not ch:
            return {"ok": False, "error": "Chapter not found."}
        content = ch.content or ""
        if not content.strip():
            return {"ok": False, "error": "Chapter is empty."}
        lang_setting = Setting.get(s, "analysis_language", "auto")

    lang = resolve_language(content, lang_setting)
    findings: list[dict] = []
    chapter_findings = _check_repeated_words(ch, content, lang)
    chapter_findings += _check_sentence_length(ch, content)
    chapter_findings += _check_adverb_overuse(ch, content, lang)
    chapter_findings += _check_passive_voice(ch, content, lang)
    chapter_findings += _check_dialogue_tags(ch, content, lang)
    findings.extend(chapter_findings)

    words = content.split()
    word_count = len(words)

    # Dialogue ratio — straight AND typographic quotes (pacing parity).
    dialogue_matches = re.findall(r'"[^"]*"|\u201c[^\u201d]*\u201d', content)
    dialogue_words = sum(len(m.split()) for m in dialogue_matches)
    dialogue_pct = round(dialogue_words / max(word_count, 1) * 100, 1)

    sentences = _split_sentences(content)
    sentence_count = len(sentences)
    sent_lens = [_sentence_words(s["text"]) for s in sentences]
    avg_sent_len = round(sum(sent_lens) / max(sentence_count, 1), 1)
    longest = max(sent_lens) if sent_lens else 0

    # Paragraph stats
    paragraphs = [p for p in re.split(r"\n\s*\n+", content) if p.strip()]
    para_count = len(paragraphs)

    # Prose lexicon hits (language-aware)
    telling = _category_examples(content, sentences, find_prose_hits(content, lang, "telling"))
    sensory = _category_examples(content, sentences, find_prose_hits(content, lang, "sensory"))
    filter_w = _category_examples(content, sentences, find_prose_hits(content, lang, "filter"))
    cliches = _category_examples(content, sentences, find_prose_hits(content, lang, "cliche"))

    show_tell_ratio = round(
        sensory["count"] / max(telling["count"] + filter_w["count"], 1), 1
    )

    # Sentence rhythm: lengths + variation
    if len(sent_lens) > 1:
        mean = sum(sent_lens) / len(sent_lens)
        var = sum((x - mean) ** 2 for x in sent_lens) / (len(sent_lens) - 1)
        stdev = var ** 0.5
    else:
        mean = float(avg_sent_len or 0)
        stdev = 0.0
    cv = round(stdev / mean, 2) if mean else 0.0
    variation = "monotonous" if cv < 0.25 else ("moderate" if cv < 0.5 else "varied")
    # Sparkline points: normalize to 0-100, cap series length for the SVG
    spark = [round(x / max(longest, 1) * 100, 1) for x in sent_lens]
    if len(spark) > 120:
        step = len(spark) / 120
        spark = [spark[int(i * step)] for i in range(120)]

    # Word variety (stopwords excluded — content words only)
    tokens = tokenize_words(content)
    content_tokens = [t.lower() for t in tokens if t.lower() not in stopwords_for(lang)]
    unique = len(set(content_tokens))
    variety_ratio = round(unique / max(len(content_tokens), 1), 2)
    variety_label = (
        "repetitive" if variety_ratio < 0.30
        else ("typical" if variety_ratio < 0.45 else "rich")
    )

    # Readability (Flesch — syllables counted per language)
    syl_counter = _syllables_tr if lang == "tr" else _syllables_en
    total_syll = sum(syl_counter(w) for w in tokens) if tokens else 0
    avg_syll = total_syll / max(len(tokens), 1)
    readability = _readability(avg_sent_len, avg_syll, lang)

    report = {
        "ok": True,
        "chapter_id": chapter_id,
        "chapter_title": ch.title,
        "language": lang,
        "word_count": word_count,
        "sentence_count": sentence_count,
        "paragraph_count": para_count,
        "dialogue_pct": dialogue_pct,
        "narration_pct": round(100 - dialogue_pct, 1),
        "avg_sentence_length": avg_sent_len,
        "longest_sentence_words": longest,
        "sentence_rhythm": {
            "lengths": sent_lens[:120],
            "spark_points": spark,
            "stdev": round(stdev, 1),
            "cv": cv,
            "variation": variation,
        },
        "telling": telling,
        "sensory": sensory,
        "filter": filter_w,
        "cliches": cliches,
        "show_dont_tell_ratio": show_tell_ratio,
        "word_variety": {
            "unique": unique,
            "total": len(content_tokens),
            "ratio": variety_ratio,
            "label": variety_label,
        },
        "readability": readability,
        "findings": findings,
        "suggestions": [],
    }

    # ---- suggestions (legacy ones kept, new metrics added) ----
    S = report["suggestions"]
    if dialogue_pct < 15:
        S.append({"type": "dialogue", "severity": "info",
                  "message": f"Dialogue is only {dialogue_pct}% of the chapter. Consider adding more character interaction."})
    if dialogue_pct > 70:
        S.append({"type": "dialogue", "severity": "info",
                  "message": f"Dialogue is {dialogue_pct}% — very dialogue-heavy. Add more narration and description."})
    if avg_sent_len > 25:
        S.append({"type": "pacing", "severity": "info",
                  "message": f"Average sentence length is {avg_sent_len} words. Try shorter sentences for action scenes."})
    if telling["count"] > sensory["count"] and telling["count"] > 3:
        S.append({"type": "show_dont_tell", "severity": "warning",
                  "message": f"Found {telling['count']} 'telling' indicators vs {sensory['count']} sensory words. Try 'show, don't tell'."})
    if filter_w["count"] >= 8:
        top = ", ".join(e for e, _ in filter_w["entries"][:4])
        S.append({"type": "filter_words", "severity": "warning",
                  "message": f"{filter_w['count']} filter words put distance between reader and scene (most: {top}). Cut or replace with direct experience."})
    if cliches["count"]:
        S.append({"type": "cliche", "severity": "warning",
                  "message": f"{cliches['count']} stock phrase(s) detected — rewrite them in your own voice."})
    if variation == "monotonous" and sentence_count >= 6:
        S.append({"type": "rhythm", "severity": "info",
                  "message": f"Sentence rhythm is monotonous (variation {cv}). Mix short punches with longer flow."})
    if variety_label == "repetitive" and len(content_tokens) >= 120:
        S.append({"type": "vocabulary", "severity": "info",
                  "message": f"Word variety is low ({variety_ratio}). Repeating the same content words — consider synonyms."})

    # ---- AI rewrite targets: worst telling/filter/cliché sentences ----
    targets: list[dict] = []
    for cat, cat_data in (("telling", telling), ("filter", filter_w), ("cliche", cliches)):
        for ex in cat_data["examples"]:
            if len(targets) >= _MAX_TARGETS:
                break
            targets.append({
                "category": cat,
                "sentence": ex["sentence"],
                "entries": ex["entries"][:4],
            })
    report["rewrite_targets"] = targets

    return report
