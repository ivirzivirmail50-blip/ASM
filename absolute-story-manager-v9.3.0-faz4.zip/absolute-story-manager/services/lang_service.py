"""Language-aware analysis primitives for ASM.

v7.7 — Turkish Language Engine.

PROBLEM (research finding): every analysis service (lint, pacing, word
frequency, spellcheck) was English-centric:

  * lint's repeated-word regex ``\\b[a-z]{3,}\\b`` is ASCII-only — Turkish
    words containing ç/ğ/ı/ö/ş/ü are INVISIBLE ("gölge" repeated 5× in a
    paragraph: not detected).
  * pacing's tension dictionary is English-only (fight/battle/blood) — a
    Turkish manuscript scores a flat zero-tension curve.
  * word_freq's stopword list is English — Turkish function words (ve, bir,
    bu, da, de, için…) dominate every "overused words" report.
  * spellcheck bundles a ~1000-word English list — useless for Turkish text.

This module centralizes per-language resources and detection so every
service speaks the writer's language. Detection is lightweight and
deterministic (no external NLP deps): a diacritic + common-word heuristic
scored over a text sample, with an explicit user override via the
``analysis_language`` setting ("auto" | "tr" | "en").
"""
from __future__ import annotations

import re
from collections import Counter

# ----------------------------------------------------------------- languages

LANGUAGES = ("auto", "tr", "en")

# Lowercase-only Turkish letters outside ASCII (ı is the dotless i).
# NOTE: never test membership via .lower() of an uppercase set — Python
# decomposes "İ".lower() into "i" + U+0307, which makes plain ASCII "i" a
# false positive for English text. We always lowercase the SAMPLE and match
# against this explicit lowercase set instead.
_TR_SPECIFIC = "çğışöüâîû"

# ----------------------------------------------------------------- stopwords

# Turkish function words that dominate naive frequency reports.
TR_STOPWORDS = frozenset("""
bir ve veya ile için ama fakat ancak çünkü eğer gibi kadar daha çok az
bu şu o bunlar şunlar onlar ben sen biz siz onun bunun şunun
benim senin bizim sizin onların bende sende bizde sizde
evet hayır de da ki mi mı mu mü ne kim hangi nerede neden nasıl
var yok oldu olur oldu diye her bazı tüm hepsi şey kadar
içinde üzerine altında arasında üzerinden sonra önce beri göre rağmen
değil olan olarak diye için
the a an and or but
""".split())

EN_STOPWORDS = frozenset("""
the a an and or but in on at to of is was are were be been being have has
had do does did will would could should may might must can shall it its he
she his her they them their there here this that these those with from by
as for not no so if then than when while which who whom whose what where
how all any both each few more most other some such only own same too very
just said says say went go get got
""".split())

STOPWORDS = {"tr": TR_STOPWORDS, "en": EN_STOPWORDS}

# ------------------------------------------------------------ tension words

# Pacing/tension vocabulary per language. Turkish set covers conflict,
# danger, motion, and supernatural markers common in genre fiction.
TR_TENSION_WORDS = frozenset("""
savaş dövüş kavga vur vuruş saldır öldür ölüm öldürül kan kanı kılıç kılıcı
hançer bıçak ok yay zehir vur yık kır parçala çat çatıldad
kork korku korktu ürkü dehşet terör panik kaygı endişe tehlike tehdit düşman
düşmanın kaos kaosu
kaç kaçtı koval kovalamaca saklan saklandı iz sür tuzak esir alıkoy
ihanet ihaneti hain pus tuzak
koş koştu atıld fırla zıpla atla düşdü çarpt patla
ateş alev yangın duman yandı kavur
yanan karart gölge gölgesi karanlık gece sisli
canavar yaratık ejderha ejder hayalet iblis şeytan ruh
büyü büyüsi lanet laneti tılsım muska kehanet
güç güçü enerji şimşek fırtına deprem
çığlık bağırdı haykırdı fısıldadı kükredi
acı acısı yara yaralı acıyla zehir
son son nefes kıyamet yıkım
""".split())

EN_TENSION_WORDS = frozenset("""
fight battle attack kill die death blood sword blade strike fall crash
burn fire scream shout rage fury terror fear danger threat enemy war
run chase escape flee hunt trap betray dark shadow monster beast dragon
magic spell curse break destroy shatter explode force power storm
""".split())

TENSION_WORDS = {"tr": TR_TENSION_WORDS, "en": EN_TENSION_WORDS}

# --------------------------------------------------------------- adverb cues

# Turkish adverbs/adverbial intensifiers commonly overused in prose.
TR_ADVERBS = frozenset("""
çok fazla epey gayetoldukça son derece az buçuk hayli
hızlıca yavaşça sessizce aniden derhal hemen hemen yavaşça
gerçekten kesinlikle muhakkak mutlaka belki galiba herhalde
malesef maalesef ne yazık ki açıkça bariz net şekilde
""".split())

EN_ADVERB_SUFFIX = "ly"
EN_NON_ADVERBS = frozenset({
    "only", "family", "reply", "apply", "supply", "july", "assembly", "fly",
    "belly", "jelly", "holy", "ugly", "early", "daily", "weekly", "monthly",
    "friendly", "lovely", "lonely", "silly", "multiply", "imply", "July",
})

# Turkish passive voice markers: verb stems ending in -ildi/-ıldı/-üldü/-uldı
# or -indi/-ındı/-ündü/-undu (e.g. "yazıldı", "görüldü", "alındı").
_TR_PASSIVE_RE = re.compile(
    r"\b\w+(?:ildi|ıldı|üldü|uldı|indi|ındı|ündü|undu)\b", re.UNICODE
)
# English passive voice: was/were/been + past participle (loose heuristic).
_EN_PASSIVE_RE = re.compile(
    r"\b(?:was|were|been|is|are)\s+\w+(?:ed|en)\b", re.IGNORECASE
)

PASSIVE_PATTERNS = {"tr": _TR_PASSIVE_RE, "en": _EN_PASSIVE_RE}

# ---------------------------------------------------------------- detection

_TR_MARKERS = frozenset("""
ve bir bu şu için ile gibi ama çok daha sonra önce her ne kim var yok
değil olarak şey evet hayır çünkü eğer kadar diye
""".split())

_EN_MARKERS = frozenset("""
the and of to in is was a an that this with for on it
""".split())


def detect_language(text: str) -> str:
    """Heuristic language detection: 'tr' or 'en'.

    Scores diacritic density (Turkish-specific letters are a near-certain
    signal) plus common function-word hits, over up to the first 4000 chars.
    Ties/default → 'en' (historical behaviour of the analyzers).
    """
    if not text:
        return "en"
    sample = text[:4000].lower()
    tr_score = sum(1 for ch in sample if ch in _TR_SPECIFIC)
    # Weight diacritics heavily: 3 Turkish letters per 1000 chars is already
    # strong evidence; English text virtually never contains them.
    if tr_score >= 2:
        return "tr"
    words = re.findall(r"[a-zçğıöşü]+", sample)
    if not words:
        return "en"
    counts = Counter(words)
    tr_hits = sum(counts[w] for w in _TR_MARKERS)
    en_hits = sum(counts[w] for w in _EN_MARKERS)
    return "tr" if tr_hits > en_hits else "en"


def resolve_language(text: str, setting_value: str | None) -> str:
    """Resolve the effective analysis language.

    ``setting_value`` comes from the ``analysis_language`` Setting:
    "auto" (or None/unset) → detect from text; otherwise the explicit value.
    Unknown values fall back to detection.
    """
    lang = (setting_value or "auto").strip().lower()
    if lang in ("tr", "en"):
        return lang
    return detect_language(text)


def stopwords_for(lang: str) -> frozenset:
    """Stopword set for a language ('tr'/'en'). Both sets include the
    other language's markers when harmless, so mixed text stays sane."""
    return STOPWORDS.get(lang, EN_STOPWORDS)


def tension_words_for(lang: str) -> frozenset:
    return TENSION_WORDS.get(lang, EN_TENSION_WORDS)


def adverbs_in(words: list[str], lang: str) -> list[str]:
    """Return the adverb subset of ``words`` for the given language."""
    if lang == "tr":
        tr_set = TR_ADVERBS
        return [w for w in words if w in tr_set]
    return [
        w for w in words
        if w.endswith(EN_ADVERB_SUFFIX) and w not in EN_NON_ADVERBS
    ]


def passive_hits(text: str, lang: str) -> list[str]:
    """Passive-voice marker hits in ``text`` for the given language."""
    pattern = PASSIVE_PATTERNS.get(lang, _EN_PASSIVE_RE)
    return pattern.findall(text)


# ---------------------------------------------------------- v8.3 prose style
#
# Style Coach 2.0 lexicons. Same English-centrism problem as v7.7: the old
# show-don't-tell check counted "felt"/"was angry"/"saw" — a Turkish
# manuscript scored zero telling AND zero sensory, making the ratio
# meaningless. These lexicons make the prose analysis language-aware.
#
# Matching rules (see find_prose_hits):
#   * entries WITH a space  → case-insensitive phrase match (substring)
#   * single-word EN entry  → \\b word-boundary match (list inflections
#     explicitly: felt/feeling/feelings)
#   * single-word TR entry  → per-token prefix stem match with ≤4 suffix
#     chars (emotion_service pattern: hisset → hissetti/hissetmişti).
#     Stems must be ≥3 chars and must NOT start with "i"/"ı" (İ lowers to
#     i+U+0307, which would break prefix comparison — see _lookup notes).
#     No stem below contains a capital-İ hazard at the matched position.

# Direct emotion statements ("she was angry") — telling instead of showing.
# NOTE: multi-word entries MUST live in the *PHRASES tuple — never inside a
# .split() list (split would shatter "fark et" into the stem "et", which
# prefix-matches "etraF"/"etki" and floods the report with false hits).
TR_TELLING_WORDS = frozenset("""
hisset hissediy korktu korkuyo öfkelendi kızdı sinirlendi sevindi
üzüldü üzgün mutlu şaşırdı şaşkın endişe kaygı heyecan utandı mahcup
kıskan yorgun rahatla emin hüzün umutsuz memnun dehşete
gurur panikledi panik
""".split()) | frozenset((
    "nefret et", "kafası karışık", "kafası karışıktı",
))

EN_TELLING_WORDS = frozenset("""
felt feeling feelings despaired rejoiced cringed blushed
""".split()) | frozenset((
    "was angry", "was sad", "was happy", "was afraid", "was scared",
    "was excited", "was nervous", "was confused", "was surprised",
    "was furious", "was terrified", "was devastated", "was overjoyed",
    "was embarrassed", "was exhausted", "was relieved",
    "felt a surge", "felt a wave of",
))

# Concrete sensory detail & physical manifestation — "showing" signals.
TR_SENSORY_WORDS = frozenset("""
titr ürper kalb nefes terle ses çıtırtı hışırtı uğultu yankı
gürültü patırtı cıvıltı fısıltı koku tadı tattı acı ekşi tatlı
ışık parlak karanlık gölge aydınlık sıcak soğuk nemli pürüzlü
yumuşak sert
""".split()) | frozenset((
    "yüzü kızardı", "gözleri doldu", "dişlerini sıktı", "boğazı düğümlendi",
    "kalbi hızlandı", "nefesi kesildi", "eli titredi", "gözleri parladı",
))

EN_SENSORY_WORDS = frozenset("""
warmth cold brightness darkness echo scent flavor aroma texture rough
smooth bitter sweet salty sour pungent musty velvety gritty damp sticky
trembled shivered glowed flickered hummed throbbed whispered hissed
cracked snapped roared buzzed gleamed shimmered gritty
""".split())

# Filter words — narrative distance (felt/saw/realized/noticed/began to).
# Perception verbs live HERE, not in sensory: "she saw the table" filters
# the scene through the narrator; "the table stood at..." shows it.
TR_FILTER_WORDS = frozenset("""
farkında düşündü düşünüyordu biliyordu bildi anladı anlamış hatırla
izledi izliyor baktı bakıyor gördü görüyordu görmüş duydu duyuyordu
başladı başlamış koyuldu denedi denemeye sanki gibiydi dalgın
""".split()) | frozenset((
    "fark et", "farkına var", "karar ver", "merak et",
))

EN_FILTER_WORDS = frozenset("""
saw watched noticed observed heard listened smelled tasted touched felt
realized understood thought knew wondered decided seemed appeared
""".split()) | frozenset((
    "looked like", "sounded like", "began to", "started to", "tried to",
    "as if", "could feel", "could see", "could hear", "felt like",
))

# Overused stock phrases — cliché radar (phrase matching both languages).
TR_CLICHES = frozenset((
    "derin bir nefes aldı", "kalbi yerinden fırlayacak", "yüreği ağzına geldi",
    "zaman durmuş gibi", "bir anda her şey karardı", "kanı dondu",
    "saniyeler dakikalar gibi", "gözden kayboldu", "dili tutuldu",
    "yüzünde belirsiz bir ifade", "kaderin cilvesi", "buz gibi bir korku",
    "derin bir iç geçirdi", "kelimeler boğazında düğümlendi",
    "son nefesini verdi", "gözleri faltaşı gibi",
))

EN_CLICHES = frozenset((
    "heart skipped a beat", "time stood still", "took a deep breath",
    "in the nick of time", "blood ran cold", "a shiver ran down",
    "lost track of time", "before they knew it", "as luck would have it",
    "in the dead of night", "only a matter of time", "weak in the knees",
    "calm before the storm", "tip of the iceberg", "only time will tell",
    "avoid like the plague", "heart pounding in", "let out a breath",
    "eyes widened in shock", "a mix of emotions",
))

_PROSE_LEXICONS = {
    "telling": {"tr": TR_TELLING_WORDS, "en": EN_TELLING_WORDS},
    "sensory": {"tr": TR_SENSORY_WORDS, "en": EN_SENSORY_WORDS},
    "filter": {"tr": TR_FILTER_WORDS, "en": EN_FILTER_WORDS},
    "cliche": {"tr": TR_CLICHES, "en": EN_CLICHES},
}

# Stems shorter than this are still matched (ses/acı/sert are 3), but we
# cap suffix growth at 4 chars either way (korku → korkusuna).
_PROSE_SUFFIX_TOLERANCE = 4


def prose_lexicon(category: str, lang: str) -> frozenset:
    """Lexicon for a prose category ('telling'|'sensory'|'filter'|'cliche')."""
    by_lang = _PROSE_LEXICONS.get(category)
    if not by_lang:
        raise ValueError(f"unknown prose category: {category}")
    return by_lang.get(lang, by_lang["en"])


def find_prose_hits(text: str, lang: str, category: str) -> list[dict]:
    """Find all hits of a prose category in ``text``.

    Returns [{"offset": int, "entry": str}, ...] — offsets point into the
    ORIGINAL text (no .lower() of the whole string: that changes length
    for 'İ' and would corrupt offsets).
    """
    entries = prose_lexicon(category, lang)
    hits: list[dict] = []
    if not text or not entries:
        return hits

    phrases = [e for e in entries if " " in e]
    single = [e for e in entries if " " not in e]

    if phrases:
        # Longest-first so overlapping phrases report the specific one.
        pattern = re.compile(
            "|".join(re.escape(p) for p in sorted(phrases, key=len, reverse=True)),
            re.IGNORECASE,
        )
        for m in pattern.finditer(text):
            hits.append({"offset": m.start(), "entry": m.group(0).lower()})

    if single:
        if lang == "tr":
            for m in _WORD_RE.finditer(text):
                tok = m.group(0).lower()
                for stem in single:
                    if (
                        len(tok) >= len(stem)
                        and tok.startswith(stem)
                        and len(tok) - len(stem) <= _PROSE_SUFFIX_TOLERANCE
                    ):
                        hits.append({"offset": m.start(), "entry": stem})
                        break
        else:
            pattern = re.compile(
                r"\b(?:" + "|".join(re.escape(w) for w in single) + r")\b",
                re.IGNORECASE,
            )
            for m in pattern.finditer(text):
                hits.append({"offset": m.start(), "entry": m.group(0).lower()})

    hits.sort(key=lambda h: h["offset"])
    return hits


# Unicode-aware word tokenizer — understands ç/ğ/ı/ö/ş/ü and İ/ı casing.
_WORD_RE = re.compile(r"[0-9_]*[a-zçğıöşüâîûA-ZÇĞİŞÖÜÂÎÛ][a-zçğıöşüâîûA-ZÇĞİŞÖÜÂÎÛ'\-]*", re.UNICODE)


def tokenize_words(text: str) -> list[str]:
    """Tokenize into words, Turkish-safe (diacritics preserved, apostrophes
    kept for suffixes like \"Aylin'ın\" but suffixes after ' stripped)."""
    words = _WORD_RE.findall(text)
    # Strip possessive/suffix clitics after apostrophe: Aylin'ın → Aylin
    return [w.split("'")[0] if "'" in w else w for w in words]
