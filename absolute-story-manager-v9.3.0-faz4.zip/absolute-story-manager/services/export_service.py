"""Export service: TXT, MD, DOCX, PDF, EPUB, HTML, JSON.

Supports both synchronous (small) and async (large) exports.
v9.3.0 (F-05): async exports run on the DISK-BACKED durable task queue
(services/task_queue_service) — progress survives application restarts.
"""
from __future__ import annotations

import io
import json
import logging
import os
from pathlib import Path
from typing import Any

from sqlalchemy import select

from config import Config
from core.db import read_session
from core.errors import NotFoundError
from models.chapter import Chapter
from models.character import Character
from models.world import WorldEntry, WorldEntryRelation
from services import pdf_fonts
from services._common import current_project_id, load_json

log = logging.getLogger("asm.export")


def _sf(name: str) -> str:
    """v9.1.0 (M-05): delegates to services._common.safe_filename — the
    three former copies differed subtly (allowed chars, separator, length,
    fallback); the EXPORT preset reproduces this file's historical behavior
    byte-identically."""
    from services._common import SAFE_FILENAME_EXPORT, safe_filename
    return safe_filename(name, **SAFE_FILENAME_EXPORT)


def export_chapter(chapter_id: str, fmt: str) -> tuple[bytes, str, str]:
    """Export a single chapter. Returns (content, mimetype, filename)."""
    fmt = fmt.lower()
    with read_session() as s:
        ch = s.get(Chapter, chapter_id)
        if not ch:
            raise NotFoundError("Chapter not found.")
        title = ch.title or "Untitled"
        content = ch.content or ""
    if fmt == "txt":
        return content.encode("utf-8"), "text/plain", f"{_sf(title)}.txt"
    if fmt == "md":
        md = f"# {title}\n\n{content}\n"
        return md.encode("utf-8"), "text/markdown", f"{_sf(title)}.md"
    if fmt == "html":
        html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:Georgia,serif;max-width:720px;margin:2rem auto;padding:1rem;line-height:1.7}}h1{{text-align:center}}</style>
</head><body><h1>{title}</h1><div>{_md_to_html(content)}</div></body></html>"""
        return html.encode("utf-8"), "text/html", f"{_sf(title)}.html"
    if fmt == "docx":
        return _chapter_to_docx(title, content), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{_sf(title)}.docx"
    if fmt == "pdf":
        return _chapter_to_pdf(title, content), \
            "application/pdf", f"{_sf(title)}.pdf"
    if fmt == "json":
        data = {"title": title, "content": content, "format": "asm-chapter-v1"}
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", f"{_sf(title)}.json"
    raise NotFoundError(f"Unknown format: {fmt}")


def export_manuscript(fmt: str) -> tuple[bytes, str, str]:
    """Full manuscript (concatenated chapters)."""
    fmt = fmt.lower()
    with read_session() as s:
        pid = current_project_id(s)
        chapters = list(s.scalars(
            select(Chapter).where(Chapter.project_id == pid)
            .order_by(Chapter.sort_order.asc())
        ).all())
        from models.settings import Setting
        title = Setting.get(s, "story_title", "My Story")
        author = Setting.get(s, "story_author", "Author")
    if fmt == "txt":
        parts = [f"{title}\nby {author}\n\n"]
        for ch in chapters:
            parts.append(f"\n\n{ch.title}\n\n{ch.content or ''}\n")
        return "".join(parts).encode("utf-8"), "text/plain", f"{_sf(title)}.txt"
    if fmt == "md":
        parts = [f"# {title}\n\n*by {author}*\n\n"]
        for ch in chapters:
            parts.append(f"\n\n## {ch.title}\n\n{ch.content or ''}\n")
        return "".join(parts).encode("utf-8"), "text/markdown", f"{_sf(title)}.md"
    if fmt == "html":
        parts = [f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:Georgia,serif;max-width:720px;margin:2rem auto;padding:1rem;line-height:1.7}}h1{{text-align:center}}h2{{page-break-before:always;border-bottom:1px solid #ccc;padding-bottom:.3rem}}</style>
</head><body><h1>{title}</h1><p style="text-align:center"><em>by {author}</em></p>"""]
        for ch in chapters:
            parts.append(f"<h2>{ch.title}</h2><div>{_md_to_html(ch.content or '')}</div>")
        parts.append("</body></html>")
        return "".join(parts).encode("utf-8"), "text/html", f"{_sf(title)}.html"
    if fmt == "docx":
        return _manuscript_to_docx(title, author, chapters), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{_sf(title)}.docx"
    if fmt == "pdf":
        return _manuscript_to_pdf(title, author, chapters), \
            "application/pdf", f"{_sf(title)}.pdf"
    if fmt == "epub":
        return _manuscript_to_epub(title, author, chapters), \
            "application/epub+zip", f"{_sf(title)}.epub"
    raise NotFoundError(f"Unknown format: {fmt}")


def export_character_sheet(character_id: str, fmt: str = "pdf") -> tuple[bytes, str, str]:
    with read_session() as s:
        ch = s.get(Character, character_id)
        if not ch:
            raise NotFoundError("Character not found.")
        aliases = load_json(ch.aliases, [])
        quotes = load_json(ch.philosophy_quotes, [])
        data = {
            "name": ch.name, "role": ch.role, "age": ch.age,
            "gender": ch.gender, "aliases": aliases,
            "avatar_color": ch.avatar_color,
            "physical": ch.physical, "psychology": ch.psychology,
            "background": ch.background, "philosophy": ch.philosophy,
            "philosophy_quotes": quotes, "story_role": ch.story_role,
            "voice": ch.voice, "notes": ch.notes,
        }
    if fmt == "json":
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", f"{_sf(data['name'])}.json"
    if fmt == "txt":
        parts = [f"{data['name']} ({data['role']})\n{'='*40}\n"]
        for k, v in data.items():
            if k in ("name", "avatar_color"):
                continue
            if v:
                parts.append(f"\n{k.upper()}:\n{v}\n")
        return "".join(parts).encode("utf-8"), "text/plain", f"{_sf(data['name'])}.txt"
    if fmt == "pdf":
        return _character_sheet_pdf(data), "application/pdf", \
            f"{_sf(data['name'])}.pdf"
    if fmt == "docx":
        return _character_sheet_docx(data), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{_sf(data['name'])}.docx"
    raise NotFoundError(f"Unknown format: {fmt}")


def export_world_bible(fmt: str = "pdf") -> tuple[bytes, str, str]:
    with read_session() as s:
        pid = current_project_id(s)
        from models.settings import Setting
        title = Setting.get(s, "story_title", "My Story")
        entries = list(s.scalars(
            select(WorldEntry).where(WorldEntry.project_id == pid)
            .order_by(WorldEntry.type.asc(), WorldEntry.name.asc())
        ).all())
    if fmt == "json":
        data = {
            "title": f"{title} — World Bible",
            "entries": [
                {"type": e.type, "name": e.name, "category": e.category,
                 "description": e.description, "content": e.content, "notes": e.notes}
                for e in entries
            ],
        }
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", "world_bible.json"
    if fmt == "txt":
        parts = [f"{title} — World Bible\n\n"]
        by_type: dict[str, list] = {}
        for e in entries:
            by_type.setdefault(e.type, []).append(e)
        for t, group in by_type.items():
            parts.append(f"\n\n=== {t.upper()} ===\n")
            for e in group:
                parts.append(f"\n--- {e.name} ---\n{e.description or ''}\n\n{e.content or ''}\n")
        return "".join(parts).encode("utf-8"), "text/plain", "world_bible.txt"
    if fmt == "pdf":
        return _world_bible_pdf(title, entries), "application/pdf", "world_bible.pdf"
    if fmt == "docx":
        return _world_bible_docx(title, entries), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            "world_bible.docx"
    raise NotFoundError(f"Unknown format: {fmt}")


# ---------- PDF / DOCX / EPUB helpers ----------

# v9.1.0 (M-05): former local copy — delegates to the single source in
# services._common (byte-identical: markdown package, extra + nl2br).
def _md_to_html(text: str) -> str:
    from services._common import md_to_html
    return md_to_html(text)


def _chapter_to_docx(title: str, content: str) -> bytes:
    from docx import Document
    doc = Document()
    doc.add_heading(title, level=1)
    for para in (content or "").split("\n\n"):
        if para.strip():
            doc.add_paragraph(para.strip())
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _chapter_to_pdf(title: str, content: str) -> bytes:
    """Single chapter PDF — industry standard manuscript format.

    Uses settings: manuscript_font, manuscript_font_size, manuscript_line_spacing,
    manuscript_margins.
    """
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    # Read manuscript settings
    from core.db import read_session
    from models.settings import Setting
    with read_session() as s:
        font_name = Setting.get(s, "manuscript_font", "Courier") or "Courier"
        font_size = int(Setting.get(s, "manuscript_font_size", 12) or 12)
        line_spacing = float(Setting.get(s, "manuscript_line_spacing", 2.0) or 2.0)
        margins = float(Setting.get(s, "manuscript_margins", 1.0) or 1.0)

    leading = int(font_size * line_spacing)  # double-spaced = 24pt for 12pt font

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=margins*inch, rightMargin=margins*inch,
                            topMargin=margins*inch, bottomMargin=margins*inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    h1 = ParagraphStyle("ChapterH1", parent=styles["Heading1"],
                        alignment=TA_CENTER, fontSize=18, spaceAfter=24)
    body = ParagraphStyle("ChapterBody", parent=styles["BodyText"],
                          fontName=pdf_fonts.map_font(font_name), fontSize=font_size, leading=leading,
                          firstLineIndent=0.5*inch, spaceAfter=10)
    story = [Paragraph(title, h1), Spacer(1, 12)]
    for para in (content or "").split("\n\n"):
        if para.strip():
            safe = para.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            story.append(Paragraph(safe, body))
            story.append(Spacer(1, 6))
    doc.build(story)
    return buf.getvalue()


def _manuscript_to_docx(title: str, author: str, chapters: list[Chapter]) -> bytes:
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    # Title page
    t = doc.add_paragraph()
    t.alignment = 1  # center
    run = t.add_run(title)
    run.bold = True
    run.font.size = Pt(28)  # v9.1.0 (M-05): was __import__("docx").shared.Pt
    doc.add_paragraph()
    a = doc.add_paragraph()
    a.alignment = 1
    a.add_run(f"by {author}").italic = True
    doc.add_page_break()
    for ch in chapters:
        doc.add_heading(ch.title, level=1)
        for para in (ch.content or "").split("\n\n"):
            if para.strip():
                doc.add_paragraph(para.strip())
        doc.add_page_break()
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _manuscript_to_pdf(title: str, author: str, chapters: list[Chapter]) -> bytes:
    """Full manuscript PDF — industry standard manuscript format.

    Uses settings: manuscript_font, manuscript_font_size, manuscript_line_spacing,
    manuscript_margins. Default: 12pt Courier, double-spaced (24pt leading),
    1-inch margins, 0.5-inch first-line indent.
    """
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    # Read manuscript settings
    from core.db import read_session
    from models.settings import Setting
    with read_session() as s:
        font_name = Setting.get(s, "manuscript_font", "Courier") or "Courier"
        font_size = int(Setting.get(s, "manuscript_font_size", 12) or 12)
        line_spacing = float(Setting.get(s, "manuscript_line_spacing", 2.0) or 2.0)
        margins = float(Setting.get(s, "manuscript_margins", 1.0) or 1.0)

    leading = int(font_size * line_spacing)  # double-spaced = 24pt for 12pt font

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=margins*inch, rightMargin=margins*inch,
                            topMargin=margins*inch, bottomMargin=margins*inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    title_style = ParagraphStyle("Title", parent=styles["Title"],
                                 alignment=TA_CENTER, fontSize=24, spaceAfter=18)
    author_style = ParagraphStyle("Author", parent=styles["Normal"],
                                  alignment=TA_CENTER, fontSize=14, spaceAfter=24)
    h1 = ParagraphStyle("ChH1", parent=styles["Heading1"],
                         alignment=TA_CENTER, fontSize=18, spaceAfter=24)
    body = ParagraphStyle("Body", parent=styles["BodyText"],
                          fontName=pdf_fonts.map_font(font_name), fontSize=font_size, leading=leading,
                          firstLineIndent=0.5*inch, spaceAfter=10)

    story = [
        Spacer(1, 3*inch), Paragraph(title, title_style),
        Paragraph(f"by {author}", author_style),
        Spacer(1, 2*inch),
        Paragraph(f"Approx. {sum((c.word_count or 0) for c in chapters)} words",
                  author_style),
        PageBreak(),
    ]
    for ch in chapters:
        story.append(Paragraph(ch.title, h1))
        story.append(Spacer(1, 12))
        for para in (ch.content or "").split("\n\n"):
            if para.strip():
                safe = para.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                story.append(Paragraph(safe, body))
                story.append(Spacer(1, 6))
        story.append(PageBreak())
    doc.build(story)
    return buf.getvalue()


def _manuscript_to_epub(title: str, author: str, chapters: list[Chapter]) -> bytes:
    from ebooklib import epub
    book = epub.EpubBook()
    book.set_identifier("asm-manuscript")
    book.set_title(title)
    book.set_language("en")
    book.add_author(author)
    # Cover / TOC
    book.toc = []
    chapters_epub = []
    for idx, ch in enumerate(chapters, start=1):
        c = epub.EpubHtml(title=ch.title, file_name=f"ch{idx}.xhtml")
        paras = "".join(f"<p>{p.strip()}</p>" for p in (ch.content or "").split("\n\n") if p.strip())
        c.set_content(f"<h1>{ch.title}</h1>{paras}")
        book.add_item(c)
        chapters_epub.append(c)
        book.toc.append(c)
    # Default spine
    book.spine = ["nav"] + chapters_epub
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    buf = io.BytesIO()
    epub.write_epub(buf, book, {})
    return buf.getvalue()


def _character_sheet_pdf(data: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=0.75*inch, rightMargin=0.75*inch,
                            topMargin=0.75*inch, bottomMargin=0.75*inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    name_style = ParagraphStyle("CharName", parent=styles["Title"],
                                alignment=TA_CENTER, fontSize=22, spaceAfter=6,
                                textColor=colors.HexColor(data.get("avatar_color") or "#6366f1"))
    role_style = ParagraphStyle("CharRole", parent=styles["Normal"],
                                alignment=TA_CENTER, fontSize=12, spaceAfter=18,
                                textColor=colors.grey)
    h2 = ParagraphStyle("CharH2", parent=styles["Heading2"],
                        fontSize=14, spaceBefore=12, spaceAfter=6,
                        textColor=colors.HexColor("#6366f1"))
    body = ParagraphStyle("CharBody", parent=styles["BodyText"],
                          fontSize=10, leading=14, spaceAfter=8)
    story = [
        Paragraph(data["name"], name_style),
        Paragraph(f"{data.get('role', '')} • {data.get('age', '')} • {data.get('gender', '')}",
                  role_style),
    ]
    # Aliases
    aliases = data.get("aliases") or []
    if aliases:
        story.append(Paragraph(f"<b>Aliases:</b> {', '.join(aliases)}", body))
    # Sections
    sections = [
        ("Physical", "physical"),
        ("Psychology", "psychology"),
        ("Background", "background"),
        ("Philosophy", "philosophy"),
        ("Story Role", "story_role"),
        ("Voice & Dialogue", "voice"),
        ("Notes", "notes"),
    ]
    for label, key in sections:
        v = data.get(key)
        if v:
            story.append(Paragraph(label, h2))
            safe = v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            story.append(Paragraph(safe, body))
    # Quotes
    quotes = data.get("philosophy_quotes") or []
    if quotes:
        story.append(Paragraph("Notable Quotes", h2))
        for q in quotes:
            story.append(Paragraph(f'<i>"{q}"</i>', body))
    doc.build(story)
    return buf.getvalue()


def _character_sheet_docx(data: dict) -> bytes:
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    h = doc.add_heading(data["name"], 0)
    h.alignment = 1
    p = doc.add_paragraph()
    p.alignment = 1
    r = p.add_run(f"{data.get('role', '')} • {data.get('age', '')} • {data.get('gender', '')}")
    r.italic = True
    aliases = data.get("aliases") or []
    if aliases:
        doc.add_paragraph(f"Aliases: {', '.join(aliases)}")
    sections = [
        ("Physical", "physical"),
        ("Psychology", "psychology"),
        ("Background", "background"),
        ("Philosophy", "philosophy"),
        ("Story Role", "story_role"),
        ("Voice & Dialogue", "voice"),
        ("Notes", "notes"),
    ]
    for label, key in sections:
        v = data.get(key)
        if v:
            doc.add_heading(label, level=2)
            doc.add_paragraph(v)
    quotes = data.get("philosophy_quotes") or []
    if quotes:
        doc.add_heading("Notable Quotes", level=2)
        for q in quotes:
            doc.add_paragraph(f'"{q}"', style="Intense Quote")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _world_bible_pdf(title: str, entries: list[WorldEntry]) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=1*inch, rightMargin=1*inch,
                            topMargin=1*inch, bottomMargin=1*inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    title_style = ParagraphStyle("WBTitle", parent=styles["Title"],
                                 alignment=TA_CENTER, fontSize=24, spaceAfter=18)
    h1 = ParagraphStyle("WBH1", parent=styles["Heading1"],
                        fontSize=16, spaceBefore=12, spaceAfter=8,
                        textColor=colors.HexColor("#6366f1"))
    h2 = ParagraphStyle("WBH2", parent=styles["Heading2"],
                        fontSize=13, spaceBefore=10, spaceAfter=4)
    body = ParagraphStyle("WBBody", parent=styles["BodyText"],
                          fontSize=10, leading=14, spaceAfter=8)
    story = [Paragraph(f"{title} — World Bible", title_style), Spacer(1, 12)]

    by_type: dict[str, list] = {}
    for e in entries:
        by_type.setdefault(e.type, []).append(e)

    for t, group in by_type.items():
        story.append(Paragraph(t.upper().replace("_", " "), h1))
        for e in group:
            story.append(Paragraph(e.name, h2))
            if e.description:
                story.append(Paragraph(f"<i>{e.description}</i>", body))
            if e.content:
                safe = e.content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                story.append(Paragraph(safe, body))
        story.append(PageBreak())
    doc.build(story)
    return buf.getvalue()


def _world_bible_docx(title: str, entries: list[WorldEntry]) -> bytes:
    from docx import Document
    doc = Document()
    h = doc.add_heading(f"{title} — World Bible", 0)
    h.alignment = 1
    by_type: dict[str, list] = {}
    for e in entries:
        by_type.setdefault(e.type, []).append(e)
    for t, group in by_type.items():
        doc.add_heading(t.upper().replace("_", " "), level=1)
        for e in group:
            doc.add_heading(e.name, level=2)
            if e.description:
                doc.add_paragraph(e.description)
            if e.content:
                doc.add_paragraph(e.content)
        doc.add_page_break()
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def export_full_project(fmt: str = "docx",
                        include_secrets: bool = False) -> tuple[bytes, str, str]:
    """Export the entire project (manuscript + characters + world)."""
    # For brevity: produce a single combined DOCX/PDF.
    with read_session() as s:
        pid = current_project_id(s)
        from models.settings import Setting
        title = Setting.get(s, "story_title", "My Story")
        author = Setting.get(s, "story_author", "Author")
        chapters = list(s.scalars(
            select(Chapter).where(Chapter.project_id == pid)
            .order_by(Chapter.sort_order.asc())
        ).all())
        characters = list(s.scalars(
            select(Character).where(Character.project_id == pid)
            .order_by(Character.name.asc())
        ).all())
        world_entries = list(s.scalars(
            select(WorldEntry).where(WorldEntry.project_id == pid)
            .order_by(WorldEntry.type.asc(), WorldEntry.name.asc())
        ).all())
    if fmt == "docx":
        return _full_project_docx(title, author, chapters, characters, world_entries), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{_sf(title)}_full.docx"
    if fmt == "pdf":
        return _full_project_pdf(title, author, chapters, characters, world_entries), \
            "application/pdf", f"{_sf(title)}_full.pdf"
    raise NotFoundError(f"Unknown format: {fmt}")


def _full_project_docx(title, author, chapters, characters, world_entries) -> bytes:
    from docx import Document
    doc = Document()
    h = doc.add_heading(title, 0)
    h.alignment = 1
    p = doc.add_paragraph()
    p.alignment = 1
    p.add_run(f"by {author}").italic = True
    doc.add_page_break()
    # TOC-ish
    doc.add_heading("Contents", level=1)
    doc.add_paragraph("Manuscript")
    doc.add_paragraph("Characters")
    doc.add_paragraph("World Bible")
    doc.add_page_break()
    # Manuscript
    doc.add_heading("Manuscript", level=1)
    for ch in chapters:
        doc.add_heading(ch.title, level=2)
        for para in (ch.content or "").split("\n\n"):
            if para.strip():
                doc.add_paragraph(para.strip())
        doc.add_page_break()
    # Characters
    doc.add_heading("Characters", level=1)
    for c in characters:
        doc.add_heading(c.name, level=2)
        doc.add_paragraph(f"Role: {c.role} • Age: {c.age} • Gender: {c.gender}")
        if c.physical:
            doc.add_paragraph(c.physical)
        if c.psychology:
            doc.add_paragraph(c.psychology)
    # World
    doc.add_heading("World Bible", level=1)
    by_type: dict[str, list] = {}
    for e in world_entries:
        by_type.setdefault(e.type, []).append(e)
    for t, group in by_type.items():
        doc.add_heading(t.upper().replace("_", " "), level=2)
        for e in group:
            doc.add_heading(e.name, level=3)
            if e.description:
                doc.add_paragraph(e.description)
            if e.content:
                doc.add_paragraph(e.content)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _full_project_pdf(title, author, chapters, characters, world_entries) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=1*inch, rightMargin=1*inch,
                            topMargin=1*inch, bottomMargin=1*inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    title_style = ParagraphStyle("Title", parent=styles["Title"],
                                 alignment=TA_CENTER, fontSize=24, spaceAfter=18)
    h1 = ParagraphStyle("H1", parent=styles["Heading1"],
                        fontSize=18, spaceBefore=12, spaceAfter=8,
                        textColor=colors.HexColor("#6366f1"))
    h2 = ParagraphStyle("H2", parent=styles["Heading2"],
                        fontSize=14, spaceBefore=10, spaceAfter=6)
    body = ParagraphStyle("Body", parent=styles["BodyText"],
                          fontSize=10, leading=14, spaceAfter=8)
    story = [
        Spacer(1, 2*inch),
        Paragraph(title, title_style),
        Paragraph(f"by {author}", body),
        PageBreak(),
    ]
    story.append(Paragraph("Manuscript", h1))
    for ch in chapters:
        story.append(Paragraph(ch.title, h2))
        for para in (ch.content or "").split("\n\n"):
            if para.strip():
                safe = para.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                story.append(Paragraph(safe, body))
    story.append(PageBreak())
    story.append(Paragraph("Characters", h1))
    for c in characters:
        story.append(Paragraph(c.name, h2))
        story.append(Paragraph(f"Role: {c.role} • Age: {c.age} • Gender: {c.gender}", body))
        if c.physical:
            story.append(Paragraph(c.physical.replace("&", "&amp;"), body))
        if c.psychology:
            story.append(Paragraph(c.psychology.replace("&", "&amp;"), body))
    story.append(PageBreak())
    story.append(Paragraph("World Bible", h1))
    by_type: dict[str, list] = {}
    for e in world_entries:
        by_type.setdefault(e.type, []).append(e)
    for t, group in by_type.items():
        story.append(Paragraph(t.upper().replace("_", " "), h2))
        for e in group:
            story.append(Paragraph(f"<b>{e.name}</b>", body))
            if e.description:
                story.append(Paragraph(f"<i>{e.description}</i>", body))
            if e.content:
                safe = e.content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                story.append(Paragraph(safe, body))
    doc.build(story)
    return buf.getvalue()


# ---- Universal Export (v8.5): world entries, characters bulk, scenes,
#      glossary, references — every collection exportable in writer formats ----

def _story_title() -> str:
    """Current project's story title (for export headers)."""
    from models.settings import Setting
    with read_session() as s:
        return Setting.get(s, "story_title", "My Story")


def _world_entry_data(s, entry_id: str) -> dict:
    """Gather a full world entry (with hierarchy, relations, metadata) as dict."""
    e = s.get(WorldEntry, entry_id)
    if not e:
        raise NotFoundError("World entry not found.")
    # Parent chain (nearest ancestor first, cycle-safe)
    chain: list[str] = []
    seen = {e.id}
    pid = e.parent_id
    while pid and pid not in seen and len(chain) < 20:
        p = s.get(WorldEntry, pid)
        if not p:
            break
        chain.append(p.name)
        seen.add(pid)
        pid = p.parent_id
    children = list(s.scalars(select(WorldEntry).where(
        WorldEntry.parent_id == entry_id).order_by(WorldEntry.name.asc())).all())
    out_rels = list(s.scalars(select(WorldEntryRelation).where(
        WorldEntryRelation.from_entry_id == entry_id)).all())
    in_rels = list(s.scalars(select(WorldEntryRelation).where(
        WorldEntryRelation.to_entry_id == entry_id)).all())

    def _name_of(rid: str) -> str:
        r = s.get(WorldEntry, rid)
        return r.name if r else "?"

    data: dict[str, Any] = {
        "id": e.id,
        "name": e.name, "type": e.type, "category": e.category,
        "description": e.description, "content": e.content, "notes": e.notes,
        "metadata": load_json(e.metadata_, {}) or {},
        "parent_id": e.parent_id,
        "parent_chain": chain,
        "children": [c.name for c in children],
        "relations_out": [{"type": r.relation_type, "target": _name_of(r.to_entry_id),
                           "description": r.description} for r in out_rels],
        "relations_in": [{"type": r.relation_type, "source": _name_of(r.from_entry_id),
                          "description": r.description} for r in in_rels],
        "created_at": e.created_at.isoformat() if e.created_at else None,
        "updated_at": e.updated_at.isoformat() if e.updated_at else None,
    }
    if e.map_pin_x is not None:
        data["map_pin"] = {"x": round(e.map_pin_x, 2), "y": round(e.map_pin_y, 2),
                           "label": e.map_pin_label, "color": e.map_pin_color}
    else:
        data["map_pin"] = None
    return data


def _world_entry_txt(data: dict) -> str:
    parts = [f"{data['name'].upper()}\n{'=' * 40}\n"]
    bits = [data["type"].replace("_", " ").title()]
    if data["category"]:
        bits.append(data["category"])
    parts.append(" · ".join(bits) + "\n")
    if data["description"]:
        parts.append(f"\nDESCRIPTION:\n{data['description']}\n")
    if data["content"]:
        parts.append(f"\nCONTENT:\n{data['content']}\n")
    if data["notes"]:
        parts.append(f"\nNOTES:\n{data['notes']}\n")
    if data["metadata"]:
        parts.append("\nMETADATA:\n")
        for k, v in data["metadata"].items():
            parts.append(f"  {k.replace('_', ' ').title()}: {v}\n")
    if data["parent_chain"]:
        parts.append(f"\nHIERARCHY:\n  {' > '.join(reversed(data['parent_chain']))} > {data['name']}\n")
    if data["children"]:
        parts.append(f"\nCHILDREN:\n  {', '.join(data['children'])}\n")
    if data["relations_out"] or data["relations_in"]:
        parts.append("\nRELATIONS:\n")
        for r in data["relations_out"]:
            parts.append(f"  → {r['type'].replace('_',' ')}: {r['target']}\n")
        for r in data["relations_in"]:
            parts.append(f"  ← {r['type'].replace('_',' ')}: {r['source']}\n")
    if data["map_pin"]:
        m = data["map_pin"]
        parts.append(f"\nMAP PIN: ({m['x']}, {m['y']})"
                     + (f" — {m['label']}" if m["label"] else "") + "\n")
    return "".join(parts)


def _world_entry_md(data: dict) -> str:
    bits = [data["type"].replace("_", " ").title()]
    if data["category"]:
        bits.append(data["category"])
    parts = [f"# {data['name']}\n\n", f"`{' · '.join(bits)}`\n"]
    if data["description"]:
        parts.append(f"\n> {data['description']}\n")
    if data["content"]:
        parts.append(f"\n## Content\n\n{data['content']}\n")
    if data["notes"]:
        parts.append(f"\n## Notes\n\n{data['notes']}\n")
    if data["metadata"]:
        parts.append("\n## Metadata\n\n")
        for k, v in data["metadata"].items():
            parts.append(f"- **{k.replace('_', ' ').title()}:** {v}\n")
    if data["parent_chain"]:
        parts.append(f"\n## Hierarchy\n\n"
                     f"{' → '.join(reversed(data['parent_chain'] + [data['name']]))}\n")
    if data["children"]:
        parts.append(f"\n## Children\n\n{', '.join(data['children'])}\n")
    if data["relations_out"] or data["relations_in"]:
        parts.append("\n## Relations\n\n")
        for r in data["relations_out"]:
            parts.append(f"- → **{r['type'].replace('_',' ')}** → {r['target']}\n")
        for r in data["relations_in"]:
            parts.append(f"- ← **{r['type'].replace('_',' ')}** ← {r['source']}\n")
    if data["map_pin"]:
        m = data["map_pin"]
        parts.append(f"\n## Map Pin\n\n({m['x']}, {m['y']})"
                     + (f" — {m['label']}" if m["label"] else "") + "\n")
    return "".join(parts)


def export_world_entry(entry_id: str, fmt: str) -> tuple[bytes, str, str]:
    """Export a single world entry (location, species, faction, ...).

    Formats: txt / md / pdf / docx / json
    """
    fmt = fmt.lower()
    with read_session() as s:
        data = _world_entry_data(s, entry_id)
    base = _sf(data["name"])
    if fmt == "json":
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", f"{base}.json"
    if fmt == "txt":
        return _world_entry_txt(data).encode("utf-8"), "text/plain", f"{base}.txt"
    if fmt == "md":
        return _world_entry_md(data).encode("utf-8"), "text/markdown", f"{base}.md"
    if fmt == "pdf":
        return _world_entry_pdf(data), "application/pdf", f"{base}.pdf"
    if fmt == "docx":
        return _world_entry_docx(data), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{base}.docx"
    raise NotFoundError(f"Unknown format: {fmt}")


def _world_entry_pdf(data: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    def _esc(t: str) -> str:
        return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=0.75 * inch, rightMargin=0.75 * inch,
                            topMargin=0.75 * inch, bottomMargin=0.75 * inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    name_style = ParagraphStyle("WeName", parent=styles["Title"], alignment=TA_CENTER,
                                fontSize=22, spaceAfter=6,
                                textColor=colors.HexColor("#6366f1"))
    sub_style = ParagraphStyle("WeSub", parent=styles["Normal"], alignment=TA_CENTER,
                               fontSize=12, spaceAfter=18, textColor=colors.grey)
    h2 = ParagraphStyle("WeH2", parent=styles["Heading2"], fontSize=14,
                        spaceBefore=12, spaceAfter=6,
                        textColor=colors.HexColor("#6366f1"))
    body = ParagraphStyle("WeBody", parent=styles["BodyText"], fontSize=10,
                          leading=14, spaceAfter=8)
    small = ParagraphStyle("WeSmall", parent=styles["BodyText"], fontSize=9,
                           leading=12, spaceAfter=4, textColor=colors.HexColor("#475569"))

    bits = [data["type"].replace("_", " ").title()]
    if data["category"]:
        bits.append(data["category"])
    story = [Paragraph(_esc(data["name"]), name_style),
             Paragraph(_esc(" · ".join(bits)), sub_style)]
    if data["description"]:
        story.append(Paragraph(f"<i>{_esc(data['description'])}</i>", body))
    if data["content"]:
        story.append(Paragraph("Content", h2))
        for para in str(data["content"]).split("\n"):
            if para.strip():
                story.append(Paragraph(_esc(para), body))
    if data["notes"]:
        story.append(Paragraph("Notes", h2))
        story.append(Paragraph(_esc(data["notes"]), body))
    if data["metadata"]:
        story.append(Paragraph("Metadata", h2))
        rows = [[Paragraph(f"<b>{_esc(k.replace('_', ' ').title())}</b>", small),
                 Paragraph(_esc(v), small)] for k, v in data["metadata"].items()]
        t = Table(rows, colWidths=[1.6 * inch, 4.9 * inch])
        t.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)
        story.append(Spacer(1, 6))
    if data["parent_chain"] or data["children"]:
        story.append(Paragraph("Hierarchy", h2))
        if data["parent_chain"]:
            story.append(Paragraph(
                " → ".join(_esc(n) for n in reversed(data["parent_chain"] + [data["name"]])), small))
        if data["children"]:
            story.append(Paragraph(f"Children: {_esc(', '.join(data['children']))}", small))
    if data["relations_out"] or data["relations_in"]:
        story.append(Paragraph("Relations", h2))
        for r in data["relations_out"]:
            story.append(Paragraph(
                f"→ {_esc(r['type'].replace('_',' '))} → <b>{_esc(r['target'])}</b>", small))
        for r in data["relations_in"]:
            story.append(Paragraph(
                f"← {_esc(r['type'].replace('_',' '))} ← <b>{_esc(r['source'])}</b>", small))
    if data["map_pin"]:
        m = data["map_pin"]
        label = f" — {_esc(m['label'])}" if m["label"] else ""
        story.append(Paragraph("Map Pin", h2))
        story.append(Paragraph(f"({m['x']}, {m['y']}){label}", small))
    if data["updated_at"]:
        story.append(Spacer(1, 16))
        story.append(Paragraph(
            f"Updated: {str(data['updated_at'])[:19].replace('T', ' ')}", small))
    doc.build(story)
    return buf.getvalue()


def _world_entry_docx(data: dict) -> bytes:
    from docx import Document
    doc = Document()
    h = doc.add_heading(data["name"], 0)
    h.alignment = 1
    bits = [data["type"].replace("_", " ").title()]
    if data["category"]:
        bits.append(data["category"])
    p = doc.add_paragraph()
    p.alignment = 1
    p.add_run(" · ".join(bits)).italic = True
    if data["description"]:
        doc.add_paragraph(data["description"])
    if data["content"]:
        doc.add_heading("Content", level=2)
        doc.add_paragraph(data["content"])
    if data["notes"]:
        doc.add_heading("Notes", level=2)
        doc.add_paragraph(data["notes"])
    if data["metadata"]:
        doc.add_heading("Metadata", level=2)
        for k, v in data["metadata"].items():
            doc.add_paragraph(f"{k.replace('_', ' ').title()}: {v}")
    if data["parent_chain"] or data["children"]:
        doc.add_heading("Hierarchy", level=2)
        if data["parent_chain"]:
            doc.add_paragraph(" → ".join(reversed(data["parent_chain"] + [data["name"]])))
        if data["children"]:
            doc.add_paragraph(f"Children: {', '.join(data['children'])}")
    if data["relations_out"] or data["relations_in"]:
        doc.add_heading("Relations", level=2)
        for r in data["relations_out"]:
            doc.add_paragraph(f"→ {r['type'].replace('_', ' ')} → {r['target']}")
        for r in data["relations_in"]:
            doc.add_paragraph(f"← {r['type'].replace('_', ' ')} ← {r['source']}")
    if data["map_pin"]:
        m = data["map_pin"]
        label = f" — {m['label']}" if m["label"] else ""
        doc.add_heading("Map Pin", level=2)
        doc.add_paragraph(f"({m['x']}, {m['y']}){label}")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---- World collection (type-filtered: all locations, all species, ...) ----

def _plural_type_label(type_: str) -> str:
    """Human plural label for a world type: location → Locations,
    species → Species, magic_system → Magic Systems, technology → Technologies."""
    label = type_.replace("_", " ").title()
    low = type_.lower()
    if low.endswith("s"):          # species, custom ...s types
        return label
    if low.endswith("y") and len(low) > 1 and low[-2] not in "aeiou":
        return label[:-1] + "ies"  # technology → Technologies
    return label + "s"             # location → Locations


def export_world_collection(
    type_: str = "all", fmt: str = "md",
    *, search: str | None = None, category: str | None = None,
) -> tuple[bytes, str, str]:
    """Export every world entry of one type (or all types).

    Formats: txt / md / pdf / docx / json. Filters mirror the World Library
    page (type tab + search + category chip).
    """
    fmt = fmt.lower()
    if type_ in ("", "all"):
        # Whole bible → reuse the established export, extended with MD
        if fmt == "md":
            entries = _world_entries_all()
            title = _story_title()
            md = [f"# {title} — World Bible\n"]
            by_type: dict[str, list] = {}
            for e in entries:
                by_type.setdefault(e.type, []).append(e)
            for t, group in sorted(by_type.items()):
                md.append(f"\n## {t.replace('_', ' ').title()}\n")
                for e in group:
                    md.append(f"\n### {e.name}\n")
                    if e.category:
                        md.append(f"`{e.category}`\n")
                    if e.description:
                        md.append(f"> {e.description}\n")
                    if e.content:
                        md.append(f"\n{e.content}\n")
                    if e.notes:
                        md.append(f"\n*Notes: {e.notes}*\n")
            return "".join(md).encode("utf-8"), "text/markdown", "world_bible.md"
        return export_world_bible(fmt)

    with read_session() as s:
        pid = current_project_id(s)
        q = select(WorldEntry).where(WorldEntry.project_id == pid,
                                     WorldEntry.type == type_)
        if search:
            like = f"%{search}%"
            q = q.where((WorldEntry.name.ilike(like)) | (WorldEntry.description.ilike(like)))
        if category:
            q = q.where(WorldEntry.category == category)
        entries = list(s.scalars(q.order_by(
            WorldEntry.sort_order.asc(), WorldEntry.name.asc())).all())
        # Full data dicts (hierarchy + relations included)
        data_list = [_world_entry_data(s, e.id) for e in entries]

    label = _plural_type_label(type_)
    base = _sf(f"{type_}s" if not type_.endswith("s") else type_)
    if fmt == "json":
        payload = {"collection": type_, "count": len(data_list), "entries": data_list}
        return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", f"{base}.json"
    if fmt == "txt":
        parts = [f"{label.upper()} — {_story_title()}\n{'=' * 50}\n"]
        for d in data_list:
            parts.append("\n" + _world_entry_txt(d) + "\n" + "-" * 50 + "\n")
        return "".join(parts).encode("utf-8"), "text/plain", f"{base}.txt"
    if fmt == "md":
        parts = [f"# {label} — {_story_title()}\n"]
        for d in data_list:
            parts.append("\n---\n\n" + _world_entry_md(d))
        return "".join(parts).encode("utf-8"), "text/markdown", f"{base}.md"
    if fmt == "pdf":
        return _world_collection_pdf(label, data_list), "application/pdf", f"{base}.pdf"
    if fmt == "docx":
        return _world_collection_docx(label, data_list), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            f"{base}.docx"
    raise NotFoundError(f"Unknown format: {fmt}")


def _world_entries_all() -> list[WorldEntry]:
    with read_session() as s:
        pid = current_project_id(s)
        return list(s.scalars(select(WorldEntry).where(
            WorldEntry.project_id == pid)
            .order_by(WorldEntry.type.asc(), WorldEntry.name.asc())).all())


def _world_collection_pdf(label: str, data_list: list[dict]) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    def _esc(t: str) -> str:
        return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=0.9 * inch, rightMargin=0.9 * inch,
                            topMargin=0.9 * inch, bottomMargin=0.9 * inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    title_style = ParagraphStyle("WcTitle", parent=styles["Title"], alignment=TA_CENTER,
                                 fontSize=24, spaceAfter=6)
    sub = ParagraphStyle("WcSub", parent=styles["Normal"], alignment=TA_CENTER,
                         fontSize=11, spaceAfter=24, textColor=colors.grey)
    h2 = ParagraphStyle("WcH2", parent=styles["Heading2"], fontSize=15,
                        spaceBefore=14, spaceAfter=4,
                        textColor=colors.HexColor("#6366f1"))
    small = ParagraphStyle("WcSmall", parent=styles["BodyText"], fontSize=9,
                           leading=12, spaceAfter=4, textColor=colors.HexColor("#475569"))
    body = ParagraphStyle("WcBody", parent=styles["BodyText"], fontSize=10,
                          leading=14, spaceAfter=8)
    story = [Paragraph(_esc(label), title_style),
             Paragraph(f"{len(data_list)} entries · {_esc(_story_title())}", sub)]
    for d in data_list:
        story.append(Paragraph(_esc(d["name"]), h2))
        bits = []
        if d["category"]:
            bits.append(_esc(d["category"]))
        if d["parent_chain"]:
            bits.append(_esc(" > ".join(reversed(d["parent_chain"]))))
        if bits:
            story.append(Paragraph(" · ".join(bits), small))
        if d["description"]:
            story.append(Paragraph(f"<i>{_esc(d['description'])}</i>", body))
        if d["content"]:
            for para in str(d["content"]).split("\n")[:40]:
                if para.strip():
                    story.append(Paragraph(_esc(para), body))
        if d["metadata"]:
            kv = " · ".join(f"{k.replace('_',' ').title()}: {v}"
                            for k, v in d["metadata"].items())
            story.append(Paragraph(kv, small))
        if d["relations_out"]:
            rel = " · ".join(f"→ {r['type'].replace('_',' ')} → {r['target']}"
                             for r in d["relations_out"])
            story.append(Paragraph(rel, small))
    doc.build(story)
    return buf.getvalue()


def _world_collection_docx(label: str, data_list: list[dict]) -> bytes:
    from docx import Document
    doc = Document()
    h = doc.add_heading(label, 0)
    h.alignment = 1
    doc.add_paragraph(f"{len(data_list)} entries")
    for d in data_list:
        doc.add_heading(d["name"], level=2)
        if d["category"]:
            doc.add_paragraph(f"Category: {d['category']}")
        if d["parent_chain"]:
            doc.add_paragraph(" > ".join(reversed(d["parent_chain"] + [d["name"]])))
        if d["description"]:
            doc.add_paragraph(d["description"])
        if d["content"]:
            doc.add_paragraph(d["content"])
        if d["metadata"]:
            for k, v in d["metadata"].items():
                doc.add_paragraph(f"{k.replace('_', ' ').title()}: {v}")
        for r in d["relations_out"]:
            doc.add_paragraph(f"→ {r['type'].replace('_', ' ')} → {r['target']}")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---- Characters bulk export ----

def export_characters(fmt: str) -> tuple[bytes, str, str]:
    """Export ALL character sheets as one file. txt / md / pdf / docx / json."""
    fmt = fmt.lower()
    with read_session() as s:
        pid = current_project_id(s)
        chars = list(s.scalars(select(Character).where(
            Character.project_id == pid).order_by(Character.name.asc())).all())
        data_list = [{
            "name": c.name, "role": c.role, "age": c.age, "gender": c.gender,
            "aliases": load_json(c.aliases, []),
            "avatar_color": c.avatar_color,
            "physical": c.physical, "psychology": c.psychology,
            "background": c.background, "philosophy": c.philosophy,
            "philosophy_quotes": load_json(c.philosophy_quotes, []),
            "story_role": c.story_role, "voice": c.voice, "notes": c.notes,
        } for c in chars]
    title = _story_title()
    if fmt == "json":
        payload = {"collection": "characters", "count": len(data_list),
                   "characters": data_list}
        return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", "characters.json"
    if fmt == "txt":
        parts = [f"CHARACTERS — {title}\n{'=' * 50}\n"]
        for d in data_list:
            parts.append(f"\n\n{d['name'].upper()} ({d.get('role') or '-'})\n{'-' * 40}\n")
            for k, v in d.items():
                if k in ("name", "avatar_color") or not v:
                    continue
                if isinstance(v, list):
                    v = "; ".join(str(x) for x in v)
                parts.append(f"\n{k.replace('_', ' ').upper()}:\n{v}\n")
        return "".join(parts).encode("utf-8"), "text/plain", "characters.txt"
    if fmt == "md":
        parts = [f"# Characters — {title}\n"]
        for d in data_list:
            parts.append(f"\n---\n\n## {d['name']}\n\n")
            bits = [str(d.get("role") or "-"), str(d.get("age") or "-"),
                    str(d.get("gender") or "-")]
            parts.append(f"`{' · '.join(bits)}`\n")
            if d.get("aliases"):
                parts.append(f"\n*Aliases: {', '.join(d['aliases'])}*\n")
            for label, key in (("Physical", "physical"), ("Psychology", "psychology"),
                               ("Background", "background"), ("Philosophy", "philosophy"),
                               ("Story Role", "story_role"), ("Voice", "voice"),
                               ("Notes", "notes")):
                if d.get(key):
                    parts.append(f"\n### {label}\n\n{d[key]}\n")
            if d.get("philosophy_quotes"):
                parts.append("\n### Notable Quotes\n\n")
                for q in d["philosophy_quotes"]:
                    parts.append(f"> \"{q}\"\n")
        return "".join(parts).encode("utf-8"), "text/markdown", "characters.md"
    if fmt == "pdf":
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

        def _esc(t: str) -> str:
            return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=letter,
                                leftMargin=0.85 * inch, rightMargin=0.85 * inch,
                                topMargin=0.85 * inch, bottomMargin=0.85 * inch)
        styles = getSampleStyleSheet()
        pdf_fonts.apply_to_stylesheet(styles)
        title_style = ParagraphStyle("CsT", parent=styles["Title"], alignment=TA_CENTER,
                                     fontSize=24, spaceAfter=24)
        h1 = ParagraphStyle("CsH1", parent=styles["Heading1"], fontSize=17,
                            spaceBefore=6, spaceAfter=2,
                            textColor=colors.HexColor("#6366f1"))
        sub = ParagraphStyle("CsSub", parent=styles["Normal"], fontSize=10,
                             spaceAfter=10, textColor=colors.grey)
        h3 = ParagraphStyle("CsH3", parent=styles["Heading3"], fontSize=12,
                            spaceBefore=8, spaceAfter=2,
                            textColor=colors.HexColor("#334155"))
        body = ParagraphStyle("CsB", parent=styles["BodyText"], fontSize=10,
                              leading=14, spaceAfter=6)
        story = [Paragraph(f"Characters — {_esc(title)}", title_style)]
        for i, d in enumerate(data_list):
            if i:
                story.append(PageBreak())
            story.append(Paragraph(_esc(d["name"]), h1))
            story.append(Paragraph(_esc(" · ".join(
                str(x) for x in (d.get("role") or "-", d.get("age") or "-",
                                 d.get("gender") or "-"))), sub))
            if d.get("aliases"):
                story.append(Paragraph(f"<i>Aliases: {_esc(', '.join(d['aliases']))}</i>", sub))
            for label, key in (("Physical", "physical"), ("Psychology", "psychology"),
                               ("Background", "background"), ("Philosophy", "philosophy"),
                               ("Story Role", "story_role"), ("Voice & Dialogue", "voice"),
                               ("Notes", "notes")):
                if d.get(key):
                    story.append(Paragraph(label, h3))
                    story.append(Paragraph(_esc(d[key]), body))
            if d.get("philosophy_quotes"):
                story.append(Paragraph("Notable Quotes", h3))
                for q in d["philosophy_quotes"]:
                    story.append(Paragraph(f"<i>\"{_esc(q)}\"</i>", body))
        doc.build(story)
        return buf.getvalue(), "application/pdf", "characters.pdf"
    if fmt == "docx":
        from docx import Document
        doc = Document()
        h = doc.add_heading(f"Characters — {title}", 0)
        h.alignment = 1
        for d in data_list:
            doc.add_heading(d["name"], level=1)
            doc.add_paragraph(f"{d.get('role') or '-'} • {d.get('age') or '-'} • "
                              f"{d.get('gender') or '-'}")
            if d.get("aliases"):
                doc.add_paragraph(f"Aliases: {', '.join(d['aliases'])}")
            for label, key in (("Physical", "physical"), ("Psychology", "psychology"),
                               ("Background", "background"), ("Philosophy", "philosophy"),
                               ("Story Role", "story_role"), ("Voice & Dialogue", "voice"),
                               ("Notes", "notes")):
                if d.get(key):
                    doc.add_heading(label, level=2)
                    doc.add_paragraph(d[key])
            if d.get("philosophy_quotes"):
                doc.add_heading("Notable Quotes", level=2)
                for q in d["philosophy_quotes"]:
                    doc.add_paragraph(f'"{q}"', style="Intense Quote")
            doc.add_page_break()
        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue(), \
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", \
            "characters.docx"
    raise NotFoundError(f"Unknown format: {fmt}")


# ---- Scene cards export ----

def export_scenes(fmt: str) -> tuple[bytes, str, str]:
    """Export all scene cards (grouped by chapter). txt / md / csv / json."""
    from models.scene import SceneCard
    fmt = fmt.lower()
    with read_session() as s:
        pid = current_project_id(s)
        cards = list(s.scalars(select(SceneCard).where(
            SceneCard.project_id == pid)
            .order_by(SceneCard.sort_order.asc())).all())
        # Chapter titles for grouping
        chapter_titles = {}
        for c in s.scalars(select(Chapter).where(Chapter.project_id == pid)).all():
            chapter_titles[c.id] = c.title
        rows = [{
            "title": card.title or "Untitled Scene",
            "chapter": chapter_titles.get(card.chapter_id, "Standalone") if card.chapter_id else "Standalone",
            "pov": None, "location": card.location,
            "time_of_day": card.time_of_day, "mood": card.mood,
            "status": card.status, "word_count": card.word_count or 0,
            "tags": load_json(card.tags, []),
            "summary": card.summary, "notes": card.notes,
            "content": card.full_text or card.content_snippet or "",
        } for card in cards]
        # POV names
        from models.character import Character as Char
        char_names = {c.id: c.name for c in s.scalars(
            select(Char).where(Char.project_id == pid)).all()}
        for card, row in zip(cards, rows):
            if card.pov_character_id:
                row["pov"] = char_names.get(card.pov_character_id)
    if fmt == "json":
        payload = {"collection": "scenes", "count": len(rows), "scenes": rows}
        return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", "scenes.json"
    if fmt == "txt":
        parts = [f"SCENE CARDS — {_story_title()}\n{'=' * 50}\n"]
        cur_ch = None
        for r in rows:
            if r["chapter"] != cur_ch:
                cur_ch = r["chapter"]
                parts.append(f"\n\n### {cur_ch.upper()} ###\n")
            bits = [r["title"]]
            if r["pov"]:
                bits.append(f"POV: {r['pov']}")
            if r["location"]:
                bits.append(f"@ {r['location']}")
            bits.append(f"[{r['status']}] ({r['word_count']} words)")
            parts.append(f"\n• {' — '.join(bits)}\n")
            if r["summary"]:
                parts.append(f"  {r['summary']}\n")
        return "".join(parts).encode("utf-8"), "text/plain", "scenes.txt"
    if fmt == "md":
        parts = [f"# Scene Cards — {_story_title()}\n"]
        cur_ch = None
        for r in rows:
            if r["chapter"] != cur_ch:
                cur_ch = r["chapter"]
                parts.append(f"\n## {cur_ch}\n")
            bits = [f"**{r['title']}**"]
            if r["pov"]:
                bits.append(f"POV: {r['pov']}")
            if r["location"]:
                bits.append(f"@ {r['location']}")
            if r["time_of_day"]:
                bits.append(r["time_of_day"])
            if r["mood"]:
                bits.append(r["mood"])
            parts.append(f"\n- {' — '.join(bits)} `{r['status']}` ({r['word_count']} words)\n")
            if r["summary"]:
                parts.append(f"\n  {r['summary']}\n")
            if r["tags"]:
                parts.append(f"  Tags: {', '.join(r['tags'])}\n")
        return "".join(parts).encode("utf-8"), "text/markdown", "scenes.md"
    if fmt == "csv":
        import csv as _csv
        out = io.StringIO()
        w = _csv.writer(out)
        w.writerow(["title", "chapter", "pov", "location", "time_of_day",
                    "mood", "status", "word_count", "tags", "summary"])
        for r in rows:
            w.writerow([r["title"], r["chapter"], r["pov"] or "", r["location"] or "",
                        r["time_of_day"] or "", r["mood"] or "", r["status"],
                        r["word_count"], "; ".join(r["tags"] or []),
                        (r["summary"] or "").replace("\n", " ")])
        return out.getvalue().encode("utf-8"), "text/csv", "scenes.csv"
    raise NotFoundError(f"Unknown format: {fmt}")


# ---- Glossary export ----

def export_glossary(fmt: str) -> tuple[bytes, str, str]:
    """Export the full glossary & style sheet. txt / md / csv / json."""
    from models.glossary import GlossaryEntry
    fmt = fmt.lower()
    with read_session() as s:
        pid = current_project_id(s)
        entries = list(s.scalars(select(GlossaryEntry).where(
            GlossaryEntry.project_id == pid)
            .order_by(GlossaryEntry.category.asc(), GlossaryEntry.term.asc())).all())
        rows = [{
            "term": e.term, "category": e.category or "general",
            "definition": e.definition,
            "alternates": load_json(e.alternates, []),
            "forbidden": load_json(e.forbidden, []),
            "case_sensitive": bool(e.case_sensitive),
            "notes": e.notes,
        } for e in entries]
    if fmt == "json":
        payload = {"collection": "glossary", "count": len(rows), "entries": rows}
        return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", "glossary.json"
    if fmt == "txt":
        parts = [f"GLOSSARY & STYLE SHEET — {_story_title()}\n{'=' * 50}\n"]
        for r in rows:
            parts.append(f"\n{r['term']} [{r['category']}]\n")
            if r["definition"]:
                parts.append(f"  {r['definition']}\n")
            if r["alternates"]:
                parts.append(f"  Alternates: {', '.join(r['alternates'])}\n")
            if r["forbidden"]:
                parts.append(f"  FORBIDDEN: {', '.join(r['forbidden'])}\n")
            if r["notes"]:
                parts.append(f"  Note: {r['notes']}\n")
        return "".join(parts).encode("utf-8"), "text/plain", "glossary.txt"
    if fmt == "md":
        parts = [f"# Glossary & Style Sheet — {_story_title()}\n"]
        by_cat: dict[str, list] = {}
        for r in rows:
            by_cat.setdefault(r["category"], []).append(r)
        for cat, group in sorted(by_cat.items()):
            parts.append(f"\n## {cat.title()}\n")
            for r in group:
                parts.append(f"\n- **{r['term']}**")
                if r["definition"]:
                    parts.append(f" — {r['definition']}")
                parts.append("\n")
                if r["alternates"]:
                    parts.append(f"  - Alternates: {', '.join(r['alternates'])}\n")
                if r["forbidden"]:
                    parts.append(f"  - ⛔ Forbidden: {', '.join(r['forbidden'])}\n")
        return "".join(parts).encode("utf-8"), "text/markdown", "glossary.md"
    if fmt == "csv":
        import csv as _csv
        out = io.StringIO()
        w = _csv.writer(out)
        w.writerow(["term", "category", "definition", "alternates",
                    "forbidden", "case_sensitive", "notes"])
        for r in rows:
            w.writerow([r["term"], r["category"],
                        (r["definition"] or "").replace("\n", " "),
                        "; ".join(r["alternates"]), "; ".join(r["forbidden"]),
                        "yes" if r["case_sensitive"] else "no",
                        (r["notes"] or "").replace("\n", " ")])
        return out.getvalue().encode("utf-8"), "text/csv", "glossary.csv"
    raise NotFoundError(f"Unknown format: {fmt}")


# ---- References (research library) export ----

def export_references(fmt: str) -> tuple[bytes, str, str]:
    """Export the research library (bibliography-friendly). txt / md / csv / json."""
    from models.reference import Reference
    fmt = fmt.lower()
    with read_session() as s:
        pid = current_project_id(s)
        refs = list(s.scalars(select(Reference).where(
            Reference.project_id == pid)
            .order_by(Reference.source_type.asc(), Reference.title.asc())).all())
        rows = [{
            "title": r.title, "author": r.author, "url": r.url,
            "source_type": r.source_type, "publication_date": r.publication_date,
            "publisher": r.publisher, "isbn_or_doi": r.isbn_or_doi,
            "description": r.description, "quotes": load_json(r.quotes, []),
            "tags": load_json(r.tags, []), "read_status": r.read_status,
            "priority": r.priority, "rating": r.rating, "notes": r.notes,
        } for r in refs]
    if fmt == "json":
        payload = {"collection": "references", "count": len(rows), "references": rows}
        return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"), \
            "application/json", "references.json"
    if fmt == "txt":
        parts = [f"RESEARCH & REFERENCES — {_story_title()}\n{'=' * 50}\n"]
        for r in rows:
            who = r["author"] or "Unknown"
            when = f" ({r['publication_date']})" if r["publication_date"] else ""
            parts.append(f"\n• {r['title']} — {who}{when} [{r['source_type']}]\n")
            if r["url"]:
                parts.append(f"  {r['url']}\n")
            if r["description"]:
                parts.append(f"  {r['description']}\n")
            for q in r["quotes"]:
                page = f" (p. {q.get('page')})" if q.get("page") else ""
                parts.append(f'  Quote{page}: "{q.get("text", "")}"\n')
        return "".join(parts).encode("utf-8"), "text/plain", "references.txt"
    if fmt == "md":
        parts = [f"# Research & References — {_story_title()}\n"]
        for r in rows:
            who = r["author"] or "Unknown"
            when = f" ({r['publication_date']})" if r["publication_date"] else ""
            parts.append(f"\n## {r['title']}\n\n*{who}*{when} · `{r['source_type']}` · "
                         f"status: {r['read_status']}"
                         + (f" · rating: {'★' * r['rating']}" if r["rating"] else "")
                         + "\n")
            if r["url"]:
                parts.append(f"\n<{r['url']}>\n")
            if r["description"]:
                parts.append(f"\n{r['description']}\n")
            if r["quotes"]:
                parts.append("\n### Quotes\n")
                for q in r["quotes"]:
                    page = f" (p. {q.get('page')})" if q.get("page") else ""
                    qtext = str(q.get("text", ""))
                    parts.append(f'> "{qtext}"{page}\n')
            if r["tags"]:
                parts.append(f"\nTags: {', '.join(r['tags'])}\n")
        return "".join(parts).encode("utf-8"), "text/markdown", "references.md"
    if fmt == "csv":
        import csv as _csv
        out = io.StringIO()
        w = _csv.writer(out)
        w.writerow(["title", "author", "source_type", "publication_date", "publisher",
                    "isbn_or_doi", "url", "read_status", "priority", "rating",
                    "tags", "description", "notes"])
        for r in rows:
            w.writerow([r["title"], r["author"] or "", r["source_type"],
                        r["publication_date"] or "", r["publisher"] or "",
                        r["isbn_or_doi"] or "", r["url"] or "", r["read_status"],
                        r["priority"], r["rating"] or "", "; ".join(r["tags"]),
                        (r["description"] or "").replace("\n", " "),
                        (r["notes"] or "").replace("\n", " ")])
        return out.getvalue().encode("utf-8"), "text/csv", "references.csv"
    raise NotFoundError(f"Unknown format: {fmt}")


# ---- Async export with progress ----
# v9.3.0 (F-05): tasks live in the durable background_tasks table. The
# executor moved to task_queue_service._execute_export; this module keeps
# only the public face used by routes/export.py.

def async_export(entity_type: str, fmt: str, *, entity_id: str | None = None) -> str:
    """Start a background export task. Returns task_id.

    entity_type: "manuscript" | "world_bible" | "full_project" | "chapter" | "character"
    fmt: txt/md/html/docx/pdf/epub/json
    entity_id: required for chapter/character, ignored for manuscript/world_bible/full_project

    v9.3.0 (F-05): the task is enqueued on the DISK-BACKED queue — if the
    app closes mid-export, the task survives and re-runs on next start.
    """
    from services import task_queue_service

    t = task_queue_service.enqueue("export", {
        "entity_type": entity_type, "fmt": fmt, "entity_id": entity_id,
    })
    return t.id


def get_export_status(task_id: str) -> dict[str, Any] | None:
    """Get export task status. Returns None if task not found.

    Shape (worker-compatible with the pre-v9.3.0 cache dict):
        {"status": "pending|processing|done|failed", "progress": 0-100,
         "stage": str, "filename": ..., "mime": ..., "size": ...}
    """
    from services import task_queue_service

    return task_queue_service.status_dict(task_id)


def get_export_file(task_id: str) -> tuple[bytes, str, str] | None:
    """Get the completed export file. Returns (content, mime, filename) or None."""
    status = get_export_status(task_id)
    if not status or status.get("status") != "done":
        return None
    filename = status.get("filename", "")
    mime = status.get("mime", "application/octet-stream")
    file_path = Config.EXPORT_DIR / task_id / filename
    if not file_path.exists():
        return None
    return file_path.read_bytes(), mime, filename
