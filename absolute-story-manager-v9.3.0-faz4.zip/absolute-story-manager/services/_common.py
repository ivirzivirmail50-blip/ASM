"""Common service helpers (activity logging, JSON serialization, current project)."""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable

from sqlalchemy.orm import Session

from core.db import read_session, write_transaction

log = logging.getLogger("asm.services")

# v9.1.0 (M-05): models are imported LAZILY inside the helpers. A top-level
# `from models... import` here created an import cycle
# (_common -> models/__init__ -> services.checklist_service -> _common)
# that exploded whenever _common was imported FIRST — previously it only
# worked by accident of import order. Lazy imports make every order safe.


def new_uuid() -> str:
    return uuid.uuid4().hex


def current_project_id(session: Session) -> str:
    """Return the active project id from settings, defaulting to 'default'."""
    from models.settings import Setting  # noqa: PLC0415 - cycle-safe (M-05)

    pid = Setting.get(session, "active_project_id", "default")
    return pid or "default"


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def load_json(value: str | None, default: Any = None) -> Any:
    if not value:
        return default if default is not None else []
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return default if default is not None else []


def dump_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


# ---------------------------------------------------------------------------
# v9.1.0 (M-05) — filename / markdown helpers, single source.
# Formerly three copies of _safe_filename (compile/export/scrivener) and two
# copies of _md_to_html (compile/export) with DIFFERENT behavior each. The
# parameterized function below reproduces every variant byte-identically;
# the presets lock each call site's historical behavior.
# ---------------------------------------------------------------------------

import re  # noqa: E402


def safe_filename(
    s: str | None,
    *,
    allow: str = r"\w\s-",
    replace: str = "",
    collapse: str | None = None,
    lower: bool = False,
    max_len: int = 60,
    fallback: str = "export",
    fallback_after_truncate: bool = True,
) -> str:
    """Sanitize a string for filesystem safety (M-05 single source).

    Args:
        allow: regex character class of characters to KEEP.
        replace: string substituted for runs of disallowed characters.
        collapse: if set, `[-\\s]+` runs collapse to this separator.
        lower: lowercase the result (slug style).
        max_len: truncation length.
        fallback: used when the INPUT is empty/None.
        fallback_after_truncate: also fall back when the result is empty
            after sanitization (compile/scrivener did; export did not).
    """
    import re as _re

    out = _re.sub(f"[^{allow}]+", replace, s if s else fallback)
    out = out.strip()
    if lower:
        out = out.lower()
    if collapse is not None:
        out = _re.sub(r"[-\s]+", collapse, out)
    out = out[:max_len]
    if fallback_after_truncate and not out:
        return fallback
    return out


# Historical behaviors as presets (byte-identical to the former copies):
SAFE_FILENAME_SLUG = dict(
    lower=True, collapse="-", max_len=60, fallback="manuscript",
)
SAFE_FILENAME_SCRIV = dict(
    collapse="_", max_len=60, fallback="untitled",
)
SAFE_FILENAME_EXPORT = dict(
    allow=r"\w.\- ", replace="_", max_len=180, fallback="export",
    fallback_after_truncate=False,
)


def md_to_html(text: str) -> str:
    """Full markdown → HTML via the markdown package (former export copy)."""
    import markdown

    return markdown.markdown(text or "", extensions=["extra", "nl2br"])


def md_to_html_minimal(text: str) -> str:
    """Conservative markdown → HTML (former compile copy).

    Escapes HTML first, then applies bold/italic + paragraph/br structure —
    deliberately library-free and output-compatible with the v9.0 compile
    pipeline. Behavior intentionally differs from md_to_html().
    """
    if not text:
        return ""
    # Escape HTML first
    import html as _html

    s = _html.escape(text)
    # Bold
    s = s.replace("**", "<strong>", 1) if "**" in s else s
    # Italic
    s = s.replace("*", "<em>", 1) if "*" in s else s
    # Paragraphs
    paras = s.split("\n\n")
    return "".join(
        f"<p>{p.strip().replace(chr(10), '<br>')}</p>"
        for p in paras if p.strip()
    )


def log_activity(
    session: Session,
    *,
    entity_type: str,
    entity_id: str,
    entity_title: str,
    action: str,
    word_count_delta: int = 0,
    details: dict | None = None,
    project_id: str | None = None,
) -> None:
    """Insert an activity log entry and cap the table.

    Must be called within an existing write transaction.
    Also invalidates the stats cache so dashboard reflects fresh data.
    """
    from models.activity import (  # noqa: PLC0415 - cycle-safe (M-05)
        ActivityLog,
        cap_activity_log,
    )

    pid = project_id or current_project_id(session)
    entry = ActivityLog(
        project_id=pid,
        entity_type=entity_type,
        entity_id=entity_id,
        entity_title=(entity_title or "")[:500],
        action=action,
        word_count_delta=word_count_delta or 0,
        details=dump_json(details) if details else None,
        timestamp=now_utc(),
    )
    session.add(entry)
    session.flush()  # ensure id assigned
    cap_activity_log(session)
    # Invalidate stats cache so next read fetches fresh data
    try:
        from core.cache import cache
        cache.invalidate("stats:")
    except Exception:
        pass  # don't fail the write if cache invalidation fails
