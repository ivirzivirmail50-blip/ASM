"""Story Atlas service — unified view of nested locations + pinned characters + travel routes.

v7.6 feature. Combines:
- World entries of type "location" with their parent_id tree
- Character-location pins (CharacterLocationPin model)
- Travel routes (TravelRoute model)
- Optional chapter-scoped filter (show where everyone is "at chapter N")

Produces two main payloads:
- atlas_tree(): nested location tree with pinned character counts
- atlas_pins(): flat list of pins (character_id, location_id, kind, note)
- atlas_routes(): travel routes for the active project (from travel_service)
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import select

from core.db import read_session
from models.char_location_pin import PIN_KINDS, CharacterLocationPin
from models.character import Character
from models.world import WorldEntry
from services import travel_service
from services._common import current_project_id, load_json

log = logging.getLogger("asm.atlas")


def _entry_to_dict(e: WorldEntry, include_children: bool = True) -> dict[str, Any]:
    """Convert a WorldEntry to JSON-serializable dict."""
    return {
        "id": e.id,
        "name": e.name,
        "type": e.type,
        "category": e.category or "",
        "description": (e.description or "")[:200],
        "parent_id": e.parent_id,
        "map_pin_x": e.map_pin_x,
        "map_pin_y": e.map_pin_y,
        "map_pin_label": e.map_pin_label or "",
        "map_pin_color": e.map_pin_color or "#6366f1",
        "has_map_image": bool(e.map_image_path),
        "sort_order": e.sort_order or 0,
    }


def atlas_tree() -> dict[str, Any]:
    """Return nested location tree with pinned character counts per node.

    Returns:
        {
            "roots": [{"id","name","type","category","description","parent_id",
                       "children": [...], "pins": N (total subtree)}, ...],
            "stats": {"total_locations", "max_depth", "pinned_characters",
                      "with_map_image", "roots_count"},
        }
    """
    with read_session() as s:
        pid = current_project_id(s)
        # All location entries for this project
        entries = list(s.scalars(
            select(WorldEntry).where(
                WorldEntry.project_id == pid,
                WorldEntry.type == "location",
            ).order_by(WorldEntry.sort_order, WorldEntry.name)
        ))
        # All pins for this project
        pins = list(s.scalars(
            select(CharacterLocationPin).where(
                CharacterLocationPin.project_id == pid,
            )
        ))
        # Count pins per location
        pin_count: dict[str, int] = {}
        for p in pins:
            pin_count[p.location_id] = pin_count.get(p.location_id, 0) + 1
        # Characters map (name/role/color for tooltip)
        chars = list(s.scalars(
            select(Character).where(Character.project_id == pid)
        ))
        char_map = {c.id: {"id": c.id, "name": c.name, "role": c.role or "",
                           "color": c.avatar_color or "#6366f1"} for c in chars}

    # Build children index
    by_id: dict[str, dict[str, Any]] = {}
    children_index: dict[str | None, list[str]] = {}
    for e in entries:
        d = _entry_to_dict(e)
        d["pins"] = pin_count.get(e.id, 0)
        d["children"] = []
        d["depth"] = 0
        by_id[e.id] = d
        children_index.setdefault(e.parent_id, []).append(e.id)

    # Recursive subtree build with depth assignment
    def _build_subtree(parent_id: str | None, depth: int) -> list[dict[str, Any]]:
        out = []
        for cid in children_index.get(parent_id, []):
            node = by_id[cid]
            node["depth"] = depth
            sub = _build_subtree(cid, depth + 1)
            node["children"] = sub
            # Compute subtree pin total
            subtree_pins = node["pins"]
            for ch in sub:
                subtree_pins += ch.get("_subtree_pins", 0)
            node["_subtree_pins"] = subtree_pins
            out.append(node)
        return out

    roots = _build_subtree(None, 0)
    # Strip internal _subtree_pins from output (keep clean)
    def _strip(nodes: list[dict[str, Any]]) -> None:
        for n in nodes:
            n["subtree_pins"] = n.pop("_subtree_pins", 0)
            _strip(n["children"])
    _strip(roots)

    # Compute stats
    max_depth = 0
    def _walk_depth(nodes: list[dict[str, Any]], d: int) -> None:
        nonlocal max_depth
        max_depth = max(max_depth, d)
        for n in nodes:
            _walk_depth(n["children"], d + 1)
    _walk_depth(roots, 0)

    return {
        "roots": roots,
        "stats": {
            "total_locations": len(entries),
            "max_depth": max_depth,
            "pinned_characters": len({p.character_id for p in pins}),
            "total_pins": len(pins),
            "with_map_image": sum(1 for e in entries if e.map_image_path),
            "roots_count": len(roots),
        },
        "pin_kinds": [{"value": k, "label": v["label"], "color": v["color"]}
                       for k, v in PIN_KINDS.items()],
    }


def atlas_pins() -> dict[str, Any]:
    """Return flat list of all character-location pins for the active project."""
    with read_session() as s:
        pid = current_project_id(s)
        pins = list(s.scalars(
            select(CharacterLocationPin).where(
                CharacterLocationPin.project_id == pid,
            ).order_by(CharacterLocationPin.sort_order, CharacterLocationPin.created_at)
        ))
        char_ids = {p.character_id for p in pins}
        loc_ids = {p.location_id for p in pins}
        chars = list(s.scalars(
            select(Character).where(Character.id.in_(list(char_ids)))
        )) if char_ids else []
        locs = list(s.scalars(
            select(WorldEntry).where(WorldEntry.id.in_(list(loc_ids)))
        )) if loc_ids else []
    char_map = {c.id: {"id": c.id, "name": c.name, "role": c.role or "",
                       "color": c.avatar_color or "#6366f1"} for c in chars}
    loc_map = {l.id: {"id": l.id, "name": l.name} for l in locs}
    return {
        "pins": [
            {
                "id": p.id,
                "character_id": p.character_id,
                "location_id": p.location_id,
                "kind": p.kind,
                "note": p.note or "",
                "chapter_id": p.chapter_id,
                "character": char_map.get(p.character_id, {"name": "Unknown"}),
                "location": loc_map.get(p.location_id, {"name": "Unknown"}),
                "kind_label": PIN_KINDS.get(p.kind, {"label": p.kind})["label"],
                "kind_color": PIN_KINDS.get(p.kind, {"color": "#6366f1"})["color"],
            }
            for p in pins
        ],
        "pin_kinds": [{"value": k, "label": v["label"], "color": v["color"]}
                       for k, v in PIN_KINDS.items()],
    }


def atlas_routes() -> dict[str, Any]:
    """Return travel routes for the active project (delegates to travel_service)."""
    routes = travel_service.get_routes_json()
    return {"routes": routes}


def atlas_full() -> dict[str, Any]:
    """Combined payload for the atlas page."""
    return {
        "tree": atlas_tree(),
        "pins": atlas_pins(),
        "routes": atlas_routes(),
    }


# ---------------------------------------------------------------------------
# CRUD for character-location pins
# ---------------------------------------------------------------------------

def create_pin(*, character_id: str, location_id: str,
               kind: str = "current_residence",
               note: str = "", chapter_id: str | None = None) -> dict[str, Any]:
    """Pin a character to a location."""
    from core.errors import ValidationError
    if not character_id or not location_id:
        raise ValidationError("character_id and location_id are required", code="invalid_pin")
    if kind not in PIN_KINDS:
        raise ValidationError(f"Unknown pin kind: {kind}", code="invalid_pin_kind")
    import uuid

    from core.db import write_transaction
    with write_transaction() as s:
        pid = current_project_id(s)
        pin = CharacterLocationPin(
            id=str(uuid.uuid4()),
            project_id=pid,
            character_id=character_id,
            location_id=location_id,
            kind=kind,
            note=note or None,
            chapter_id=chapter_id or None,
        )
        s.add(pin)
        s.flush()
        return {"id": pin.id, "ok": True}


def delete_pin(pin_id: str) -> dict[str, Any]:
    """Remove a character-location pin."""
    from core.db import write_transaction
    with write_transaction() as s:
        pin = s.get(CharacterLocationPin, pin_id)
        if not pin:
            return {"ok": False, "error": "not_found"}
        s.delete(pin)
    return {"ok": True, "id": pin_id}


def list_candidate_characters() -> list[dict[str, Any]]:
    """Return all characters for the active project (for the pin picker)."""
    with read_session() as s:
        pid = current_project_id(s)
        chars = list(s.scalars(
            select(Character).where(Character.project_id == pid)
            .order_by(Character.name)
        ))
    return [{"id": c.id, "name": c.name, "role": c.role or "",
             "color": c.avatar_color or "#6366f1"} for c in chars]


def list_candidate_locations() -> list[dict[str, Any]]:
    """Return all location world entries for the active project."""
    with read_session() as s:
        pid = current_project_id(s)
        locs = list(s.scalars(
            select(WorldEntry).where(
                WorldEntry.project_id == pid,
                WorldEntry.type == "location",
            ).order_by(WorldEntry.name)
        ))
    return [{"id": l.id, "name": l.name, "category": l.category or "",
             "parent_id": l.parent_id} for l in locs]
