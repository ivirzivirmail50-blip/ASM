"""Publishing Preflight — the quality gate before your book ships (v8.7).

Runs a battery of local, deterministic checks over the ACTIVE book and
returns a score (0-100), a letter grade, and an issue list with
chapter-level jump links. Nothing here calls the AI; it is pure text
analysis so it works offline and instantly.

Check families
--------------
status      chapters not yet marked final (draft / revised)
empty       chapters with no content at all
short       chapters under a sensible publishable floor
markers     leftover editorial placeholders (TODO, FIXME, XXX, TK, [placeholder], ???)
quotes      unbalanced double quotes in a chapter (dialogue risk)
emphasis    odd number of * / _ emphasis markers (markdown risk)
untitled    chapters with no title when numbering is off
long_paras  paragraphs too long for comfortable e-reader rendering
progress    word-count vs. the book's target
"""
from __future__ import annotations

import logging
import re
from typing import Any

from sqlalchemy import select

from core.db import read_session
from models.chapter import Chapter
from models.project import Project
from models.settings import Setting
from services._common import current_project_id

log = logging.getLogger("asm.preflight")

# Weight per severity: score = 100 - sum(weights), floored at 0.
_SEVERITY_WEIGHT = {"error": 12, "warn": 5, "info": 1}

_SHORT_CHAPTER_WORDS = 150      # below this a chapter feels skeletal
_LONG_PARA_WORDS = 600          # wall-of-text threshold on e-readers

_MARKER_PATTERNS = [
    re.compile(r"\bTODO\b"),
    re.compile(r"\bFIXME\b"),
    re.compile(r"\bXXX\b"),
    re.compile(r"\bTK\b(?![a-zçğıöşü])"),          # editorial placeholder, not Turkish "tk"
    re.compile(r"\[\s*placeholder\s*\]", re.I),
    re.compile(r"\[\s*note?s?\s*:.*?\]", re.I),  # [note: ...] / [not: ...]
    re.compile(r"\?{3,}"),
]


def _count_words(text: str) -> int:
    return len((text or "").split())


def preflight_report() -> dict[str, Any]:
    """Analyze the active book and return the preflight report."""
    with read_session() as s:
        pid = current_project_id(s)
        proj = s.get(Project, pid)
        book_title = (proj.name if proj and proj.name else
                      Setting.get(s, "story_title", "My Story"))
        target_words = (proj.target_words if proj and proj.target_words else 0)
        chapters = list(
            s.scalars(select(Chapter).where(Chapter.project_id == pid)
                      .order_by(Chapter.sort_order.asc()))
        )

    issues: list[dict[str, Any]] = []

    def add(severity: str, category: str, message: str,
            chapter: Chapter | None = None):
        issues.append({
            "severity": severity,
            "category": category,
            "message": message,
            "chapter_id": chapter.id if chapter else None,
            "chapter_title": chapter.title if chapter else None,
            "chapter_no": (chapters.index(chapter) + 1) if chapter in chapters else None,
        })

    if not chapters:
        add("error", "empty_book",
            "This book has no chapters to publish yet — write or import first.")
        return _finalize(issues, book_title, 0, 0, target_words)

    status_counts: dict[str, int] = {}
    total_words = 0

    for idx, ch in enumerate(chapters, start=1):
        content = ch.content or ""
        words = _count_words(content)
        total_words += words
        status = (ch.status or "draft").lower()
        status_counts[status] = status_counts.get(status, 0) + 1

        if status != "final":
            add("warn", "status",
                "Chapter %d (%s) is still marked “%s” — final chapters only in a "
                "publication build." % (idx, ch.title or "untitled", status),
                ch)

        if words == 0:
            add("error", "empty",
                "Chapter %d (%s) is completely empty." % (idx, ch.title or "untitled"),
                ch)
        elif words < _SHORT_CHAPTER_WORDS:
            add("warn", "short",
                "Chapter %d (%s) is very short: %d words." %
                (idx, ch.title or "untitled", words), ch)

        if content:
            for pat in _MARKER_PATTERNS:
                hits = pat.findall(content)
                if hits:
                    preview = pat.pattern
                    add("error", "markers",
                        "Chapter %d (%s) contains %d leftover placeholder marker(s) "
                        "matching %s — strip them before publishing." %
                        (idx, ch.title or "untitled", len(hits), preview), ch)
                    break  # one marker issue per chapter is enough signal

            if content.count('"') % 2 == 1:
                add("info", "quotes",
                    "Chapter %d (%s) has an odd number of double quotes — a stray "
                    "opening or closing quote may have escaped." %
                    (idx, ch.title or "untitled"), ch)

            stars = content.count("*")
            if stars % 2 == 1:
                add("info", "emphasis",
                    "Chapter %d (%s) has an odd number of asterisks — unbalanced "
                    "markdown emphasis?" % (idx, ch.title or "untitled"), ch)

            if not (ch.title or "").strip():
                add("info", "untitled",
                    "Chapter %d has no title (it will render as just a number)."
                    % idx, ch)

            for para in content.split("\n\n"):
                pwords = _count_words(para)
                if pwords > _LONG_PARA_WORDS:
                    add("info", "long_paras",
                        "Chapter %d (%s) has a %d-word paragraph — consider "
                        "splitting it for e-reader comfort." %
                        (idx, ch.title or "untitled", pwords), ch)
                    break  # flag once per chapter

    # Book-level progress note
    if target_words:
        pct = round(100.0 * total_words / max(target_words, 1), 1)
        if total_words < target_words:
            add("info", "progress",
                "Manuscript is at %s / %s words (%.1f%% of target)." %
                (f"{total_words:,}", f"{target_words:,}", pct))
        else:
            add("info", "progress",
                "Manuscript reached the target: %s / %s words (%.1f%%)." %
                (f"{total_words:,}", f"{target_words:,}", pct))

    return _finalize(issues, book_title, total_words, len(chapters), target_words)


def _finalize(issues: list[dict[str, Any]], title: str, total_words: int,
              chapter_count: int, target_words: int) -> dict[str, Any]:
    penalty = sum(_SEVERITY_WEIGHT.get(i["severity"], 0) for i in issues)
    score = max(0, 100 - penalty)
    grade = ("A" if score >= 95 else
             "B" if score >= 80 else
             "C" if score >= 60 else
             "D" if score >= 40 else "F")
    counts = {"error": 0, "warn": 0, "info": 0}
    for i in issues:
        counts[i["severity"]] += 1
    ready = counts["error"] == 0 and counts["warn"] == 0
    return {
        "ok": True,
        "book_title": title,
        "score": score,
        "grade": grade,
        "ready": ready,
        "issue_counts": counts,
        "issue_count": len(issues),
        "issues": issues,
        "total_words": total_words,
        "chapter_count": chapter_count,
        "target_words": target_words,
    }
