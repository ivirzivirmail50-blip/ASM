"""Series Bible service (v9.0) — cross-book continuity for multi-book workspaces.

v7.0 gave ASM a multi-book workspace, but every book remained an island:
the same character re-created by hand in book 2, no way to say "this is
the SAME person", no continuity check across books, no series-level
export. This service is the explicit bridge:

  series_overview()      → all books + per-book counts + series totals
  series_cast()          → every character across every book, grouped by
                           Turkish-aware normalized name → "series cast"
  series_world()         → same grouping for world entries (type + name)
  continuity_report()    → drift detection across books:
                           role drift, attribute conflicts (eye/hair),
                           divergent world descriptions, unlinked
                           same-name entities (link suggestions)
  link_entity()/unlink() → the explicit "appears in another book" bridge
  export_series_bible()  → MD / JSON / PDF / DOCX whole-series document
  ai_series_synopsis()   → optional AI back-cover blurb for the series

Isolation contract: normal service-layer queries stay project-scoped.
Everything in THIS module deliberately reads across books, but only ever
behind the Series Hub surface (/series/*) — the same whitelisted-door
approach the Insights cross-book dashboard has used since v7.6.
"""
from __future__ import annotations

import difflib
import io
import json
import logging
import re
from typing import Any

from sqlalchemy import select

from core.db import read_session, write_transaction
from core.errors import AiDisabledError, ConflictError, NotFoundError, ValidationError
from models.chapter import Chapter
from models.character import Character
from models.project import Project
from models.series import SeriesLink
from models.world import WorldEntry
from services._common import new_uuid

log = logging.getLogger("asm.series")

# --- Normalization (same rules as the Context Engine) ----------------------

_TR_LOWER_MAP = str.maketrans("İI", "iı")


def _norm(text: str) -> str:
    """Lowercase for matching, Turkish dotted/dotless I aware."""
    if not text:
        return ""
    return text.translate(_TR_LOWER_MAP).casefold().strip()


# --- Attribute extraction (bilingual: EN + TR, shared spirit with Story Lint)

_ATTR_PATTERNS = {
    # English: "green eyes", "black hair"
    "eye": r"\b(blue|green|brown|hazel|gray|grey|amber|violet|black|gold)\s+eyes?\b",
    "hair": r"\b(black|brown|blonde|red|white|gray|grey|silver|auburn)\s+hair\b",
    # Turkish: "yeşil gözlü", "mavi göz", "siyah saçlı", "kızıl saç"
    "eye_tr": r"\b(mavi|yeşil|kahverengi|ela|gri|siyah|mor|altın|amber)\s+göz(?:lü|ler|ü)?\b",
    "hair_tr": r"\b(siyah|kahverengi|sarı|kızıl|beyaz|gri|gümüş|kumral)\s+saç(?:lı|lar|ı)?\b",
}
# Canonical attr name for each pattern key ("eye_tr" reports as "eye")
_ATTR_CANON = {"eye": "eye", "hair": "hair",
               "eye_tr": "eye", "hair_tr": "hair"}

# Turkish color word → canonical English, so "mavi gözlü" and "blue eyes"
# compare equal in continuity checks (never a false conflict).
_COLOR_CANON = {
    "mavi": "blue", "yeşil": "green", "kahverengi": "brown",
    "ela": "hazel", "gri": "gray", "siyah": "black", "mor": "violet",
    "altın": "gold", "amber": "amber",
    "sarı": "blonde", "kızıl": "auburn", "beyaz": "white",
    "gümüş": "silver", "kumral": "auburn",
}


def _extract_attrs(text: str | None) -> dict[str, str]:
    """Pull stated eye/hair colors out of a physical description (EN or TR)."""
    out: dict[str, str] = {}
    if not text:
        return out
    lowered = _norm(text)
    for key, pat in _ATTR_PATTERNS.items():
        m = re.search(pat, lowered)
        if m:
            val = m.group(1)
            out[_ATTR_CANON[key]] = _COLOR_CANON.get(val, val)
    return out


# --- Books ------------------------------------------------------------------

def _books_map(s) -> dict[str, dict[str, Any]]:
    """id → {id, name, color, genre, is_active} for every book."""
    from services._common import current_project_id
    active = current_project_id(s)
    out: dict[str, dict[str, Any]] = {}
    for p in s.scalars(select(Project).order_by(Project.created_at.asc())).all():
        out[p.id] = {
            "id": p.id, "name": p.name, "color": p.color,
            "genre": p.genre, "is_active": p.id == active,
        }
    return out


def series_overview() -> dict[str, Any]:
    """Every book with per-book counts + series totals.

    Reads ACROSS books on purpose (Series Hub surface).
    """
    with read_session() as s:
        books = _books_map(s)
        chars = list(s.scalars(select(Character)).all())
        worlds = list(s.scalars(select(WorldEntry)).all())
        word_rows = s.execute(
            select(Chapter.project_id, Chapter.word_count)
        ).all()

    words_by_book: dict[str, int] = {}
    for pid, wc in word_rows:
        words_by_book[pid] = words_by_book.get(pid, 0) + int(wc or 0)

    for bid, book in books.items():
        book["characters"] = sum(1 for c in chars if c.project_id == bid)
        book["world_entries"] = sum(1 for w in worlds if w.project_id == bid)
        book["words"] = words_by_book.get(bid, 0)

    book_list = sorted(books.values(), key=lambda b: (not b["is_active"],
                                                      b["name"].casefold()))
    return {
        "books": book_list,
        "totals": {
            "books": len(book_list),
            "characters": len(chars),
            "world_entries": len(worlds),
            "words": sum(words_by_book.values()),
        },
    }


# --- Series cast / shared world ----------------------------------------------

def _all_links(s) -> list[SeriesLink]:
    return list(s.scalars(select(SeriesLink)).all())


def _attach_links(groups: list[dict], links: list[SeriesLink],
                    books: dict[str, dict], entity_type: str) -> None:
    """Attach outgoing series links to group entities (in place).

    A link means "this entity also appears in that book" — even when the
    target book has no local copy. Links therefore count toward the
    group's books_count so the Series Hub shows the full series reach.
    """
    for l in links:
        if l.entity_type != entity_type:
            continue
        for g in groups:
            for e in g["entities"]:
                if e["id"] != l.entity_id:
                    continue
                tgt = books.get(l.target_project_id, {})
                e.setdefault("links", []).append({
                    "book_id": l.target_project_id,
                    "book_name": tgt.get("name", l.target_project_id),
                    "book_color": tgt.get("color") or "#6366f1",
                    "note": l.note or "",
                })
                g["linked"] = True


def _finalize_groups(groups: list[dict]) -> tuple[list[dict], list[dict]]:
    """Compute books_count (home books + link targets) and order groups."""
    for g in groups:
        for e in g["entities"]:
            e["links"] = e.get("links", [])
        g["entities"].sort(key=lambda e: e["book_name"].casefold())
        seen: set[str] = set()
        for e in g["entities"]:
            seen.add(e["book_id"])
            seen.update(l["book_id"] for l in e["links"])
        g["books_count"] = len(seen)
    ordered = sorted(groups, key=lambda g: (-g["books_count"],
                                            g["display"].casefold()))
    shared = [g for g in ordered if g["books_count"] > 1]
    return ordered, shared


def series_cast() -> dict[str, Any]:
    """Characters of EVERY book grouped by normalized name.

    A group with 2+ entities means the same name lives in several books —
    either an explicit series link exists (intentional) or it is a
    candidate for the continuity checker to flag.
    """
    with read_session() as s:
        books = _books_map(s)
        chars = list(s.scalars(select(Character).order_by(
            Character.name.asc())).all())
        links = _all_links(s)

    groups: dict[str, dict[str, Any]] = {}
    for c in chars:
        key = _norm(c.name)
        g = groups.setdefault(key, {
            "key": key, "display": c.name, "entities": [], "linked": False,
        })
        book = books.get(c.project_id, {})
        g["entities"].append({
            "id": c.id, "name": c.name, "role": c.role or "",
            "age": c.age or "", "gender": c.gender or "",
            "book_id": c.project_id,
            "book_name": book.get("name", c.project_id),
            "book_color": book.get("color") or "#6366f1",
            "physical_attrs": _extract_attrs(c.physical),
        })
        if g["display"] != c.name and len(c.name) > len(g["display"]):
            g["display"] = c.name  # prefer the longest spelling as display

    _attach_links(list(groups.values()), links, books, "character")
    ordered, shared = _finalize_groups(list(groups.values()))
    return {
        "groups": ordered,
        "shared": shared,
        "shared_count": len(shared),
        "total": len(ordered),
    }


def series_world() -> dict[str, Any]:
    """World entries of EVERY book grouped by (type, normalized name)."""
    with read_session() as s:
        books = _books_map(s)
        entries = list(s.scalars(select(WorldEntry).order_by(
            WorldEntry.name.asc())).all())
        links = _all_links(s)

    groups: dict[tuple[str, str], dict[str, Any]] = {}
    for e in entries:
        key = (e.type, _norm(e.name))
        g = groups.setdefault(key, {
            "key": f"{e.type}/{_norm(e.name)}", "type": e.type,
            "display": e.name, "entities": [], "linked": False,
        })
        book = books.get(e.project_id, {})
        g["entities"].append({
            "id": e.id, "name": e.name, "type": e.type,
            "category": e.category or "",
            "description": (e.description or "").strip(),
            "book_id": e.project_id,
            "book_name": book.get("name", e.project_id),
            "book_color": book.get("color") or "#6366f1",
        })

    _attach_links(list(groups.values()), links, books, "world")
    ordered, shared = _finalize_groups(list(groups.values()))
    ordered.sort(key=lambda g: (g["type"], -g["books_count"],
                                g["display"].casefold()))
    shared.sort(key=lambda g: (g["type"], g["display"].casefold()))
    return {
        "groups": ordered,
        "shared": shared,
        "shared_count": len(shared),
        "total": len(ordered),
    }


# --- Continuity report --------------------------------------------------------

_ROLES = ("protagonist", "antagonist", "supporting", "minor")


def _description_similarity(a: str, b: str) -> float:
    """0..1 ratio between two descriptions (empty texts never conflict)."""
    if not a and not b:
        return 1.0
    return difflib.SequenceMatcher(None, a[:2000], b[:2000]).ratio()


def continuity_report() -> dict[str, Any]:
    """Cross-book drift detection — the Series Doctor.

    Findings (each with severity, human message, per-book evidence):
      role_drift          warn  same-name character, different roles
      attribute_conflict  warn  same-name character, conflicting eye/hair
      description_drift   info  same-name world entry, divergent text
      unlinked_same_name  info  same-name entities, no explicit link
    """
    findings: list[dict[str, Any]] = []

    cast = series_cast()
    for g in cast["shared"]:
        name = g["display"]

        # role drift
        roles = {e["role"] for e in g["entities"] if e["role"]}
        if len(roles) > 1:
            findings.append({
                "severity": "warn", "kind": "role_drift",
                "message": (f"{name} has different roles across books "
                            f"({', '.join(sorted(roles))}) — intentional "
                            f"character development or a mistake?"),
                "books": [e["book_name"] for e in g["entities"]],
                "urls": [f"/characters/{e['id']}" for e in g["entities"]],
            })

        # attribute conflicts
        by_attr: dict[str, set[str]] = {}
        for e in g["entities"]:
            for attr, val in e["physical_attrs"].items():
                by_attr.setdefault(attr, set()).add(val)
        for attr, vals in sorted(by_attr.items()):
            if len(vals) > 1:
                findings.append({
                    "severity": "warn", "kind": "attribute_conflict",
                    "message": (f"{name}'s {attr} color differs between books: "
                                f"{', '.join(sorted(vals))}"),
                    "books": [e["book_name"] for e in g["entities"]],
                    "urls": [f"/characters/{e['id']}" for e in g["entities"]],
                })

        # unlinked same-name → suggest a series link
        if not g["linked"]:
            findings.append({
                "severity": "info", "kind": "unlinked_same_name",
                "message": (f"{name} appears in {g['books_count']} books but "
                            f"is not series-linked — link the versions so "
                            f"the Series Bible treats them as one person."),
                "books": [e["book_name"] for e in g["entities"]],
                "urls": [f"/characters/{e['id']}" for e in g["entities"]],
                "entity_ids": [e["id"] for e in g["entities"]],
                "entity_type": "character",
            })

    world = series_world()
    for g in world["shared"]:
        # divergent descriptions for the same named place/thing
        descs = [e["description"] for e in g["entities"]]
        for i in range(len(descs)):
            for j in range(i + 1, len(descs)):
                ratio = _description_similarity(descs[i], descs[j])
                if ratio < 0.55:
                    findings.append({
                        "severity": "info", "kind": "description_drift",
                        "message": (f"{g['display']} ({g['type']}) is described "
                                    f"very differently between books "
                                    f"({int(ratio * 100)}% similar) — world "
                                    f"facts may have drifted."),
                        "books": [g["entities"][i]["book_name"],
                                  g["entities"][j]["book_name"]],
                        "urls": [f"/world/{g['entities'][i]['id']}",
                                 f"/world/{g['entities'][j]['id']}"],
                    })
                    break  # one drift finding per group is enough
        if not g["linked"]:
            findings.append({
                "severity": "info", "kind": "unlinked_same_name",
                "message": (f"{g['display']} ({g['type']}) exists in "
                            f"{g['books_count']} books without a series link."),
                "books": [e["book_name"] for e in g["entities"]],
                "urls": [f"/world/{e['id']}" for e in g["entities"]],
                "entity_ids": [e["id"] for e in g["entities"]],
                "entity_type": "world",
            })

    severity_rank = {"warn": 0, "info": 1}
    findings.sort(key=lambda f: (severity_rank.get(f["severity"], 9),
                                 f["message"].casefold()))
    return {
        "findings": findings,
        "counts": {
            "warn": sum(1 for f in findings if f["severity"] == "warn"),
            "info": sum(1 for f in findings if f["severity"] == "info"),
            "total": len(findings),
        },
    }


# --- Link CRUD ----------------------------------------------------------------

def link_entity(entity_type: str, entity_id: str, target_project_id: str,
                note: str = "") -> dict[str, Any]:
    """Declare that an entity also appears in another book."""
    if entity_type not in ("character", "world"):
        raise ValidationError("entity_type must be 'character' or 'world'")
    if not target_project_id:
        raise ValidationError("Target book is required")

    with write_transaction() as s:
        if entity_type == "character":
            ent = s.get(Character, entity_id)
        else:
            ent = s.get(WorldEntry, entity_id)
        if ent is None:
            raise NotFoundError("Entity not found")
        source_pid = ent.project_id
        if target_project_id == source_pid:
            raise ValidationError("Entity already belongs to that book")

        target = s.get(Project, target_project_id)
        if target is None:
            raise NotFoundError("Target book not found")

        dup = s.scalars(select(SeriesLink).where(
            SeriesLink.entity_id == entity_id,
            SeriesLink.target_project_id == target_project_id)).first()
        if dup is not None:
            raise ConflictError("Already linked to that book")

        link = SeriesLink(
            id=f"sl-{new_uuid()}", entity_type=entity_type,
            entity_id=entity_id, source_project_id=source_pid,
            target_project_id=target_project_id, note=(note or "").strip() or None)
        s.add(link)

    return _link_dict(link)


def _link_dict(l: SeriesLink) -> dict[str, Any]:
    return {
        "id": l.id, "entity_type": l.entity_type, "entity_id": l.entity_id,
        "source_project_id": l.source_project_id,
        "target_project_id": l.target_project_id,
        "note": l.note or "",
    }


def unlink(link_id: str) -> dict[str, Any]:
    with write_transaction() as s:
        link = s.get(SeriesLink, link_id)
        if link is None:
            raise NotFoundError("Link not found")
        payload = _link_dict(link)
        s.delete(link)
    return payload


def links_for_entity(entity_type: str, entity_id: str) -> list[dict[str, Any]]:
    """Outgoing links for one entity (used by detail pages)."""
    with read_session() as s:
        books = _books_map(s)
        rows = list(s.scalars(select(SeriesLink).where(
            SeriesLink.entity_type == entity_type,
            SeriesLink.entity_id == entity_id)
            .order_by(SeriesLink.created_at.asc())).all())
        out = []
        for l in rows:
            d = _link_dict(l)
            book = books.get(l.target_project_id)
            d["target_book_name"] = book["name"] if book else l.target_project_id
            d["target_book_color"] = (book["color"] if book else None) or "#6366f1"
            out.append(d)
        return out


def link_target_books(entity_type: str, entity_id: str) -> list[dict[str, Any]]:
    """Books the entity could still be linked into (≠ home, not yet linked)."""
    with read_session() as s:
        books = _books_map(s)
        if entity_type == "character":
            ent = s.get(Character, entity_id)
        else:
            ent = s.get(WorldEntry, entity_id)
        if ent is None:
            raise NotFoundError("Entity not found")
        existing = {l.target_project_id for l in _all_links(s)
                    if l.entity_id == entity_id}
        return [b for b in books.values()
                if b["id"] != ent.project_id and b["id"] not in existing]


def series_links_all() -> list[dict[str, Any]]:
    """Every link with book names — for the Series Hub link manager."""
    with read_session() as s:
        books = _books_map(s)
        links = _all_links(s)
        names: dict[str, str] = {}
        for l in links:
            if l.entity_type == "character":
                c = s.get(Character, l.entity_id)
                names[l.id] = c.name if c else "(deleted character)"
            else:
                w = s.get(WorldEntry, l.entity_id)
                names[l.id] = w.name if w else "(deleted entry)"
        out = []
        for l in links:
            d = _link_dict(l)
            d["entity_name"] = names.get(l.id, "?")
            src = books.get(l.source_project_id)
            tgt = books.get(l.target_project_id)
            d["source_book_name"] = src["name"] if src else l.source_project_id
            d["target_book_name"] = tgt["name"] if tgt else l.target_project_id
            out.append(d)
        out.sort(key=lambda d: (d["entity_type"], d["entity_name"].casefold()))
        return out


# --- Series Bible export --------------------------------------------------------

_SERIES_FORMATS = ("md", "json", "pdf", "docx")


def _series_title() -> str:
    with read_session() as s:
        n = len(list(s.scalars(select(Project.id)).all()))
    return f"Series Bible — {n} book{'s' if n != 1 else ''}"


def export_series_bible(fmt: str) -> tuple[bytes, str, str]:
    """The whole series in one document: books, cast, shared world,
    continuity findings. Formats: md / json / pdf / docx."""
    fmt = fmt.lower()
    if fmt not in _SERIES_FORMATS:
        raise NotFoundError(f"Unknown format: {fmt}")

    overview = series_overview()
    cast = series_cast()
    world = series_world()
    report = continuity_report()

    if fmt == "json":
        payload = {
            "kind": "asm-series-bible",
            "version": 1,
            "title": _series_title(),
            "overview": overview,
            "cast": cast,
            "world": world,
            "continuity": report,
        }
        return (json.dumps(payload, ensure_ascii=False, indent=2)
                .encode("utf-8"), "application/json", "series_bible.json")

    if fmt == "md":
        md: list[str] = [f"# {_series_title()}\n"]
        md.append("\n## Books\n")
        md.append("| Book | Genre | Words | Characters | World entries |")
        md.append("|---|---|---|---|---|")
        for b in overview["books"]:
            md.append(f"| {b['name']} | {b['genre'] or '—'} | {b['words']:,} | "
                      f"{b['characters']} | {b['world_entries']} |")
        md.append(f"\n**Series totals:** {overview['totals']['words']:,} words · "
                  f"{overview['totals']['characters']} characters · "
                  f"{overview['totals']['world_entries']} world entries\n")

        md.append("\n## Series Cast\n")
        for g in cast["groups"]:
            chips = " · ".join(
                f"{e['book_name']}" + (f" ({e['role']})" if e["role"] else "")
                for e in g["entities"])
            badge = " ✦ linked" if g["linked"] else ""
            md.append(f"- **{g['display']}**{badge} — {chips}\n")

        md.append("\n## Shared World\n")
        for g in world["groups"]:
            chips = " · ".join(e["book_name"] for e in g["entities"])
            md.append(f"- **{g['display']}** ({g['type'].replace('_', ' ')}) — {chips}\n")

        md.append("\n## Continuity Findings\n")
        if report["findings"]:
            for f in report["findings"]:
                icon = "⚠️" if f["severity"] == "warn" else "ℹ️"
                md.append(f"- {icon} {f['message']}\n")
        else:
            md.append("- No continuity issues detected across books.\n")
        return "".join(md).encode("utf-8"), "text/markdown", "series_bible.md"

    if fmt == "pdf":
        return (_series_pdf(overview, cast, world, report),
                "application/pdf", "series_bible.pdf")

    return (_series_docx(overview, cast, world, report),
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "series_bible.docx")


def _series_pdf(overview, cast, world, report) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    from services import pdf_fonts

    def _esc(t) -> str:
        return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter,
                            leftMargin=0.9 * inch, rightMargin=0.9 * inch,
                            topMargin=0.9 * inch, bottomMargin=0.9 * inch)
    styles = getSampleStyleSheet()
    pdf_fonts.apply_to_stylesheet(styles)
    title_style = ParagraphStyle("SbTitle", parent=styles["Title"],
                                 alignment=TA_CENTER, fontSize=24, spaceAfter=6)
    sub = ParagraphStyle("SbSub", parent=styles["Normal"], alignment=TA_CENTER,
                         fontSize=11, spaceAfter=24, textColor=colors.grey)
    h2 = ParagraphStyle("SbH2", parent=styles["Heading2"], fontSize=15,
                        spaceBefore=14, spaceAfter=4,
                        textColor=colors.HexColor("#6366f1"))
    body = ParagraphStyle("SbBody", parent=styles["BodyText"], fontSize=10,
                          leading=14, spaceAfter=6)
    warn = ParagraphStyle("SbWarn", parent=styles["BodyText"], fontSize=10,
                          leading=14, spaceAfter=6,
                          textColor=colors.HexColor("#b45309"))

    t = overview["totals"]
    story = [
        Paragraph(_esc(_series_title()), title_style),
        Paragraph(f"{t['books']} books · {t['words']:,} words · "
                  f"{t['characters']} characters · {t['world_entries']} world entries",
                  sub),
    ]

    story.append(Paragraph("Books", h2))
    for b in overview["books"]:
        story.append(Paragraph(
            f"<b>{_esc(b['name'])}</b>"
            + (f" · {_esc(b['genre'])}" if b["genre"] else "")
            + f" — {b['words']:,} words · {b['characters']} characters · "
              f"{b['world_entries']} world entries", body))

    story.append(Paragraph("Series Cast", h2))
    for g in cast["groups"]:
        chips = " · ".join(
            _esc(e["book_name"]) + (f" ({_esc(e['role'])})" if e["role"] else "")
            for e in g["entities"])
        star = " ✦" if g["linked"] else ""
        story.append(Paragraph(f"<b>{_esc(g['display'])}</b>{star} — {chips}", body))

    story.append(Paragraph("Shared World", h2))
    for g in world["groups"]:
        chips = " · ".join(_esc(e["book_name"]) for e in g["entities"])
        story.append(Paragraph(
            f"<b>{_esc(g['display'])}</b> "
            f"({_esc(g['type'].replace('_', ' '))}) — {chips}", body))

    story.append(Paragraph("Continuity Findings", h2))
    if report["findings"]:
        for f in report["findings"]:
            icon = "⚠" if f["severity"] == "warn" else "ℹ"
            story.append(Paragraph(f"{icon} {_esc(f['message'])}",
                                   warn if f["severity"] == "warn" else body))
    else:
        story.append(Paragraph("No continuity issues detected across books.", body))

    doc.build(story)
    return buf.getvalue()


def _series_docx(overview, cast, world, report) -> bytes:
    from docx import Document

    doc = Document()
    h = doc.add_heading(_series_title(), 0)
    h.alignment = 1
    t = overview["totals"]
    doc.add_paragraph(
        f"{t['books']} books · {t['words']:,} words · "
        f"{t['characters']} characters · {t['world_entries']} world entries")

    doc.add_heading("Books", level=1)
    for b in overview["books"]:
        genre = f" · {b['genre']}" if b["genre"] else ""
        doc.add_paragraph(
            f"{b['name']}{genre} — {b['words']:,} words · "
            f"{b['characters']} characters · {b['world_entries']} world entries")

    doc.add_heading("Series Cast", level=1)
    for g in cast["groups"]:
        chips = " · ".join(
            e["book_name"] + (f" ({e['role']})" if e["role"] else "")
            for e in g["entities"])
        doc.add_paragraph(f"{g['display']}{' ✦' if g['linked'] else ''} — {chips}")

    doc.add_heading("Shared World", level=1)
    for g in world["groups"]:
        chips = " · ".join(e["book_name"] for e in g["entities"])
        doc.add_paragraph(f"{g['display']} ({g['type'].replace('_', ' ')}) — {chips}")

    doc.add_heading("Continuity Findings", level=1)
    if report["findings"]:
        for f in report["findings"]:
            doc.add_paragraph(f["message"])
    else:
        doc.add_paragraph("No continuity issues detected across books.")

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# --- AI series synopsis -----------------------------------------------------------

def ai_series_synopsis() -> str:
    """AI back-cover blurb for the whole series (optional, guarded).

    Follows the v8.9 Beta Inbox convention: AiDisabledError propagates as
    404 when AI is off; provider hiccups raise AiProviderError (502).
    """
    from services import ai_service

    if not ai_service.is_enabled():
        raise AiDisabledError()

    overview = series_overview()
    books = overview["books"]
    if not books:
        raise ValidationError("Create at least one book first")

    lines = [
        "You are a book-series blurb writer for a novelist.",
        "Below are the books of a series (title, genre, word count,",
        "chapter titles). Write a compelling back-cover style series",
        "synopsis: 3-5 sentences, no headings, no markdown, plain text.",
        "",
    ]
    for b in books:
        lines.append(f"BOOK: {b['name']} ({b['genre'] or 'unspecified genre'}, "
                     f"{b['words']:,} words)")
        with read_session() as s:
            titles = list(s.scalars(select(Chapter.title).where(
                Chapter.project_id == b["id"])
                .order_by(Chapter.sort_order.asc()).limit(25)))
        if titles:
            lines.append("CHAPTERS: " + "; ".join(titles))
        lines.append("")

    prompt = "\n".join(lines)
    return ai_service.generate(prompt, max_tokens=600, task="series_synopsis")
