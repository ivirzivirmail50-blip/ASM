"""Backup service: ZIP-based auto-backup + restore.

v9.3.0 (F-09 — Yedek 2.0):
  * Optional AES-256 ZIP encryption (``backup_password`` setting; pyzipper)
  * Copy the finished archive to an external target dir
    (``backup_target_dir`` — mounted folder / SMB share)
  * Incremental media capture (``backup_incremental``): unchanged media
    files are skipped via data/backup_manifest.json — the DB and raw/
    uploads are ALWAYS captured. Incremental archives are suffixed
    ``_incr`` and chain onto the latest full backup (restore that first).
"""
from __future__ import annotations

import json
import logging
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from config import Config

log = logging.getLogger("asm.backup")

try:  # F-09: AES-256 (WinZip AES) — restore tolerates its absence for
    # plain archives; encryption requires it.
    import pyzipper  # type: ignore
except ImportError:  # pragma: no cover - env-dependent
    pyzipper = None

_MEDIA_MANIFEST = Config.DATA_DIR / "backup_manifest.json"


def _resolve_db_path() -> Path:
    """Resolve the ACTUAL database file path from the live SQLAlchemy engine.

    Falls back to Config.DB_PATH. This keeps backups correct even when the DB
    location is overridden via ASM_DB_URI (v6.0 bugfix — previously the backup
    would silently zip the wrong/nonexistent file).
    """
    try:
        from core.db import engine
        url = str(engine.url)
        if url.startswith("sqlite:///"):
            p = url[len("sqlite:///"):]
            if p and p != ":memory:":
                return Path(p)
    except Exception:
        pass
    return Config.DB_PATH


def media_backup_enabled() -> bool:
    """S-03: read the ``backup_include_media`` setting (default: True)."""
    from core.db import read_session
    from models.settings import Setting
    try:
        with read_session() as s:
            return bool(Setting.get(s, "backup_include_media", True))
    except Exception:
        return True


def _setting(key: str, default: str = "") -> str:
    from core.db import read_session
    from models.settings import Setting
    try:
        with read_session() as s:
            v = Setting.get(s, key, default)
            return str(v) if v is not None else default
    except Exception:
        return default


def backup_password() -> str:
    """F-09: optional archive password ('' = no encryption)."""
    return _setting("backup_password", "").strip()


def backup_target_dir() -> Path | None:
    """F-09: optional external copy target (folder/SMB mount)."""
    raw = _setting("backup_target_dir", "").strip()
    if not raw:
        return None
    return Path(raw)


def backup_incremental_enabled() -> bool:
    """F-09: incremental media capture (default: off = full)."""
    return _setting("backup_incremental", "false").strip().lower() in (
        "1", "true", "on", "yes")


def _load_media_state() -> dict[str, dict]:
    """Manifest: {relative media path: {size, mtime}} captured so far."""
    try:
        return json.loads(_MEDIA_MANIFEST.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_media_state(state: dict[str, dict]) -> None:
    try:
        _MEDIA_MANIFEST.parent.mkdir(parents=True, exist_ok=True)
        _MEDIA_MANIFEST.write_text(
            json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        log.warning("Could not persist backup media manifest.", exc_info=True)


def _iter_media_files():
    """Yield ``(path, arcname)`` for every file under data/media/."""
    if not Config.MEDIA_DIR.exists():
        return
    for f in sorted(Config.MEDIA_DIR.rglob("*")):
        if f.is_file():
            yield f, str(f.relative_to(Config.DATA_DIR)).replace("\\", "/")


def create_backup() -> Path:
    """Create a timestamped ZIP of the SQLite DB + data/raw + data/media.

    v8.4 correctness fix: in WAL mode, recently committed transactions can
    still live in the -wal file. Zipping only the main DB file produced
    silently STALE backups. We now checkpoint (TRUNCATE) the WAL into the
    main file first — the zip is then guaranteed complete, and the WAL
    file shrinks as a bonus.

    v9.0.1 (S-03): media files (maps, avatars, music, ...) are included by
    default — previously the needle was recovered from the DB but every
    picture was lost. A ``media_manifest.txt`` member records exactly what
    was captured. Disable via the ``backup_include_media`` setting.

    v9.3.0 (F-09): optional AES-256 encryption (``backup_password``),
    external-target copy (``backup_target_dir``) and incremental media
    capture (``backup_incremental``). Returns the created archive path.
    """
    # Flush WAL → main DB file so the zip contains every committed write.
    try:
        from sqlalchemy import text

        from core.db import engine
        with engine.connect().execution_options(
                isolation_level="AUTOCOMMIT") as conn:
            conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
    except Exception:
        log.warning("WAL checkpoint before backup failed (continuing)",
                    exc_info=True)

    pwd = backup_password()
    if pwd and pyzipper is None:  # pragma: no cover - pyzipper normally present
        from core.errors import ValidationError
        raise ValidationError(
            "Encrypted backups require the 'pyzipper' package "
            "(pip install pyzipper) or clearing the backup password.")

    incremental = backup_incremental_enabled()
    prev_state = _load_media_state() if incremental else {}
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    suffix = "_incr" if (incremental and prev_state) else ""
    backup_path = Config.BACKUP_DIR / f"asm_backup_{ts}{suffix}.zip"

    open_cls = (lambda p, m: pyzipper.AESZipFile(
        p, m, compression=pyzipper.ZIP_DEFLATED,
        encryption=pyzipper.WZ_AES)) if pwd else (lambda p, m: zipfile.ZipFile(
        p, m, zipfile.ZIP_DEFLATED))
    with open_cls(backup_path, "w") as zf:
        if pwd:
            zf.setpassword(pwd.encode("utf-8"))
        db_path = _resolve_db_path()
        if db_path.exists():
            zf.write(db_path, arcname="asm.db")
        # Include raw uploads
        if Config.RAW_DIR.exists():
            for f in Config.RAW_DIR.rglob("*"):
                if f.is_file():
                    zf.write(f, arcname=str(f.relative_to(Config.DATA_DIR)))
        # S-03 — include media uploads (maps, avatars, music) with a manifest.
        # F-09 — incremental mode skips media whose (size, mtime) is already
        # captured in the manifest chain.
        media_manifest: list[str] = []
        new_state: dict[str, dict] = {}
        if media_backup_enabled():
            for f, arc in _iter_media_files():
                try:
                    st = f.stat()
                    # ns → ms: saniye çözünürlüğü aynı-saniye yeniden
                    # yazımları "değişmedi" sanıyordu (test'te yakalandı)
                    state = {"size": st.st_size,
                             "mtime": st.st_mtime_ns // 1_000_000}
                except OSError:
                    continue
                new_state[arc] = state
                if incremental and prev_state.get(arc) == state:
                    continue  # unchanged since last capture
                zf.write(f, arcname=arc)
                media_manifest.append(arc)
        if media_manifest:
            zf.writestr("media_manifest.txt",
                        "\n".join(sorted(media_manifest)) + "\n")
    # Manifest = full snapshot of current media state (skipped files too) —
    # a later change (size/mtime) re-includes the file.
    if media_backup_enabled() and new_state:
        _save_media_state(new_state)

    copied_to: str | None = None
    target = backup_target_dir()
    if target is not None:
        try:
            target.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup_path, target / backup_path.name)
            copied_to = str(target / backup_path.name)
            log.info("Backup copied to external target: %s", copied_to)
        except OSError:
            log.warning("External backup target unreachable: %s", target,
                        exc_info=True)

    log.info("Backup created: %s (media files: %d, encrypted: %s, "
             "incremental: %s)",
             backup_path, len(media_manifest), bool(pwd), incremental)
    _publish_event("backup.created", {
        "path": str(backup_path), "size": backup_path.stat().st_size,
        "media_included": len(media_manifest), "encrypted": bool(pwd),
        "incremental": incremental, "copied_to": copied_to,
    })
    # v9.3.0 (F-12): yedek sonrası eklenti kancası.
    try:
        from core import hooks

        hooks.fire("after_backup", {
            "path": str(backup_path), "encrypted": bool(pwd),
            "incremental": incremental, "copied_to": copied_to,
        })
    except Exception:  # noqa: BLE001
        pass
    # v8.4 — retention: keep only the newest N backups.
    _apply_backup_retention()
    return backup_path


def _publish_event(name: str, payload: dict) -> None:
    """F-04: backup events ride the central SSE bus (best-effort)."""
    try:
        from core.events import bus

        bus.publish({"event": name, **payload})
    except Exception:  # noqa: BLE001 - event publishing is never critical
        pass


def _apply_backup_retention() -> int:
    """Delete oldest backups beyond backup_retention_count. Returns deleted."""
    from core.db import read_session
    from models.settings import Setting
    try:
        with read_session() as s:
            keep = int(Setting.get(s, "backup_retention_count", "14") or 14)
    except (TypeError, ValueError):
        keep = 14
    if not keep or keep < 0:
        return 0
    backups = list_backups()  # newest first
    deleted = 0
    for b in backups[keep:]:
        try:
            Path(b["path"]).unlink()
            deleted += 1
        except OSError:
            continue
    if deleted:
        log.info("Backup retention: removed %d old backup(s)", deleted)
    return deleted


def list_backups() -> list[dict]:
    backups = []
    for f in sorted(Config.BACKUP_DIR.glob("asm_backup_*.zip"),
                    key=lambda p: p.stat().st_mtime, reverse=True):
        st = f.stat()
        backups.append({
            "name": f.name,
            "path": str(f),
            "size": st.st_size,
            "mtime": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
        })
    return backups


def restore_backup(backup_path: str, password: str | None = None) -> None:
    """Restore DB + raw files from a ZIP backup. App must be restarted after.

    v9.3.0 (F-09): supports AES-encrypted archives (pyzipper) — pass the
    password, or set it beforehand via the backup_password setting.
    """
    p = Path(backup_path)
    if not p.exists():
        raise FileNotFoundError(p)
    pwd = (password or backup_password() or "").strip()
    open_cls = pyzipper.AESZipFile if pyzipper is not None else zipfile.ZipFile
    with open_cls(p, "r") as zf:
        if pwd:
            zf.setpassword(pwd.encode("utf-8"))
        # Extract DB
        for member in zf.namelist():
            if member == "asm.db":
                db_path = _resolve_db_path()
                db_path.parent.mkdir(parents=True, exist_ok=True)
                # Backup current DB before overwriting
                if db_path.exists():
                    bak = db_path.with_suffix(f".bak.{int(datetime.now().timestamp())}")
                    db_path.rename(bak)
                with zf.open(member) as src, open(db_path, "wb") as dst:
                    dst.write(src.read())
            elif member.startswith(("raw/", "media/")):
                # v9.0.1 (S-03): media/ members are restored exactly like
                # raw/ uploads — with the same path-traversal guard.
                target = (Config.DATA_DIR / member).resolve()
                if not str(target).startswith(str(Config.DATA_DIR.resolve())):
                    log.warning("Skipping path traversal: %s", member)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as dst:
                    dst.write(src.read())
    log.info("Restored from backup: %s", p)


def maybe_auto_backup() -> bool:
    """Check if auto-backup is due; create one if so. Returns True if backed up."""
    from core.db import read_session
    from models.settings import Setting
    with read_session() as s:
        enabled = Setting.get(s, "auto_backup_enabled", True)
        if not enabled:
            return False
        interval_hours = int(Setting.get(s, "auto_backup_interval_hours", 6) or 6)
    # Find most recent backup
    backups = list_backups()
    if not backups:
        create_backup()
        return True
    last_mtime = datetime.fromisoformat(backups[0]["mtime"].replace("Z", "+00:00"))
    elapsed = datetime.now(timezone.utc) - last_mtime
    if elapsed.total_seconds() >= interval_hours * 3600:
        # v8.4 — skip if the DB hasn't changed since the last backup.
        # Zipping a 200 MB unchanged file every 6 hours was pure disk churn.
        db_path = _resolve_db_path()
        try:
            db_mtime = datetime.fromtimestamp(
                db_path.stat().st_mtime, timezone.utc)
        except OSError:
            db_mtime = None
        if db_mtime and db_mtime <= last_mtime:
            return False
        create_backup()
        return True
    return False
