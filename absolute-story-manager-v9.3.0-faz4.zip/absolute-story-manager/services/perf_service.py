"""Performance Lab service (v8.8).

The measured answer to "does my database size hurt performance, and where
is the threshold?" — three pillars:

  1. benchmark()      → times a suite of REAL application queries
                        (dashboard list, editor open, save-path version
                        lookup, FTS search, world/character listing, full
                        scans, write latency) with warm-cache medians,
                        verdicts vs thresholds, a 0-100 score + letter
                        grade, and a delta trend against the previous run
                        (stored in settings, survives restarts).
  2. report()         → health diagnostics WITHOUT running benchmarks:
                        page/free-page fragmentation (real VACUUM
                        reclaim estimate), index coverage checklist
                        (old databases miss indexes create_all won't
                        backfill), EXPLAIN QUERY PLAN scan detection on
                        big tables, FTS5 row parity (external-content
                        index can silently desync when triggers missed
                        writes), runtime pragma snapshot, WAL size.
  3. actions          → rebuild_fts() restores parity from source tables,
                        add_missing_indexes() backfills the checklist,
                        integrity_check() runs PRAGMA quick_check, and
                        run_auto_maintenance_if_due() runs PRAGMA
                        optimize + WAL checkpoint on boot at most every
                        N days (setting: auto_maintenance_days, 0 = off).

Thresholds (local SQLite, warm page cache):
  lookup-class queries : fast ≤ 5 ms · ok ≤ 25 ms · slow ≤ 150 ms
  scan-class  queries  : fast ≤ 50 ms · ok ≤ 250 ms · slow ≤ 1000 ms
Beyond that the number is shown as critical. Reads in SQLite scale with
index coverage, not file size — a 500 MB file still answers indexed
lookups in microseconds; the costs that DO grow with size are full scans,
FTS rebuilds, VACUUM and backup time, which is exactly what this lab
measures so the verdict is empirical, not a guess.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any

from sqlalchemy import text

import core.db as _db
from core.db import read_session, write_transaction
from models.settings import Setting
from services import storage_service
from services._common import now_utc


def _engine():
    """Resolve the CURRENT core.db engine (tests re-patch it per test —
    an import-time binding would freeze the first test's engine)."""
    return _db.engine

log = logging.getLogger("asm.perf")

# --- Benchmark thresholds -------------------------------------------------
# (fast, ok, slow) in milliseconds, by query class. Above "slow" → critical.
_THRESHOLDS: dict[str, tuple[float, float, float]] = {
    "lookup": (5.0, 25.0, 150.0),
    "scan": (50.0, 250.0, 1000.0),
    "write": (5.0, 20.0, 100.0),
}

_BENCH_RUNS = 5  # per query, warm-cache median reported
_WRITE_OPS = 25  # inserts inside one temp-table transaction


def _verdict(ms: float, cls: str) -> str:
    fast, ok, slow = _THRESHOLDS[cls]
    if ms <= fast:
        return "fast"
    if ms <= ok:
        return "ok"
    if ms <= slow:
        return "slow"
    return "critical"


def _median(values: list[float]) -> float:
    ordered = sorted(values)
    n = len(ordered)
    if not n:
        return 0.0
    mid = n // 2
    if n % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2.0


def _time_ms(stmt: str, params: dict | None = None,
             runs: int = _BENCH_RUNS) -> float:
    """Warm-cache median wall time of one SQL statement, in ms."""
    with _engine().connect() as conn:
        # Warm-up run (loads pages into cache) — not counted.
        conn.execute(text(stmt), params or {})
        samples: list[float] = []
        for _ in range(runs):
            t0 = time.perf_counter()
            conn.execute(text(stmt), params or {}).all()
            samples.append((time.perf_counter() - t0) * 1000.0)
        conn.rollback()  # reads only; release the autobegin txn cleanly
    return round(_median(samples), 3)


def _sample_word() -> str | None:
    """A real 5+ letter word from the biggest chapter, for FTS/LIKE tests."""
    try:
        with read_session() as s:
            content = s.execute(text(
                "SELECT content FROM chapters "
                "WHERE content IS NOT NULL AND LENGTH(content) > 200 "
                "ORDER BY LENGTH(content) DESC LIMIT 1"
            )).scalar()
        if not content:
            return None
        for tok in content.replace("\n", " ").split(" "):
            tok = tok.strip(".,!?;:\"'()[]—-")
            if len(tok) >= 5 and tok.isalpha():
                return tok
    except Exception:
        pass
    return None


def _count(table: str) -> int:
    try:
        with read_session() as s:
            return int(s.execute(text(
                f"SELECT COUNT(*) FROM {table}"  # noqa: S608
            )).scalar() or 0)
    except Exception:
        return 0


# --- Benchmark suite -------------------------------------------------------
def _benchmark_definitions() -> list[dict[str, Any]]:
    """Build the suite, adapting to what data exists."""
    defs: list[dict[str, Any]] = []

    defs.append({
        "name": "chapter_list", "label": "Chapter list (dashboard)",
        "class": "lookup",
        "sql": ("SELECT id, title, status, word_count, sort_order, "
                "updated_at FROM chapters WHERE project_id='default' "
                "ORDER BY sort_order"),
    })
    defs.append({
        "name": "chapter_read", "label": "Open largest chapter (editor)",
        "class": "lookup",
        "sql": ("SELECT content FROM chapters "
                "ORDER BY LENGTH(content) DESC LIMIT 1"),
    })
    defs.append({
        "name": "version_latest", "label": "Latest version lookup (save path)",
        "class": "lookup",
        "sql": ("SELECT version_number, LENGTH(content) FROM "
                "chapter_versions WHERE chapter_id = "
                "(SELECT chapter_id FROM chapter_versions "
                "GROUP BY chapter_id ORDER BY COUNT(*) DESC LIMIT 1) "
                "ORDER BY version_number DESC LIMIT 1"),
    })
    defs.append({
        "name": "world_by_type", "label": "World entries by type (library)",
        "class": "lookup",
        "sql": ("SELECT id, name, type, sort_order FROM world_entries "
                "WHERE project_id='default' AND type='location' "
                "ORDER BY sort_order"),
    })
    defs.append({
        "name": "characters_list", "label": "Character list (cast page)",
        "class": "lookup",
        "sql": ("SELECT id, name, role, age FROM characters "
                "WHERE project_id='default' ORDER BY name"),
    })
    defs.append({
        "name": "activity_recent", "label": "Recent activity feed",
        "class": "lookup",
        "sql": ("SELECT entity_type, action, timestamp FROM activity_log "
                "ORDER BY timestamp DESC LIMIT 20"),
    })
    defs.append({
        "name": "text_total", "label": "Total manuscript scan (stats)",
        "class": "scan",
        "sql": "SELECT COUNT(*), COALESCE(SUM(LENGTH(content)),0) FROM chapters",
    })

    word = _sample_word()
    if word:
        defs.append({
            "name": "fts_search", "label": f"FTS5 search “{word}”",
            "class": "lookup",
            "sql": ("SELECT rowid FROM chapters_fts "
                    "WHERE chapters_fts MATCH :q LIMIT 50"),
            "params": {"q": word},
        })
        defs.append({
            "name": "like_search", "label": f"LIKE search “{word}” (fallback)",
            "class": "scan",
            "sql": ("SELECT id FROM chapters WHERE content LIKE :pat "
                    "LIMIT 20"),
            "params": {"pat": f"%{word}%"},
        })
    else:
        defs.append({
            "name": "fts_search", "label": "FTS5 search (no chapters yet)",
            "class": "lookup", "skipped": True,
            "note": "Write a chapter first — FTS needs text to search.",
        })
    return defs


def _bench_write() -> dict[str, Any]:
    """Write latency: N inserts into a per-connection TEMP table.

    The scratch table is dropped before the connection returns to the
    pool (pysqlite runs DDL outside transaction control, so rollback
    alone would leak the table onto the pooled connection).
    """
    try:
        with _engine().connect() as conn:
            conn.execute(text(
                "CREATE TEMP TABLE _perf_scratch "
                "(id INTEGER PRIMARY KEY, val TEXT)"
            ))
            conn.execute(text("DELETE FROM _perf_scratch"))
            samples: list[float] = []
            for i in range(_WRITE_OPS):
                t0 = time.perf_counter()
                conn.execute(text(
                    "INSERT INTO _perf_scratch(val) VALUES (:v)"
                ), {"v": f"probe-{i}-" + "x" * 64})
                samples.append((time.perf_counter() - t0) * 1000.0)
            # Undo the probe inserts first; then drop the temp table OUTSIDE
            # any transaction (a DDL inside the pending txn would be rolled
            # back with it, re-leaking the table onto the pooled connection).
            conn.rollback()
            conn.execute(text("DROP TABLE IF EXISTS _perf_scratch"))
        ms = round(_median(samples), 3)
        return {
            "name": "write_txn", "label": "Write latency (WAL commit path)",
            "class": "write", "ms": ms, "runs": len(samples),
            "verdict": _verdict(ms, "write"),
            "context": f"{len(samples)} inserts, median",
        }
    except Exception as exc:
        return {"name": "write_txn",
                "label": "Write latency (WAL commit path)",
                "class": "write", "ms": None, "verdict": "skipped",
                "note": f"Write probe unavailable: {exc}"}


def benchmark() -> dict[str, Any]:
    """Run the full benchmark suite. Stores the compact result in settings
    so the next run can show a trend delta. Returns the full payload."""
    entries: list[dict[str, Any]] = []
    for d in _benchmark_definitions():
        if d.get("skipped"):
            entries.append({"name": d["name"], "label": d["label"],
                            "class": d["class"], "ms": None,
                            "verdict": "skipped", "note": d.get("note")})
            continue
        try:
            ms = _time_ms(d["sql"], d.get("params"))
            entries.append({
                "name": d["name"], "label": d["label"], "class": d["class"],
                "ms": ms, "runs": _BENCH_RUNS,
                "verdict": _verdict(ms, d["class"]),
            })
        except Exception as exc:
            entries.append({"name": d["name"], "label": d["label"],
                            "class": d["class"], "ms": None,
                            "verdict": "skipped",
                            "note": f"Query failed: {exc}"})
    entries.append(_bench_write())

    # Context: sizes these numbers were measured against.
    db_mb = storage_service.db_stats()["db"]["mb"]
    context = {
        "db_mb": db_mb,
        "chapters": _count("chapters"),
        "chapter_versions": _count("chapter_versions"),
        "world_entries": _count("world_entries"),
        "characters": _count("characters"),
    }

    # Delta trend vs the stored previous run.
    prev = _load_stored_benchmark()
    for e in entries:
        if e.get("ms") is not None and prev:
            old = prev.get("entries", {}).get(e["name"])
            if isinstance(old, (int, float)):
                e["delta_ms"] = round(e["ms"] - float(old), 3)
                e["trend"] = ("same" if abs(e["delta_ms"]) < 1.0
                              else ("worse" if e["delta_ms"] > 0 else "better"))

    payload = {
        "ran_at": now_utc().isoformat(),
        "entries": entries,
        "context": context,
        "score": _score(entries),
    }
    _store_benchmark(payload)
    return payload


def _score(entries: list[dict[str, Any]]) -> dict[str, Any]:
    """0-100 score + letter grade from verdicts."""
    penalty = {"fast": 0, "ok": 5, "slow": 15, "critical": 35}
    measured = [e for e in entries if e.get("verdict") in penalty]
    score = 100 - sum(penalty[e["verdict"]] for e in measured) if measured else 100
    score = max(0, min(100, score))
    grade = ("A" if score >= 90 else "B" if score >= 75 else
             "C" if score >= 60 else "D" if score >= 40 else "F")
    counts: dict[str, int] = {}
    for e in measured:
        counts[e["verdict"]] = counts.get(e["verdict"], 0) + 1
    return {"score": score, "grade": grade, "counts": counts,
            "measured": len(measured)}


def _store_benchmark(payload: dict[str, Any]) -> None:
    compact = {
        "ran_at": payload["ran_at"],
        "score": payload["score"]["score"],
        "grade": payload["score"]["grade"],
        "db_mb": payload["context"]["db_mb"],
        "entries": {e["name"]: e["ms"] for e in payload["entries"]
                    if e.get("ms") is not None},
    }
    try:
        with write_transaction() as s:
            Setting.set(s, "perf_last_benchmark", compact)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("Could not store benchmark: %s", exc)


def _load_stored_benchmark() -> dict[str, Any] | None:
    try:
        with read_session() as s:
            return Setting.get(s, "perf_last_benchmark", None)
    except Exception:
        return None


def last_benchmark_view() -> dict[str, Any] | None:
    """Stored benchmark merged with current labels (for template render)."""
    stored = _load_stored_benchmark()
    if not stored:
        return None
    labels = {d["name"]: d["label"] for d in _benchmark_definitions()}
    entries = []
    for name, ms in (stored.get("entries") or {}).items():
        entries.append({
            "name": name, "label": labels.get(name, name),
            "ms": ms, "verdict": _verdict(float(ms), "lookup"),
            "class": "lookup",
        })
    return {
        "ran_at": stored.get("ran_at"),
        "score": stored.get("score"),
        "grade": stored.get("grade"),
        "db_mb": stored.get("db_mb"),
        "entries": entries,
    }


# --- Health diagnostics ----------------------------------------------------
def _pragma_scalar(conn, name: str) -> Any:
    return conn.execute(text(f"PRAGMA {name}")).scalar()


def _page_health(conn) -> dict[str, Any]:
    page_size = int(_pragma_scalar(conn, "page_size") or 4096)
    page_count = int(_pragma_scalar(conn, "page_count") or 0)
    freelist = int(_pragma_scalar(conn, "freelist_count") or 0)
    total_bytes = page_size * page_count
    free_bytes = page_size * freelist
    pct = round(100.0 * freelist / page_count, 1) if page_count else 0.0
    if pct >= 15 or (free_bytes > 50 * 1024 * 1024 and pct >= 5):
        verdict, advice = "warn", (f"VACUUM would reclaim ~"
                                   f"{round(free_bytes / 1048576.0, 1)} MB "
                                   "of free pages inside the file.")
    elif pct >= 5:
        verdict, advice = "info", (f"~{round(free_bytes / 1048576.0, 1)} MB "
                                   "in free pages — small, VACUUM optional.")
    else:
        verdict, advice = "ok", "File is compact — no free-page bloat."
    return {
        "page_size": page_size, "page_count": page_count,
        "freelist_count": freelist,
        "total_mb": round(total_bytes / 1048576.0, 2),
        "free_mb": round(free_bytes / 1048576.0, 2),
        "fragmentation_pct": pct, "verdict": verdict, "advice": advice,
    }


# Index coverage: (index_name, table, required leading columns, why it matters)
_INDEX_CHECKLIST: tuple[tuple[str, str, tuple[str, ...], str], ...] = (
    ("ix_chapter_versions_ch_vnum", "chapter_versions",
     ("chapter_id", "version_number"),
     "Latest-version lookup runs on every chapter save"),
    ("ix_chapters_project", "chapters", ("project_id",),
     "Chapter list filters by project on every dashboard load"),
    ("ix_world_project", "world_entries", ("project_id",),
     "World Library listing"),
    ("ix_world_type", "world_entries", ("type",),
     "World Library type tabs + filtered exports"),
    ("ix_scenes_chapter", "scene_cards", ("chapter_id",),
     "Scene cards are grouped per chapter"),
    ("ix_chat_messages_session_created", "chat_messages",
     ("session_id", "created_at"),
     "Chat history load (ordered per session)"),
    ("ix_activity_created", "activity_log", ("timestamp",),
     "Recent activity feed ordering"),
)


def _index_coverage(conn) -> dict[str, Any]:
    """Which checklist indexes exist? Old databases migrated by ALTER TABLE
    never get indexes that create_all only applies to fresh databases."""
    rows: list[dict[str, Any]] = []
    missing: list[dict[str, Any]] = []
    for name, table, cols, why in _INDEX_CHECKLIST:
        exists = conn.execute(text(
            "SELECT 1 FROM sqlite_master WHERE type='index' AND name=:n"
        ), {"n": name}).scalar()
        # Also accept any index whose leading columns cover the requirement.
        if not exists:
            try:
                covered = _prefix_covered(conn, table, cols)
            except Exception:
                covered = False
        else:
            covered = True
        status = "ok" if covered else "missing"
        rows.append({"name": name, "table": table,
                     "columns": list(cols), "why": why, "status": status})
        if not covered:
            missing.append(rows[-1])
    verdict = "ok" if not missing else ("warn" if len(missing) <= 2 else "danger")
    return {"rows": rows, "missing": missing, "verdict": verdict}


def _prefix_covered(conn, table: str, cols: tuple[str, ...]) -> bool:
    """True if any index on `table` starts with the required columns."""
    idx = conn.execute(text(f"PRAGMA index_list({table})")).all()
    for row in idx:
        iname = row[1] if len(row) > 1 else row["name"]
        try:
            info = conn.execute(text(f"PRAGMA index_info({iname})")).all()
        except Exception:
            continue
        leading = [r[2] if len(r) > 2 else r["name"] for r in
                   sorted(info, key=lambda r: r[0])][:len(cols)]
        if tuple(leading) == tuple(cols):
            return True
    return False


def _query_plans(conn) -> dict[str, Any]:
    """EXPLAIN QUERY PLAN for the benchmark lookups — flags full scans on
    tables big enough for a scan to hurt."""
    plans: list[dict[str, Any]] = []
    flags = 0
    for d in _benchmark_definitions():
        if d.get("skipped") or "sql" not in d:
            continue
        try:
            detail_rows = conn.execute(
                text("EXPLAIN QUERY PLAN " + d["sql"]), d.get("params")
            ).all()
            detail = " · ".join(str(r[-1]) for r in detail_rows)
        except Exception as exc:
            plans.append({"query": d["label"], "plan": f"n/a ({exc})",
                          "scan": False, "verdict": "info"})
            continue
        # SQLite says "SCAN <table>" for full scans, "SEARCH ... USING" for
        # index/rowid lookups.
        scanning = "SCAN" in detail and "USING" not in detail
        table = d["sql"].split(" FROM ")[1].split(" ")[0].strip(",(") \
            if " FROM " in d["sql"] else ""
        big = _count(table) > 5000 if table else False
        verdict = ("warn" if scanning and big else
                   "info" if scanning else "ok")
        if scanning and big:
            flags += 1
        plans.append({"query": d["label"], "plan": detail,
                      "scan": scanning, "verdict": verdict})
    verdict = "ok" if flags == 0 else "warn"
    return {"plans": plans, "verdict": verdict, "flagged": flags}


def _fts_health(conn) -> dict[str, Any]:
    """External-content FTS can silently desync when writes bypass the
    sync triggers (bulk imports, old DBs, manual SQL).

    Parity signal: the %_docsize shadow table holds one row per indexed
    document (COUNT(*) on the fts table itself reads the CONTENT table,
    which is always equal — and FTS5's own 'integrity-check' command
    misses this drift on external-content tables, verified empirically).
    """
    rows: list[dict[str, Any]] = []
    any_bad = False
    for src, fts, label in (
        ("chapters", "chapters_fts", "Chapters"),
        ("characters", "characters_fts", "Characters"),
        ("world_entries", "world_fts", "World"),
    ):
        try:
            n_src = int(conn.execute(text(
                f"SELECT COUNT(*) FROM {src}"  # noqa: S608
            )).scalar() or 0)
            n_idx = int(conn.execute(text(
                f"SELECT COUNT(*) FROM {fts}_docsize"  # noqa: S608
            )).scalar() or 0)
        except Exception as exc:
            rows.append({"source": label, "rows": 0, "index": 0,
                         "verdict": "info", "note": f"n/a ({exc})"})
            continue
        parity = n_src == n_idx
        any_bad = any_bad or not parity
        rows.append({
            "source": label, "rows": n_src, "index": n_idx,
            "verdict": "ok" if parity else "warn",
            "note": "" if parity else
            "Index is out of sync — rebuild restores it from source rows.",
        })
    return {"rows": rows,
            "verdict": "warn" if any_bad else "ok"}


def report(deep: bool = False) -> dict[str, Any]:
    """Health diagnostics snapshot (no benchmarks). deep=True also runs
    PRAGMA quick_check, which can take seconds on large libraries."""
    out: dict[str, Any] = {"generated_at": now_utc().isoformat()}
    with _engine().connect() as conn:
        out["pages"] = _page_health(conn)
        out["pragmas"] = {
            "journal_mode": _pragma_scalar(conn, "journal_mode"),
            "synchronous": _pragma_scalar(conn, "synchronous"),
            "foreign_keys": _pragma_scalar(conn, "foreign_keys"),
            "wal_autocheckpoint": _pragma_scalar(conn, "wal_autocheckpoint"),
            "cache_size": _pragma_scalar(conn, "cache_size"),
            "page_size": _pragma_scalar(conn, "page_size"),
            "auto_vacuum": _pragma_scalar(conn, "auto_vacuum"),
        }
        out["index_coverage"] = _index_coverage(conn)
        out["query_plans"] = _query_plans(conn)
        out["fts_health"] = _fts_health(conn)
    out["wal_mb"] = storage_service.db_stats()["wal"]["mb"]

    if deep:
        out["integrity"] = _quick_check()
    else:
        out["integrity"] = None

    # Auto-maintenance status
    out["auto_maintenance"] = auto_maintenance_status()
    return out


def integrity_check() -> dict[str, Any]:
    """Public PRAGMA quick_check wrapper (route-facing)."""
    return _quick_check()


def _quick_check() -> dict[str, Any]:
    try:
        with _engine().connect() as conn:
            rows = conn.execute(text("PRAGMA quick_check")).all()
        lines = [str(r[0]) for r in rows]
        ok = lines and lines[0] == "ok"
        return {
            "ok": ok,
            "result": " · ".join(lines[:5]),
            "verdict": "ok" if ok else "danger",
        }
    except Exception as exc:  # pragma: no cover - defensive
        return {"ok": False, "result": str(exc), "verdict": "danger"}


# --- Actions ---------------------------------------------------------------
def rebuild_fts() -> dict[str, Any]:
    """Rebuild all FTS5 indexes from their source tables. Fixes parity
    drift that happens when triggers miss writes."""
    results: list[dict[str, Any]] = []
    with _engine().connect().execution_options(
            isolation_level="AUTOCOMMIT") as conn:
        for src, fts, label in (
            ("chapters", "chapters_fts", "Chapters"),
            ("characters", "characters_fts", "Characters"),
            ("world_entries", "world_fts", "World"),
        ):
            before = _parity(conn, src, fts)
            t0 = time.perf_counter()
            try:
                conn.execute(text(
                    f"INSERT INTO {fts}({fts}) VALUES('rebuild')"  # noqa: S608
                ))
                elapsed = round((time.perf_counter() - t0) * 1000.0, 1)
                after = _parity(conn, src, fts)
                results.append({
                    "source": label, "before": before, "after": after,
                    "ms": elapsed,
                    "fixed": (not before["parity"]) and after["parity"],
                })
            except Exception as exc:
                results.append({"source": label, "error": str(exc)})
    return {"results": results,
            "message": "FTS5 indexes rebuilt from source tables."}


def _parity(conn, src: str, fts: str) -> dict[str, Any]:
    """Source rows vs actually-indexed rows (docsize shadow table)."""
    try:
        n_src = int(conn.execute(text(
            f"SELECT COUNT(*) FROM {src}"  # noqa: S608
        )).scalar() or 0)
        n_idx = int(conn.execute(text(
            f"SELECT COUNT(*) FROM {fts}_docsize"  # noqa: S608
        )).scalar() or 0)
    except Exception:
        return {"rows": 0, "index": 0, "parity": True}
    return {"rows": n_src, "index": n_idx, "parity": n_src == n_idx}


def add_missing_indexes() -> dict[str, Any]:
    """Backfill every missing checklist index. Returns what was created."""
    created: list[dict[str, Any]] = []
    with _engine().connect().execution_options(
            isolation_level="AUTOCOMMIT") as conn:
        for name, table, cols, why in _INDEX_CHECKLIST:
            exists = conn.execute(text(
                "SELECT 1 FROM sqlite_master WHERE type='index' AND name=:n"
            ), {"n": name}).scalar()
            if exists:
                continue
            try:
                covered = _prefix_covered(conn, table, cols)
            except Exception:
                covered = False
            if covered:
                continue
            col_sql = ", ".join(cols)
            t0 = time.perf_counter()
            conn.execute(text(
                f"CREATE INDEX IF NOT EXISTS {name} "  # noqa: S608
                f"ON {table} ({col_sql})"
            ))
            created.append({
                "name": name, "table": table, "columns": list(cols),
                "ms": round((time.perf_counter() - t0) * 1000.0, 1),
            })
    return {"created": created,
            "message": (f"Created {len(created)} index(es)."
                        if created else
                        "All checklist indexes already present.")}


# --- Auto-maintenance ------------------------------------------------------
_MAINT_KEY = "maintenance_last_run"
_MAINT_DAYS_KEY = "auto_maintenance_days"
_DEFAULT_DAYS = 7


def auto_maintenance_days() -> int:
    try:
        with read_session() as s:
            v = Setting.get(s, _MAINT_DAYS_KEY, _DEFAULT_DAYS)
        return int(v)
    except (TypeError, ValueError):
        return _DEFAULT_DAYS


def auto_maintenance_status() -> dict[str, Any]:
    try:
        with read_session() as s:
            last = Setting.get(s, _MAINT_KEY, None)
            days = Setting.get(s, _MAINT_DAYS_KEY, _DEFAULT_DAYS)
    except Exception:
        last, days = None, _DEFAULT_DAYS
    try:
        days = int(days)
    except (TypeError, ValueError):
        days = _DEFAULT_DAYS
    return {"days": days, "last_run": last,
            "enabled": days > 0}


def set_auto_maintenance_days(days: int) -> int:
    days = max(0, min(365, int(days)))
    with write_transaction() as s:
        Setting.set(s, _MAINT_DAYS_KEY, days)
    return days


def run_auto_maintenance_if_due(force: bool = False) -> dict[str, Any]:
    """On boot: if `auto_maintenance_days` elapsed since the last run,
    execute PRAGMA optimize + a WAL checkpoint. Cheap, logged, and the
    timestamp is stored even when disabled so the UI can show status.

    Runs PRAGMA optimize + wal_checkpoint(TRUNCATE) — the two operations
    SQLite's own docs recommend for long-running apps. VACUUM is NOT run
    automatically (it rewrites the whole file; that stays a manual call
    from the Storage tab).
    """
    status = auto_maintenance_status()
    days = status["days"]
    if days <= 0 and not force:
        return {"ran": False, "reason": "disabled"}

    last = status.get("last_run")
    if last and not force:
        try:
            last_dt = last if isinstance(last, str) else str(last)
            from datetime import datetime, timedelta
            last_when = datetime.fromisoformat(last_dt)
            if now_utc() - last_when < timedelta(days=days):
                return {"ran": False, "reason": "not due yet"}
        except (ValueError, TypeError):
            pass  # unreadable timestamp — run it

    t0 = time.perf_counter()
    actions: list[str] = []
    with _engine().connect().execution_options(
            isolation_level="AUTOCOMMIT") as conn:
        conn.execute(text("PRAGMA optimize"))
        actions.append("PRAGMA optimize")
        row = conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)")).first()
        if row is not None:
            actions.append(f"wal_checkpoint(TRUNCATE) busy={row[0]}")
    elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 1)

    with write_transaction() as s:
        Setting.set(s, _MAINT_KEY, now_utc().isoformat())
    log.info("Auto-maintenance done in %sms: %s", elapsed_ms,
             ", ".join(actions))
    return {"ran": True, "actions": actions, "ms": elapsed_ms,
            "at": now_utc().isoformat()}


def start_boot_maintenance(app_ref=None) -> None:
    """Spawn the background boot thread (never blocks startup)."""
    def _run():
        try:
            run_auto_maintenance_if_due()
        except Exception:  # pragma: no cover - defensive
            log.warning("Boot auto-maintenance failed", exc_info=True)

    threading.Thread(target=_run, name="asm-boot-maintenance",
                     daemon=True).start()


# --- Threshold reference (rendered in the UI) -------------------------------
THRESHOLD_TABLE: list[dict[str, Any]] = [
    {"area": "Indexed lookups (lists, editor, save path)",
     "fast": "< 5 ms", "ok": "< 25 ms", "concern": "> 150 ms",
     "note": "B-tree depth grows with log(rows) — stays flat for years."},
    {"area": "Full scans (manuscript stats, LIKE fallback search)",
     "fast": "< 50 ms", "ok": "< 250 ms", "concern": "> 1 s",
     "note": "Linear in total text. This is where DB size ACTUALLY bites."},
    {"area": "Write latency (WAL, synchronous=NORMAL)",
     "fast": "< 5 ms", "ok": "< 20 ms", "concern": "> 100 ms",
     "note": "Stays flat until disk saturation; WAL is capped at 64 MB."},
    {"area": "FTS5 search", "fast": "< 5 ms", "ok": "< 25 ms",
     "concern": "> 150 ms",
     "note": "Inverted index — size-independent unless it desyncs."},
    {"area": "One-time costs (VACUUM, FTS rebuild, backup)",
     "fast": "seconds", "ok": "tens of seconds", "concern": "minutes",
     "note": "Grow with file size. Run them from this page, not on a deadline."},
]
