"""Universal import service (v8.6) — the mirror of v8.5 Universal Export.

WHY THIS EXISTS
---------------
v8.5 made every collection exportable (characters, world entries by type,
scene cards, glossary, references) and every single entity exportable as a
5-format sheet — but the only *import* path was the full-project JSON in
Settings. Dropping a ``locations.json`` or a species sheet into the old
Import Center kept just the filename and the raw text: hierarchy, relations,
metadata and map pins were silently lost, and a characters *collection*
export (``{"collection": "characters", ...}``) was not understood at all.

This service closes the loop: **every JSON v8.5 can write, v8.6 reads back.**

Flow:  detect_payload() → preview_import() → execute_import()

Conflict strategies
-------------------
* ``skip``      — entities that already exist (matched by natural key) are
                  left untouched. Default, safest.
* ``overwrite`` — existing entities are updated with the non-empty fields
                  from the file (a version snapshot is kept for world
                  entries, mirroring manual edits).
* ``duplicate`` — always create fresh copies, even when the name exists.

Identity / natural keys
-----------------------
characters  → name (case-insensitive)
world       → (type, name) case-insensitive
scenes      → title + resolved chapter (case-insensitive)
glossary    → term (case-insensitive)
references  → (title, author) case-insensitive

Imported rows ALWAYS get fresh ids — a re-import can never collide with
existing primary keys, and internal references (world parent/child,
relations) are remapped through an old→new id table.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from sqlalchemy import func, select

from core.db import read_session, write_transaction
from core.errors import ValidationError
from models.character import Character
from models.glossary import GlossaryEntry
from models.reference import Reference
from models.scene import SceneCard
from models.world import WorldEntry
from services._common import (
    current_project_id,
    dump_json,
    load_json,
    log_activity,
    new_uuid,
    now_utc,
)

log = logging.getLogger("asm.import_service")

STRATEGIES = ("skip", "overwrite", "duplicate")

KIND_LABELS = {
    "characters": "Characters",
    "world": "World Entries",
    "scenes": "Scene Cards",
    "glossary": "Glossary",
    "references": "References",
    "full_project": "Full Project",
}



# ---------------------------------------------------------------- detection

def detect_payload(data: Any) -> str:
    """Classify a parsed JSON payload into one import kind.

    Returns one of: characters / world / scenes / glossary / references /
    full_project / unknown.
    """
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                return _detect_item(item)
        return "unknown"
    if not isinstance(data, dict):
        return "unknown"

    # --- full project transfer (asm-v4 … asm-v7.5) ---
    version = data.get("version")
    if isinstance(version, str) and version.lower().startswith("asm-") \
            and any(k in data for k in ("tables", "projects", "chapters", "characters")):
        return "full_project"

    # --- collection envelopes written by v8.5 export ---
    coll = data.get("collection")
    if isinstance(coll, str) and coll:
        if coll == "characters" or "characters" in data:
            return "characters"
        if coll == "scenes" or "scenes" in data:
            return "scenes"
        if coll == "references" or "references" in data:
            return "references"
        if coll == "glossary":
            return "glossary"
        # any other type string is a world type (location, species, ...)
        return "world"

    # --- bare arrays under a well-known key ---
    if isinstance(data.get("characters"), list):
        return "characters"
    if isinstance(data.get("scenes"), list):
        return "scenes"
    if isinstance(data.get("references"), list):
        return "references"
    if isinstance(data.get("entries"), list):
        entries = data["entries"]
        if entries and isinstance(entries[0], dict) and "term" in entries[0]:
            return "glossary"
        return "world"

    return _detect_item(data)


def _detect_item(item: dict) -> str:
    """Classify a single entity dict (or the first item of a bare list)."""
    if not isinstance(item, dict):
        return "unknown"
    if "version" in item and "collection" not in item:
        return "unknown"  # not an entity shape
    # single world entry — v8.5 sheet shape
    if item.get("name") and item.get("type") and any(
            k in item for k in ("parent_chain", "relations_out", "map_pin",
                                "metadata", "content", "category")):
        return "world"
    # single character sheet
    if item.get("name") and any(k in item for k in ("role", "psychology", "physical",
                                                    "background", "philosophy")):
        return "characters"
    # glossary term
    if item.get("term"):
        return "glossary"
    # reference
    if item.get("title") and any(k in item for k in ("author", "source_type", "isbn_or_doi")):
        return "references"
    # scene card
    if item.get("title") and any(k in item for k in ("pov", "mood", "time_of_day", "word_count")):
        return "scenes"
    return "unknown"


def _entities_of(data: Any, kind: str) -> list[dict]:
    """Pull the entity list out of any supported payload shape."""
    if isinstance(data, list):
        return [d for d in data if isinstance(d, dict)]
    if not isinstance(data, dict):
        return []
    for key in {"characters": ("characters",), "scenes": ("scenes",),
                "references": ("references",), "glossary": ("entries",),
                "world": ("entries",)}.get(kind, ()):
        val = data.get(key)
        if isinstance(val, list):
            return [d for d in val if isinstance(d, dict)]
    if kind == "full_project":
        return []
    # single-entity payload (a character sheet / world entry sheet)
    if data.get("name") or data.get("term") or data.get("title"):
        return [data]
    return []


# ---------------------------------------------------------------- preview

def preview_import(data: Any, *, strategy: str = "skip") -> dict:
    """Dry-run: what would happen if this payload were imported now?

    No database writes. Each row gets a stable index the UI echoes back on
    execute (via ``exclude``) so per-entity checkboxes survive.
    """
    kind = detect_payload(data)
    if kind == "unknown":
        raise ValidationError(
            "Could not recognise this file. Expected a v8.5+ JSON export "
            "(character sheet, world entry, or a characters / world / scenes / "
            "glossary / references collection) or a full project JSON.")
    if kind == "full_project":
        return _preview_full_project(data)

    entities = _entities_of(data, kind)
    rows: list[dict] = []
    with read_session() as s:
        pid = current_project_id(s)
        for idx, ent in enumerate(entities):
            key, existing_id, detail, note = _match_existing(s, pid, kind, ent)
            status = "new" if existing_id is None else _status_for(strategy)
            rows.append({
                "index": idx, "name": _display_name(kind, ent), "detail": detail,
                "status": status, "note": note or "",
            })
    n_new = sum(1 for r in rows if r["status"] in ("new", "copy"))
    n_exist = len(rows) - n_new
    return {
        "kind": kind,
        "kind_label": KIND_LABELS[kind],
        "count": len(rows),
        "summary": {"new": n_new, "existing": n_exist},
        "rows": rows,
    }


def _status_for(strategy: str) -> str:
    return {"skip": "skip", "overwrite": "update", "duplicate": "copy"}[strategy]


def _display_name(kind: str, ent: dict) -> str:
    return str(ent.get("name") or ent.get("term") or ent.get("title") or "(unnamed)")


def _detail_of(kind: str, ent: dict) -> str:
    if kind == "world":
        bits = [str(ent.get("type") or "?").replace("_", " ")]
        if ent.get("category"):
            bits.append(str(ent["category"]))
        return " · ".join(bits)
    if kind == "characters":
        return str(ent.get("role") or "supporting")
    if kind == "scenes":
        return str(ent.get("chapter") or "standalone")
    if kind == "glossary":
        return str(ent.get("category") or "general")
    if kind == "references":
        return str(ent.get("source_type") or "article")
    return ""


def _match_existing(s, pid: str, kind: str, ent: dict) -> tuple[str, str | None, str, str]:
    """Natural-key lookup against the CURRENT project. Returns
    (key, existing_id_or_None, detail_label, note)."""
    detail = _detail_of(kind, ent)
    note = ""
    if kind == "characters":
        name = str(ent.get("name") or "").strip()
        row = s.execute(select(Character).where(
            Character.project_id == pid,
            func.lower(Character.name) == name.lower()).limit(1)).scalars().first() \
            if name else None
        return name.lower(), (row.id if row else None), detail, note
    if kind == "world":
        name = str(ent.get("name") or "").strip()
        type_ = str(ent.get("type") or "").strip()
        row = None
        if name:
            q = select(WorldEntry).where(
                WorldEntry.project_id == pid,
                func.lower(WorldEntry.name) == name.lower())
            if type_:
                q = q.where(WorldEntry.type == type_)
            row = s.execute(q.limit(1)).scalars().first()
        chain = ent.get("parent_chain") or []
        if chain:
            note = f"parent: {chain[0]}"
        return f"{type_}\u0000{name.lower()}", (row.id if row else None), detail, note
    if kind == "scenes":
        title = str(ent.get("title") or "").strip()
        chapter = str(ent.get("chapter") or "").strip()
        row = None
        if title:
            q = select(SceneCard).where(
                SceneCard.project_id == pid,
                func.lower(SceneCard.title) == title.lower())
            if chapter and chapter.lower() != "standalone":
                ch_id = _chapter_id_by_title(s, pid, chapter)
                if ch_id:
                    q = q.where(SceneCard.chapter_id == ch_id)
            row = s.execute(q.limit(1)).scalars().first()
        return f"{title.lower()}\u0000{chapter.lower()}", (row.id if row else None), detail, note
    if kind == "glossary":
        term = str(ent.get("term") or "").strip()
        row = s.execute(select(GlossaryEntry).where(
            GlossaryEntry.project_id == pid,
            func.lower(GlossaryEntry.term) == term.lower()).limit(1)).scalars().first() \
            if term else None
        return term.lower(), (row.id if row else None), detail, note
    if kind == "references":
        title = str(ent.get("title") or "").strip()
        author = str(ent.get("author") or "").strip()
        row = None
        if title:
            row = s.execute(select(Reference).where(
                Reference.project_id == pid,
                func.lower(Reference.title) == title.lower(),
                func.lower(func.coalesce(Reference.author, "")) == author.lower()
            ).limit(1)).scalars().first()
        return f"{title.lower()}\u0000{author.lower()}", (row.id if row else None), detail, note
    return "", None, detail, note


def _chapter_id_by_title(s, pid: str, title: str) -> str | None:
    from models.chapter import Chapter
    return s.execute(select(Chapter.id).where(
        Chapter.project_id == pid,
        func.lower(Chapter.title) == title.lower()).limit(1)).scalar_one_or_none()


def _preview_full_project(data: dict) -> dict:
    counts: dict[str, int] = {}
    from services.project_transfer_service import CONTENT_TABLES
    for key, _model in CONTENT_TABLES:
        rows = data.get(key)
        if isinstance(rows, list):
            counts[key] = len(rows)
    total = sum(counts.values())
    rows = [{"index": i, "name": f"{key}: {n} rows", "detail": "table",
             "status": "new", "note": ""} for i, (key, n) in enumerate(counts.items())]
    return {
        "kind": "full_project",
        "kind_label": KIND_LABELS["full_project"],
        "count": total,
        "summary": {"new": total, "existing": 0},
        "rows": rows,
        "note": "Existing rows are matched by id — re-importing is idempotent.",
    }


# ---------------------------------------------------------------- execute

def execute_import(data: Any, *, strategy: str = "skip",
                   exclude: set[int] | None = None) -> dict:
    """Run the import. One write transaction for the whole payload —
    a failure mid-way rolls everything back (atomic import)."""
    if strategy not in STRATEGIES:
        raise ValidationError(f"Strategy must be one of {STRATEGIES}.")
    kind = detect_payload(data)
    if kind == "unknown":
        raise ValidationError("Could not recognise this file as an ASM export.")
    exclude = exclude or set()

    if kind == "full_project":
        from services.project_transfer_service import import_all
        counts = import_all(data)
        created = sum(v for v in counts.values() if isinstance(v, int))
        return {
            "kind": kind, "kind_label": KIND_LABELS[kind], "strategy": strategy,
            "imported": created, "updated": 0, "skipped": 0, "failed": 0,
            "results": [{"name": f"{k}: +{v}", "action": "created",
                         "id": None, "entity": "project", "note": ""}
                        for k, v in counts.items() if v],
            "notes": [],
        }

    entities = _entities_of(data, kind)
    if not entities:
        raise ValidationError("The file contains no importable entities.")

    result: dict = {
        "kind": kind, "kind_label": KIND_LABELS[kind], "strategy": strategy,
        "imported": 0, "updated": 0, "skipped": 0, "failed": 0,
        "results": [], "notes": [],
    }

    with write_transaction() as s:
        pid = current_project_id(s)
        if kind == "world":
            _execute_world(s, pid, entities, strategy, exclude, result)
        elif kind == "characters":
            _execute_characters(s, pid, entities, strategy, exclude, result)
        elif kind == "scenes":
            _execute_scenes(s, pid, entities, strategy, exclude, result)
        elif kind == "glossary":
            _execute_glossary(s, pid, entities, strategy, exclude, result)
        elif kind == "references":
            _execute_references(s, pid, entities, strategy, exclude, result)
    return result


def _register(result: dict, *, name: str, action: str, entity: str,
              eid: str | None, note: str = "") -> None:
    key = {"created": "imported", "updated": "updated",
           "skipped": "skipped", "failed": "failed"}[action]
    result[key] += 1
    result["results"].append(
        {"name": name, "action": action, "id": eid, "entity": entity, "note": note})


# ---------------------------------------------------------------- world

def _execute_world(s, pid: str, entities: list[dict], strategy: str,
                   exclude: set[int], result: dict) -> None:
    """The deep one: hierarchy, relations, metadata and map pins."""
    from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion

    kept: list[tuple[int, dict]] = [(i, e) for i, e in enumerate(entities)
                                    if i not in exclude]
    # ---- pass 1: natural-key match against the current project ----------
    plan: list[dict] = []
    existing_by_key: dict[str, str] = {}
    for i, ent in kept:
        key, existing_id, _detail, note = _match_existing(s, pid, "world", ent)
        if existing_id and strategy == "skip":
            _register(result, name=_display_name("world", ent), action="skipped",
                      entity="world_entry", eid=existing_id,
                      note="already exists (same type + name)")
            continue
        plan.append({"i": i, "ent": ent, "key": key, "existing_id": existing_id,
                     "note": note})

    # ---- pass 2: topological order (parents before children) ------------
    by_old_id = {str(e.get("id")): e for e in (p["ent"] for p in plan) if e.get("id")}
    ordered: list[dict] = []
    deferred: list[dict] = list(plan)
    guard = 0
    while deferred and guard < len(plan) + 5:
        guard += 1
        still: list[dict] = []
        for p in deferred:
            pid_old = p["ent"].get("parent_id")
            # parent is another payload entry still waiting → defer
            if pid_old and str(pid_old) in by_old_id and \
                    str(pid_old) not in {str(q["ent"].get("id")) for q in ordered}:
                still.append(p)
            else:
                ordered.append(p)
        if len(still) == len(deferred):  # cycle safety — import what we can
            ordered.extend(still)
            break
        deferred = still

    # ---- pass 3: create / update in order, remapping ids ----------------
    id_map: dict[str, str] = {}          # old id → new id
    name_map: dict[str, str] = {}        # lower name → new id (for relations)
    for p in ordered:
        ent, existing_id = p["ent"], p["existing_id"]
        name = str(ent.get("name") or "").strip()[:300]
        type_ = str(ent.get("type") or "lore").strip()[:60] or "lore"
        if not name:
            _register(result, name="(unnamed)", action="failed",
                      entity="world_entry", eid=None, note="missing name")
            continue
        metadata = ent.get("metadata") if isinstance(ent.get("metadata"), dict) else {}
        pin = ent.get("map_pin") if isinstance(ent.get("map_pin"), dict) else None

        if existing_id and strategy == "overwrite":
            e = s.get(WorldEntry, existing_id)
            # keep a pre-import snapshot (same safety net as manual edits)
            snapshot = {
                "type": e.type, "name": e.name, "category": e.category,
                "description": e.description, "content": e.content,
                "notes": e.notes, "metadata": load_json(e.metadata_, {}),
            }
            s.add(WorldEntryVersion(
                id=new_uuid(), entry_id=e.id, version_number=(s.scalar(
                    select(func.max(WorldEntryVersion.version_number)).where(
                        WorldEntryVersion.entry_id == e.id)) or 0) + 1,
                snapshot=dump_json(snapshot), source="import",
                created_at=now_utc(), notes="Before v8.6 import overwrite"))
            for field, val in (("category", ent.get("category")),
                               ("description", ent.get("description")),
                               ("content", ent.get("content")),
                               ("notes", ent.get("notes"))):
                if val is not None:
                    setattr(e, field, val)
            if metadata:
                e.metadata_ = dump_json(metadata)
            if pin:
                e.map_pin_x, e.map_pin_y = pin.get("x"), pin.get("y")
                e.map_pin_label = pin.get("label")
                e.map_pin_color = pin.get("color")
            e.updated_at = now_utc()
            if e.id:
                id_map[str(ent.get("id"))] = e.id
                name_map[name.lower()] = e.id
            _register(result, name=name, action="updated", entity="world_entry",
                      eid=existing_id, note=p.get("note") or "")
            log_activity(s, entity_type="world_entry", entity_id=existing_id,
                         entity_title=name, action="updated",
                         details={"via": "import v8.6"})
            continue

        # ---- create ----
        eid = new_uuid()
        # parent: payload sibling → remapped id; else resolve by name in DB
        parent_note = ""
        parent_id: str | None = None
        pid_old = ent.get("parent_id")
        if pid_old and str(pid_old) in id_map:
            parent_id = id_map[str(pid_old)]
        elif ent.get("parent_chain"):
            # parent_chain[0] is the immediate parent's NAME
            pname = str(ent["parent_chain"][0])
            row = s.execute(select(WorldEntry.id).where(
                WorldEntry.project_id == pid,
                func.lower(WorldEntry.name) == pname.lower(),
                WorldEntry.id != eid).limit(1)).scalar_one_or_none()
            if row:
                parent_id, parent_note = row, f"parent linked: {pname}"
            else:
                parent_note = f"parent '{pname}' not found — imported at root"
        max_order = s.scalar(select(func.max(WorldEntry.sort_order)).where(
            WorldEntry.project_id == pid, WorldEntry.type == type_)) or 0
        e = WorldEntry(
            id=eid, project_id=pid, type=type_, name=name,
            category=ent.get("category"), description=ent.get("description"),
            content=ent.get("content"), notes=ent.get("notes"),
            metadata_=dump_json(metadata), parent_id=parent_id,
            map_pin_x=pin.get("x") if pin else None,
            map_pin_y=pin.get("y") if pin else None,
            map_pin_label=pin.get("label") if pin else None,
            map_pin_color=pin.get("color") if pin else None,
            sort_order=max_order + 1,
            created_at=now_utc(), updated_at=now_utc())
        s.add(e)
        s.add(WorldEntryVersion(
            id=new_uuid(), entry_id=eid, version_number=1,
            snapshot=dump_json({"type": type_, "name": name,
                                "category": ent.get("category"),
                                "description": ent.get("description"),
                                "content": ent.get("content"),
                                "notes": ent.get("notes"), "metadata": metadata}),
            source="import", created_at=now_utc(),
            notes="Imported via v8.6 Universal Import"))
        if ent.get("id"):
            id_map[str(ent["id"])] = eid
        name_map[name.lower()] = eid
        _register(result, name=name, action="created", entity="world_entry",
                  eid=eid, note=parent_note or (p.get("note") or ""))
        log_activity(s, entity_type="world_entry", entity_id=eid,
                     entity_title=name, action="created",
                     details={"via": "import v8.6"})

    # ---- pass 4: relations (deduped, names resolved) ---------------------
    seen_rels: set[tuple[str, str, str]] = set()

    def _resolve(name: str | None) -> str | None:
        if not name:
            return None
        nid = name_map.get(str(name).lower())
        if nid:
            return nid
        return s.execute(select(WorldEntry.id).where(
            WorldEntry.project_id == pid,
            func.lower(WorldEntry.name) == str(name).lower()).limit(1)
        ).scalar_one_or_none()

    def _add_relation(from_id: str, to_id: str, rtype: str, desc: str | None) -> None:
        rkey = (from_id, to_id, str(rtype).lower())
        if rkey in seen_rels:
            return
        seen_rels.add(rkey)
        s.add(WorldEntryRelation(
            id=new_uuid(), from_entry_id=from_id, to_entry_id=to_id,
            relation_type=str(rtype)[:80], description=desc))

    for p in ordered:
        ent = p["ent"]
        nid = id_map.get(str(ent.get("id"))) or name_map.get(
            str(ent.get("name") or "").lower())
        if not nid:
            continue  # failed create — no relations
        for r in ent.get("relations_out") or []:
            if not isinstance(r, dict) or not r.get("type"):
                continue
            target = _resolve(r.get("target"))
            if target:
                _add_relation(nid, target, r["type"], r.get("description"))
            else:
                result["notes"].append(
                    f"relation target '{r.get('target')}' not found — skipped")
        for r in ent.get("relations_in") or []:
            if not isinstance(r, dict) or not r.get("type"):
                continue
            source = _resolve(r.get("source"))
            if source:
                _add_relation(source, nid, r["type"], r.get("description"))
            # source not found → the note is only useful once; stay quiet
    s.flush()


# ---------------------------------------------------------------- characters

def _execute_characters(s, pid: str, entities: list[dict], strategy: str,
                        exclude: set[int], result: dict) -> None:
    from models.character import Character
    from services.character_service import ROLE_OPTIONS
    for i, ent in enumerate(entities):
        if i in exclude:
            continue
        name = str(ent.get("name") or "").strip()[:200]
        if not name:
            _register(result, name="(unnamed)", action="failed",
                      entity="character", eid=None, note="missing name")
            continue
        role = str(ent.get("role") or "supporting")
        if role not in ROLE_OPTIONS:
            role = "supporting"
        existing = s.execute(select(Character).where(
            Character.project_id == pid,
            func.lower(Character.name) == name.lower()).limit(1)).scalars().first()
        if existing and strategy == "skip":
            _register(result, name=name, action="skipped", entity="character",
                      eid=existing.id, note="name already exists")
            continue
        fields = {
            "age": ent.get("age"), "gender": ent.get("gender"),
            "physical": ent.get("physical"), "psychology": ent.get("psychology"),
            "background": ent.get("background"), "philosophy": ent.get("philosophy"),
            "story_role": ent.get("story_role"), "voice": ent.get("voice"),
            "notes": ent.get("notes"),
        }
        aliases = [str(a) for a in ent.get("aliases") or [] if str(a).strip()]
        quotes = [str(q) for q in ent.get("philosophy_quotes") or [] if str(q).strip()]
        if existing and strategy == "overwrite":
            for k, v in fields.items():
                if v is not None:
                    setattr(existing, k, v)
            if aliases:
                existing.aliases = dump_json(aliases)
            if quotes:
                existing.philosophy_quotes = dump_json(quotes)
            existing.updated_at = now_utc()
            _register(result, name=name, action="updated", entity="character",
                      eid=existing.id)
            log_activity(s, entity_type="character", entity_id=existing.id,
                         entity_title=name, action="updated",
                         details={"via": "import v8.6"})
            continue
        cid = new_uuid()
        s.add(Character(
            id=cid, project_id=pid, name=name, role=role,
            age=fields["age"], gender=fields["gender"],
            aliases=dump_json(aliases),
            avatar_color=str(ent.get("avatar_color") or "")[:20] or None,
            physical=fields["physical"], psychology=fields["psychology"],
            background=fields["background"], philosophy=fields["philosophy"],
            philosophy_quotes=dump_json(quotes),
            story_role=fields["story_role"], voice=fields["voice"],
            notes=fields["notes"], created_at=now_utc(), updated_at=now_utc()))
        _register(result, name=name, action="created", entity="character", eid=cid)
        log_activity(s, entity_type="character", entity_id=cid,
                     entity_title=name, action="created",
                     details={"via": "import v8.6"})
    s.flush()


# ---------------------------------------------------------------- scenes

def _execute_scenes(s, pid: str, entities: list[dict], strategy: str,
                    exclude: set[int], result: dict) -> None:
    from models.scene import SceneCard
    for i, ent in enumerate(entities):
        if i in exclude:
            continue
        title = str(ent.get("title") or "Untitled Scene").strip()[:500]
        chapter_title = str(ent.get("chapter") or "").strip()
        chapter_id: str | None = None
        note = ""
        if chapter_title and chapter_title.lower() != "standalone":
            chapter_id = _chapter_id_by_title(s, pid, chapter_title)
            if not chapter_id:
                note = f"chapter '{chapter_title}' not found — standalone"
        pov_name = str(ent.get("pov") or "").strip()
        pov_id: str | None = None
        if pov_name:
            from models.character import Character
            pov_id = s.execute(select(Character.id).where(
                Character.project_id == pid,
                func.lower(Character.name) == pov_name.lower()).limit(1)
            ).scalar_one_or_none()
            if not pov_id:
                note = (note + "; " if note else "") + f"POV '{pov_name}' not found"
        existing = None
        if strategy != "duplicate":
            q = select(SceneCard).where(SceneCard.project_id == pid,
                                        func.lower(SceneCard.title) == title.lower())
            if chapter_id:
                q = q.where(SceneCard.chapter_id == chapter_id)
            else:
                q = q.where(SceneCard.chapter_id.is_(None))
            existing = s.execute(q.limit(1)).scalars().first()
        if existing and strategy == "skip":
            _register(result, name=title, action="skipped", entity="scene",
                      eid=existing.id, note="same title + chapter exists")
            continue
        content = ent.get("content") or ""
        word_count = ent.get("word_count")
        if not isinstance(word_count, int) or word_count < 0:
            word_count = len(str(content).split())
        fields = {
            "summary": ent.get("summary"), "notes": ent.get("notes"),
            "location": (str(ent.get("location"))[:200] if ent.get("location") else None),
            "time_of_day": (str(ent.get("time_of_day"))[:40] if ent.get("time_of_day") else None),
            "mood": (str(ent.get("mood"))[:40] if ent.get("mood") else None),
        }
        tags = [str(t) for t in ent.get("tags") or [] if str(t).strip()]
        if existing and strategy == "overwrite":
            for k, v in fields.items():
                if v is not None:
                    setattr(existing, k, v)
            if content:
                existing.full_text = content
                existing.content_snippet = content[:500]
            if tags:
                existing.tags = dump_json(tags)
            existing.word_count = word_count
            existing.updated_at = now_utc()
            _register(result, name=title, action="updated", entity="scene",
                      eid=existing.id, note=note)
            continue
        max_order = s.scalar(select(func.max(SceneCard.sort_order)).where(
            SceneCard.project_id == pid)) or 0
        sid = new_uuid()
        s.add(SceneCard(
            id=sid, project_id=pid, chapter_id=chapter_id, title=title,
            summary=fields["summary"],
            content_snippet=(str(content)[:500] if content else None),
            full_text=(content if content else None),
            sort_order=max_order + 1,
            pov_character_id=pov_id,
            location=fields["location"], time_of_day=fields["time_of_day"],
            mood=fields["mood"],
            status=str(ent.get("status") or "draft")[:20],
            word_count=word_count,
            tags=dump_json(tags) if tags else None,
            notes=fields["notes"],
            created_at=now_utc(), updated_at=now_utc()))
        _register(result, name=title, action="created", entity="scene",
                  eid=sid, note=note)
    s.flush()


# ---------------------------------------------------------------- glossary

def _execute_glossary(s, pid: str, entities: list[dict], strategy: str,
                      exclude: set[int], result: dict) -> None:
    from models.glossary import GlossaryEntry
    for i, ent in enumerate(entities):
        if i in exclude:
            continue
        term = str(ent.get("term") or "").strip()[:300]
        if not term:
            _register(result, name="(unnamed)", action="failed",
                      entity="glossary", eid=None, note="missing term")
            continue
        existing = s.execute(select(GlossaryEntry).where(
            GlossaryEntry.project_id == pid,
            func.lower(GlossaryEntry.term) == term.lower()).limit(1)).scalars().first()
        if existing and strategy == "skip":
            _register(result, name=term, action="skipped", entity="glossary",
                      eid=existing.id, note="term already exists")
            continue
        if existing and strategy == "duplicate":
            # v9.3.0 (F-06): (project_id, term) is a UNIQUE natural key —
            # a literal duplicate row is no longer representable. Register
            # the conflict instead of failing the whole import.
            _register(result, name=term, action="skipped", entity="glossary",
                      eid=existing.id,
                      note="term already exists (glossary terms are unique)")
            continue
        alternates = [str(a) for a in ent.get("alternates") or [] if str(a).strip()]
        forbidden = [str(f) for f in ent.get("forbidden") or [] if str(f).strip()]
        fields = {
            "category": str(ent.get("category") or "general")[:60],
            "definition": ent.get("definition"),
            "notes": ent.get("notes"),
        }
        cs = 1 if ent.get("case_sensitive") else 0
        if existing and strategy == "overwrite":
            for k, v in fields.items():
                if v is not None:
                    setattr(existing, k, v)
            if alternates:
                existing.alternates = dump_json(alternates)
            if forbidden:
                existing.forbidden = dump_json(forbidden)
            existing.case_sensitive = cs
            existing.updated_at = now_utc()
            _register(result, name=term, action="updated", entity="glossary",
                      eid=existing.id)
            continue
        gid = new_uuid()
        s.add(GlossaryEntry(
            id=gid, project_id=pid, term=term, category=fields["category"],
            definition=fields["definition"],
            alternates=dump_json(alternates) if alternates else None,
            forbidden=dump_json(forbidden) if forbidden else None,
            case_sensitive=cs, notes=fields["notes"],
            created_at=now_utc(), updated_at=now_utc()))
        _register(result, name=term, action="created", entity="glossary", eid=gid)
    s.flush()


# ---------------------------------------------------------------- references

def _execute_references(s, pid: str, entities: list[dict], strategy: str,
                        exclude: set[int], result: dict) -> None:
    from models.reference import Reference
    for i, ent in enumerate(entities):
        if i in exclude:
            continue
        title = str(ent.get("title") or "").strip()[:500]
        if not title:
            _register(result, name="(unnamed)", action="failed",
                      entity="reference", eid=None, note="missing title")
            continue
        author = str(ent.get("author") or "").strip()[:300] or None
        existing = s.execute(select(Reference).where(
            Reference.project_id == pid,
            func.lower(Reference.title) == title.lower(),
            func.lower(func.coalesce(Reference.author, "")) == (author or "").lower()
        ).limit(1)).scalars().first()
        if existing and strategy == "skip":
            _register(result, name=title, action="skipped", entity="reference",
                      eid=existing.id, note="title + author already exists")
            continue
        quotes = [q for q in ent.get("quotes") or [] if isinstance(q, dict) and q.get("text")]
        tags = [str(t) for t in ent.get("tags") or [] if str(t).strip()]
        rating = ent.get("rating")
        if not isinstance(rating, int) or not (1 <= rating <= 5):
            rating = None
        fields = {
            "url": ent.get("url"),
            "source_type": str(ent.get("source_type") or "article")[:40],
            "publication_date": (str(ent.get("publication_date"))[:40]
                                 if ent.get("publication_date") else None),
            "publisher": (str(ent.get("publisher"))[:300] if ent.get("publisher") else None),
            "isbn_or_doi": (str(ent.get("isbn_or_doi"))[:100] if ent.get("isbn_or_doi") else None),
            "description": ent.get("description"),
            "read_status": str(ent.get("read_status") or "unread")[:20],
            "priority": str(ent.get("priority") or "medium")[:20],
            "notes": ent.get("notes"),
        }
        if existing and strategy == "overwrite":
            for k, v in fields.items():
                if v is not None:
                    setattr(existing, k, v)
            if quotes:
                existing.quotes = dump_json(quotes)
            if tags:
                existing.tags = dump_json(tags)
            if rating is not None:
                existing.rating = rating
            existing.updated_at = now_utc()
            _register(result, name=title, action="updated", entity="reference",
                      eid=existing.id)
            continue
        rid = new_uuid()
        s.add(Reference(
            id=rid, project_id=pid, title=title, author=author,
            url=fields["url"], source_type=fields["source_type"],
            publication_date=fields["publication_date"],
            publisher=fields["publisher"], isbn_or_doi=fields["isbn_or_doi"],
            description=fields["description"],
            quotes=dump_json(quotes) if quotes else None,
            tags=dump_json(tags) if tags else None,
            read_status=fields["read_status"], priority=fields["priority"],
            rating=rating, notes=fields["notes"],
            created_at=now_utc(), updated_at=now_utc()))
        _register(result, name=title, action="created", entity="reference", eid=rid)
    s.flush()


# ---------------------------------------------------------------- parsing

def parse_json_bytes(raw: bytes) -> Any:
    """Parse uploaded bytes into a JSON value with a friendly error."""
    if not raw:
        raise ValidationError("The file is empty.")
    try:
        return json.loads(raw.decode("utf-8-sig"))
    except UnicodeDecodeError:
        raise ValidationError("The file is not valid UTF-8 JSON.")
    except json.JSONDecodeError as exc:
        raise ValidationError(f"Invalid JSON: {exc.msg} (line {exc.lineno}).")
