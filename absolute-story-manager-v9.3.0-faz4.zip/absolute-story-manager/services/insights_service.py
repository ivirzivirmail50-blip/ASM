"""Writing Insights Dashboard 2.0 — cross-cutting insights beyond Analytics & Habits.

Distinct from:
- analytics_service.py — per-chapter manuscript statistics (sentence counts, dialogue ratio)
- habits_service.py — best day/hour patterns, 7x24 heatmap, streaks
- forecast_service.py — completion-date prediction

This module produces the unified "writer dashboard" view by combining data from
activity_log, writing_sessions, projects, and chapters into a single payload:

- YEAR HEATMAP: GitHub-style 365-day calendar heatmap (last 365 days).
  Each day's color intensity = total words written that day (clamped to 4 buckets).
  Useful for the writer to see at-a-glance: "I've written 47 of the last 90 days".

- CROSS-BOOK DASHBOARD: For multi-book workspaces, list every project with:
  word count / target / progress %, days remaining to deadline, estimated
  completion date at current pace, and a recommendation ("on track" / "behind" /
  "ahead"). Single-click switch to that book.

- TODAY INSIGHT: a single smart card "Today's insight" — combines today's
  progress (X words of Y daily goal), your best writing hour of the week, your
  current streak, and a contextual tip ("It's Wednesday — your most productive
  day. Aim for 750 words between 20:00 and 22:00.").

- VELOCITY TREND: 7/30/90-day pace (words/day) for the active project and
  cross-project total — useful for spotting slumps and surges.

- PEAK HOUR: best writing hour (UTC converted to local) for the active project
  with sample size and average words written in that hour.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select

from core.cache import cache
from core.db import read_session
from models.activity import ActivityLog
from models.chapter import Chapter
from models.project import Project
from models.settings import Setting
from services._common import current_project_id

log = logging.getLogger("asm.insights")

CACHE_TTL = 90  # 1.5 minutes

DAYS_OF_WEEK = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


# ---------------------------------------------------------------------------
# Year heatmap (GitHub-style 365 days)
# ---------------------------------------------------------------------------

def year_heatmap(*, days: int = 365) -> dict[str, Any]:
    """Return 365-day word-count heatmap.

    Returns:
        {
            "days": [{"date": "2026-08-26", "words": 1234, "level": 3, "weekday": 2}, ...],
            "max": 1234,
            "buckets": [0, 1, 100, 500, 1000],   # thresholds for levels 0..4
            "total_words": 34567,
            "writing_days": 47,
            "total_days": 365,
            "streak_current": 3,
            "streak_longest": 12,
        }
    """
    cache_key = f"insights:heatmap:{days}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days - 1)

    with read_session() as s:
        rows = list(s.execute(
            select(
                ActivityLog.timestamp,
                ActivityLog.word_count_delta,
            ).where(
                ActivityLog.entity_type == "chapter",
                ActivityLog.timestamp >= start,
                ActivityLog.timestamp < end + timedelta(days=1),
            )
        ).all())

    # Bucket by date (UTC)
    daily: dict[str, int] = defaultdict(int)
    for ts, delta in rows:
        if not ts or not delta:
            continue
        if delta <= 0:
            continue  # only count positive deltas
        day_key = ts.date().isoformat()
        daily[day_key] += delta

    # Build full calendar
    cal_days: list[dict[str, Any]] = []
    cur = start.date()
    last = end.date()
    today = datetime.now(timezone.utc).date()
    while cur <= last:
        w = daily.get(cur.isoformat(), 0)
        cal_days.append({
            "date": cur.isoformat(),
            "words": w,
            "level": _level(w),
            "weekday": cur.weekday(),
            "is_today": cur == today,
        })
        cur += timedelta(days=1)

    max_words = max((d["words"] for d in cal_days), default=0)
    writing_days = sum(1 for d in cal_days if d["words"] > 0)
    streak_cur, streak_long = _streaks([d["date"] for d in cal_days if d["words"] > 0])

    result = {
        "days": cal_days,
        "max": max_words,
        "buckets": [0, 1, 100, 500, 1000],
        "total_words": sum(d["words"] for d in cal_days),
        "writing_days": writing_days,
        "total_days": len(cal_days),
        "streak_current": streak_cur,
        "streak_longest": streak_long,
    }
    cache.set(cache_key, result, ttl_seconds=CACHE_TTL)
    return result


def _level(words: int) -> int:
    """Map word count to 0-4 color intensity bucket (GitHub-style)."""
    if words <= 0:
        return 0
    if words < 100:
        return 1
    if words < 500:
        return 2
    if words < 1000:
        return 3
    return 4


def _streaks(active_dates: list[str]) -> tuple[int, int]:
    """Given sorted active writing dates (ISO), compute (current, longest) streaks.

    A "streak" is consecutive calendar days with >0 words written.
    """
    if not active_dates:
        return 0, 0
    # Parse + sort
    days = sorted({date.fromisoformat(d) for d in active_dates})

    # Current streak: walk backwards from today (UTC date)
    today = datetime.now(timezone.utc).date()
    current = 0
    if days[-1] == today:
        current = 1
        prev = today
        for d in reversed(days[:-1]):
            if (prev - d).days == 1:
                current += 1
                prev = d
            else:
                break
    elif days[-1] == today - timedelta(days=1):
        # Allow yesterday to count as "current streak continues" only if today hasn't started
        current = 1

    # Longest streak: walk full sequence
    longest = 1
    run = 1
    for i in range(1, len(days)):
        if (days[i] - days[i - 1]).days == 1:
            run += 1
            longest = max(longest, run)
        else:
            run = 1
    return current, longest


# ---------------------------------------------------------------------------
# Cross-book dashboard
# ---------------------------------------------------------------------------

def cross_book_dashboard() -> dict[str, Any]:
    """For multi-book workspaces: per-book progress + projected completion.

    Returns:
        {
            "books": [{
                "id", "name", "color", "genre",
                "words_written", "target_words", "progress_pct",
                "deadline", "deadline_str", "days_left",
                "pace_7d", "pace_30d",
                "projected_completion_date", "projected_completion_str",
                "days_to_finish_at_pace",
                "status": "on_track"|"behind"|"ahead"|"no_pace"|"done",
                "is_active"
            }, ...],
            "totals": {"words", "target_words", "progress_pct", "books_count"},
        }
    """
    cache_key = "insights:cross_book"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    today = date.today()
    now = datetime.now(timezone.utc)

    with read_session() as s:
        projects = list(s.query(Project).order_by(Project.created_at.asc()).all())
        active_id = current_project_id(s)

        # Aggregate per-project word totals + pace
        book_payload = []
        total_words = 0
        total_target = 0
        for p in projects:
            words = s.scalar(
                select(func.coalesce(func.sum(Chapter.word_count), 0))
                .where(Chapter.project_id == p.id)
            ) or 0
            total_words += words

            # Pace: words written in last 7 / 30 days for THIS project
            pace_7, pace_30 = _pace_for_project(s, p.id, 7), _pace_for_project(s, p.id, 30)

            target = p.target_words or 0
            total_target += target
            progress = min(100, round((words / target * 100) if target else 0, 1))

            days_left = None
            deadline_str = None
            if p.deadline:
                days_left = (p.deadline - today).days
                deadline_str = p.deadline.strftime("%d %b %Y")

            # Projected completion: based on 30-day pace
            projected_date = None
            projected_str = None
            days_to_finish = None
            status = "no_pace"
            if target and words < target and pace_30 > 0:
                remaining = target - words
                days_to_finish = int(remaining / max(pace_30, 1))
                projected_date = today + timedelta(days=days_to_finish)
                projected_str = projected_date.strftime("%d %b %Y")
                # Status: compare projection to deadline (if any)
                if days_left is not None:
                    if days_to_finish <= days_left:
                        status = "ahead"
                    elif days_to_finish <= days_left + 14:
                        status = "on_track"
                    else:
                        status = "behind"
                else:
                    status = "on_track" if pace_30 > 0 else "no_pace"
            elif target and words >= target:
                status = "done"

            book_payload.append({
                "id": p.id,
                "name": p.name,
                "color": p.color or "#6366f1",
                "genre": p.genre or "",
                "subtitle": p.subtitle or "",
                "words_written": words,
                "target_words": target,
                "progress_pct": progress,
                "deadline_str": deadline_str,
                "days_left": days_left,
                "pace_7d": pace_7,
                "pace_30d": pace_30,
                "projected_completion_str": projected_str,
                "days_to_finish_at_pace": days_to_finish,
                "status": status,
                "is_active": p.id == active_id,
            })

    overall_progress = (round(total_words / total_target * 100, 1)
                        if total_target else 0)

    result = {
        "books": book_payload,
        "totals": {
            "words": total_words,
            "target_words": total_target,
            "progress_pct": overall_progress,
            "books_count": len(book_payload),
        },
    }
    cache.set(cache_key, result, ttl_seconds=CACHE_TTL)
    return result


def _pace_for_project(session, project_id: str, days: int) -> int:
    """Average words/day over the last N days for a specific project."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    total = session.scalar(
        select(func.coalesce(func.sum(ActivityLog.word_count_delta), 0))
        .where(
            ActivityLog.entity_type == "chapter",
            ActivityLog.project_id == project_id,
            ActivityLog.timestamp >= cutoff,
            ActivityLog.word_count_delta > 0,
        )
    ) or 0
    return int(total // days) if days else 0


# ---------------------------------------------------------------------------
# Today's insight card
# ---------------------------------------------------------------------------

def today_insight() -> dict[str, Any]:
    """Smart one-line insight for today: progress + best hour + streak + tip.

    Returns:
        {
            "today_words", "daily_goal", "daily_goal_met",
            "today_date", "weekday", "weekday_name",
            "best_hour", "best_hour_label",
            "current_streak",
            "tip": "...",
        }
    """
    cache_key = "insights:today"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    weekday = now.weekday()
    weekday_name = DAYS_OF_WEEK[weekday]

    # Today's words (active project only)
    with read_session() as s:
        pid = current_project_id(s)
        daily_goal_str = Setting.get(s, "daily_word_goal", "500") or "500"
        try:
            daily_goal = int(daily_goal_str)
        except (ValueError, TypeError):
            daily_goal = 500
        today_words = s.scalar(
            select(func.coalesce(func.sum(ActivityLog.word_count_delta), 0))
            .where(
                ActivityLog.entity_type == "chapter",
                ActivityLog.project_id == pid,
                ActivityLog.timestamp >= today_start,
                ActivityLog.word_count_delta > 0,
            )
        ) or 0

    # Best hour over last 30 days
    best_hour = _best_hour(pid, days=30)

    # Streak
    hm = year_heatmap(days=90)
    current_streak = hm["streak_current"]

    # Compose tip
    tip = _compose_tip(weekday, best_hour, today_words, daily_goal, current_streak)

    result = {
        "today_words": today_words,
        "daily_goal": daily_goal,
        "daily_goal_met": today_words >= daily_goal if daily_goal else False,
        "today_date": now.date().isoformat(),
        "weekday": weekday,
        "weekday_name": weekday_name,
        "best_hour": best_hour,
        "best_hour_label": f"{best_hour:02d}:00–{best_hour + 1:02d}:00" if best_hour is not None else "—",
        "current_streak": current_streak,
        "tip": tip,
    }
    cache.set(cache_key, result, ttl_seconds=60)  # 1 minute — fresher than others
    return result


def _best_hour(project_id: str, *, days: int) -> int | None:
    """Best writing hour (0-23) over last N days (UTC)."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    hour_expr = func.extract("hour", ActivityLog.timestamp).label("h")
    with read_session() as s:
        rows = list(s.execute(
            select(
                hour_expr,
                func.sum(ActivityLog.word_count_delta).label("w"),
            ).where(
                ActivityLog.entity_type == "chapter",
                ActivityLog.project_id == project_id,
                ActivityLog.timestamp >= cutoff,
                ActivityLog.word_count_delta > 0,
            ).group_by(hour_expr)
        ))
    if not rows:
        return None
    best = max(rows, key=lambda r: int(r[1] or 0))
    return int(best[0])


def _compose_tip(weekday: int, best_hour: int | None,
                 today_words: int, daily_goal: int,
                 current_streak: int) -> str:
    """One-sentence actionable tip shown in the today card."""
    if daily_goal and today_words >= daily_goal:
        return (f"Daily goal met! {today_words}/{daily_goal} words. "
                f"You're on a {current_streak}-day streak — keep it alive tomorrow.")
    if current_streak == 0:
        return "Start a new streak today — even 50 words counts!"
    if best_hour is not None and best_hour == datetime.now(timezone.utc).hour:
        return (f"You're in your peak hour ({best_hour:02d}:00)! "
                f"You have {daily_goal - today_words} words left to hit today's goal.")
    if best_hour is not None:
        return (f"Your most productive hour is {best_hour:02d}:00. "
                f"Plan to write then — {daily_goal - today_words} words to go.")
    return f"Write {daily_goal - today_words} more words to hit today's goal of {daily_goal}."


# ---------------------------------------------------------------------------
# Velocity trend (last 30 days, per day)
# ---------------------------------------------------------------------------

def velocity_trend(*, days: int = 30) -> dict[str, Any]:
    """Last N days of words written per day for sparkline + summary.

    Returns {"series": [{"date": "2026-08-26", "words": 1234}, ...],
             "avg", "max", "total", "trend": "up"|"down"|"flat"}.
    """
    cache_key = f"insights:velocity:{days}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days - 1)
    with read_session() as s:
        rows = list(s.execute(
            select(
                ActivityLog.timestamp,
                ActivityLog.word_count_delta,
            ).where(
                ActivityLog.entity_type == "chapter",
                ActivityLog.timestamp >= start,
                ActivityLog.timestamp < end + timedelta(days=1),
            )
        ).all())

    daily: dict[str, int] = defaultdict(int)
    for ts, delta in rows:
        if delta and delta > 0:
            daily[ts.date().isoformat()] += delta

    series = []
    cur = start.date()
    last = end.date()
    while cur <= last:
        series.append({"date": cur.isoformat(), "words": daily.get(cur.isoformat(), 0)})
        cur += timedelta(days=1)

    words_list = [d["words"] for d in series]
    avg = sum(words_list) // len(words_list) if words_list else 0
    max_w = max(words_list, default=0)
    total = sum(words_list)

    # Trend: compare last 7 days avg to previous 7 days avg
    if len(words_list) >= 14:
        last7 = sum(words_list[-7:]) / 7
        prev7 = sum(words_list[-14:-7]) / 7
        if prev7 == 0:
            trend = "up" if last7 > 0 else "flat"
        elif last7 > prev7 * 1.1:
            trend = "up"
        elif last7 < prev7 * 0.9:
            trend = "down"
        else:
            trend = "flat"
    else:
        trend = "flat"

    result = {
        "series": series,
        "avg": avg,
        "max": max_w,
        "total": total,
        "trend": trend,
        "days": days,
    }
    cache.set(cache_key, result, ttl_seconds=CACHE_TTL)
    return result


# ---------------------------------------------------------------------------
# Full dashboard payload
# ---------------------------------------------------------------------------

def full_dashboard() -> dict[str, Any]:
    """Combine all insight modules into one payload for the /insights/ page."""
    return {
        "year_heatmap": year_heatmap(days=365),
        "velocity": velocity_trend(days=30),
        "today": today_insight(),
        "cross_book": cross_book_dashboard(),
    }
