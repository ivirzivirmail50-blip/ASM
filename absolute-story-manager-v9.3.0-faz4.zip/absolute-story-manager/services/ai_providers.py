"""AI provider adapter layer — F-01 (v9.2.0).

One interface behind four providers:

- ``ollama``    local native API (``/api/generate``, ``/api/tags``)
- ``openai``    any OpenAI-compatible endpoint (``/v1/chat/completions``,
                ``/v1/models``) — Groq, OpenRouter, LM Studio, llama.cpp, Z.AI
- ``anthropic`` native Messages API (``/v1/messages``, ``/v1/models``)
- ``gemini``    Google Generative Language API
                (``/v1beta/models/{model}:generateContent``)

Reliability policy applied to EVERY provider call:

- a single shared ``requests.Session`` (connection pooling, one place to
  configure adapters/proxies if ever needed)
- exponential-backoff retry: 3 attempts total, retrying ONLY connection
  errors, timeouts and HTTP 5xx — never 4xx client errors (retrying those
  would just burn the rate limit)
- an explicit ``(connect, read)`` timeout tuple so a dead host fails in
  seconds instead of hanging a worker for the full read timeout

Streaming calls retry only the initial request (status line + headers).
Once chunks are being consumed a mid-stream failure surfaces as a clear
AiProviderError — resuming a half-consumed stream is not possible.
"""
from __future__ import annotations

import json
import logging
import threading
from typing import Any, Iterator

import requests

from core.errors import AiProviderError

log = logging.getLogger("asm.ai.providers")

# Total attempts per call (1 initial + 2 retries — "after 2 retries a clear
# error", per the acceptance criteria). Patchable by tests.
HTTP_RETRY_ATTEMPTS = 3
# Base delay between retries in seconds: 0.35 → 0.7 → (no third sleep).
# Tests set this to 0 to keep the suite fast.
BACKOFF_BASE = 0.35
# Connect timeout cap: fail fast when the host is unreachable, even if the
# read timeout is configured generously (e.g. a slow 300s local model).
_CONNECT_TIMEOUT_CAP = 10

KNOWN_PROVIDERS = ("ollama", "openai", "anthropic", "gemini")

_ANTHROPIC_VERSION = "2023-06-01"


class _SharedSession:
    """Lazily-built, thread-safe shared requests.Session.

    ``requests.Session`` is thread-safe for pooled requests; the lock only
    guards construction (tests may swap ``ai_providers._session``).
    """

    _lock = threading.Lock()

    def build(self) -> requests.Session:
        s = requests.Session()
        s.headers.update({"User-Agent": "AbsoluteStoryManager/9.2"})
        return s


_session: requests.Session | None = None


def get_session() -> requests.Session:
    """Return the shared HTTP session (lazily created)."""
    global _session
    if _session is None:
        with _SharedSession._lock:
            if _session is None:
                _session = _SharedSession().build()
    return _session


def _timeout_pair(cfg: dict[str, Any]) -> tuple[float, float]:
    read = float(cfg.get("timeout") or 60)
    connect = min(_CONNECT_TIMEOUT_CAP, read)
    return (connect, read)


def _sleep_backoff(attempt: int) -> None:
    """Exponential backoff — indirected for test patching."""
    import time
    time.sleep(BACKOFF_BASE * (2 ** (attempt - 1)))


def _retryable(exc: BaseException) -> bool:
    """Connection errors, timeouts and 5xx are transient; 4xx is not."""
    if isinstance(exc, (requests.exceptions.ConnectionError,
                        requests.exceptions.Timeout)):
        return True
    response = getattr(exc, "response", None)
    if response is not None:
        status = getattr(response, "status_code", 0) or 0
        return status >= 500
    # HTTPError without response, bad URL, etc. — assume terminal.
    return False


def _clear_error(what: str, url: str, attempts: int, exc: BaseException) -> AiProviderError:
    detail = str(exc) or exc.__class__.__name__
    return AiProviderError(
        f"{what} failed after {attempts} attempt(s): {detail}. "
        f"Check that the provider is running and reachable at {url.rstrip('/')}, "
        "and that the API key / model name are correct."
    )


def http_request(method: str, url: str, *, what: str,
                 cfg: dict[str, Any],
                 **kwargs: Any) -> requests.Response:
    """Perform an HTTP request with the retry/backoff/timeout policy.

    ``what`` names the operation for error messages ("Ollama generate",
    "Anthropic model list", ...).
    """
    attempts = max(1, int(cfg.get("retry_attempts") or HTTP_RETRY_ATTEMPTS))
    session = get_session()
    last_exc: BaseException | None = None
    for attempt in range(1, attempts + 1):
        try:
            resp = session.request(
                method, url, timeout=_timeout_pair(cfg), **kwargs)
            resp.raise_for_status()
            return resp
        except requests.RequestException as exc:
            last_exc = exc
            if not _retryable(exc) or attempt == attempts:
                if isinstance(exc, requests.RequestException):
                    raise _clear_error(what, url, attempts, exc) from exc
            log.warning("%s: attempt %d/%d failed (%s); %s",
                        what, attempt, attempts, exc,
                        "retrying" if attempt < attempts else "giving up")
            _sleep_backoff(attempt)
    # Unreachable — the loop always returns or raises — but keep the type
    # checker happy and surface the last error defensively.
    raise _clear_error(what, url, attempts, last_exc or RuntimeError("no attempt"))


# ---------------------------------------------------------------------------
# Adapter protocol
# ---------------------------------------------------------------------------

class BaseAdapter:
    """Provider adapter: generate / stream / list_models."""

    name: str = "base"

    def generate(self, cfg: dict[str, Any], prompt: str,
                 max_tokens: int, temperature: float) -> str:
        raise NotImplementedError

    def stream(self, cfg: dict[str, Any], prompt: str,
               max_tokens: int, temperature: float) -> Iterator[tuple[str, bool]]:
        raise NotImplementedError

    def list_models(self, cfg: dict[str, Any]) -> list[str]:
        raise NotImplementedError

    # -- helpers shared by all adapters -----------------------------------
    def _base(self, cfg: dict[str, Any]) -> str:
        return (cfg.get("api_base") or "http://localhost:11434").rstrip("/")


class OllamaAdapter(BaseAdapter):
    name = "ollama"

    def generate(self, cfg, prompt, max_tokens, temperature) -> str:
        url = self._base(cfg) + "/api/generate"
        resp = http_request(
            "POST", url, what="Ollama generate", cfg=cfg,
            json={
                "model": cfg["model"],
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens,
                },
            })
        data = resp.json()
        return (data.get("response") or "").strip()

    def stream(self, cfg, prompt, max_tokens, temperature):
        url = self._base(cfg) + "/api/generate"
        # Retry covers connection + status only; a mid-stream death is
        # surfaced by the consumer loop below.
        resp = http_request(
            "POST", url, what="Ollama streaming", cfg=cfg,
            json={
                "model": cfg["model"],
                "prompt": prompt,
                "stream": True,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens,
                },
            },
            stream=True)
        for line in resp.iter_lines():
            if not line:
                continue
            try:
                chunk = json.loads(line)
            except (json.JSONDecodeError, ValueError):
                continue
            if chunk.get("thinking") or chunk.get("reasoning"):
                # Ollama reasoning models (deepseek-r1:8b et al.) put
                # reasoning in a separate field — never emit it.
                continue
            text = chunk.get("response", "")
            if text:
                yield text, False
            if chunk.get("done"):
                yield "", True
                return
        yield "", True

    def list_models(self, cfg) -> list[str]:
        url = self._base(cfg) + "/api/tags"
        resp = http_request("GET", url, what="Ollama model list", cfg=cfg)
        data = resp.json()
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]


class OpenAICompatAdapter(BaseAdapter):
    name = "openai"

    def _headers(self, cfg) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if cfg.get("api_key"):
            headers["Authorization"] = f"Bearer {cfg['api_key']}"
        return headers

    def generate(self, cfg, prompt, max_tokens, temperature) -> str:
        url = self._base(cfg) + "/v1/chat/completions"
        resp = http_request(
            "POST", url, what="OpenAI-compatible generate", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "model": cfg["model"],
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": False,
            })
        data = resp.json()
        try:
            msg = data["choices"][0]["message"]
        except (KeyError, IndexError) as exc:
            raise AiProviderError(
                f"Malformed provider response: {exc}") from exc
        # Use `content` only — never reasoning_content / reasoning fields.
        content = (msg.get("content") or "").strip()
        if not content and (msg.get("reasoning_content") or msg.get("reasoning")):
            raise AiProviderError(
                "The AI model returned only reasoning/thinking text with no "
                "final answer. Try a non-reasoning model or increase max_tokens."
            )
        return content

    def stream(self, cfg, prompt, max_tokens, temperature):
        url = self._base(cfg) + "/v1/chat/completions"
        resp = http_request(
            "POST", url, what="OpenAI-compatible streaming", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "model": cfg["model"],
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": True,
            },
            stream=True)
        for line in resp.iter_lines():
            if not line:
                continue
            line_str = line.decode("utf-8", errors="replace")
            if line_str.startswith("data: "):
                line_str = line_str[6:]
            if line_str.strip() == "[DONE]":
                yield "", True
                return
            try:
                chunk = json.loads(line_str)
            except (json.JSONDecodeError, ValueError):
                continue
            try:
                delta = chunk.get("choices", [{}])[0].get("delta", {})
            except IndexError:
                continue
            # OpenAI-compat reasoning models put reasoning in
            # `reasoning` or `reasoning_content` (DeepSeek, GLM, QwQ).
            if delta.get("reasoning") or delta.get("reasoning_content"):
                continue
            text = delta.get("content", "")
            if text:
                yield text, False
        yield "", True

    def list_models(self, cfg) -> list[str]:
        url = self._base(cfg) + "/v1/models"
        resp = http_request("GET", url, what="OpenAI-compatible model list",
                            cfg=cfg, headers=self._headers(cfg))
        data = resp.json()
        return [m.get("id", "") for m in data.get("data", []) if m.get("id")]


class AnthropicAdapter(BaseAdapter):
    """Native Anthropic Messages API (``POST /v1/messages``)."""

    name = "anthropic"

    def _headers(self, cfg) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "x-api-key": cfg.get("api_key") or "",
            "anthropic-version": _ANTHROPIC_VERSION,
        }

    @staticmethod
    def _extract_text(data: dict) -> str:
        # Thinking blocks carry ``type: "thinking"`` — only text blocks are
        # joined, so extended-thinking responses stay clean.
        blocks = data.get("content") or []
        return "".join(
            b.get("text", "") for b in blocks if b.get("type") == "text"
        ).strip()

    def generate(self, cfg, prompt, max_tokens, temperature) -> str:
        url = self._base(cfg) + "/v1/messages"
        resp = http_request(
            "POST", url, what="Anthropic generate", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "model": cfg["model"],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "messages": [{"role": "user", "content": prompt}],
            })
        data = resp.json()
        text = self._extract_text(data)
        if not text:
            raise AiProviderError(
                "Anthropic returned no text content (only thinking blocks or "
                "an empty response). Raise max_tokens or disable extended "
                "thinking for this model."
            )
        return text

    def stream(self, cfg, prompt, max_tokens, temperature):
        url = self._base(cfg) + "/v1/messages"
        resp = http_request(
            "POST", url, what="Anthropic streaming", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "model": cfg["model"],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "messages": [{"role": "user", "content": prompt}],
                "stream": True,
            },
            stream=True)
        for line in resp.iter_lines():
            if not line:
                continue
            line_str = line.decode("utf-8", errors="replace")
            if line_str.startswith("data: "):
                line_str = line_str[6:]
            if not line_str.strip():
                continue
            try:
                event = json.loads(line_str)
            except (json.JSONDecodeError, ValueError):
                continue
            etype = event.get("type", "")
            if etype == "content_block_delta":
                delta = event.get("delta", {})
                # Skip thinking_delta; emit text_delta only.
                if delta.get("type") == "text_delta" and delta.get("text"):
                    yield delta["text"], False
            elif etype == "message_stop":
                yield "", True
                return
        yield "", True

    def list_models(self, cfg) -> list[str]:
        url = self._base(cfg) + "/v1/models"
        resp = http_request("GET", url, what="Anthropic model list", cfg=cfg,
                            headers=self._headers(cfg))
        data = resp.json()
        return [m.get("id", "") for m in data.get("data", []) if m.get("id")]


class GeminiAdapter(BaseAdapter):
    """Google Gemini — Generative Language API (v1beta)."""

    name = "gemini"

    def _headers(self, cfg) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "x-goog-api-key": cfg.get("api_key") or "",
        }

    @staticmethod
    def _url(base: str, model: str, method: str) -> str:
        return f"{base}/v1beta/models/{model}:{method}"

    @staticmethod
    def _extract_text(data: dict) -> str:
        try:
            parts = data["candidates"][0]["content"]["parts"]
        except (KeyError, IndexError, TypeError):
            return ""
        # Gemini thinking models mark internal parts with ``thought: true``.
        return "".join(
            p.get("text", "") for p in parts if not p.get("thought")
        ).strip()

    def generate(self, cfg, prompt, max_tokens, temperature) -> str:
        url = self._url(self._base(cfg), cfg["model"], "generateContent")
        resp = http_request(
            "POST", url, what="Gemini generate", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {
                    "maxOutputTokens": max_tokens,
                    "temperature": temperature,
                },
            })
        data = resp.json()
        text = self._extract_text(data)
        if not text:
            raise AiProviderError(
                "Gemini returned no text content. Check the model name, API "
                "key and safety settings; also try raising max_tokens."
            )
        return text

    def stream(self, cfg, prompt, max_tokens, temperature):
        url = self._url(self._base(cfg), cfg["model"], "streamGenerateContent")
        resp = http_request(
            "POST", url + "?alt=sse", what="Gemini streaming", cfg=cfg,
            headers=self._headers(cfg),
            json={
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {
                    "maxOutputTokens": max_tokens,
                    "temperature": temperature,
                },
            },
            stream=True)
        saw_any = False
        for line in resp.iter_lines():
            if not line:
                continue
            line_str = line.decode("utf-8", errors="replace")
            if line_str.startswith("data: "):
                line_str = line_str[6:]
            if not line_str.strip():
                continue
            try:
                chunk = json.loads(line_str)
            except (json.JSONDecodeError, ValueError):
                continue
            text = self._extract_text(chunk)
            if text:
                saw_any = True
                yield text, False
        yield "", True

    def list_models(self, cfg) -> list[str]:
        url = self._base(cfg) + "/v1beta/models"
        resp = http_request("GET", url, what="Gemini model list", cfg=cfg,
                            headers=self._headers(cfg))
        data = resp.json()
        out = []
        for m in data.get("models", []):
            name = (m.get("name") or "").removeprefix("models/")
            if name:
                out.append(name)
        return out


_ADAPTERS: dict[str, BaseAdapter] = {
    "ollama": OllamaAdapter(),
    "openai": OpenAICompatAdapter(),
    "anthropic": AnthropicAdapter(),
    "gemini": GeminiAdapter(),
}


def get_adapter(provider: str | None) -> BaseAdapter:
    """Return the adapter for ``provider``.

    Unknown/blank providers fall back to the OpenAI-compatible adapter
    (historical behavior: anything that is not Ollama speaks
    ``/v1/chat/completions``). The fallback logs a warning so typos in
    settings are discoverable.
    """
    key = (provider or "").strip().lower()
    adapter = _ADAPTERS.get(key)
    if adapter is None:
        log.warning("Unknown AI provider %r — using OpenAI-compatible adapter",
                    provider)
        adapter = _ADAPTERS["openai"]
    return adapter
