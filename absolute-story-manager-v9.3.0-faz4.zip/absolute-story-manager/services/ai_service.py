"""AI service — optional, opt-in hybrid AI (4 providers, F-01).

Providers (via services/ai_providers.py adapter layer):
Ollama (local), any OpenAI-compatible API, Anthropic native, Google Gemini.
All HTTP goes through a shared requests.Session with exponential-backoff
retry (3 attempts) and an explicit (connect, read) timeout policy.

Disabled unless ai.enabled = true in settings. Returns AiDisabledError
otherwise. Routes return 404 when disabled so AI is invisible by default.

Every AI action is logged to activity_log with entity_type='ai_action'.
Prompt text is NEVER stored — only action type + entity id + timestamp.

Rate limit: 30 requests per session per minute (configurable).
"""
from __future__ import annotations

import logging
import re  # v9.1.0 (M-05): was 26x __import__("re")
import threading
import time
from collections import deque
from typing import Any

import requests

from core.cache import cache
from core.db import read_session, write_transaction
from core.errors import AiDisabledError, AiProviderError
from models.settings import Setting
from services import ai_providers
from services._common import log_activity, new_uuid

log = logging.getLogger("asm.ai")


_THINK_BLOCK_RE = re.compile(r'<think(?:ing)?>.*?</think(?:ing)?>', re.DOTALL | re.IGNORECASE)
_THINK_UNCLOSED_RE = re.compile(r'<think(?:ing)?>.*$', re.DOTALL | re.IGNORECASE)
_THINK_TAG_RE = re.compile(r'</?think(?:ing)?>', re.IGNORECASE)
# v6.0: additional reasoning wrappers seen in the wild
_REASON_BLOCK_RE = re.compile(
    r'<(?:reasoning|thought|analysis|scratchpad|internal)>.*?</(?:reasoning|thought|analysis|scratchpad|internal)>',
    re.DOTALL | re.IGNORECASE)
_REASON_UNCLOSED_RE = re.compile(
    r'<(?:reasoning|thought|analysis|scratchpad|internal)>.*$',
    re.DOTALL | re.IGNORECASE)
_ANTHROPIC_RE = re.compile(
    r'<antThinking(?:ing)?>.*?</antThinking(?:ing)?>|<anthropic_thinking>.*?</anthropic_thinking>',
    re.DOTALL | re.IGNORECASE)
# Markdown code blocks labeled thinking/reasoning/internal
_THINK_MD_BLOCK_RE = re.compile(
    r'```(?:thinking|reasoning|internal|analysis|thought)\s*\n.*?\n```',
    re.DOTALL | re.IGNORECASE)
_THINK_MD_BLOCK_UNCLOSED_RE = re.compile(
    r'```(?:thinking|reasoning|internal|analysis|thought)\s*\n.*$',
    re.DOTALL | re.IGNORECASE)
# ```think ... ``` (short form seen with some GLM builds)
_THINK_MD_SHORT_RE = re.compile(
    r'```think\s*\n.*?```', re.DOTALL | re.IGNORECASE)
# **Thinking:** ... or **Reasoning:** ... or **Internal monologue:** ...
# until next **Heading:** or two blank lines or end of text
_THINK_MD_HEADER_RE = re.compile(
    r'\*\*(?:Thinking|Reasoning|Internal\s+monologue|Thought\s+process|Analysis|Reasoning\s+process|Step-by-step)\s*:?\*\*\s*\n.*?(?=\n\s*\*\*[^*]+\*\*|\n\s*\n\s*\n|\Z)',
    re.DOTALL | re.IGNORECASE)
# v6.0: "Thinking: ..." / "Reasoning: ..." plain-text headers (no bold)
_THINK_PLAIN_HEADER_RE = re.compile(
    r'^(?:Thinking|Reasoning|Reasoning\s+process)\s*:\s*\n.*?(?=\n\s*\n\s*\n|\n[A-Z][A-Za-z ]{2,30}:\s*\n|\Z)',
    re.DOTALL | re.IGNORECASE | re.MULTILINE)
# Lines that are clearly thinking prefixes (rare — be conservative)
# "Let me think about this..." or "First, let me consider..." at the start
_THINK_INTRO_RE = re.compile(
    r'^(?:Let me think about this.*|First, let me consider.*|I need to think.*|Let\'s reason through this.*|Okay,?\s+(?:so\s+)?(?:let me|the user).*)\n',
    re.IGNORECASE)


def _clean_thinking(text: str) -> str:
    """Remove thinking/reasoning blocks from reasoning model responses.

    Handles (case-insensitive):
    - <think>...</think> and <thinking>...</thinking> (XML-style)
    - <reasoning>/<thought>/<analysis>/<scratchpad>/<internal> blocks
    - <antThinking>/<anthropic_thinking> (Anthropic-style)
    - Unclosed blocks at end (model still thinking)
    - Markdown code blocks labeled ```thinking/```reasoning/```think
    - Markdown headers like **Thinking:** or **Reasoning:** followed by content
    - Plain-text "Thinking:" / "Reasoning:" headers
    - Stray thinking tags from streaming fragments
    - Conservative intro removal ("Let me think about this...")

    NEVER falls back to raw text — returns empty string if nothing remains.
    """
    if not text:
        return ""
    # 1. XML-style: <think>...</think> (and <thinking>...</thinking>) blocks
    text = _THINK_BLOCK_RE.sub('', text)
    # 2. Unclosed thinking block at end (model still thinking / no close tag)
    text = _THINK_UNCLOSED_RE.sub('', text)
    # 3. v6.0: other reasoning block flavors + Anthropic
    text = _REASON_BLOCK_RE.sub('', text)
    text = _REASON_UNCLOSED_RE.sub('', text)
    text = _ANTHROPIC_RE.sub('', text)
    # 4. Stray open/close tags (streaming fragments)
    text = _THINK_TAG_RE.sub('', text)
    # 5. Markdown code blocks labeled "thinking"/"reasoning"/"analysis" (closed)
    text = _THINK_MD_BLOCK_RE.sub('', text)
    text = _THINK_MD_SHORT_RE.sub('', text)
    # 6. Same but unclosed at end
    text = _THINK_MD_BLOCK_UNCLOSED_RE.sub('', text)
    # 7. **Thinking:** or **Reasoning:** markdown headers + their content
    text = _THINK_MD_HEADER_RE.sub('', text)
    # 8. v6.0: plain-text "Thinking:"/"Reasoning:" headers
    text = _THINK_PLAIN_HEADER_RE.sub('', text)
    # 9. Conservative intro lines ("Let me think about this...")
    text = _THINK_INTRO_RE.sub('', text)
    return text.strip()

# Rate limit: 30 requests per 60 seconds (sliding window)
_RATE_LIMIT = 30
_RATE_WINDOW = 60  # seconds
_request_times: deque = deque()
_rate_lock = threading.Lock()  # v9.1.0 (M-05)


def _check_rate_limit() -> None:
    """Raise AiProviderError if rate limit exceeded."""
    with _rate_lock:
        now = time.time()
        while _request_times and _request_times[0] < now - _RATE_WINDOW:
            _request_times.popleft()
        if len(_request_times) >= _RATE_LIMIT:
            from core.errors import AsmError
            raise AsmError(
                f"Rate limit exceeded ({_RATE_LIMIT} requests/{_RATE_WINDOW}s). Please wait.",
                code="rate_limited", status_code=429,
            )
        _request_times.append(now)


def is_enabled(session=None) -> bool:
    """Check if AI is enabled in settings."""
    if session is None:
        with read_session() as s:
            return bool(Setting.get(s, "ai.enabled", False))
    return bool(Setting.get(session, "ai.enabled", False))


def _get_config(session=None) -> dict[str, Any]:
    """Read the AI settings block.

    v9.0.1 (S-04): ``session`` is now optional — ``None`` opens its own
    ``read_session`` instead of crashing with ``AttributeError`` on
    ``None.query`` (this is exactly what broke ``/ai/models`` when AI was
    enabled). Callers inside a transaction still pass their session.
    """
    if session is None:
        with read_session() as s:
            return _get_config(s)
    return {
        "enabled": bool(Setting.get(session, "ai.enabled", False)),
        "provider": Setting.get(session, "ai.provider", "ollama") or "ollama",
        "api_base": Setting.get(session, "ai.api_base",
                                "http://localhost:11434") or "http://localhost:11434",
        "api_key": Setting.get(session, "ai.api_key", "") or "",
        "model": Setting.get(session, "ai.model", "") or "",
        # v6.0: optional fast/lightweight model for small tasks (names, tags).
        # Falls back to the main model when unset. Useful for routing around
        # reasoning models that burn the token budget on <think> blocks.
        "model_fast": Setting.get(session, "ai.model_fast", "") or "",
        "timeout": int(Setting.get(session, "ai.timeout_seconds", 60) or 60),
    }


# Tasks that are lightweight enough for a fast model when one is configured.
_FAST_TASKS = {"name_gen", "tags", "short_label"}


def _resolve_model(cfg: dict[str, Any], task: str | None) -> str:
    """Return the model to use: fast model for light tasks, main otherwise."""
    if task in _FAST_TASKS and cfg.get("model_fast"):
        return cfg["model_fast"]
    return cfg["model"]


def generate(prompt: str, *, max_tokens: int = 600,
             temperature: float = 0.7, task: str | None = None) -> str:
    """Generate text via the configured provider.

    Args:
        task: Optional task hint ("name_gen", "tags", ...). Light tasks are
            routed to ai.model_fast when configured (see _resolve_model).

    Raises AiDisabledError if disabled, AiProviderError on HTTP failure.
    Enforces a rate limit of 30 requests per 60 seconds.
    """
    with read_session() as s:
        cfg = _get_config(s)
    if not cfg["enabled"]:
        raise AiDisabledError()
    model = _resolve_model(cfg, task)
    if not model:
        raise AiProviderError("No AI model configured.")
    cfg = dict(cfg)
    cfg["model"] = model
    _check_rate_limit()
    adapter = ai_providers.get_adapter(cfg.get("provider"))
    raw = adapter.generate(cfg, prompt, max_tokens, temperature)
    cleaned = _clean_thinking(raw)
    if not cleaned:
        # v6.0: the response was ONLY reasoning/thinking (or empty).
        # Previously a "remove tags only" fallback leaked the raw thinking
        # text into the UI (e.g. name generator garbage). Never do that —
        # surface a clear, actionable error instead.
        log.warning("AI response was empty after cleaning thinking tags. Raw length: %d", len(raw or ""))
        raise AiProviderError(
            "The AI model returned only reasoning/thinking text with no final "
            "answer. Fix: use a non-reasoning model, increase max_tokens, or "
            "set a fast model for small tasks in Settings → AI."
        )
    return cleaned


# Backwards-compat alias — some routes call ai_service.complete() instead of generate()
complete = generate


# ----------------------------------------------------------------------------
# v6.0 — Robust JSON output handling
# ----------------------------------------------------------------------------

def _extract_json_candidates(text: str) -> list[str]:
    """Yield candidate JSON substrings from a messy model response, best first.

    Handles: fenced blocks, leading prose, trailing prose, multiple blocks,
    arrays, objects. Does NOT parse — just extracts candidates.
    """
    import re as _re
    candidates: list[str] = []

    # 1. Fenced code blocks (```json ... ``` or ``` ... ```)
    for m in _re.finditer(r"```(?:json)?\s*\n(.*?)```", text, _re.DOTALL):
        candidates.append(m.group(1).strip())

    # 2. Outermost balanced {..} and [..] spans (scored by span length)
    for opener, closer in (("{", "}"), ("[", "]")):
        depth = 0
        start = -1
        for i, ch in enumerate(text):
            if ch == opener:
                if depth == 0:
                    start = i
                depth += 1
            elif ch == closer and depth > 0:
                depth -= 1
                if depth == 0 and start >= 0:
                    candidates.append(text[start:i + 1])
        # (unbalanced spans are simply skipped)

    # Deduplicate, keep order, drop tiny fragments
    seen: set[str] = set()
    out: list[str] = []
    for c in candidates:
        if len(c) >= 2 and c not in seen:
            seen.add(c)
            out.append(c)
    # Prefer longer candidates (more likely complete)
    out.sort(key=len, reverse=True)
    return out


def _repair_json(s: str) -> str:
    """Best-effort repairs for common LLM JSON defects."""
    import re as _re
    t = s.strip()
    # Strip // line comments (never valid inside strings in practice here)
    t = _re.sub(r"^\s*//.*$", "", t, flags=_re.MULTILINE)
    # Smart quotes → straight quotes
    t = t.replace("\u201c", '"').replace("\u201d", '"')
    # Remove trailing commas before } or ]
    t = _re.sub(r",\s*([\]}])", r"\1", t)
    # Python-isms: True/False/None → true/false/null
    t = _re.sub(r"\bTrue\b", "true", t)
    t = _re.sub(r"\bFalse\b", "false", t)
    t = _re.sub(r"\bNone\b", "null", t)
    return t


def complete_json(prompt: str, *, max_tokens: int = 600,
                  temperature: float = 0.5,
                  task: str | None = None) -> Any:
    """Generate and parse a JSON response, surviving messy model output.

    Pipeline: generate → clean thinking → strip fences → balanced-span
    extraction → parse → repair → parse. Raises AiProviderError when no valid
    JSON can be recovered.
    """
    import json as _json
    out = generate(prompt, max_tokens=max_tokens, temperature=temperature,
                   task=task)
    if not out:
        raise AiProviderError("Empty AI response while expecting JSON.")
    # Fast path: already valid JSON
    try:
        return _json.loads(out)
    except (ValueError, TypeError):
        pass
    for candidate in _extract_json_candidates(out):
        for attempt in (candidate, _repair_json(candidate)):
            try:
                return _json.loads(attempt)
            except (ValueError, TypeError):
                continue
    raise AiProviderError(
        f"Could not parse JSON from AI response (got {len(out)} chars). "
        "Try a non-reasoning model, raise max_tokens, or configure a fast "
        "model for structured tasks in Settings → AI."
    )


def generate_streaming(prompt: str, *, max_tokens: int = 600,
                       temperature: float = 0.7):
    """Generator that yields text chunks for streaming display.

    Supports Ollama's native streaming API. For OpenAI-compatible providers,
    uses SSE streaming. Yields (chunk_text, is_final) tuples.

    Thinking/reasoning blocks (```<think>...</think>``` or ```<thinking>...</thinking>```)
    are filtered out STATEFULLY — even when they span multiple stream chunks.
    OpenAI-compat providers that put reasoning in a separate ``reasoning_content``
    field (DeepSeek-R1, GLM-4.5, QwQ, etc.) are also stripped.
    """
    with read_session() as s:
        cfg = _get_config(s)
    if not cfg["enabled"]:
        raise AiDisabledError()
    if not cfg["model"]:
        raise AiProviderError("No AI model configured.")
    _check_rate_limit()
    adapter = ai_providers.get_adapter(cfg.get("provider"))
    thinking_filter = _ThinkingStreamFilter()
    for text, is_final in adapter.stream(cfg, prompt, max_tokens, temperature):
        if text:
            filtered = thinking_filter.feed(text)
            if filtered:
                yield (filtered, False)
        if is_final:
            final = thinking_filter.flush()
            if final:
                yield (final, False)
            yield ("", True)
            return


def list_models(session=None) -> list[str]:
    """List available models from the configured provider.

    v9.2.0 (F-01): centralized here (was inline in routes/ai.py) so every
    provider speaks the same interface and benefits from retry/timeout.
    Raises AiProviderError on transport failure (the route wraps it).
    """
    cfg = _get_config(session)
    adapter = ai_providers.get_adapter(cfg.get("provider"))
    return adapter.list_models(cfg)


class _ThinkingStreamFilter:
    """Stateful filter that suppresses ```<think>...</think>``` blocks across chunk boundaries.

    Reasoning models (DeepSeek-R1, GLM-4.5, QwQ, etc.) wrap their internal
    reasoning in ```<think>…``` or ```<thinking>…</thinking>``` tags. When streaming,
    these tags span multiple chunks, so per-chunk regex cleanup does NOT work.

    This filter maintains state (inside/outside thinking) and only emits text
    that falls OUTSIDE a thinking block.
    """

    _OPEN_RE = re.compile(
        r'<think(?:ing)?>', re.IGNORECASE)
    _CLOSE_RE = re.compile(
        r'</think(?:ing)?>', re.IGNORECASE)
    # Safety: keep last 12 chars in case a tag spans a chunk boundary
    _SAFETY_MARGIN = 12

    def __init__(self):
        self._buffer = ""
        self._inside_thinking = False

    def feed(self, text: str) -> str:
        """Accept a chunk, return the safe-to-emit text."""
        if not text:
            return ""
        self._buffer += text
        emit = ""
        while self._buffer:
            if self._inside_thinking:
                # Look for the closing </think> or </thinking> tag
                m = self._CLOSE_RE.search(self._buffer)
                if m:
                    # Discard everything up to and including the close tag
                    self._buffer = self._buffer[m.end():]
                    self._inside_thinking = False
                    continue
                else:
                    # Still inside thinking; discard everything (buffer now empty
                    # of emit-able text). Keep last _SAFETY_MARGIN chars in case
                    # the close tag spans the next chunk boundary.
                    if len(self._buffer) > self._SAFETY_MARGIN:
                        self._buffer = self._buffer[-self._SAFETY_MARGIN:]
                    break
            else:
                # Look for the opening <think> or <thinking> tag
                m = self._OPEN_RE.search(self._buffer)
                if m:
                    # Emit text BEFORE the opener
                    emit += self._buffer[:m.start()]
                    # Skip the opener
                    self._buffer = self._buffer[m.end():]
                    self._inside_thinking = True
                    continue
                else:
                    # No opener in buffer — emit safe text but keep the margin
                    if len(self._buffer) > self._SAFETY_MARGIN:
                        safe_len = len(self._buffer) - self._SAFETY_MARGIN
                        emit += self._buffer[:safe_len]
                        self._buffer = self._buffer[safe_len:]
                    break
        return emit

    def flush(self) -> str:
        """Emit any remaining buffer content at stream end."""
        if self._inside_thinking or not self._buffer:
            return ""
        # At end of stream, any leftover buffer is safe to emit
        out = self._buffer
        self._buffer = ""
        return out


def _log_ai_action(action: str, entity_id: str | None = None,
                   entity_title: str | None = None,
                   details: dict | None = None) -> None:
    """Log AI usage to activity_log. Prompt body is NEVER stored."""
    try:
        with write_transaction() as s:
            log_activity(
                s,
                entity_type="ai_action",
                entity_id=entity_id or new_uuid(),
                entity_title=entity_title or action,
                action=action,
                details=details or {},
            )
    except Exception as exc:
        log.warning("Failed to log AI action: %s", exc)


def continue_writing(chapter_tail: str | None, *, max_tokens: int = 400,
                     entity_id: str | None = None) -> str:
    """Suggest the next paragraph(s) given the end of a chapter."""
    # v9.0.1 (S-09/ruff): nested "" quotes inside the f-string made this
    # line a SyntaxError on Python 3.11 (project requires >=3.11).
    tail = (chapter_tail or "")[-1000:]
    prompt = (
        "Continue the following story text in the same style and tone. "
        "Return only the continuation, no preamble.\n\n"
        f"...{tail}"
    )
    result = generate(prompt, max_tokens=max_tokens, temperature=0.8)
    _log_ai_action("continue_writing", entity_id=entity_id,
                   details={"max_tokens": max_tokens})
    return result


def continue_with_context(chapter_tail: str, *,
                          character_profiles: list[dict] | None = None,
                          world_entries: list[dict] | None = None,
                          recent_summaries: list[str] | None = None,
                          tone: str = "",
                          max_tokens: int = 500,
                          entity_id: str | None = None) -> str:
    """Context-aware continuation: sends character/world context + recent chapter summaries.

    This produces much better results than continue_writing() because the AI
    knows the characters, world, and recent plot events.
    """
    parts = ["You are a skilled fiction writer. Continue the story in the same style and tone."]
    parts.append("Return ONLY the continuation text, no preamble or commentary.\n")

    # Add character context
    if character_profiles:
        parts.append("CHARACTERS IN THIS SCENE:")
        for c in character_profiles[:8]:
            parts.append(f"- {c.get('name', '?')}: {(c.get('physical') or '')[:80]}")
            if c.get('voice'):
                parts.append(f"  Voice: {c['voice'][:80]}")
            if c.get('psychology'):
                parts.append(f"  Personality: {c['psychology'][:80]}")
        parts.append("")

    # Add world context
    if world_entries:
        parts.append("WORLD/SETTING:")
        for w in world_entries[:5]:
            parts.append(f"- {w.get('name', '?')} ({w.get('type', '?')}): {(w.get('description') or '')[:80]}")
        parts.append("")

    # Add recent plot context
    if recent_summaries:
        parts.append("RECENT EVENTS:")
        for i, s in enumerate(recent_summaries[-3:], 1):
            parts.append(f"  Chapter {i}: {s[:150]}")
        parts.append("")

    if tone:
        parts.append(f"DESIRED TONE: {tone}")
        parts.append("")

    # Add the actual text to continue
    parts.append("TEXT TO CONTINUE:")
    parts.append(chapter_tail[-1500:])

    prompt = "\n".join(parts)
    result = generate(prompt, max_tokens=max_tokens, temperature=0.8)
    _log_ai_action("continue_with_context", entity_id=entity_id,
                   details={"max_tokens": max_tokens,
                            "has_chars": bool(character_profiles),
                            "has_world": bool(world_entries),
                            "has_summaries": bool(recent_summaries)})
    return result


def summarize(text: str, *, max_tokens: int = 200,
              entity_id: str | None = None) -> str:
    prompt = (
        "Summarize the following text in 1-3 sentences. "
        "Return only the summary.\n\n" + text[:4000]
    )
    result = generate(prompt, max_tokens=max_tokens, temperature=0.5)
    _log_ai_action("summarize", entity_id=entity_id)
    return result


def rewrite(text: str, tone: str, *, max_tokens: int = 600,
            entity_id: str | None = None) -> str:
    prompt = (
        f"Rewrite the following text in a {tone} tone. "
        "Return only the rewritten text.\n\n" + text[:4000]
    )
    result = generate(prompt, max_tokens=max_tokens, temperature=0.7)
    _log_ai_action("rewrite", entity_id=entity_id, details={"tone": tone})
    return result


def suggest_tags(text: str, *, max_tokens: int = 60,
                 entity_id: str | None = None) -> list[str]:
    prompt = (
        "Suggest 3-5 short tags (single words or short phrases, comma-separated) "
        "for the following text. Return only the tags.\n\n" + text[:2000]
    )
    out = generate(prompt, max_tokens=max_tokens, temperature=0.4, task="tags")
    tags = [t.strip() for t in out.split(",") if t.strip()][:10]
    _log_ai_action("suggest_tags", entity_id=entity_id,
                   details={"count": len(tags)})
    return tags


def suggest_synopsis(text: str, *, max_tokens: int = 120,
                     entity_id: str | None = None) -> str:
    prompt = (
        "Write a 1-2 sentence synopsis for the following chapter. "
        "Return only the synopsis.\n\n" + text[:4000]
    )
    result = generate(prompt, max_tokens=max_tokens, temperature=0.5)
    _log_ai_action("suggest_synopsis", entity_id=entity_id)
    return result


def _valid_name_line(line: str) -> str | None:
    """Return a cleaned name if the line looks like an actual name, else None.

    Rejects: sentences, thinking leftovers, numbered-preamble-only lines,
    lines with sentence punctuation, over-long lines.
    """
    import re as _re
    s = line.strip().strip('"').strip("'").strip("`*•-–— ")
    # Strip leading numbering: "1." "2)" " - "
    s = _re.sub(r"^\d[\.\)]\s*", "", s)
    if not s or len(s) < 2 or len(s) > 48:
        return None
    # Names don't contain sentence punctuation or brackets
    if _re.search(r"[.!?,;:()\[\]{}<>]", s):
        return None
    # Must contain at least one letter (any script)
    if not _re.search(r"\w", s, _re.UNICODE):
        return None
    # Reject obvious thinking-style prose (4+ lowercase words in a row)
    if len(s.split()) > 5:
        return None
    return s


def generate_name(culture: str = "fantasy", kind: str = "character",
                  *, max_tokens: int = 400) -> list[str]:
    """Generate names with caching — same culture+kind returns cached result for 5 min.

    v6.0 fixes for reasoning models:
    - max_tokens raised (30 → 400) so <think> blocks don't eat the budget
    - prompt explicitly forbids reasoning/commentary
    - every line validated via _valid_name_line (no sentence leakage)
    - garbage responses are never cached
    - routed to the fast model when one is configured (task="name_gen")
    """
    cache_key = f"ai:name_gen:{culture}:{kind}"
    cached_names = cache.get(cache_key)
    if cached_names is not None:
        return cached_names
    prompt = (
        f"Suggest 8 {culture}-style names for a {kind} in fiction. "
        "Rules: plain names only, one per line, no numbering, no explanations, "
        "no commentary, no reasoning. First line must already be a name.\n"
        "Example format:\nKael\nSeraphine\nThorne"
    )
    out = generate(prompt, max_tokens=max_tokens, temperature=0.9,
                   task="name_gen")
    names: list[str] = []
    for line in (out or "").splitlines():
        cleaned = _valid_name_line(line)
        if cleaned and cleaned.casefold() not in {n.casefold() for n in names}:
            names.append(cleaned)
    names = names[:5]
    _log_ai_action("generate_name", details={
        "culture": culture, "kind": kind, "got": len(names)})
    # Only cache a GOOD response — never cache garbage that would stick for 5 min
    if len(names) >= 3:
        cache.set(cache_key, names, ttl_seconds=300)  # 5 min cache
    return names


def generate_dialogue(character_name: str, character_voice: str,
                      character_psychology: str,
                      other_character: str = "",
                      scene_context: str = "",
                      emotion: str = "neutral",
                      *, max_tokens: int = 300,
                      entity_id: str | None = None) -> str:
    """Generate dialogue in a character's voice.

    Args:
        character_name: The speaking character's name.
        character_voice: How they speak (dialect, vocabulary, verbal tics).
        character_psychology: Personality, fears, motivations.
        other_character: Who they're talking to (optional).
        scene_context: What's happening in the scene.
        emotion: angry, sad, happy, fearful, sarcastic, neutral.

    Returns: Generated dialogue text (no quotation marks, just the spoken words).
    """
    parts = [
        f"You are writing dialogue for {character_name}, a character in a novel.",
        f"\nCHARACTER VOICE: {character_voice or 'No specific voice notes.'}",
        f"\nCHARACTER PERSONALITY: {character_psychology or 'No personality notes.'}",
    ]
    if other_character:
        parts.append(f"\nSPEAKING TO: {other_character}")
    if scene_context:
        parts.append(f"\nSCENE CONTEXT: {scene_context}")
    parts.append(f"\nEMOTION: {emotion}")
    parts.append(
        f"\nWrite 3-5 lines of dialogue for {character_name}. "
        "Return ONLY the spoken words (no narration, no action tags, no quotation marks). "
        "Each line on its own line."
    )
    prompt = "\n".join(parts)
    result = generate(prompt, max_tokens=max_tokens, temperature=0.8)
    _log_ai_action("generate_dialogue", entity_id=entity_id,
                   details={"character": character_name, "emotion": emotion})
    return result


def consistency_check(chapter_texts: list[dict],
                      character_profiles: list[dict],
                      world_entries: list[dict]) -> list[dict]:
    """Scan chapters for contradictions against character/world DB.

    chapter_texts: [{"title": ..., "content": ...}, ...]
    character_profiles: [{"name": ..., "physical": ..., "psychology": ...}, ...]
    world_entries: [{"name": ..., "type": ..., "description": ...}, ...]

    Returns a list of findings, each: {severity, category, chapter, message}.
    The user reviews these before any change is made — AI never edits.
    """
    # Build a compact context summary (under 4000 chars to fit most models)
    char_summary = "\n".join(
        f"- {c.get('name', '?')}: {(c.get('physical') or '')[:100]} | "
        f"{(c.get('psychology') or '')[:100]}"
        for c in character_profiles[:20]
    )
    world_summary = "\n".join(
        f"- {w.get('name', '?')} ({w.get('type', '?')}): {(w.get('description') or '')[:80]}"
        for w in world_entries[:20]
    )
    chapter_summary = "\n\n".join(
        f"CHAPTER: {ch.get('title', '?')}\n{(ch.get('content') or '')[:1500]}"
        for ch in chapter_texts[:5]
    )
    prompt = (
        "You are a story consistency checker. Read the chapters below and the "
        "character/world reference. Find any contradictions, e.g.:\n"
        "- A character's eye color differs across chapters\n"
        "- A character dies in chapter 1 but reappears in chapter 3\n"
        "- A location's description contradicts earlier text\n"
        "- Timeline inconsistencies (events out of order)\n\n"
        "CHARACTERS:\n" + char_summary + "\n\n"
        "WORLD:\n" + world_summary + "\n\n"
        "CHAPTERS:\n" + chapter_summary + "\n\n"
        "Return findings as a JSON array, one per line, each object with keys: "
        "severity (error/warning), category (character/world/timeline), "
        "chapter (title), message (1-2 sentences). "
        "Return ONLY the JSON array, no preamble."
    )
    out = generate(prompt, max_tokens=800, temperature=0.3)
    # v6.0: use the robust JSON recovery pipeline instead of a raw regex
    import json
    findings = None
    for candidate in _extract_json_candidates(out or ""):
        for attempt in (candidate, _repair_json(candidate)):
            try:
                parsed_val = json.loads(attempt)
                if isinstance(parsed_val, list):
                    findings = parsed_val
                    break
            except json.JSONDecodeError:
                continue
        if findings is not None:
            break
    if findings is not None:
        _log_ai_action("consistency_check", details={"findings": len(findings)})
        return findings
    # Fallback: return the raw text as a single info finding
    _log_ai_action("consistency_check", details={"findings": 0, "fallback": True})
    return [{
        "severity": "info",
        "category": "ai_response",
        "chapter": "",
        "message": out[:500] if out else "No findings returned.",
    }]
