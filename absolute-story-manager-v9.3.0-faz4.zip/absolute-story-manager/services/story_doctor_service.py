"""Story Doctor — v6.4: one-click manuscript health report.

Aggregates the app's scattered analysis tools into a single checkup:
- Story Lint (7 mechanical checks)
- Word Frequency (overused words + repeated phrases)
- Glossary & Style consistency scan
- Timeline audit (ordering conflicts, gaps)
- Pacing summary (tension, rhythm)
- Structure stats (chapters, words, cast, world)

From these it computes a 0-100 health score with letter grades, a weighted
breakdown, and prioritized human-readable recommendations.

Pure-local analysis (no AI, no network). The optional AI deep-check is a
separate button on the page that calls the existing /ai/consistency-check.
"""
from __future__ import annotations

import logging
from typing import Any

from core.db import read_session
from models.chapter import Chapter
from models.character import Character
from models.world import WorldEntry

log = logging.getLogger("asm.story_doctor")

# ---- Score weights (how many points each finding category costs) ----
_WEIGHTS = {
    "lint_error": 3.0,
    "lint_warning": 1.0,
    "lint_info": 0.25,
    "overused_word": 2.0,
    "repeated_phrase": 1.0,
    "glossary_forbidden": 3.0,
    "glossary_near_miss": 1.0,
    "timeline_issue": 3.0,
    "timeline_gap": 0.5,
    "missing_synopsis": 1.0,
    "thin_chapter": 1.5,
    "flat_pacing": 5.0,
}
# Caps per category so one noisy check can't dominate the whole score
_CAPS = {
    "lint_error": 24,
    "lint_warning": 18,
    "lint_info": 6,
    "overused_word": 14,
    "repeated_phrase": 8,
    "glossary_forbidden": 12,
    "glossary_near_miss": 6,
    "timeline_issue": 12,
    "timeline_gap": 4,
    "missing_synopsis": 8,
    "thin_chapter": 9,
    "flat_pacing": 5,
}

_THIN_CHAPTER_WORDS = 150  # chapters below this are "thin"


def _grade(score: float) -> dict[str, str]:
    if score >= 90:
        return {"grade": "A", "label": "Excellent", "color": "success"}
    if score >= 75:
        return {"grade": "B", "label": "Healthy", "color": "success"}
    if score >= 55:
        return {"grade": "C", "label": "Needs attention", "color": "warning"}
    if score >= 35:
        return {"grade": "D", "label": "Needs work", "color": "warning"}
    return {"grade": "E", "label": "Intensive care", "color": "danger"}


def _clamp_penalties(penalties: dict[str, float]) -> dict[str, float]:
    return {k: min(v, _CAPS.get(k, v)) for k, v in penalties.items()}


def full_checkup() -> dict[str, Any]:
    """Run every local analysis and assemble the health report."""
    report: dict[str, Any] = {
        "ok": True,
        "structure": {},
        "lint": None,
        "word_freq": None,
        "glossary": None,
        "timeline": None,
        "pacing": None,
        "penalties": {},
        "score": 100,
        "grade": {},
        "breakdown": [],
        "recommendations": [],
        "checks_ran": [],
    }

    # ------------------------------------------------------------- structure
    with read_session() as s:
        from sqlalchemy import select

        from services._common import current_project_id
        pid = current_project_id(s)
        chapters = list(s.scalars(
            select(Chapter)
            .where(Chapter.project_id == pid)
            .order_by(Chapter.sort_order.asc())
        ))
        char_count = s.query(Character).filter_by(project_id=pid).count()
        world_count = s.query(WorldEntry).filter_by(project_id=pid).count()

    total_words = sum(c.word_count or 0 for c in chapters)
    missing_synopsis = sum(1 for c in chapters if not (c.synopsis or "").strip())
    thin_chapters = [
        {"id": c.id, "title": c.title, "words": c.word_count or 0}
        for c in chapters
        if (c.word_count or 0) < _THIN_CHAPTER_WORDS and (c.content or "").strip()
    ]
    report["structure"] = {
        "chapters": len(chapters),
        "total_words": total_words,
        "characters": char_count,
        "world_entries": world_count,
        "missing_synopsis": missing_synopsis,
        "thin_chapters": thin_chapters,
        "avg_chapter_words": round(total_words / len(chapters)) if chapters else 0,
    }

    penalties: dict[str, float] = {
        "missing_synopsis": missing_synopsis * _WEIGHTS["missing_synopsis"],
        "thin_chapter": len(thin_chapters) * _WEIGHTS["thin_chapter"],
    }

    # ------------------------------------------------------------------ lint
    try:
        from services import lint_service
        lint = lint_service.lint_all()
        report["lint"] = lint
        report["checks_ran"].append("lint")
        summ = lint.get("summary", {})
        penalties["lint_error"] = summ.get("errors", 0) * _WEIGHTS["lint_error"]
        penalties["lint_warning"] = summ.get("warnings", 0) * _WEIGHTS["lint_warning"]
        penalties["lint_info"] = summ.get("info", 0) * _WEIGHTS["lint_info"]
    except Exception as exc:
        log.warning("Story Doctor: lint failed: %s", exc)

    # ------------------------------------------------------------ word freq
    try:
        from services import word_freq_service
        wf = word_freq_service.analyze_manuscript(top_n=30)
        report["word_freq"] = {
            "overused": wf.get("overused", [])[:10],
            "repeated_2": wf.get("repeated_2", [])[:8],
            "repeated_3": wf.get("repeated_3", [])[:6],
            "total_words": wf.get("total_words", 0),
            "lexical_diversity": wf.get("lexical_diversity"),
        }
        report["checks_ran"].append("word_freq")
        penalties["overused_word"] = len(wf.get("overused", [])) * _WEIGHTS["overused_word"]
        penalties["repeated_phrase"] = (
            len(wf.get("repeated_2", [])) + len(wf.get("repeated_3", []))
        ) * _WEIGHTS["repeated_phrase"]
    except Exception as exc:
        log.warning("Story Doctor: word freq failed: %s", exc)

    # --------------------------------------------------------------- glossary
    try:
        from services import glossary_service
        gl = glossary_service.scan_chapters()
        forbidden = [i for i in gl.get("issues", []) if i.get("type") == "forbidden"]
        near_miss = [i for i in gl.get("issues", []) if i.get("type") == "near_miss"]
        report["glossary"] = {
            "issues": gl.get("issues", [])[:12],
            "forbidden_count": len(forbidden),
            "near_miss_count": len(near_miss),
            "terms_tracked": len(gl.get("presence", [])),
        }
        report["checks_ran"].append("glossary")
        penalties["glossary_forbidden"] = len(forbidden) * _WEIGHTS["glossary_forbidden"]
        penalties["glossary_near_miss"] = len(near_miss) * _WEIGHTS["glossary_near_miss"]
    except Exception as exc:
        log.warning("Story Doctor: glossary failed: %s", exc)

    # --------------------------------------------------------------- timeline
    try:
        from services import timeline_check_service
        tl = timeline_check_service.detect_conflicts()
        report["timeline"] = {
            "issues": tl.get("issues", [])[:10],
            "gaps": tl.get("gaps", [])[:6],
            "total_events": tl.get("total_events", 0),
            "parsed_events": tl.get("parsed_events", 0),
        }
        report["checks_ran"].append("timeline")
        penalties["timeline_issue"] = len(tl.get("issues", [])) * _WEIGHTS["timeline_issue"]
        penalties["timeline_gap"] = len(tl.get("gaps", [])) * _WEIGHTS["timeline_gap"]
    except Exception as exc:
        log.warning("Story Doctor: timeline failed: %s", exc)

    # ---------------------------------------------------------------- pacing
    try:
        from services import pacing_service
        pac = pacing_service.analyze_all()
        summ = pac.get("summary", {})
        report["pacing"] = {
            "avg_tension": summ.get("avg_tension"),
            "overall_rhythm": summ.get("overall_rhythm"),
            "avg_chapter_words": summ.get("avg_chapter_words"),
            "longest": summ.get("longest"),
            "shortest": summ.get("shortest"),
        }
        report["checks_ran"].append("pacing")
        rhythm = (summ.get("overall_rhythm") or "").lower()
        if "flat" in rhythm or "monoton" in rhythm:
            penalties["flat_pacing"] = _WEIGHTS["flat_pacing"]
    except Exception as exc:
        log.warning("Story Doctor: pacing failed: %s", exc)

    # ------------------------------------------------------- score + grading
    penalties = _clamp_penalties(penalties)
    report["penalties"] = {k: round(v, 1) for k, v in penalties.items()}
    total_penalty = sum(penalties.values())
    report["score"] = int(max(0, min(100, round(100 - total_penalty))))
    report["grade"] = _grade(report["score"])

    # Breakdown: biggest cost first, for the UI bars
    labels = {
        "lint_error": "Style errors", "lint_warning": "Style warnings",
        "lint_info": "Style notes", "overused_word": "Overused words",
        "repeated_phrase": "Repeated phrases", "glossary_forbidden": "Glossary violations",
        "glossary_near_miss": "Glossary near-misses", "timeline_issue": "Timeline conflicts",
        "timeline_gap": "Timeline gaps", "missing_synopsis": "Missing synopses",
        "thin_chapter": "Very short chapters", "flat_pacing": "Flat pacing",
    }
    report["breakdown"] = [
        {"key": k, "label": labels.get(k, k), "cost": round(v, 1)}
        for k, v in sorted(penalties.items(), key=lambda kv: -kv[1]) if v > 0
    ]

    report["recommendations"] = _recommendations(report)
    return report


def _recommendations(report: dict[str, Any]) -> list[dict[str, Any]]:
    """Prioritized, actionable advice with links to the right tool."""
    recs: list[dict[str, Any]] = []
    st = report.get("structure", {})

    def add(priority: int, icon: str, text: str, url: str | None = None):
        recs.append({"priority": priority, "icon": icon, "text": text, "url": url})

    # Highest impact first
    lint = report.get("lint") or {}
    lsum = lint.get("summary", {})
    if lsum.get("errors", 0):
        add(1, "⚠", f"{lsum['errors']} style errors need fixing (repeated words, name typos…)", "/lint/")
    tl = report.get("timeline") or {}
    if len(tl.get("issues", [])):
        add(2, "🕐", f"{len(tl['issues'])} timeline conflicts detected", "/timeline-check/")
    gl = report.get("glossary") or {}
    if gl.get("forbidden_count"):
        add(3, "📖", f"{gl['forbidden_count']} forbidden term variants in use", "/glossary/scan")
    wf = report.get("word_freq") or {}
    if wf.get("overused"):
        words = ", ".join(w["word"] for w in wf["overused"][:5])
        add(4, "📊", f"Overused words: {words}", "/word-freq/")
    if st.get("missing_synopsis"):
        add(5, "📝", f"{st['missing_synopsis']} chapters have no synopsis (weakens AI plot memory)", "/chapters/")
    if st.get("thin_chapters"):
        add(6, "✂", f"{len(st['thin_chapters'])} very short chapters (<{_THIN_CHAPTER_WORDS} words)")
    if wf.get("repeated_2"):
        add(7, "🔁", f"{len(wf['repeated_2'])} repeated 2-word phrases", "/word-freq/")
    pac = report.get("pacing") or {}
    if pac.get("overall_rhythm") and "flat" in (pac["overall_rhythm"] or "").lower():
        add(8, "📈", "Pacing looks flat — consider varying scene intensity", "/pacing/")
    if not st.get("chapters"):
        add(9, "✍", "No chapters yet — start writing, then come back for a checkup", "/chapters/new")
    elif not recs:
        add(10, "✓", "No significant issues found. Keep writing!", None)

    recs.sort(key=lambda r: r["priority"])
    return recs
