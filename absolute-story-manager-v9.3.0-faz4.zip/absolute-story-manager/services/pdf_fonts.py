"""Unicode-safe PDF font resolution for ReportLab.

WHY THIS EXISTS
---------------
ReportLab's built-in Type-1 fonts (Times-Roman, Helvetica, Courier) only
cover WinAnsi (Latin-1-ish). Characters outside it — Turkish ğ ş ı İ, and
most non-Latin scripts — are SILENTLY corrupted: "Boğaz" renders as
"Bonaz". Every PDF this app produced before v8.7 had that latent bug for
Turkish users.

This module probes common system TTF locations (Linux / Windows / macOS)
and registers a serif + sans family, each with regular / bold / italic /
bold-italic faces (falling back to the family's regular face when a
style file is missing — the text stays correct, only the slant is lost).
When no TTF can be found anywhere, we fall back to the built-in faces so
English-only users still get output.

Usage:
    from services import pdf_fonts
    faces = pdf_fonts.ensure_fonts()          # idempotent
    style = ParagraphStyle(..., fontName=pdf_fonts.body_font())

Families register under stable names:
    ASM-Serif / ASM-Serif-Bold / ASM-Serif-Italic / ASM-Serif-BoldItalic
    ASM-Sans  / …
so ``<b>``/``<i>`` markup inside Paragraph() works through
registerFontFamily().
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Dict, List, Tuple

log = logging.getLogger("asm.pdf_fonts")

_LOCK = threading.Lock()
_STATE: Dict[str, Tuple[str, str, str, str]] = {}
_PROBED = False

# Family probe lists. Each entry: (regular, bold, italic, bold-italic)
# Paths are tried in order; first complete-enough family wins.
# Linux: DejaVu / Liberation / Noto / WQY / FreeFont
# Windows: Times New Roman / Georgia / Arial / Calibri (Cambria is .ttc — unusable)
# macOS: Supplemental fonts directory
_CANDIDATES: List[Dict[str, Tuple[str, str, str, str]]] = [
    {  # DejaVu (very common on Linux; full Unicode coverage)
        "serif": (
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif-BoldItalic.ttf",
        ),
        "sans": (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-BoldOblique.ttf",
        ),
    },
    {  # Liberation (metric-compatible with Times/Arial)
        "serif": (
            "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSerif-BoldItalic.ttf",
        ),
        "sans": (
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-BoldItalic.ttf",
        ),
    },
    {  # Noto Serif/Sans SC + generic Noto layout
        "serif": (
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Regular.otf",
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Bold.otf",
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Regular.otf",
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Bold.otf",
        ),
        "sans": (
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Bold.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Bold.ttf",
        ),
    },
    {  # GNU FreeFont
        "serif": (
            "/usr/share/fonts/truetype/freefont/FreeSerif.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSerifItalic.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSerifBoldItalic.ttf",
        ),
        "sans": (
            "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansOblique.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBoldOblique.ttf",
        ),
    },
    {  # Windows
        "serif": (
            "C:\\Windows\\Fonts\\times.ttf",
            "C:\\Windows\\Fonts\\timesbd.ttf",
            "C:\\Windows\\Fonts\\timesi.ttf",
            "C:\\Windows\\Fonts\\timesbi.ttf",
        ),
        "sans": (
            "C:\\Windows\\Fonts\\arial.ttf",
            "C:\\Windows\\Fonts\\arialbd.ttf",
            "C:\\Windows\\Fonts\\ariali.ttf",
            "C:\\Windows\\Fonts\\arialbi.ttf",
        ),
    },
    {  # macOS
        "serif": (
            "/System/Library/Fonts/Supplemental/Times New Roman.ttf",
            "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf",
            "/System/Library/Fonts/Supplemental/Times New Roman Italic.ttf",
            "/System/Library/Fonts/Supplemental/Times New Roman Bold Italic.ttf",
        ),
        "sans": (
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/System/Library/Fonts/Supplemental/Arial Italic.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold Italic.ttf",
        ),
    },
    {  # Home-dir fontconfig / user-installed (Linux)
        "serif": (
            str(Path.home() / ".fonts" / "DejaVuSerif.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSerif-Bold.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSerif-Italic.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSerif-BoldItalic.ttf"),
        ),
        "sans": (
            str(Path.home() / ".fonts" / "DejaVuSans.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSans-Bold.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSans-Oblique.ttf"),
            str(Path.home() / ".fonts" / "DejaVuSans-BoldOblique.ttf"),
        ),
    },
]

# Monospace family probe (manuscript-format Courier replacement).
# Probed separately; falls back to built-in Courier.
_MONO_CANDIDATES: List[Tuple[str, str, str, str]] = [
    (
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Oblique.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-BoldOblique.ttf",
    ),
    (
        "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Italic.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-BoldItalic.ttf",
    ),
    (
        "C:\\Windows\\Fonts\\cour.ttf",
        "C:\\Windows\\Fonts\\courbd.ttf",
        "C:\\Windows\\Fonts\\couri.ttf",
        "C:\\Windows\\Fonts\\courbi.ttf",
    ),
    (
        "/System/Library/Fonts/Supplemental/Courier New.ttf",
        "/System/Library/Fonts/Supplemental/Courier New Bold.ttf",
        "/System/Library/Fonts/Supplemental/Courier New Italic.ttf",
        "/System/Library/Fonts/Supplemental/Courier New Bold Italic.ttf",
    ),
]

_BUILTIN = {
    "serif": ("Times-Roman", "Times-Bold", "Times-Italic", "Times-BoldItalic"),
    "sans": ("Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique"),
    "mono": ("Courier", "Courier-Bold", "Courier-Oblique", "Courier-BoldOblique"),
}


def _register_family(kind: str, paths: Tuple[str, str, str, str]) -> Tuple[str, str, str, str] | None:
    """Register one family from candidate file paths.

    Returns the (regular, bold, italic, bold-italic) face-name tuple, or
    None when even the regular face is missing. Missing style faces fall
    back to the regular face (correct glyphs, no slant).
    """
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.pdfmetrics import registerFontFamily
    from reportlab.pdfbase.ttfonts import TTFont

    regular_path = paths[0]
    if not Path(regular_path).is_file():
        return None

    base = f"ASM-{kind.capitalize()}"
    names: List[str] = []
    # Map: reportlab family slot -> (path, fallback slot)
    slots = [
        (f"{base}", regular_path, None),
        (f"{base}-Bold", paths[1], 0),
        (f"{base}-Italic", paths[2], 0),
        (f"{base}-BoldItalic", paths[3], 1),
    ]
    for name, path, fallback_slot in slots:
        if path and Path(path).is_file():
            try:
                pdfmetrics.registerFont(TTFont(name, path))
                names.append(name)
                continue
            except Exception as exc:  # noqa: BLE001 — corrupt font file
                log.warning("Font %s failed to register (%s); falling back", path, exc)
        if fallback_slot is not None and names:
            names.append(names[fallback_slot])
        else:
            names.append(f"{base}")  # regular registered moments ago
    if not names:
        return None

    registerFontFamily(
        f"{base}",
        normal=names[0], bold=names[1], italic=names[2], boldItalic=names[3],
    )
    return (names[0], names[1], names[2], names[3])


def ensure_fonts() -> Dict[str, Tuple[str, str, str, str]]:
    """Probe, register, and cache font families. Idempotent & thread-safe.

    Returns {"serif": (r, b, i, bi), "sans": (r, b, i, bi)} — either
    embedded TTF names (ASM-Serif / ASM-Sans) or built-in fallbacks.
    """
    global _PROBED
    with _LOCK:
        if _PROBED:
            return dict(_STATE)
        _PROBED = True
        for group in _CANDIDATES:
            for kind in ("serif", "sans"):
                if kind in _STATE:
                    continue  # already satisfied by an earlier group
                faces = _register_family(kind, group[kind])
                if faces:
                    _STATE[kind] = faces
        for mono_paths in _MONO_CANDIDATES:
            faces = _register_family("mono", mono_paths)
            if faces:
                _STATE["mono"] = faces
                break
        # Fill anything still missing with built-ins.
        for kind, faces in _BUILTIN.items():
            _STATE.setdefault(kind, faces)
        for kind, faces in _STATE.items():
            if faces[0].startswith("ASM-"):
                log.info("PDF fonts: %s -> %s (Unicode-safe TTF)", kind, faces[0])
            else:
                log.info("PDF fonts: %s -> %s (built-in fallback; non-WinAnsi "
                         "characters such as Turkish ğ/ş/ı may render "
                         "incorrectly)", kind, faces[0])
        return dict(_STATE)


def body_font(kind: str = "serif") -> str:
    """Regular face name for Paragraph styles."""
    return ensure_fonts()[kind][0]


def font_faces(kind: str = "serif") -> Tuple[str, str, str, str]:
    """(regular, bold, italic, bold-italic) face names."""
    return ensure_fonts()[kind]


def using_embedded_fonts(kind: str = "serif") -> bool:
    """True when a real TTF family got embedded (Unicode-safe)."""
    return ensure_fonts()[kind][0].startswith("ASM-")


# --- legacy font-name remapping -------------------------------------------
# Old code (and user settings) reference built-in names. map_font() sends
# them to the Unicode-safe equivalents so Turkish text stops corrupting.

def map_font(name: str) -> str:
    """Map a built-in font name to the Unicode-safe ASM face (or itself)."""
    faces = ensure_fonts()
    _map = {
        "Helvetica": faces["sans"][0], "Helvetica-Bold": faces["sans"][1],
        "Helvetica-Oblique": faces["sans"][2], "Helvetica-BoldOblique": faces["sans"][3],
        "Times-Roman": faces["serif"][0], "Times-Bold": faces["serif"][1],
        "Times-Italic": faces["serif"][2], "Times-BoldItalic": faces["serif"][3],
        "Courier": faces["mono"][0], "Courier-Bold": faces["mono"][1],
        "Courier-Oblique": faces["mono"][2], "Courier-BoldOblique": faces["mono"][3],
    }
    return _map.get(name, name)


def apply_to_stylesheet(stylesheet) -> None:
    """Rewire every style in a reportlab sample stylesheet to ASM faces."""
    try:
        styles = list(stylesheet.byName.values())
    except Exception:  # noqa: BLE001 — not a standard stylesheet
        return
    for st in styles:
        fn = getattr(st, "fontName", None)
        if isinstance(fn, str):
            st.fontName = map_font(fn)


def reset_for_tests() -> None:
    """Re-probe on next use (tests may monkeypatch the probe lists)."""
    global _PROBED
    with _LOCK:
        _PROBED = False
        _STATE.clear()
        try:  # allow re-registration under the same names
            from reportlab.pdfbase import pdfmetrics
            for name in ("ASM-Serif", "ASM-Sans"):
                pdfmetrics.getFont(name)  # raises if absent
        except Exception:  # noqa: BLE001
            pass
