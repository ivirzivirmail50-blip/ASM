"""v8.2 — Chat → Story actions (the A / B / C options).

Three AI-powered bridges that turn a finished chat session into story
assets, so a great interview or group scene never evaporates:

  A. scene_draft()      — "Turn this conversation into a scene" — generates
                          prose from the transcript and saves it as a
                          SceneCard (draft) ready for the corkboard.
  B. extract_character_updates() + apply_character_updates()
                        — "Sync to character card" — the AI reads the
                          transcript, extracts new traits / quotes /
                          background reveals / voice notes, and the writer
                          picks which to apply to the character card.
  C. suggest_questions() — "Interview coach" — reads the story context and
                          the conversation so far, proposes the next deep
                          questions to ask.

All three run on the same ai_service used everywhere else and degrade to
plain heuristic fallbacks when AI is unavailable (offline-safe).
"""
from __future__ import annotations

import logging
import re
from typing import Any

from sqlalchemy import func, select

from core.db import read_session, write_transaction
from core.errors import NotFoundError, ValidationError
from models.character import Character
from models.scene import SceneCard
from services import chat_service
from services._common import dump_json, load_json, new_uuid, now_utc

log = logging.getLogger("asm.chat_actions")

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _session_transcript(sid: str, *, max_chars: int = 7000) -> tuple[dict, str, list[Character]]:
    """Return (session, rendered transcript, participant Character rows)."""
    sess = chat_service.get_session(sid)
    msgs = chat_service.get_messages(sid)
    if not msgs:
        raise ValidationError("This conversation is empty — chat a little first.")

    participants: list[Character] = []
    with read_session() as s:
        for cid in sess.participants:
            ch = s.get(Character, cid)
            if ch:
                participants.append(ch)

    def _name(m: dict) -> str:
        if m.get("role") == "user":
            return "Interviewer"
        return m.get("speaker_name") or "Character"

    lines = [f"{_name(m)}: {m['content']}" for m in msgs]
    transcript = "\n".join(lines)
    if len(transcript) > max_chars:
        transcript = transcript[-max_chars:]
        transcript = "…(earlier turns trimmed)…\n" + transcript
    return sess, transcript, participants


def _ai_available() -> bool:
    try:
        from models.settings import Setting
        with read_session() as s:
            return Setting.get(s, "ai.enabled", "false") in (True, "true", "1", "on")
    except Exception:
        return False


def _char_header(char: Character) -> str:
    bits = [f"Name: {char.name}", f"Role: {char.role or 'unspecified'}"]
    if char.psychology:
        bits.append(f"Current psychology notes: {char.psychology[:600]}")
    if char.background:
        bits.append(f"Current background: {char.background[:600]}")
    if char.voice:
        bits.append(f"Current voice notes: {char.voice[:400]}")
    return "\n".join(bits)


# ---------------------------------------------------------------------------
# A — Chat → Scene draft
# ---------------------------------------------------------------------------


def scene_draft(sid: str, *, style: str = "novel") -> dict[str, Any]:
    """Generate prose from the chat transcript (does NOT save anything).

    Returns {title, text, participants} for preview; save_scene_draft()
    persists it as a SceneCard.
    """
    sess, transcript, participants = _session_transcript(sid)
    names = ", ".join(c.name for c in participants) or "the characters"
    chapter_hint = ""
    if sess.chapter_id:
        from models.chapter import Chapter
        with read_session() as s:
            ch = s.get(Chapter, sess.chapter_id)
            if ch:
                chapter_hint = f"\nThis scene takes place around the events of the chapter “{ch.title}”."

    if _ai_available():
        from services import ai_service
        prompt = (
            "You are a novelist. The following is a conversation (an interview "
            "or an improvised group scene) between a writer and their fictional "
            f"characters: {names}.{chapter_hint}\n\n"
            "Turn it into a SCENE DRAFT in polished prose:\n"
            "- Third person limited or omniscient — whichever fits the material\n"
            "- Convert the dialogue into natural scene dialogue; cut interviewer "
            "questions that don't belong in the story\n"
            "- Add beats, sensory detail and subtext where the transcript is bare\n"
            "- Stay strictly true to each character's voice and any world facts\n"
            "- First line MUST be the scene title in the form: TITLE: <short title>\n"
            "- Then the prose. Aim for 300-600 words.\n\n"
            f"TRANSCRIPT:\n{transcript}"
        )
        try:
            text = ai_service.complete(prompt, max_tokens=900, temperature=0.7)
            title = ""
            m = re.match(r"^\s*TITLE:\s*(.+?)\s*\n", text)
            if m:
                title = m.group(1).strip().strip('"“”')
                text = text[m.end():].strip()
            if not title:
                title = f"Scene — {names}"
            return {"title": title[:500], "text": text.strip(),
                    "participants": [c.id for c in participants]}
        except Exception as exc:
            log.warning("scene_draft AI failed, falling back: %s", exc)

    # Offline fallback — lightly cleaned transcript
    return {
        "title": f"Scene draft — {names}",
        "text": transcript,
        "participants": [c.id for c in participants],
    }


def save_scene_draft(sid: str, draft: dict[str, Any]) -> dict[str, Any]:
    """Persist a previewed draft as a SceneCard (status=draft)."""
    sess = chat_service.get_session(sid)
    title = (draft.get("title") or "Scene draft").strip()[:500]
    text = (draft.get("text") or "").strip()
    if not text:
        raise ValidationError("Draft text is empty.")
    summary = text[:200].replace("\n", " ").strip() + ("…" if len(text) > 200 else "")
    with write_transaction() as s:
        from services._common import current_project_id
        pid = current_project_id(s)
        max_order = s.scalar(
            select(func.max(SceneCard.sort_order)).where(SceneCard.project_id == pid)
        ) or 0
        card = SceneCard(
            id=new_uuid(),
            project_id=pid,
            chapter_id=sess.chapter_id,
            title=title,
            summary=summary,
            content_snippet=text[:500],
            full_text=text,
            scene_break_marker="###",
            sort_order=max_order + 1,
            color="#a78bfa",
            status="draft",
            word_count=len(text.split()),
            tags=dump_json(["from-chat"]),
            notes=f"Generated from chat session “{sess.title}”.",
            created_at=now_utc(),
            updated_at=now_utc(),
        )
        s.add(card)
        s.flush()
        return {"scene_id": card.id, "title": title}


# ---------------------------------------------------------------------------
# B — Chat → Character card sync
# ---------------------------------------------------------------------------

_SYNC_FIELDS = ("traits", "quotes", "background_facts", "voice_notes",
                "relationship_notes")


def extract_character_updates(sid: str, character_id: str) -> dict[str, Any]:
    """AI reads the transcript and proposes card updates (nothing written)."""
    sess, transcript, participants = _session_transcript(sid)
    with read_session() as s:
        char = s.get(Character, character_id)
        if not char:
            raise NotFoundError("Character not found.")
        if character_id not in sess.participants:
            raise ValidationError("That character is not in this conversation.")

    result: dict[str, Any] = {
        "character_id": character_id,
        "character_name": char.name,
        "traits": [], "quotes": [], "background_facts": [],
        "voice_notes": [], "relationship_notes": [],
    }

    if _ai_available():
        from services import ai_service
        prompt = (
            "Analyze this conversation between a writer and their fictional "
            "characters. Focus ONLY on the character below. Extract NEW "
            "information the conversation revealed that is NOT already on "
            "their card.\n\n"
            f"CHARACTER CARD:\n{_char_header(char)}\n\n"
            f"TRANSCRIPT:\n{transcript}\n\n"
            "Reply ONLY as JSON with these keys (use empty arrays when nothing new):\n"
            "{\n"
            '  "traits": ["new personality traits or contradictions revealed"],\n'
            '  "quotes": ["verbatim lines the character said that showcase their voice"],\n'
            '  "background_facts": ["new biography facts / past events revealed"],\n'
            '  "voice_notes": ["how they speak — vocabulary, rhythm, verbal tics observed"],\n'
            '  "relationship_notes": ["new feelings/facts about other characters mentioned"]\n'
            "}"
        )
        try:
            data = ai_service.complete_json(prompt, max_tokens=500, temperature=0.3)
            for k in _SYNC_FIELDS:
                v = data.get(k)
                if isinstance(v, list):
                    result[k] = [str(x).strip() for x in v if str(x).strip()][:12]
            return result
        except Exception as exc:
            log.warning("extract_character_updates AI failed: %s", exc)

    # Offline fallback: character lines become voice quotes
    msgs = chat_service.get_messages(sid)
    result["quotes"] = [
        m["content"] for m in msgs
        if m.get("role") == "assistant"
        and (m.get("speaker_name") or "").lower() == char.name.lower()
        and 10 < len(m["content"]) < 300
    ][:5]
    return result


def apply_character_updates(character_id: str, updates: dict[str, Any]) -> dict[str, Any]:
    """Append the writer-approved extraction onto the character card."""
    from services import character_service
    fields: dict[str, Any] = {}

    def _append(current: str | None, items: list[str], prefix: str) -> str:
        existing = (current or "").rstrip()
        block = "\n".join(f"- {i}" for i in items if i)
        if not block:
            return existing
        if existing:
            return f"{existing}\n\n{prefix} (from chat, v8.2):\n{block}"
        return f"{prefix} (from chat, v8.2):\n{block}"

    traits = [str(t) for t in (updates.get("traits") or [])]
    facts = [str(t) for t in (updates.get("background_facts") or [])]
    voice = [str(t) for t in (updates.get("voice_notes") or [])]
    rels = [str(t) for t in (updates.get("relationship_notes") or [])]
    quotes = [str(t) for t in (updates.get("quotes") or [])]

    with read_session() as s:
        ch = s.get(Character, character_id)
        if not ch:
            raise NotFoundError("Character not found.")
        if traits:
            fields["psychology"] = _append(ch.psychology, traits, "Revealed in conversation")
        if facts:
            fields["background"] = _append(ch.background, facts, "Revealed in conversation")
        if voice:
            fields["voice"] = _append(ch.voice, voice, "Voice observed in conversation")
        if rels or quotes:
            fields["notes"] = _append(ch.notes, rels + quotes, "From chat sessions")

    if not fields:
        return {"updated": []}
    character_service.update_character(character_id, **fields)
    return {"updated": list(fields.keys())}


# ---------------------------------------------------------------------------
# C — Smart interview questions
# ---------------------------------------------------------------------------


def suggest_questions(sid: str, *, count: int = 5) -> dict[str, Any]:
    """Interview coach: the next questions worth asking."""
    sess, transcript, participants = _session_transcript(sid, max_chars=4000)

    if _ai_available():
        from services import ai_service
        names = ", ".join(c.name for c in participants) or "the character"
        prompt = (
            f"You are an interview coach for novelists. The writer is "
            f"interviewing: {names}.\n\n"
            "Conversation so far:\n"
            f"{transcript}\n\n"
            "Propose the NEXT questions the writer should ask — ones that go "
            "DEEPER than what has already been covered: contradictions, "
            "memories, secrets, desires, fears, relationships. Questions must "
            "be answerable IN CHARACTER.\n\n"
            f"Reply ONLY as JSON: {{\"questions\": [\"...\", \"...\"]}} with "
            f"{count} questions."
        )
        try:
            data = ai_service.complete_json(prompt, max_tokens=300, temperature=0.8)
            qs = data.get("questions")
            if isinstance(qs, list):
                return {"questions": [str(q).strip() for q in qs if str(q).strip()][:count]}
        except Exception as exc:
            log.warning("suggest_questions AI failed: %s", exc)

    # Offline fallback — proven interview prompts
    return {"questions": [
        "What do you want that you've never told anyone?",
        "What memory do you try not to think about?",
        "Who do you owe something to — and what would it cost to repay?",
        "What lie do you keep telling yourself?",
        "If everything went wrong tomorrow, what would you save first?",
    ][:count]}
