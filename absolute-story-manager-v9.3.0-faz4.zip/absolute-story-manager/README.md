# Absolute Story Manager v9.0

> **Local-first, single-user creative writing management tool.** Works completely offline — no CDN, no cloud, no account required. **v7.0: multi-book workspace** (topbar switcher, per-book metadata, Writer's Home, onboarding). **v7.1: detail polish** (notes read modal, nested locations, character builder redesign). **v7.2: world builder redesign + AI auto-fill in the editor**. **v7.3: deep writing experience** (Focus Mode 2.0 with typewriter + paragraph focus + synthesized ambient sounds, Corkboard Outline 2.0 unified manuscript view, Floating Quick Capture via Ctrl+Shift+N). **v7.4: hierarchy deepening** (Location Tree drag-and-drop reparenting + breadcrumbs + descendant counts + type switcher; Note modal with server-rendered markdown + keyboard navigation + fullscreen; Creation panels with progress bar + sticky status pill + inline section hints). **v7.5: root-cause fixes** (notes page rebuilt on a static-JS architecture that cannot be broken by Jinja; full-fidelity JSON export/import that carries book names AND notes across versions; global JS error visibility net so no page can ever silently die). **v7.6: deep insights + story atlas + reader 2.0** (year heatmap + cross-book dashboard + smart today card; nested location atlas with character pinning + travel routes; reading mode with bookmarks, highlights, and per-chapter reading-time tracking — fully externalized JS). **v7.7: Turkish language engine + unified quick capture** (language-aware lint/pacing/word-freq/spellcheck; single capture composer for every entry point). **v7.8: Graph 2.0 + multi-group membership + unified BR-Dock**. **v8.0 "Everywhere"** (installable PWA with offline reading + app icons & favicon; Emotion Arc engine that charts the valence/tension curve of every chapter and the whole book, Turkish+English; Mobile Writing Mode — the v2 sidebar drawer bug that broke phones is fixed, touch targets, scrolling tables). **v8.1 "AI Chat 2.0"** (characters with real conversation memory + persistent saved sessions; group scenes where several characters share one room and the AI picks who answers; per-message actions — regenerate/delete/copy; reply length + creativity controls; transcript export to notes; the global AI assistant drawer now streams with story context). **v8.2 "Collision-Free + Chat→Story"** (the floating-button collision saga ends with a documented z-index layer system + an Overlay Watchdog that hides the dock whenever ANY overlay owns the corner; reading mode ↑/↓ keys; Turkish spell-check 500 fixed at the root; full import now carries the book name; **Chat→Story bridges**: Scene Draft turns a conversation into prose on the Scenes corkboard, Sync-to-Card extracts what a character revealed onto their card, the Interview Coach suggests the next deep questions; **Copilot 2.0** quick story actions — plot holes, book summary, next scene, consistency, twists, world gaps — no input text needed). **v8.3 "Prose Lab + Chronology"** (Style Coach 2.0 — deep, Turkish-aware prose analysis: show-don't-tell, filter words, cliché radar, sentence rhythm with sparkline, word variety, calibrated readability; the **AI Rewrite Studio** rewrites problem sentences showing-not-telling and applies them version-safe; the **Story Chronology** page maps your written manuscript onto story time with plan events, gaps, out-of-order flags, and character presence filters). **v8.4 "Performance & Storage Health"** (measured, not guessed: a 3-scale benchmark harness proves SQLite reads stay fast at any file size while full-manuscript Python scans and unbounded version snapshots were the real bottlenecks; list pages no longer load chapter bodies — deferred content; a version retention policy caps the #1 growth vector while always keeping the original draft and pinned versions; a **Storage & Health** dashboard shows where every byte lives with one-click VACUUM / WAL-checkpoint / prune actions; backups were silently WAL-incomplete before — they are checkpoint-verified now, retention-capped, and skipped when nothing changed; WAL journal hard-capped at 64 MB). **v8.5 "Universal Export"** (the character-sheet export pattern is now everywhere: export a single world entry — location, species, faction, any type — as TXT/MD/PDF/DOCX/JSON with full metadata, hierarchy and relations; export all entries of one type with your World Library filters honored; bulk character bible, scene cards, glossary and research bibliography exports; a redesigned Export Center with a Collections section and type chips). **v8.7: Book Forge** (the Compile Wizard now outputs a typeset print-ready book PDF with real trim sizes, mirrored binding margins, running headers and a clickable page-numbered TOC, plus a publication-grade EPUB 3 ebook with cover, nav and embedded typography — with a Publishing Preflight quality gate before you download; every PDF in the app now renders Turkish and other non-Latin-1 characters correctly through embedded Unicode fonts). **v8.8: Performance Lab** (the measured answer to “does my database size hurt performance?”: real app queries timed against live data with warm-cache medians, class thresholds and a 0–100 score with trend arrows; fragmentation, index-coverage, query-plan and FTS-parity diagnostics; one-click FTS rebuild / index backfill / integrity check; boot-time auto-maintenance). **v8.9: Review Loop** (the feedback stage of the writing lifecycle: a Beta Review Hub with per-reader chapter progress, a Beta Reader 2.0 that lets readers move through the whole book with threaded comments, quote highlighting and mark-as-read tracking, and a Feedback Inbox that turns every comment into an action — resolve, convert to a linked Note or Kanban task, or ask the AI for a concrete fix suggestion grounded in story context).

![Python](https://img.shields.io/badge/Python-3.11+-blue)
![Flask](https://img.shields.io/badge/Flask-3.x-green)
![Tests](https://img.shields.io/badge/tests-1748-brightgreen)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features

### 📝 Writing & Editing
- **Multi-Book Workspace (v7.0 + v9.0 Series Bible)** — A book switcher in the topbar: every page respects the active book. Per-book genre, word targets, deadlines and colors. Writer's Home dashboard with a daily goal ring, streak badge and book progress. First-run onboarding wizard. **v9.0**: the **Series Hub** (`/series/`) shows every book with series stats, a **cross-book Series Cast** and **Shared World** list grouped by Turkish-aware (İ/i/I/ı) name normalization, and a **Continuity checker** (Series Doctor) that flags role drift, conflicting physical attributes, divergent world descriptions and unlinked same-name entities between books. **Series links** (new `series_links` table) let you declare from any character or world entry page that it also appears in another book — the entity stays edited in its home book, links never leak into the target book's lists (isolation regression-tested), and the ✦ AI series synopsis writes a back-cover blurb from your books' titles, genres and chapter names
- **Chapter Management** — CRUD, drag-reorder, file upload (TXT/DOCX/PDF/RTF/ODT/HTML), CodeMirror 6 editor (v9.2, EasyMDE rollback flag), version control, diff, split/merge
- **Focus Mode 2.0 (v7.3)** — Full-screen distraction-free writing with Pomodoro timer, auto-save, customizable background/font/width, typewriter mode (current line centered), paragraph focus (other paragraphs dimmed), synthesized ambient sounds (rain/cafe/fire/library via Web Audio API, no asset files), inline daily goal ring (SVG), milestone toasts (100/500/1k/2k words)
- **Reading Mode 2.0 (v7.6)** — Continuous scroll across chapters, font/size/line-height/width controls, 4 themes, auto-resume position. **v7.6 additions**: bookmark any chapter (Ctrl+D), highlight passages with 4 colors via floating toolbar (Ctrl+Shift+H), slide-out panel with three tabs (Bookmarks / Highlights / Reading Time), per-chapter time tracking via IntersectionObserver, session-time tracker with blur/focus pause, persists all to localStorage — and the entire 300+ line JS layer moved to static `reading_mode.js` (no more inline-JS Jinja-collision risk)
- **Corkboard Outline 2.0 (v7.3)** — Unified manuscript view at `/outline/`: all chapters as visual cards in one corkboard, drag-drop reorder (calls existing `/chapters/reorder` API), per-card synopsis + word count + status + scene count + tag chips, status & tag filters, empty state CTA. Scene Cards page also polished: emoji chrome replaced with SVG sprite icons
- **Quick Capture** — Dashboard widget for instant notes, chapters, journal entries, or snippets. **Floating composer (v7.3)**: press **Ctrl+Shift+N** anywhere to open a global floating composer (right-side FAB also available); pick type, optional category/mood, submit. Uses existing `/quick-capture/api/capture` endpoint

### 🧠 AI Features (Optional — Disable in Settings)
- **Story Context Engine (RAG) — v6.0** — Every AI call automatically receives the characters, relationships, world entries, glossary terms, and recent plot events detected in your text. Turkish-aware name matching (İ/i/I/ı). Full transparency: preview exactly what the AI sees
- **AI Editor Copilot** — Continue, expand, shorten, or generate dialogue — story-aware, **streams live token-by-token with a Stop button**, per-source context toggles
- **In-Editor AI Drawer (v6.3)** — Press **Alt+A** while editing a chapter: a streaming AI assistant slides in beside your text. Continue from the cursor, expand/shorten the selection, insert suggestions at the cursor, replace selections — the AI automatically knows the current chapter's characters, world, and plot
- **Character AI Chat** — Talk to your characters; they know their relationships, world, and plot; **replies stream live**; anchor to any chapter
- **AI Assistant** — Context-aware continuation, consistency check, name generator, streaming chat
- **Character Generator** — Random or AI-powered character creation with structured JSON output; knows your existing cast; graceful fallback
- **Reasoning-model safe** — thinking/reasoning blocks (`<think>`, `<reasoning>`, `**Thinking:**`, …) are stripped in every code path; JSON outputs are rescued and repaired; optional fast model routing for small tasks
- **Command Palette (Ctrl+K)** — Fuzzy search every page and quick action from anywhere

### 🎭 Characters & World
- **Character Profiles** — Rich profiles with physical, psychological, background, philosophy, voice. **Creation panel (v7.4)**: sticky form-progress bar with section completion %, unsaved-changes status pill (bottom-right), inline section hints, ✓ check marks per complete section, quick-start templates (protagonist/antagonist/mentor/ally/mystery/blank)
- **Voice Profiles** — Define speech patterns, catchphrases, vocabulary; scan dialogue for consistency
- **Character Arcs** — Track development stages with progress bars and chapter links
- **Mood Tracker** — Per-chapter emotional state timeline (8 moods, 3 intensities)
- **Relationship Graph** — Interactive vis-network graph with group support, drag-save positions
- **Relationship Timeline** — Character×character relationship matrix
- **Family Tree** — Visual family tree with parent/marriage relations
- **World Library** — Typed entries (location/lore/faction/glossary), hierarchy tree, versioning
- **Story Atlas (v7.6)** — A unified atlas view at `/atlas/`: nested collapsible location tree with per-node pin counts (current residence / origin / visiting / hiding / temporary), slide-out character pins grouped by location, travel routes list, inline "Pin character here" buttons on every tree node, stats strip (locations / pinned characters / total pins / max depth / travel routes)
- **Location Hierarchy (v7.4)** — Full parent-child hierarchy with **drag-and-drop reparenting** (drop a card onto another to nest it under the target), breadcrumb trails, descendant counts per node, type switcher (locations / factions / species / ...), stats badges (total count, roots count, max depth), "move to root" button. Parent picker dropdown on create/edit forms auto-refreshes candidates when entry type changes. Cycle prevention (entry cannot be moved under its own descendant).
- **Interactive World Map** — Upload images, place colored pins, **nested sub-maps** (Galaxy → Planet → City → Street), travel routes

### 📊 Analysis & Tracking
- **Style Coach 2.0 / Üslup Laboratuvarı (v8.3)** — deep, language-aware prose analysis per chapter (reachable from the Story Lint page): **show-don't-tell** with Turkish + English lexicons (telling stems like "korktu/hisset/üzgün", sensory stems like "kalb/nefes/hışırtı/koku" plus physical-manifestation phrases like "kalbi hızlandı, eli titredi"); **filter-word distance** (gördü/duydu/fark et/began to…); **cliché radar** ("derin bir nefes aldı", "time stood still"…); **sentence rhythm** profile with SVG sparkline + variation coefficient (monotonous/moderate/varied); **word variety** (unique-content-word ratio); **readability** (Flesch for English, a calibrated model for agglutinative Turkish — raw Flesch scored all Turkish prose near zero); every category lists counts, top entries, and example sentences showing which words triggered them.
- **AI Rewrite Studio (v8.3)** — found a problem sentence? ✦ Rewrite streams an AI rewrite that SHOWS the emotion instead of telling it (language-aware prompt + RAG chapter context via SSE); **Apply to chapter** does a server-side exact-match replacement that snapshots the previous content as a version first (undo-safe); Copy as a one-click alternative. Hidden entirely when AI is off.
- **Story Chronology / Hikâye Kronolojisi (v8.3)** — the written manuscript mapped onto story time at `/chronology/`: chapter cards positioned by parsed story dates ("2026-03-01", "July 2026", "Day 14"/"Gün 3" markers, or reading-order fallback), plan events overlaid as pins (green = linked to a written chapter, purple = planned), out-of-order chapters flagged with a red badge, scale-aware time-gap ribbons, undated chapters listed as chips, and **character presence filters** — click character chips to spotlight the chapters they appear in (alias-aware, word-boundary matching). Zoom controls + horizontal pan; auto-detects date vs. day-marker vs. order mode from the chapters themselves.

### 📦 Performance & Storage (v8.4)
- **Storage & Health dashboard** at `/storage/` — measured numbers, not guesses: DB + WAL file sizes, a per-table "where the bytes live" breakdown (row counts + text-byte share bars), chapter-version stats (total / per-chapter average / prunable estimate), backup inventory, and health hints (oversized WAL, prunable versions, retention overflow). One-click maintenance with before/after feedback: **Checkpoint WAL**, **Prune Versions**, **Prune Backups**, **Optimize (VACUUM + planner statistics)**. Retention settings (version limit, backup count) editable right on the page. Sidebar → System → *Storage & Health*, or Ctrl+K.
- **Deferred content loading** — chapter list pages, pickers and stats no longer load chapter bodies from SQLite (300-chapter library: list queries ~36% faster; FTS search stays sub-millisecond even at 243 MB). Reading mode, EPUB build and consistency check explicitly request full text — nothing else pays for it. Character-appearance queries now load only the `character_ids` column they actually read.
- **Version retention policy** — `version_history_limit` (default 25, 0 = unlimited) prunes old chapter versions automatically on every save while **always keeping the original draft (v1) and pinned versions**. The #1 database growth vector (full-text snapshots on every save — 87% of a heavy vault's size) is now bounded. Demonstrated on a 243 MB synthetic library: prune + VACUUM → **161 MB (−34%)**.
- **Backup correctness (silent data loss fixed)** — in WAL mode recent commits live in the `-wal` file; backups used to zip only the main DB file and could be silently stale. Every backup now checkpoints (TRUNCATE) first — verified by a test that extracts the zipped DB and finds the latest write. Backups are retention-capped (`backup_retention_count`, default 14) and auto-backup skips runs when nothing changed since the last one.
- **WAL journal capped** — `PRAGMA journal_size_limit = 64 MB` (measured before: the WAL grew to 246 MB next to a 243 MB DB and never shrank). Plus a composite `(chapter_id, version_number DESC)` index for the latest-version lookup on every save, and streaming (single-pass, half-memory) manuscript analytics that produce bit-identical results.
- **Benchmark harness shipped** — `scripts/bench_db.py` seeds synthetic libraries at three scales (1 book / series / heavy vault) and times the nine hot paths; `scripts/bench_maintenance_demo.py` demonstrates the maintenance effect on the heavy vault. Measure your own numbers any time.
- **Emotion Arc / Duygu Yayı (v8.0)** — the emotional curve of your story, deterministic and offline: valence (-100..+100 mood) and tension (0..100 stakes) per paragraph window; SVG curve with sign-colored areas and key-moment markers; arc-shape classification (rising/falling/V-dip/peak/wave); "Key emotional moments" table with dominant-emotion chips; rule-based coach notes (flat curve → add a reversal, relentless dark → add warmth, no tension peaks → conflict markers missing…); book-level curve (per-chapter tension bars + valence line); Turkish suffix-tolerant lexicon (~230 stems, "korku" matches "korkusu") + English, honouring the analysis-language setting; punctuation arousal signals (!, ?, …, CAPS)
- **Chat→Story bridges (v8.2)** — three one-click conversions inside every character chat session: **🎬 Scene Draft** turns the conversation (interview or group scene) into polished prose — editable preview, then saved as a draft SceneCard on the corkboard tagged `from-chat`; **⇄ Sync to Card** has the AI diff the transcript against the character card and propose ONLY new traits / verbatim voice quotes / background reveals / speech patterns / relationship notes — you check what gets applied, and it's appended (never overwrites) the card fields; **💡 Interview Coach** reads the story context plus the conversation so far and suggests the next deep questions as clickable chips.
- **AI Editor Copilot 2.0 (v8.2)** — new **Quick Story Actions** grid: 🔍 Find plot holes · 📖 Summarize the book · ➡️ Next scene · 🎭 Consistency check · 💡 Brainstorm twists · 🌍 World gaps — all context-only (no input text needed), fed by the RAG story engine + the selected chapter's tail, streaming with the same Stop button, and any result can be **saved straight to Notes**.
- **Character Chat 2.0 (v8.1)** — talk to your characters with REAL memory: conversations are persistent (sessions + messages tables), the last turns are replayed into every prompt, so the character remembers what was just said. Session sidebar with search / pin / rename / auto-titles; **group scenes** — pick 2+ characters and direct them like a scene ("Who answers: Auto" lets the AI choose the natural speaker); per-message actions (copy, regenerate, delete-from-here, edit & resend); reply length (brief/normal/expansive) + creativity slider + context toggles (relations/world/glossary/plot) + chapter anchor; markdown-lite rendering; typing indicator; streaming with stop; transcript → Markdown copy or **save as note**. The global **AI Assistant drawer** (every page) got the same engine: streaming, story-context aware (RAG), persistent across pages
- **Story Doctor (v6.4)** — One-click manuscript health report: 6 analyzers (style lint, repetition, glossary, timeline, pacing, structure) rolled into a 0-100 score with letter grade, animated score ring, top-cost bars, and prioritized prescriptions linking to each tool. 100% local analysis
- **Writing Analytics** — Per-chapter: word count, dialogue ratio, lexical diversity, reading time
- **Writing Insights Dashboard (v7.6)** — Unified writer dashboard at `/insights/`: (1) **Year Activity Heatmap** — GitHub-style 365-day calendar where each cell's color intensity reflects words written that day, hover to see exact date and word count, today cell outlined; (2) **Today's Smart Card** — current word count vs daily goal with SVG progress ring, current streak count, peak writing hour for the week, contextual one-line tip ("It's Wednesday — your most productive day. Aim for 750 words between 20:00 and 22:00"); (3) **Velocity Trend** — last 30 days sparkline (Canvas, no external deps) showing words/day with up/down/flat trend indicator + avg/peak/total; (4) **Cross-Book Progress** — per-book progress bars, deadline days-left, projected completion date based on 30-day pace, status badge (ahead / on track / behind / done / no pace), overall workspace progress
- **Word Frequency Analyzer** — Overused words, repeated phrases, character mention counts
- **Pacing Analysis** — Tension curve, word distribution, dialogue vs narration
- **Turkish Language Engine (v7.7)** — Language-aware analysis: every analyzer (lint, pacing, word frequency, spell-check) detects the chapter's language and picks matching dictionaries — Turkish stopwords, ~180 Turkish tension words, Turkish passive-voice suffixes (-ildi/-ıldı/-üldü/-uldı), Turkish dialogue verbs (dedi, fısıldadı…), Turkish-safe tokenizer. Previously Turkish words were invisible to the ASCII regex, tension curves stayed flat, and English spell-check flagged every Turkish word. Settings → Goals → Analysis Language: auto (per chapter) / Türkçe / English
- **Unified Quick Capture (v7.7)** — ONE capture surface: + FAB (bottom-right, never overlaps the sidebar), Ctrl+N, Ctrl+Shift+N, Quick Switch and the header menu all open the same 4-type composer (Note/Chapter/Journal/Snippet); fixed a dead-code race where Ctrl+N actually opened /chapters/new

- **Unified Bottom-Right Dock (v7.8)** — ONE fixed container (#brDock) owns the bottom-right corner: undo/redo row, form-status pill, AI assistant button and the Quick Capture FAB stack in a flex column with stable CSS order — overlap is structurally impossible (fixes the v7.7 FAB↔undo-toolbar collision, confirmed live via bounding-box geometry)
- **Multi-Group Membership (v7.8)** — a character can belong to SEVERAL groups: "+ Members" checkbox picker per group (drag still moves), "+ Manage Groups" picker on the character page; memberships in other groups are never touched
- **Group Connections (v7.8)** — real group↔group and group↔character relationships (alliance, rivalry, war…) with create/edit/delete on the Groups page or straight on the graph; the old auto-generated, non-editable "group link" noise edges are gone
- **Graph 2.0 (v7.8)** — edge editing (click an edge → Edit type/description/bidirectional), one-click PNG export, character search with focus+dim, a 6-card stats strip (most connected, lonely characters, multi-group count…), and group ellipse positions persist across reloads
- **Story Lint** — 7 automated checks (repeated words, sentence length, adverbs, passive voice, etc.)
- **Glossary & Style Sheet** — Term consistency with Levenshtein near-miss detection
- **Spell Check** — English dictionary + custom words, disable for non-English writers
- **Manuscript Forecast** — Completion date prediction based on writing pace
- **Writing Habits** — 7×24 heatmap, best day/hour, streak tracking

### 📅 Planning & Motivation
- **Kanban Board** — 6-column (idea→final), subtasks, dependencies, deadlines
- **Plot Structure Templates** — 11 structures (Hero's Journey, Save the Cat, Three-Act, Seven-Point, Freytag, Kishōtenketsu, Fichtean Curve, Heroine's Journey, Tragedy, Voyage & Return, Comedy)
- **Timeline** — Vertical/horizontal, zoom, colored pins, event CRUD
- **Timeline Audit** — Detects ordering violations, cycles, gaps, character double-booking
- **Goals Calendar** — Monthly heatmap, year overview, daily/weekly/monthly progress
- **Achievements** — 18 badges across 5 categories (streak/words/chapters/cast/consistency)
- **Milestones** — 12 word-count milestones (1K → 1M) with one-time celebrations
- **Session Timer** — Pomodoro-style focused sessions with WPM tracking
- **Writing Journal** — Daily mood, energy, wins, struggles, gratitude
- **Prompt Calendar** — Daily writing prompts in calendar view
- **Inspiration Hub** — 70+ curated prompts, scenario generator, daily prompt
- **Chapter Dependencies** — DAG with cycle detection and topological sort

### 📦 Export & Publish
- **Export** — TXT/MD/HTML/DOCX/PDF/EPUB/JSON, async progress, Scrivener compile presets. **Full data transfer (v7.5)**: `/settings/export-json` ships a complete portable archive — ALL books (names, genre, target words, deadlines), notes, chapters, scenes, characters, world hierarchy, journal, glossary, plans, milestones, submissions, atlas character-location pins — 30 content tables total. Import into a new version is idempotent and never blanks the AI API key
- **Universal Export (v8.5)** — Every collection exports in writer formats, not just chapters and characters: **single world entries** (any location/species/faction/lore — TXT/MD/PDF Sheet/DOCX/JSON with metadata tables, hierarchy chains, relations and map pins; export menu on every World Library detail page), **world collections by type** (all locations, all species… — filters from the World Library page are honored: type tab + search + category), **character bible in one file** (TXT/MD/PDF with one page per character/DOCX/JSON), **scene cards** grouped by chapter with POV/location/mood metadata (TXT/MD/CSV/JSON), **glossary** with alternates and forbidden variants (TXT/MD/CSV/JSON), and **research references** in bibliography format with quotes and ratings (TXT/MD/CSV/JSON). The Export Center gained a Collections section with type chips; `GET /export/collections` lists everything programmatically

- **Book Forge — Print PDF + EPUB 3 (v8.7)** — The Compile Wizard is a real production pipeline now: **Print PDF** with book trim sizes (6×9 / digest / A5 / A4 / letter), mirrored binding margins, running headers (book title on verso, chapter on recto), folios, chapter openers, scene-break styling, a **clickable Table of Contents with real converged page numbers** (multiBuild) and a PDF outline; full-bleed cover page when you upload one. **EPUB 3** with proper dc metadata, cover (image or typographic), nav + ncx, per-chapter XHTML, scene-break paragraphs and an embedded book stylesheet. **Publishing Preflight** scores the active book 0–100 before you ship: non-final chapters, empty/too-short chapters, leftover TODO/FIXME/TK/[placeholder] markers, unbalanced quotes, odd emphasis marks, wall-of-text paragraphs — every issue links to its chapter. Book Identity card: author override, language-aware front-matter labels (tr/en/es/fr/de), cover upload (magic-byte-verified, ≤10 MB). The compile title now follows the ACTIVE book (multi-book fix), and a shared Unicode font resolver (`services/pdf_fonts.py`) embedded DejaVu/Liberation/Noto/Windows TTFs so every PDF in the app renders ğ ş ı correctly — previously they silently corrupted (e.g. "Boğaz" → "Bonaz") in all 9 PDF producers.
- **Performance Lab — measured, not guessed (v8.8)** — The Storage & Health page is now two tabs. The **⚡ Performance Lab** times the queries the app actually runs (dashboard list, editor open, save-path version lookup, FTS5 search, LIKE fallback, world/character listings, manuscript scan, write latency through the WAL commit path) with warm-cache medians and scores them 0–100 with class-specific thresholds (indexed lookups ≤ 5 ms fast / ≤ 25 ms ok; scans ≤ 50 / 250 ms; writes ≤ 5 / 20 ms) — results are stored, so the next run shows ▼ faster / ▲ slower trend arrows. Health diagnostics: page/free-page fragmentation with a real VACUUM reclaim estimate, an index-coverage checklist (databases migrated with ALTER TABLE never receive the indexes fresh installs get — one click backfills them), EXPLAIN QUERY PLAN scan flags on big tables, FTS5 parity through the %_docsize shadow table (COUNT(*) on an external-content FTS reads the CONTENT table and always looks equal; SQLite's own integrity-check misses this drift — verified empirically), a runtime pragma snapshot and a PRAGMA quick_check button. Actions: rebuild FTS, create missing indexes, integrity check. **Auto-maintenance** runs PRAGMA optimize + WAL checkpoint on startup at most every N days in a background thread (never blocks; VACUUM stays manual). Also fixes two hidden v8.4 bugs: wrong table names in the storage report (scenes/glossary/inspiration/milestones/voice_notes rows never appeared).
- **Review Loop — beta feedback end-to-end (v8.9)** — **Beta Review Hub** (`/beta/`): open/resolved counts, resolution rate, active readers, feedback coverage and a per-reader progress bar ("Elif read 12/30 chapters") fed by mark-as-read; chapter table with reader chips, last activity and an only-open filter. **Beta Reader 2.0**: readers walk the whole book (prev/next + jump dropdown + position badge), their identity persists via URL + localStorage, threaded replies finally render (author badge), quoted passages are `<mark>`-highlighted in the chapter body, and every action (comment, reply, resolve, reopen, delete) updates the DOM without a reload. **Feedback Inbox** (`/beta/inbox`): every comment across the active book with status/reader/chapter/text filters; per-comment actions — resolve, convert to a chapter-linked Note (todo) or a Kanban task (planned), **✦ AI fix suggestion** (prompt grounded in the Story Context Engine + chapter tail), and MD/CSV/JSON exports that respect the filters. New `beta_read_progress` table is created automatically on existing databases; hub/inbox/exports are scoped to the active book (cross-project leak tested). **v9.0: Series Bible** (the multi-book workspace finally connects its islands: a Series Hub with a cross-book cast list and shared-world view grouped by Turkish-aware name matching, explicit series links that declare a character or world entry appears in another book without breaking project isolation, a continuity checker that catches role drift, conflicting eye/hair colors and divergent world descriptions between books, an optional AI series synopsis, and a whole-series Series Bible export in MD/JSON/PDF/DOCX).
- **Universal Import (v8.6)** — Every JSON the app can write, the app can read back: drop a **character sheet, a single world entry (full profile: hierarchy + relations + metadata + map pin), a type-filtered world collection, the character bible, scene cards, glossary or references** into the Import Center's **ASM Export Bundle** card — the payload type is detected automatically, a **dry-run preview** lists every item as new/existing with per-row checkboxes, and three conflict strategies control what happens to existing rows: *skip* (safe default), *overwrite* (updates fields and keeps a version snapshot first), or *duplicate* (fresh copies). Imports are **atomic** (one transaction), get **fresh ids** with internal references remapped (child locations re-link to imported parents; relation targets resolve by name against your project), and both-direction relations dedupe. Full-project JSON backups go through the same door
- **Compile Wizard** — Publication-ready manuscript with front matter, TOC, back matter
- **Scrivener Export** — .scriv-compatible ZIP package
- **Interactive EPUB** — EPUB 3 with embedded character cards and navigable TOC
- **Serial Reader** — Clean web-based reading interface with prev/next navigation
- **Story Bible** — Auto-generated reference document (characters, world, timeline, glossary)
- **Manuscript Diff** — Compare manuscript state between two dates
- **Find & Replace** — Regex-supported bulk search with preview
- **Submission Tracker** — Track markets, response times, acceptance rate

### 🎨 Customization
- **Polished UI (v6.1)** — 63 Lucide-style SVG icons (single sprite, zero dependencies), collapsible accordion sidebar with animated sections, motion language (page fade-in, modal/toast animations), `prefers-reduced-motion` accessibility
- **Theme Editor** — 7 preset themes (dark/light/sepia/forest/ocean/sunset/midnight), 13 CSS variable overrides, custom CSS
- **Modern UI default** — refined typography & components out of the box; classic Legacy look still selectable in Settings
- **Multi-language UI** — English, Türkçe, Español, Français, Deutsch
- **Snippets & Templates** — Reusable text blocks and chapter templates
- **Notes & Ideas** — Quick-capture inbox with 6 categories, cross-references, promote to chapter/snippet/plan. **Read modal (v7.4)**: server-rendered markdown, keyboard navigation (← → for prev/next note, F for fullscreen, Esc to close), counter (1/N), all metadata shown (tags, links, pinned/done status), inline pin/done buttons. **Architecture (v7.5)**: all notes-page JS lives in `static/js/notes.js` (static file, Jinja-proof) with event delegation — the recurring "dead notes page" bug class is structurally eliminated; the settings JSON export now carries notes and book metadata across versions
- **Research & References** — Track books, articles, websites with quotes and ratings
- **Music Player** — Upload and play local audio files with custom progress bar
- **Keyboard Shortcuts** — `?` for cheatsheet, `g` chord navigation, `t` theme, `b` sidebar

### 📲 PWA — Installable App & Offline Reading (v8.0)
- **Install ASM as a real app** — "⬇ Install App" in the sidebar (Chrome/Edge desktop + Android); standalone window, own taskbar entry, app icons on desktop/home screen
- **App icons generated from scratch** — open-book + spark logo: 192/512 + maskable 512 + apple-touch-icon + favicons (ASM's first favicon ever!)
- **Offline reading** — the service worker caches the app shell and every page you visit; kill the server, go offline, visited pages still open with full content; never-visited URLs fall to a friendly offline page
- **Safe offline writes** — POST/PUT while offline returns a clear JSON "offline — NOT saved" response instead of a silent network-error wall; an "● Offline" badge pulses in the topbar; toasts announce connectivity changes
- **One-click updates** — a new service worker shows a clickable "New version available" toast (SKIP_WAITING + reload); /sw.js is served no-cache so updates land immediately

### 📱 Mobile Writing Mode (v8.0)
- **Fixed the phone-breaking sidebar bug** — the v2 UI's `position: sticky` rule silently overrode the mobile hamburger drawer: on phones the sidebar never hid and covered the whole screen. Re-asserted at v2 specificity; the drawer now slides with a dark overlay
- Touch targets ≥ 40px, horizontally scrolling tables, truncating book switcher, wrapping toolbars, card grids that stack to one column, BR-dock hugging the corner

## Quick Start

```bash
# Clone
git clone https://github.com/yourusername/absolute-story-manager.git
cd absolute-story-manager

# Install dependencies
pip install -r requirements.txt

# Run
python app.py
# → Opens at http://localhost:3000/
```

**Windows:** Double-click `start.bat` · **Linux/macOS:** `./start.sh`

### 🧬 Database Schema (v9.1.0 — Alembic)

The schema is managed by [Alembic](https://alembic.sqlalchemy.org/) migrations
(`alembic/versions/`). On first run the app migrates your database
automatically: a fresh install gets the full schema via `alembic upgrade
head`; a database created by v9.x is aligned, backed up next to the DB file
(`<name>.pre-alembic-<timestamp>.bak`), then stamped and upgraded. For manual
control: `alembic upgrade head`, `alembic downgrade -1`, or
`alembic revision --autogenerate -m "..."` after model changes.

### 🌍 Translations (v9.2.0 — F-02)
UI translations live in `translations/*.json` (one flat key-value file per
language: en/tr/es/fr/de). The sidebar and command palette render
server-side via `t('nav.x')` — no flash of English on non-English pages.
Adding a nav link requires adding its key to every language file (CI
enforces this). Turkish glyphs render in the same font family via
latin-ext subsets.

### ✍️ Editor Engine (v9.2.0 — F-03)
The chapter editor runs on CodeMirror 6 (`static/vendor/codemirror/`,
built locally by `scripts/build_cm6.sh` — npm is never needed at runtime).
Set `editor.engine = easymde` in Settings to roll back to the legacy
engine. Preview panes are server-rendered through the single
`md_to_html` pipeline (`POST /chapters/preview-md`).

### 🤖 AI Providers (v9.2.0 — F-01)
Ollama, any OpenAI-compatible endpoint, Anthropic native and Google
Gemini — all through one adapter layer with retry/backoff, a shared
HTTP session and explicit timeouts. Configure in Settings → AI.

### 🗄️ Schema Constraints (v9.3.0 — F-06)
The database enforces referential integrity (58 FKs with `ON DELETE`
rules), natural-key uniques (glossary terms, custom words, per-project
journal dates, ...) and 27 CHECK constraints. Migration `asm0003`
rebuilds tables from the ORM metadata and **purges legacy orphan rows
deterministically** — upgrading an old database cleans it up safely
(`PRAGMA foreign_key_check` must come out empty).

### ⚙️ Background Jobs (v9.3.0 — F-05)
Exports run on a disk-backed queue (`background_tasks`): if the app
closes mid-job, the task survives and re-runs on next start.
`GET /tasks` / `GET /tasks/<id>` expose progress. Realtime events
(task progress, backups) stream over the central SSE channel
`GET /events` (F-04); `window.asmEvents` is the browser consumer.

### 💾 Backups 2.0 (v9.3.0 — F-09)
Optional AES-256 archive password, an external copy target
(USB/SMB folder) and an incremental mode (only changed media files —
DB is always captured). Configure in Settings → Backup.

### 🔌 Hooks & Undo/Redo (v9.3.0 — F-12 / F-10)
Run your own scripts on `after_export`, `after_chapter_save` and
`after_backup` (opt-in via `hooks_enabled` + `hooks_scripts` JSON).
Deleting notes, glossary terms, journal entries, references or
submissions is undoable — and undo itself has **redo** (`POST /redo`).

### 🔎 Type Checks & E2E (v9.3.0 — F-11 / F-08)
`mypy` strictly checks the v9.3.0 core modules (see `pyproject.toml`);
browser end-to-end tests live in `tests/e2e/` — run them separately:
`python -m pytest tests/e2e/` (requires `pip install playwright` +
`playwright install chromium`).


### 🔒 Network Access & Security Note (v9.0.1)

The app **binds to `127.0.0.1` (loopback) by default**. This is deliberate:
ASM is a local-first, single-user tool with no authentication layer, so it
must not be reachable from your network unless you explicitly choose to
expose it.

- To allow access from other devices on your LAN, start it with
  `ASM_HOST=0.0.0.0` (or edit `start.bat` / `start.sh`).
- When the bind host is **not** loopback, CSRF protection is automatically
  **enforced** on every write request (forms already carry `csrf_token`
  fields and the `asmFetch` helper already sends the `X-CSRFToken` header,
  so the UI keeps working — but third-party sites can no longer forge
  writes).
- Even on loopback, keep in mind that any local process can reach the app.

## Configuration

### AI (Optional)
1. Settings → AI → Enable
2. Choose provider — presets: Ollama (local), OpenRouter, Groq, OpenAI, Z.ai (GLM), LM Studio, llama.cpp
3. Enter API base URL and key (one-click preset buttons)
4. Click ↻ to fetch model list
5. Optional: set a fast model for small tasks (names/tags) — recommended if your main model is a reasoning model

### Interface Language
Settings → Appearance → Interface Language → English / Türkçe / Español / Français / Deutsch

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Backend | Python 3.11+, Flask 3.x, SQLAlchemy 2.x |
| Database | SQLite (WAL mode + FTS5 full-text search) |
| Context engine (RAG) | Local SQLite retrieval — no embeddings, provider-agnostic |
| Frontend | Vanilla JS + hand-rolled CSS (utility layer in `main.css`), SortableJS, vis-network, EasyMDE, Chart.js |
| AI (optional) | Ollama / any OpenAI-compatible API |
| Assets | All vendor files bundled locally (no CDN) |

## Project Structure

```
absolute-story-manager/
├── app.py                 # Flask app factory + main entry
├── config.py              # Configuration
├── requirements.txt
├── start.bat              # Windows launcher
├── core/                  # DB, CSRF, errors, logging, cache
├── models/                # 26 SQLAlchemy models
├── routes/                # 60+ blueprints (one per feature)
├── services/              # 51 service modules
├── templates/             # 100+ Jinja2 templates
├── static/                # CSS, JS, vendor assets
├── tests/                 # 1748 tests
├── data/                  # SQLite DB, media, backups (gitignored)
└── scripts/               # Vendor fetch, seed data, init
```

## Statistics

| Metric | Value |
|--------|-------|
| Python files | 195+ |
| HTML templates | 105+ |
| Blueprints | 60+ |
| Test count | 1748 |
| Plot templates | 11 |
| Languages | 5 (EN/TR/ES/FR/DE) |
| Export formats | 50+ combinations |

## License

MIT — See LICENSE file for details.
