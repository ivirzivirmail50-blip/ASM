"""AI Editor Copilot — AI-powered writing suggestions within the editor.

v6.0: every suggestion is now context-aware — the copilot knows the characters,
world, glossary, and what happened in previous chapters via the Story Context
Engine (services/context_engine.py). The API returns context stats so the UI
can show exactly what the AI was told.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, redirect, render_template, request, url_for

from core.db import read_session
from models.settings import Setting
from services import ai_service, chapter_service, context_engine

bp = Blueprint("ai_copilot", __name__, url_prefix="/ai-copilot")

# Actions that work on a longer text window vs. the tail only
_TAIL_ACTIONS = {"continue", "dialogue"}


def _ai_enabled():
    with read_session() as s:
        return Setting.get(s, "ai.enabled", "false") in (True, "true", "1", "on")


@bp.route("/")
def index():
    if not _ai_enabled():
        return redirect(url_for("settings.ai_settings"))
    chapters, _ = chapter_service.list_chapters(per_page=10000)
    return render_template("ai_copilot/index.html", active_nav="ai_copilot", chapters=chapters)


@bp.route("/api/suggest", methods=["POST"])
def api_suggest():
    data = request.get_json(silent=True) or request.form
    try:
        prompt, bundle = _build_suggest_prompt(data)
        result = ai_service.complete(prompt, max_tokens=int(data.get("max_tokens", 300)))
        return jsonify({
            "ok": True,
            "suggestion": result,
            "context": bundle.stats(),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/api/context-preview", methods=["POST"])
def api_context_preview():
    """Transparency endpoint: show exactly what context would be sent."""
    data = request.get_json(silent=True) or request.form
    text = data.get("text", "")
    chapter_id = data.get("chapter_id") or None
    include = {
        "characters": bool(data.get("ctx_characters", True)),
        "relationships": bool(data.get("ctx_relationships", True)),
        "world": bool(data.get("ctx_world", True)),
        "glossary": bool(data.get("ctx_glossary", True)),
        "plot": bool(data.get("ctx_plot", True)),
    }
    try:
        bundle = context_engine.build_context(
            text[-500:], chapter_id=chapter_id, include=include,
        )
        rendered = bundle.render()
        return jsonify({
            "ok": True,
            "context_text": rendered,
            "stats": bundle.stats(),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


# ---------------------------------------------------------------------------
# v6.2 — Context-aware streaming suggestions (SSE)
# ---------------------------------------------------------------------------

def _build_suggest_prompt(data):
    """Shared prompt/context builder for suggest + suggest-stream."""
    text = data.get("text", "")
    action = data.get("action", "continue")
    chapter_id = data.get("chapter_id") or None
    include = {
        "characters": bool(data.get("ctx_characters", True)),
        "relationships": bool(data.get("ctx_relationships", True)),
        "world": bool(data.get("ctx_world", True)),
        "glossary": bool(data.get("ctx_glossary", True)),
        "plot": bool(data.get("ctx_plot", True)),
    }
    instructions = {
        "continue": "Continue this story naturally for 2-4 sentences, "
                    "matching the existing voice and tense. Return only the continuation.",
        "shorter": "Rewrite the passage below to be more concise while keeping "
                   "meaning and voice. Return only the rewritten text.",
        "expand": "Expand the passage below with more sensory detail and interiority, "
                  "staying consistent with the characters and setting. Return only the expanded text.",
        "dialogue": "Write a natural dialogue exchange (3-6 lines) for the characters "
                    "present in the scene below, each line on its own line, true to each "
                    "character's voice. Return only the dialogue.",
    }
    instruction = instructions.get(action, "Assist with the text below. Return only the result.")
    working_text = text[-500:] if action in _TAIL_ACTIONS else text
    prompt, bundle = context_engine.build_prompt(
        instruction, working_text,
        chapter_id=chapter_id, include=include, tail_chars=1500,
    )
    return prompt, bundle


@bp.route("/api/suggest-stream", methods=["POST"])
def api_suggest_stream():
    """Streaming version of /api/suggest — tokens flow to the UI live.

    SSE protocol (JSON-encoded events, newline-safe):
      data: {"type": "context", "context": {...}}
      data: {"type": "chunk", "text": "..."}
      data: {"type": "done"}
      data: {"type": "error", "message": "..."}
    """
    from flask import Response, stream_with_context

    data = request.get_json(silent=True) or request.form
    try:
        prompt, bundle = _build_suggest_prompt(data)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    max_tokens = int(data.get("max_tokens", 300))
    import json as _json

    def generate():
        # First event: context stats so the UI can show what the AI knows
        yield f"data: {_json.dumps({'type': 'context', 'context': bundle.stats()})}\n\n"
        try:
            for chunk, is_final in ai_service.generate_streaming(
                prompt, max_tokens=max_tokens, temperature=0.8,
            ):
                if chunk:
                    yield f"data: {_json.dumps({'type': 'chunk', 'text': chunk})}\n\n"
                if is_final:
                    yield f"data: {_json.dumps({'type': 'done'})}\n\n"
                    return
            yield f"data: {_json.dumps({'type': 'done'})}\n\n"
        except Exception as exc:
            yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------------------------------------------------------------------
# v8.2 — Copilot 2.0: Quick Story Actions (no input text needed)
# ---------------------------------------------------------------------------

STORY_ACTIONS: dict[str, dict] = {
    "plot_holes": {
        "label": "Find plot holes",
        "instruction": "You are a developmental editor. Read the story context "
                       "and the current draft excerpt. Identify potential plot "
                       "holes, inconsistencies, or unanswered questions a "
                       "reader would notice. For each: what's the problem, "
                       "where it shows, and one concrete fix. Rank by severity.",
        "max_tokens": 600,
    },
    "book_summary": {
        "label": "Summarize the book",
        "instruction": "Summarize the story so far in a structured recap: "
                       "where we are, what each major character wants, the "
                       "open threads, and the likely next act. Keep it tight.",
        "max_tokens": 500,
    },
    "next_scene": {
        "label": "Suggest the next scene",
        "instruction": "Propose the NEXT scene to write. Give 3 options: for "
                       "each, a 2-3 sentence pitch with the dramatic purpose "
                       "(advance plot / deepen character / raise stakes) and "
                       "which characters it needs.",
        "max_tokens": 500,
    },
    "consistency": {
        "label": "Character consistency check",
        "instruction": "Check the characters against how they appear in the "
                       "draft excerpt: voice drift, motivation drift, or facts "
                       "that contradict their card. Only report REAL "
                       "contradictions with the exact evidence.",
        "max_tokens": 500,
    },
    "twists": {
        "label": "Brainstorm twists",
        "instruction": "Suggest 4 surprising-but-earned plot twists for this "
                       "story. For each: the twist, the clue you'd need to "
                       "plant earlier, and what it changes emotionally.",
        "max_tokens": 500,
    },
    "world_gaps": {
        "label": "World gaps",
        "instruction": "Look at the world entries and the draft. Identify "
                       "underdeveloped areas of the world the story will soon "
                       "need (rules, history, economy, culture) and propose "
                       "what to define first.",
        "max_tokens": 500,
    },
}


@bp.route("/api/story-actions")
def api_story_actions():
    """List the available quick story actions (labels for the UI grid)."""
    return jsonify({"ok": True, "actions": [
        {"id": k, "label": v["label"], "max_tokens": v["max_tokens"]}
        for k, v in STORY_ACTIONS.items()
    ]})


@bp.route("/api/story-action-stream", methods=["POST"])
def api_story_action_stream():
    """v8.2 — context-ONLY streaming actions: no input text required.

    The prompt is built from the whole story context (characters, world,
    glossary, recent chapters via the RAG engine) plus, when provided, the
    tail of the currently selected chapter.
    """
    import json as _json

    from flask import Response, stream_with_context

    data = request.get_json(silent=True) or request.form
    action_id = str(data.get("action", ""))
    spec = STORY_ACTIONS.get(action_id)
    if not spec:
        return jsonify({"ok": False, "error": f"Unknown action: {action_id}"}), 400

    chapter_id = data.get("chapter_id") or None
    include = {
        "characters": bool(data.get("ctx_characters", True)),
        "relationships": bool(data.get("ctx_relationships", True)),
        "world": bool(data.get("ctx_world", True)),
        "glossary": bool(data.get("ctx_glossary", True)),
        "plot": bool(data.get("ctx_plot", True)),
    }

    # Seed: current chapter tail (or the action label alone when no chapter)
    seed = spec["label"]
    if chapter_id:
        try:
            ch = chapter_service.get_chapter(chapter_id)
            seed = f"{ch.title}\n{(ch.content or '')[-1200:]}"
        except Exception:
            pass

    try:
        bundle = context_engine.build_context(seed, chapter_id=chapter_id,
                                              include=include)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    prompt = (
        f"{spec['instruction']}\n\n"
        "--- STORY CONTEXT ---\n"
        f"{bundle.render()}\n\n"
        "Answer in Markdown. Be specific — quote names and details from the "
        "context, not generic advice."
    )
    max_tokens = int(data.get("max_tokens", spec["max_tokens"]))

    def generate():
        yield f"data: {_json.dumps({'type': 'context', 'context': bundle.stats()})}\n\n"
        try:
            for chunk, is_final in ai_service.generate_streaming(
                prompt, max_tokens=max_tokens, temperature=0.7,
            ):
                if chunk:
                    yield f"data: {_json.dumps({'type': 'chunk', 'text': chunk})}\n\n"
                if is_final:
                    yield f"data: {_json.dumps({'type': 'done'})}\n\n"
                    return
            yield f"data: {_json.dumps({'type': 'done'})}\n\n"
        except Exception as exc:
            yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
