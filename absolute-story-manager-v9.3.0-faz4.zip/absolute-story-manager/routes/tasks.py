"""Task queue routes — durable background jobs (F-05, v9.3.0).

GET  /tasks            → recent tasks (JSON envelope)
GET  /tasks/<task_id>  → one task detail (progress polling)
"""
from __future__ import annotations

from flask import Blueprint, jsonify

from core.errors import NotFoundError
from services import task_queue_service

bp = Blueprint("tasks", __name__, url_prefix="/tasks")


@bp.route("")
def list_tasks():
    rows = task_queue_service.list_recent(limit=50)
    return jsonify({
        "ok": True,
        "tasks": [task_queue_service.task_to_dict(t) for t in rows],
    })


@bp.route("/<task_id>")
def task_detail(task_id: str):
    t = task_queue_service.get_task(task_id)
    if t is None:
        raise NotFoundError("Task not found.")
    return jsonify({"ok": True, "task": task_queue_service.task_to_dict(t)})
