"""Manuscript Compile Wizard routes."""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template, request, send_file

from core.errors import AsmError
from services import compile_service as svc

log = logging.getLogger("asm.routes.compile")
bp = Blueprint("compile", __name__, url_prefix="/compile")


@bp.route("/")
def index():
    config = svc.get_config()
    return render_template(
        "compile.html",
        active_nav="compile",
        config=config,
    )


@bp.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "GET":
        return jsonify({"ok": True, "config": svc.get_config()})
    data = request.get_json(silent=True) or request.form
    saved = svc.save_config(dict(data))
    return jsonify({"ok": True, "config": saved})


@bp.route("/api/preview")
def api_preview():
    """Compile and return the structure (sections list) for preview."""
    config = svc.get_config()
    compiled = svc.compile_manuscript(config)
    # Don't return the full body of chapters (could be huge); just metadata
    preview_sections = []
    for sec in compiled["sections"]:
        preview_sections.append({
            "type": sec["type"],
            "heading": sec["heading"],
            "body_preview": (sec["body"] or "")[:500] + ("…" if len(sec.get("body") or "") > 500 else ""),
            "word_count": sec.get("word_count"),
        })
    return jsonify({
        "ok": True,
        "title": compiled["title"],
        "author": compiled["author"],
        "sections": preview_sections,
        "total_words": compiled["total_words"],
        "chapter_count": compiled["chapter_count"],
    })


@bp.route("/download")
def download():
    """Compile and download the manuscript."""
    fmt = request.args.get("format", "html")
    config = svc.get_config()
    config["format"] = fmt
    compiled = svc.compile_manuscript(config)
    content, mime, filename = svc.render_compiled(compiled, fmt)
    import io
    return send_file(
        io.BytesIO(content),
        mimetype=mime,
        as_attachment=True,
        download_name=filename,
    )


# ---------------------------------------------------------------------------
# v8.7 — Book Forge: cover upload / preflight
# ---------------------------------------------------------------------------

_COVER_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
_COVER_MAGIC = {
    ".png": b"\x89PNG",
    ".jpg": b"\xff\xd8\xff",
    ".jpeg": b"\xff\xd8\xff",
    ".webp": b"RIFF",
}
_COVER_MAX = 10 * 1024 * 1024


@bp.route("/api/cover", methods=["POST"])
def api_cover_upload():
    """Upload a book cover image for the compiled PDF/EPUB."""
    import time

    if "file" not in request.files:
        return jsonify({"ok": False, "error": "No file provided"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"ok": False, "error": "Empty filename"}), 400

    import os
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in _COVER_EXTS:
        return jsonify({"ok": False, "error":
                        "Extension %s not allowed. Use: %s"
                        % (ext, ", ".join(sorted(_COVER_EXTS)))}), 400

    content = f.read()
    if not content:
        return jsonify({"ok": False, "error": "File is empty"}), 400
    if len(content) > _COVER_MAX:
        return jsonify({"ok": False, "error":
                        "Cover too large (%d KB, max 10 MB)"
                        % (len(content) // 1024)}), 400
    sig = _COVER_MAGIC[ext]
    if not content.startswith(sig):
        return jsonify({"ok": False, "error":
                        "File content does not look like a real %s image." %
                        ext.strip(".")}), 400

    from config import Config
    from services import compile_service as svc2

    covers_dir = Config.MEDIA_DIR / "covers"
    covers_dir.mkdir(parents=True, exist_ok=True)
    name = "cover_%d%s" % (int(time.time()), ext)
    (covers_dir / name).write_bytes(content)
    public = "/media/covers/" + name
    try:
        cfg = svc2.set_cover_image(public)
    except AsmError as exc:
        (covers_dir / name).unlink(missing_ok=True)
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code
    log.info("Book cover uploaded: %s (%d KB)", name, len(content) // 1024)
    return jsonify({"ok": True, "cover": public,
                    "has_cover": True, "config": cfg})


@bp.route("/api/cover/remove", methods=["POST"])
def api_cover_remove():
    """Remove the configured cover (file + config reference)."""
    from services import compile_service as svc2
    cfg = svc2.get_config()
    path = svc2.cover_media_path(cfg)
    if path is not None:
        path.unlink(missing_ok=True)
        log.info("Book cover removed: %s", path.name)
    cfg = svc2.remove_cover_image()
    return jsonify({"ok": True, "has_cover": False, "config": cfg})


@bp.route("/api/preflight")
def api_preflight():
    """Publishing preflight — the pre-download quality gate."""
    from services import preflight_service
    return jsonify(preflight_service.preflight_report())
