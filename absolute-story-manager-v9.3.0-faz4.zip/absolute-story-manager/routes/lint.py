"""Story Lint route — AI-free automated consistency checks.

v8.3 adds the AI Rewrite Studio endpoints: streaming rewrites of problem
sentences found by Style Coach 2.0, plus a safe apply that snapshots the
previous chapter content as a version first.
"""
from __future__ import annotations

import json
import logging

from flask import (
    Blueprint,
    Response,
    jsonify,
    render_template,
    request,
    stream_with_context,
    url_for,
)

from services import lint_service

log = logging.getLogger("asm.routes.lint")
bp = Blueprint("lint", __name__, url_prefix="/lint")


def _ai_enabled() -> bool:
    from core.db import read_session
    from models.settings import Setting
    with read_session() as s:
        return Setting.get(s, "ai.enabled", "false") in (True, "true", "1", "on")


@bp.route("/")
def index():
    """Run Story Lint and show results."""
    from sqlalchemy import select

    from core.db import read_session
    from models.chapter import Chapter
    from services._common import current_project_id

    result = lint_service.lint_all()
    with read_session() as s:
        chapters = [
            {"id": ch.id, "title": ch.title, "word_count": ch.word_count or 0}
            for ch in s.scalars(
                select(Chapter)
                .where(Chapter.project_id == current_project_id(s))
                .order_by(Chapter.sort_order.asc())
            ).all()
        ]
    return render_template("lint.html", result=result, chapters=chapters, active_nav="lint")


@bp.route("/style-coach/<chapter_id>")
def style_coach(chapter_id: str):
    """Deep style report (v8.3: language-aware, rhythm, rewrite targets)."""
    result = lint_service.style_coach(chapter_id)
    return render_template("style_coach.html", result=result, active_nav="lint")


# ---------------------------------------------------------------------------
# v8.3 — AI Rewrite Studio
# ---------------------------------------------------------------------------

_REWRITE_INSTRUCTIONS = {
    "tr": {
        "telling": (
            "Aşağıdaki cümle DUYGUYU DOĞRUDAN bildiriyor ('anlatma' hatası). "
            "Aynı bilgiyi duyguyu göstererek yeniden yaz: bedensel tepki, eylem, "
            "duyusal ayrıntı veya diyalogla. Anlatıcı sesini, zamanı ve üslubu koru. "
            "SADECE yeniden yazılmış cümleyi döndür — açıklama, tırnak veya başlık yok."
        ),
        "filter": (
            "Aşağıdaki cümle filtre kelime içeriyor (gördü/duydu/fark etti gibi), "
            "okuyucuyu sahnenin dışına çekiyor. Filtreyi kaldır ve deneyimi DOĞRUDAN "
            "anlat: 'duydu' yerine sesin kendisini tarif et. Anlatıcı sesini ve zamanı koru. "
            "SADECE yeniden yazılmış cümleyi döndür — açıklama yok."
        ),
        "cliche": (
            "Aşağıdaki cümle klişe bir kalıp içeriyor. Aynı anlamı taze, somut, "
            "bu hikâyeye özgü bir imgelerle yeniden yaz. Anlatıcı sesini ve zamanı koru. "
            "SADECE yeniden yazılmış cümleyi döndür — açıklama yok."
        ),
    },
    "en": {
        "telling": (
            "The sentence below TELLS the emotion directly. Rewrite it so the "
            "emotion is SHOWN: physical reaction, action, sensory detail, or dialogue. "
            "Keep the narrator's voice, tense, and register. Return ONLY the rewritten "
            "sentence — no quotes, no explanation."
        ),
        "filter": (
            "The sentence below contains filter words (saw/heard/noticed) that hold "
            "the reader at arm's length. Remove the filter and render the experience "
            "directly: instead of 'heard a sound', describe the sound itself. Keep voice "
            "and tense. Return ONLY the rewritten sentence."
        ),
        "cliche": (
            "The sentence below leans on a stock phrase. Rewrite it with fresh, "
            "concrete imagery specific to this story. Keep the narrator's voice and "
            "tense. Return ONLY the rewritten sentence."
        ),
    },
}


@bp.route("/style-rewrite-stream", methods=["POST"])
def style_rewrite_stream():
    """Stream an AI rewrite for one problem sentence.

    SSE protocol (same shape as the copilot's):
      data: {"type": "context", "context": {...}}
      data: {"type": "chunk", "text": "..."}
      data: {"type": "done", "sentence": "..."}   # full text on done
      data: {"type": "error", "message": "..."}
    """
    from services import ai_service, context_engine

    if not _ai_enabled():
        return Response(
            f"data: {json.dumps({'type': 'error', 'message': 'AI is disabled in Settings.'})}\n\n",
            mimetype="text/event-stream",
        )

    data = request.get_json(silent=True) or request.form
    chapter_id = (data.get("chapter_id") or "").strip() or None
    sentence = (data.get("sentence") or "").strip()
    category = (data.get("category") or "telling").strip().lower()
    lang = (data.get("lang") or "en").strip().lower()

    if not sentence:
        return Response(
            f"data: {json.dumps({'type': 'error', 'message': 'Missing sentence.'})}\n\n",
            mimetype="text/event-stream",
        )
    if category not in ("telling", "filter", "cliche"):
        category = "telling"
    if lang not in ("tr", "en"):
        lang = "en"

    instruction = _REWRITE_INSTRUCTIONS[lang][category]

    def generate():
        full: list[str] = []
        try:
            prompt, bundle = context_engine.build_prompt(
                instruction, sentence, chapter_id=chapter_id,
                include={"characters": True, "relationships": True, "world": True,
                         "glossary": True, "plot": False},
                tail_chars=600,
            )
            yield f"data: {json.dumps({'type': 'context', 'context': bundle.stats()})}\n\n"
            for chunk, is_final in ai_service.generate_streaming(
                prompt, max_tokens=220, temperature=0.7,
            ):
                if chunk:
                    full.append(chunk)
                    yield f"data: {json.dumps({'type': 'chunk', 'text': chunk})}\n\n"
                if is_final:
                    break
            yield f"data: {json.dumps({'type': 'done', 'sentence': ''.join(full).strip()})}\n\n"
        except Exception as exc:  # noqa: BLE001
            log.exception("style rewrite stream failed")
            yield f"data: {json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@bp.route("/style-rewrite-apply", methods=["POST"])
def style_rewrite_apply():
    """Replace the FIRST occurrence of ``original`` in a chapter's content.

    Safety: exact-match required, both strings size-capped, and the update
    goes through chapter_service.update_chapter(create_version=True) so the
    previous content is snapshotted (undo/version history preserved).
    """
    from core.db import read_session
    from core.errors import NotFoundError, ValidationError
    from models.chapter import Chapter
    from services import chapter_service

    data = request.get_json(silent=True) or request.form
    chapter_id = (data.get("chapter_id") or "").strip()
    original = data.get("original") or ""
    replacement = data.get("replacement") or ""

    if not chapter_id:
        return jsonify({"ok": False, "error": "Missing chapter_id."}), 400
    if len(original) > 600 or len(replacement) > 2000:
        return jsonify({"ok": False, "error": "Sentence too long to apply safely."}), 400
    if not replacement.strip():
        return jsonify({"ok": False, "error": "Replacement is empty."}), 400

    try:
        with read_session() as s:
            ch = s.get(Chapter, chapter_id)
            if not ch:
                raise NotFoundError("Chapter not found.")
            content = ch.content or ""
        if original not in content:
            return jsonify({
                "ok": False,
                "error": "Original sentence no longer matches the chapter content. Refresh and try again.",
            }), 409

        new_content = content.replace(original, replacement, 1)
        old_words = len(content.split())
        new_words = len(new_content.split())
        chapter_service.update_chapter(
            chapter_id,
            content=new_content,
            create_version=True,
            version_source="ai_rewrite",
            version_notes="Style Coach AI Rewrite",
        )
        return jsonify({
            "ok": True,
            "applied": True,
            "word_delta": new_words - old_words,
        })
    except NotFoundError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    except ValidationError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:  # noqa: BLE001
        log.exception("style rewrite apply failed")
        return jsonify({"ok": False, "error": str(exc)}), 500
