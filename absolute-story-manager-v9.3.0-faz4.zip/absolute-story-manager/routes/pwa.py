"""PWA routes — manifest, service worker, offline page (v8.0).

The service worker MUST be served from the root path (/sw.js) so its
scope covers the whole app; Flask's /static/ mount cannot do that.
The manifest is generated dynamically so theme colors and names stay in
sync with the app without a build step.
"""
from __future__ import annotations

import logging
import os

from flask import Blueprint, jsonify, render_template, send_file

log = logging.getLogger("asm.routes.pwa")
bp = Blueprint("pwa", __name__)

_APP_NAME = "Absolute Story Manager"
_THEME_COLOR = "#0b1020"      # matches CSS --bg (dark shell)
_BG_COLOR = "#0b1020"
_STATIC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")
_SW_PATH = os.path.join(_STATIC, "js", "sw.js")


@bp.route("/manifest.webmanifest")
def manifest():
    """Web app manifest — installable app metadata."""
    return jsonify({
        "name": _APP_NAME,
        "short_name": "ASM",
        "description": "Local-first novel writing workspace: chapters, characters, "
                       "world, analysis and AI copilot — all on your device.",
        "id": "/",
        "start_url": "/dashboard",
        "scope": "/",
        "display": "standalone",
        "orientation": "any",
        "background_color": _BG_COLOR,
        "theme_color": _THEME_COLOR,
        "lang": "en",
        "dir": "ltr",
        "categories": ["productivity", "books", "education"],
        "icons": [
            {
                "src": "/static/img/icons/icon-192.png",
                "sizes": "192x192",
                "type": "image/png",
                "purpose": "any",
            },
            {
                "src": "/static/img/icons/icon-512.png",
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "any",
            },
            {
                "src": "/static/img/icons/icon-maskable-512.png",
                "sizes": "512x512",
                "type": "image/png",
                "purpose": "maskable",
            },
        ],
    })


@bp.route("/sw.js")
def service_worker():
    """Serve the service worker from root scope with no-cache headers.

    Browsers cap service worker freshness at 24h by default; serving with
    Cache-Control: no-cache makes every page load check for updates so the
    v8.0 update flow (toast + reload) activates promptly.
    """
    resp = send_file(_SW_PATH, mimetype="application/javascript", max_age=0)
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    resp.headers["Service-Worker-Allowed"] = "/"
    return resp


@bp.route("/offline")
def offline():
    """Offline fallback page — precached by the service worker."""
    return render_template("offline.html")
