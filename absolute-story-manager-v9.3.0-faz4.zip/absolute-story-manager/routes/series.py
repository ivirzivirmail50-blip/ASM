"""Series Bible routes (v9.0) — cross-book continuity hub."""
from __future__ import annotations

import io
import logging

from flask import Blueprint, jsonify, render_template, request, send_file

from core.errors import AsmError
from services import series_service as svc

log = logging.getLogger("asm.routes.series")
bp = Blueprint("series", __name__, url_prefix="/series")


@bp.route("/")
def index():
    """Series Hub: books overview, series cast, shared world, continuity."""
    overview = svc.series_overview()
    cast = svc.series_cast()
    world = svc.series_world()
    report = svc.continuity_report()
    links = svc.series_links_all()
    return render_template(
        "series.html", active_nav="series",
        overview=overview, cast=cast, world=world,
        report=report, links=links,
        formats=("md", "json", "pdf", "docx"))


# ---- JSON APIs ---------------------------------------------------------------

@bp.route("/api/overview")
def api_overview():
    return jsonify({"ok": True, "overview": svc.series_overview()})


@bp.route("/api/cast")
def api_cast():
    return jsonify({"ok": True, "cast": svc.series_cast()})


@bp.route("/api/world")
def api_world():
    return jsonify({"ok": True, "world": svc.series_world()})


@bp.route("/api/continuity")
def api_continuity():
    return jsonify({"ok": True, "report": svc.continuity_report()})


# ---- Link management -----------------------------------------------------------

@bp.route("/link", methods=["POST"])
def create_link():
    """Declare that an entity also appears in another book."""
    data = request.get_json(silent=True) or request.form
    entity_type = (data.get("entity_type") or "").strip()
    entity_id = (data.get("entity_id") or "").strip()
    target_project_id = (data.get("target_project_id") or "").strip()
    note = (data.get("note") or "").strip()
    if not entity_id or not target_project_id:
        return jsonify({"ok": False, "error": "entity_id and target_project_id required"}), 400
    link = svc.link_entity(entity_type, entity_id, target_project_id,
                           note=note)
    return jsonify({"ok": True, "link": link})


@bp.route("/link/<link_id>", methods=["DELETE", "POST"])
def remove_link(link_id: str):
    payload = svc.unlink(link_id)
    return jsonify({"ok": True, "removed": payload})


# ---- Export ---------------------------------------------------------------------

@bp.route("/export/<fmt>")
def export(fmt: str):
    content, mimetype, filename = svc.export_series_bible(fmt)
    return send_file(io.BytesIO(content), mimetype=mimetype,
                     as_attachment=True, download_name=filename)


# ---- AI series synopsis -----------------------------------------------------------

@bp.route("/api/ai-synopsis", methods=["POST"])
def ai_synopsis():
    """Optional AI back-cover blurb for the whole series."""
    try:
        text = svc.ai_series_synopsis()
        return jsonify({"ok": True, "synopsis": text})
    except AsmError as exc:
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code
    except Exception as exc:  # provider hiccups must not 500 the hub
        log.exception("Series AI synopsis failed")
        return jsonify({"ok": False,
                        "error": f"AI request failed: {exc}"}), 502
