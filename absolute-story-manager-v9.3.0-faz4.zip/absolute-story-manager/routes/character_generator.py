"""Character Generator — AI-powered random character creation.

v6.0:
- AI mode now returns STRUCTURED fields (name/age/personality/...) via the
  robust complete_json pipeline — thinking-model leakage can no longer turn
  into garbage characters.
- The generator knows your existing cast (avoids duplicate names) and your
  world flavor, so suggestions fit the story.
- Graceful fallback to the random generator on any AI failure.
"""
from __future__ import annotations

import random

from flask import Blueprint, jsonify, render_template, request

from services import ai_service, character_service, context_engine

bp = Blueprint("character_generator", __name__, url_prefix="/character-generator")


NAMES_FANTASY = ["Elara", "Kael", "Mira", "Voss", "Lyra", "Darian", "Seraphine", "Thorne", "Elowen", "Ragnar", "Isolde", "Caspian"]
NAMES_MODERN = ["Alex", "Sam", "Jordan", "Casey", "Riley", "Morgan", "Taylor", "Quinn"]
ROLES = ["protagonist", "antagonist", "supporting", "minor"]
ROLES_FANTASY = ["warrior", "mage", "rogue", "healer", "scholar", "noble", "merchant", "assassin"]
TRAITS_POS = ["brave", "loyal", "clever", "compassionate", "determined", "honorable", "witty", "patient"]
TRAITS_NEG = ["stubborn", "arrogant", "impulsive", "vengeful", "secretive", "cynical", "reckless", "possessive"]
MOTIVATIONS = ["revenge", "redemption", "discovery", "love", "power", "freedom", "justice", "survival", "family", "duty"]
FEARS = ["death", "betrayal", "losing loved ones", "failure", "the unknown", "being forgotten", "heights", "darkness"]
QUIRKS = ["collects odd objects", "hums when nervous", "always late", "never lies", "talks to animals", "obsessive about cleanliness", "can't swim", "remembers every face"]

_VALID_FIELDS = ("name", "role", "age", "physical", "personality",
                 "background", "motivation", "fear", "quirk")


@bp.route("/")
def index():
    return render_template("character_generator/index.html", active_nav="character_generator")


def _random_character(setting: str) -> dict:
    names = NAMES_FANTASY if setting == "fantasy" else NAMES_MODERN
    name = random.choice(names) + " " + random.choice(["Blackwood", "Stormrider", "Nightshade", "Ironheart", "Moonwhisper", "Thornfield", "Ashbourne", "Ravenscar"])
    role = random.choice(ROLES)
    age = random.randint(16, 65)
    traits_pos = random.sample(TRAITS_POS, 2)
    traits_neg = random.sample(TRAITS_NEG, 1)
    motivation = random.choice(MOTIVATIONS)
    fear = random.choice(FEARS)
    quirk = random.choice(QUIRKS)
    fantasy_role = ""
    if setting == "fantasy":
        fantasy_role = random.choice(ROLES_FANTASY)

    return {
        "name": name,
        "role": role,
        "age": str(age),
        "physical": f"{'Tall' if random.random() > 0.5 else 'Short'} and {'lean' if random.random() > 0.5 else 'stout'}, with {random.choice(['dark', 'fair', 'tanned'])} skin and {random.choice(['blue', 'green', 'brown', 'grey'])} eyes.",
        "personality": f"{', '.join(traits_pos)} but {traits_neg[0]}.",
        "background": f"A {fantasy_role if setting == 'fantasy' else 'former ' + random.choice(['soldier', 'teacher', 'thief', 'doctor'])} who lost everything and now seeks {motivation}.",
        "motivation": motivation,
        "fear": fear,
        "quirk": quirk,
        "ai_generated": False,
    }


@bp.route("/api/generate", methods=["POST"])
def api_generate():
    data = request.get_json(silent=True) or request.form
    use_ai = data.get("use_ai", False)
    setting = data.get("setting", "fantasy")

    if use_ai:
        try:
            # Context: existing cast names (to avoid duplicates) + world flavor
            existing_names: list[str] = []
            world_flavor: list[str] = []
            try:
                all_chars = character_service.list_characters()
                existing_names = [c.name for c in all_chars[:30]]
            except Exception:
                pass
            try:
                bundle = context_engine.build_context(
                    "", include={"characters": False, "relationships": False,
                                 "world": True, "glossary": False, "plot": False},
                    budget_chars=1200,
                )
                world_flavor = [w.get("name", "") for w in bundle.world if w.get("name")]
            except Exception:
                pass

            prompt = (
                "Create ONE original character for a {setting} story. "
                "Respond with ONLY a JSON object (no prose, no reasoning) with these keys: "
                "name (string), role (one of protagonist/antagonist/supporting/minor), "
                "age (string), physical (1-2 sentences), personality (1-2 sentences), "
                "background (2-3 sentences), motivation (short phrase), fear (short phrase), "
                "quirk (short phrase). Make the character vivid and specific.\n"
                "{avoid}{flavor}"
            ).format(
                setting=setting,
                avoid=(
                    "Existing characters to NOT duplicate (pick a clearly different name): "
                    + ", ".join(existing_names) + "\n" if existing_names else ""
                ),
                flavor=(
                    "Story world elements to be consistent with: "
                    + ", ".join(world_flavor) + "\n" if world_flavor else ""
                ),
            )
            parsed = ai_service.complete_json(prompt, max_tokens=600, temperature=0.9)
            if isinstance(parsed, dict):
                character = {
                    "name": str(parsed.get("name") or "Unnamed")[:200],
                    "role": str(parsed.get("role") or "supporting")[:40],
                    "age": str(parsed.get("age") or "")[:40],
                    "physical": str(parsed.get("physical") or "")[:2000],
                    "personality": str(parsed.get("personality") or "")[:2000],
                    "background": str(parsed.get("background") or "")[:3000],
                    "motivation": str(parsed.get("motivation") or "")[:300],
                    "fear": str(parsed.get("fear") or "")[:300],
                    "quirk": str(parsed.get("quirk") or "")[:300],
                    "ai_generated": True,
                }
                # Guard: a character without a usable name is a failed generation
                if len(character["name"].strip()) >= 2:
                    return jsonify({"ok": True, "character": character})
            # Structurally invalid → fall through to random
        except Exception:
            pass  # Fall back to random

    # Random generation (also the AI fallback path)
    return jsonify({"ok": True, "character": _random_character(setting)})


@bp.route("/api/save", methods=["POST"])
def api_save():
    data = request.get_json(silent=True) or request.form
    try:
        ch = character_service.create_character(
            name=data.get("name", "Generated"),
            role=data.get("role", "supporting"),
            age=data.get("age", ""),
            physical=data.get("physical", ""),
            psychology=data.get("personality", ""),
            background=data.get("background", ""),
        )
        return jsonify({"ok": True, "id": ch.id})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
