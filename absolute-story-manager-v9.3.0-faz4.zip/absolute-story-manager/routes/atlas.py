"""Story Atlas routes — interactive nested location tree with character pins.

v7.6 feature. Distinct from /world/map/ (visual map image with pins) and
/world/hierarchy/ (just the tree). The atlas combines:
- A nested collapsible tree of all locations
- Each node shows pinned character count + travel routes originating there
- Pin/unpin a character to a location inline
- View all pins as a flat list and travel routes overlay
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template, request

from core.errors import AsmError
from services import atlas_service as svc

log = logging.getLogger("asm.routes.atlas")
bp = Blueprint("atlas", __name__, url_prefix="/atlas")


@bp.route("/")
def index():
    payload = svc.atlas_full()
    return render_template(
        "atlas/index.html",
        active_nav="atlas",
        tree=payload["tree"],
        pins=payload["pins"],
        routes=payload["routes"],
    )


@bp.route("/api/full")
def api_full():
    return jsonify({"ok": True, **svc.atlas_full()})


@bp.route("/api/tree")
def api_tree():
    return jsonify({"ok": True, **svc.atlas_tree()})


@bp.route("/api/pins")
def api_pins():
    return jsonify({"ok": True, **svc.atlas_pins()})


@bp.route("/api/routes")
def api_routes():
    return jsonify({"ok": True, **svc.atlas_routes()})


@bp.route("/api/pin", methods=["POST"])
def api_pin_create():
    """Pin a character to a location. JSON: {character_id, location_id, kind, note}."""
    data = request.get_json(silent=True) or request.form
    try:
        result = svc.create_pin(
            character_id=data.get("character_id", ""),
            location_id=data.get("location_id", ""),
            kind=data.get("kind", "current_residence"),
            note=data.get("note", ""),
            chapter_id=data.get("chapter_id") or None,
        )
        return jsonify(result)
    except AsmError as exc:
        return jsonify({"ok": False, "error": str(exc), "code": exc.code}), exc.status_code
    except Exception as exc:
        log.exception("atlas pin create failed")
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/api/pin/<pin_id>", methods=["DELETE"])
def api_pin_delete(pin_id: str):
    result = svc.delete_pin(pin_id)
    if not result.get("ok"):
        return jsonify(result), 404
    return jsonify(result)


@bp.route("/api/candidates")
def api_candidates():
    """Return characters + locations for the pin picker."""
    return jsonify({
        "ok": True,
        "characters": svc.list_candidate_characters(),
        "locations": svc.list_candidate_locations(),
        "pin_kinds": svc.atlas_pins()["pin_kinds"],
    })
