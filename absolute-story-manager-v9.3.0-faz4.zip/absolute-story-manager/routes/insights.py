"""Writing Insights Dashboard 2.0 — unified writer dashboard.

Combines year heatmap, velocity trend, today's smart card, and cross-book
dashboard into one page. Distinct from /analytics/ (per-chapter manuscript
stats) and /habits/ (best day/hour patterns).
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template

from services import insights_service as svc

log = logging.getLogger("asm.routes.insights")
bp = Blueprint("insights", __name__, url_prefix="/insights")


@bp.route("/")
def index():
    payload = svc.full_dashboard()
    return render_template(
        "insights/index.html",
        active_nav="insights",
        heatmap=payload["year_heatmap"],
        velocity=payload["velocity"],
        today=payload["today"],
        cross_book=payload["cross_book"],
    )


@bp.route("/api/dashboard")
def api_dashboard():
    return jsonify({"ok": True, **svc.full_dashboard()})


@bp.route("/api/heatmap")
def api_heatmap():
    days = 365
    return jsonify({"ok": True, **svc.year_heatmap(days=days)})


@bp.route("/api/today")
def api_today():
    return jsonify({"ok": True, **svc.today_insight()})


@bp.route("/api/cross-book")
def api_cross_book():
    return jsonify({"ok": True, **svc.cross_book_dashboard()})


@bp.route("/api/velocity")
def api_velocity():
    days = 30
    return jsonify({"ok": True, **svc.velocity_trend(days=days)})
