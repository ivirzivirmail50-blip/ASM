"""Export routes."""
from __future__ import annotations

import io
import logging

from flask import Blueprint, jsonify, render_template, request, send_file

from core.errors import AsmError
from services import export_service
from services.compile_presets import apply_preset_to_settings, get_all_presets, get_preset

log = logging.getLogger("asm.routes.export")
bp = Blueprint("export", __name__, url_prefix="/export")


@bp.route("/")
def index():
    presets = get_all_presets()
    from services.world_service import get_all_types
    return render_template("export.html", presets=presets,
                           world_types=get_all_types(),
                           active_nav="export")


@bp.route("/presets")
def list_presets():
    """List all compile presets (JSON API for Quick Switch / UI)."""
    return jsonify({"presets": get_all_presets()})


@bp.route("/presets/<key>/apply", methods=["POST"])
def apply_preset(key: str):
    """Apply a compile preset to manuscript settings."""
    settings = apply_preset_to_settings(key)
    if not settings:
        return jsonify({"ok": False, "error": "Unknown preset"}), 400
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        for k, v in settings.items():
            Setting.set(s, k, v)
    return jsonify({"ok": True, "preset": key, "settings": settings})


@bp.route("/manuscript/<fmt>")
def manuscript(fmt: str):
    content, mimetype, filename = export_service.export_manuscript(fmt)
    return send_file(io.BytesIO(content), mimetype=mimetype,
                     as_attachment=True, download_name=filename)


@bp.route("/world-bible/<fmt>")
def world_bible(fmt: str):
    content, mimetype, filename = export_service.export_world_bible(fmt)
    return send_file(io.BytesIO(content), mimetype=mimetype,
                     as_attachment=True, download_name=filename)


@bp.route("/full-project/<fmt>")
def full_project(fmt: str):
    include_secrets = request.args.get("include_secrets", "0") == "1"
    content, mimetype, filename = export_service.export_full_project(
        fmt, include_secrets=include_secrets,
    )
    return send_file(io.BytesIO(content), mimetype=mimetype,
                     as_attachment=True, download_name=filename)


# ---- Universal collection exports (v8.5) ----

_COLLECTIONS = {
    "characters": ("txt", "md", "pdf", "docx", "json"),
    "scenes": ("txt", "md", "csv", "json"),
    "glossary": ("txt", "md", "csv", "json"),
    "references": ("txt", "md", "csv", "json"),
    "world": ("txt", "md", "pdf", "docx", "json"),
}


@bp.route("/collections")
def collections():
    """JSON API: list of exportable collections and their formats."""
    from services.world_service import get_all_types
    return jsonify({
        "collections": [
            {"name": k, "formats": list(v)} for k, v in _COLLECTIONS.items()
        ],
        "world_types": get_all_types(),
    })


@bp.route("/collection/<name>/<fmt>")
def collection(name: str, fmt: str):
    """Export a whole collection (characters / scenes / glossary / references / world).

    For world: ?type=location&search=...&category=... mirrors the World Library
    filters; type=all (or absent) exports the whole World Bible.
    """
    if name == "world":
        type_ = request.args.get("type", "all") or "all"
        search = request.args.get("q", "").strip() or None
        category = request.args.get("category", "").strip() or None
        content, mimetype, filename = export_service.export_world_collection(
            type_, fmt, search=search, category=category)
    elif name == "characters":
        content, mimetype, filename = export_service.export_characters(fmt)
    elif name == "scenes":
        content, mimetype, filename = export_service.export_scenes(fmt)
    elif name == "glossary":
        content, mimetype, filename = export_service.export_glossary(fmt)
    elif name == "references":
        content, mimetype, filename = export_service.export_references(fmt)
    else:
        return jsonify({"ok": False, "error": "Unknown collection"}), 404
    return send_file(io.BytesIO(content), mimetype=mimetype,
                     as_attachment=True, download_name=filename)


# ---- Async export with progress ----

@bp.route("/async/<entity_type>/<fmt>")
def async_start(entity_type: str, fmt: str):
    """Start a background export task. Returns task_id."""
    entity_id = request.args.get("entity_id")
    task_id = export_service.async_export(entity_type, fmt, entity_id=entity_id)
    return jsonify({"ok": True, "task_id": task_id})


@bp.route("/status/<task_id>")
def status(task_id: str):
    """Poll export task status."""
    result = export_service.get_export_status(task_id)
    if result is None:
        return jsonify({"ok": False, "error": "Task not found or expired"}), 404
    return jsonify({"ok": True, **result})


@bp.route("/download/<task_id>")
def download(task_id: str):
    """Download completed export file."""
    result = export_service.get_export_file(task_id)
    if result is None:
        return jsonify({"ok": False, "error": "File not ready or task expired"}), 404
    content, mime, filename = result
    return send_file(io.BytesIO(content), mimetype=mime,
                     as_attachment=True, download_name=filename)
