"""Story Chronology — visual manuscript timeline (v8.3)."""
from __future__ import annotations

import json
import logging

from flask import Blueprint, render_template

from services import chronology_service

log = logging.getLogger("asm.routes.chronology")
bp = Blueprint("chronology", __name__, url_prefix="/chronology")


@bp.route("/")
def index():
    payload = chronology_service.build_timeline()
    # JSON data tag (v8.0 emotion pattern): '<' escaped so a story_date or
    # title can never break out of the script block.
    payload_json = json.dumps(payload).replace("<", "\\u003c")
    return render_template(
        "chronology/index.html",
        payload_json=payload_json,
        stats=payload["stats"],
        active_nav="chronology",
    )


@bp.route("/api/timeline")
def api_timeline():
    from flask import jsonify
    return jsonify(chronology_service.build_timeline())
