"""Storage & Health routes (v8.4, Performance Lab in v8.8).

A measured answer to "is my database getting too big?" — file sizes, per-table
breakdown, version/backup stats, health hints, and maintenance actions
(VACUUM, WAL checkpoint, version prune, backup prune, retention settings).

v8.8 adds the Performance Lab: query benchmarks with verdicts and trend
deltas, fragmentation/index-coverage/FTS parity diagnostics, FTS rebuild,
index backfill, integrity check, and the auto-maintenance interval.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

from services import perf_service, storage_service

bp = Blueprint("storage", __name__, url_prefix="/storage")


@bp.route("/")
def index():
    stats = storage_service.db_stats()
    perf = perf_service.report()
    last_bench = perf_service.last_benchmark_view()
    return render_template("storage.html", stats=stats, active_nav="storage",
                           perf=perf, last_bench=last_bench,
                           threshold_table=perf_service.THRESHOLD_TABLE)


@bp.route("/api/stats")
def api_stats():
    return jsonify({"ok": True, "stats": storage_service.db_stats()})


@bp.route("/api/perf")
def api_perf():
    """Health diagnostics without benchmarks (cheap, safe to poll)."""
    return jsonify({"ok": True, "report": perf_service.report()})


@bp.route("/action", methods=["POST"])
def action():
    """Run a maintenance action.

    Body: {"action": "vacuum|checkpoint|prune_versions|prune_backups|
                          save_settings|benchmark|rebuild_fts|
                          add_missing_indexes|integrity_check|save_auto"}
    """
    data = request.get_json(silent=True) or request.form or {}
    act = (data.get("action") or "").strip()
    try:
        if act == "benchmark":
            result = perf_service.benchmark()
            message = (f"Benchmark complete: score {result['score']['score']}/100"
                       f" (grade {result['score']['grade']}) — "
                       f"{result['score']['measured']} queries measured.")
            return jsonify({"ok": True, "message": message,
                            "result": result})
        elif act == "rebuild_fts":
            result = perf_service.rebuild_fts()
            parts = []
            for r in result["results"]:
                ms = f" in {r['ms']}ms" if r.get("ms") is not None else ""
                parts.append(f"{r.get('source')}: "
                             f"{r.get('before', {}).get('index')}→"
                             f"{r.get('after', {}).get('index')} rows{ms}")
            message = result["message"] + " " + " · ".join(parts)
        elif act == "add_missing_indexes":
            result = perf_service.add_missing_indexes()
            message = result["message"]
        elif act == "integrity_check":
            result = perf_service.integrity_check()
            message = ("Integrity check: " + result["result"])
        elif act == "save_auto":
            days = _to_int(data.get("auto_maintenance_days"), default=7,
                           minimum=0, maximum=365)
            result = {"auto_maintenance_days":
                      perf_service.set_auto_maintenance_days(days)}
            message = (f"Auto-maintenance saved: runs every {days} days on "
                       "startup" if days else
                       "Auto-maintenance disabled.")
        elif act == "vacuum":
            result = storage_service.vacuum()
            message = (f"VACUUM complete: {result['before_mb']} MB → "
                       f"{result['after_mb']} MB "
                       f"({result['reclaimed_mb']} MB reclaimed).")
        elif act == "checkpoint":
            result = storage_service.checkpoint()
            message = (f"WAL checkpoint complete: "
                       f"{result['before_mb']} MB → {result['after_mb']} MB.")
        elif act == "prune_versions":
            result = storage_service.prune_versions()
            message = (f"Pruned {result['deleted']} old version(s), "
                       f"~{result['reclaimed_mb']} MB reclaimed. "
                       f"Run VACUUM to shrink the file on disk.")
        elif act == "prune_backups":
            result = storage_service.prune_backups()
            message = (f"Removed {result['deleted']} backup(s), "
                       f"{result['freed_mb']} MB freed.")
        elif act == "save_settings":
            result = _save_retention_settings(data)
            message = "Retention settings saved."
        else:
            return jsonify({"ok": False,
                            "error": "Unknown action."}), 400
        # Fresh stats after the action
        return jsonify({"ok": True, "message": message,
                        "result": result,
                        "stats": storage_service.db_stats()})
    except Exception as exc:  # pragma: no cover - defensive
        import logging
        logging.getLogger("asm.storage").exception("Storage action failed")
        return jsonify({"ok": False, "error": str(exc)}), 500


def _save_retention_settings(data: dict) -> dict:
    from core.db import write_transaction
    from models.settings import Setting

    vl = _to_int(data.get("version_history_limit"), default=25,
                 minimum=0, maximum=1000)
    br = _to_int(data.get("backup_retention_count"), default=14,
                 minimum=0, maximum=1000)
    with write_transaction() as s:
        Setting.set(s, "version_history_limit", str(vl))
        Setting.set(s, "backup_retention_count", str(br))
    return {"version_history_limit": vl, "backup_retention_count": br}


def _to_int(value, *, default: int, minimum: int, maximum: int) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, n))
