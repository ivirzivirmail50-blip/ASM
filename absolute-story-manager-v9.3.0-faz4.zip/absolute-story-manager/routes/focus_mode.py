"""Focus Mode Pro — distraction-free writing with ambient sounds, Pomodoro, and notification blocking.

v7.3 — Focus Mode 2.0:
  - Typewriter mode (current line vertically centered)
  - Paragraph focus mode (current paragraph highlighted, others dimmed)
  - Ambient sound player (Web Audio synthesized rain/cafe/fire/library — no asset files)
  - Inline daily goal ring (SVG circle showing today's progress)
  - Milestone toasts (100 / 500 / 1k / 2k words)
  - SVG icons throughout (replaces emoji)
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, render_template, request

from core.db import read_session
from models.settings import Setting
from services import chapter_service, session_service, stats_service

bp = Blueprint("focus_mode", __name__, url_prefix="/focus")
log = logging.getLogger("asm.routes.focus")


@bp.route("/")
def index():
    chapters, _ = chapter_service.list_chapters(per_page=10000)
    active_session = session_service.get_active_session()
    start_id = request.args.get("chapter") or (chapters[0].id if chapters else "")
    return render_template("focus_mode/index.html", active_nav="focus_mode",
                           chapters=chapters, active_session=active_session,
                           start_id=start_id)


@bp.route("/api/session/start", methods=["POST"])
def api_start_session():
    data = request.get_json(silent=True) or request.form
    try:
        sess = session_service.start_session(
            session_type=data.get("session_type", "pomodoro"),
            target_minutes=int(data["target_minutes"]) if data.get("target_minutes") else None,
            chapter_id=data.get("chapter_id") or None,
        )
        return jsonify({"ok": True, "id": sess.id})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@bp.route("/api/session/end", methods=["POST"])
def api_end_session():
    data = request.get_json(silent=True) or request.form
    sess = session_service.get_active_session()
    if not sess:
        return jsonify({"ok": False, "error": "No active session"}), 400
    try:
        ended = session_service.end_session(sess.id, status=data.get("status", "completed"))
        return jsonify({"ok": True, "words_written": ended.words_written})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@bp.route("/api/today")
def api_today():
    """Return today's word count, daily goal, and percent for the inline goal ring.

    Used by Focus Mode 2.0 to show a live progress ring next to the timer.
    """
    try:
        words = stats_service.words_today()
    except Exception:
        words = 0
    try:
        with read_session() as s:
            goal = int(Setting.get(s, "daily_word_goal", 500) or 500)
    except Exception:
        goal = 500
    pct = min(100, round(words / max(1, goal) * 100, 1))
    return jsonify({
        "ok": True,
        "words_today": words,
        "daily_goal": goal,
        "percent": pct,
        "goal_met": words >= goal,
    })
