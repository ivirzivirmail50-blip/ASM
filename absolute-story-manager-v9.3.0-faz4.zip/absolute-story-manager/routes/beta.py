"""Beta reader routes — read-only chapter viewing + threaded comments.

v8.9 "Review Loop": Beta Review Hub (/beta/), Feedback Inbox (/beta/inbox),
read progress, feedback exports (MD/CSV/JSON), comment → Note/Task conversion,
and AI revision suggestions.
"""
from __future__ import annotations

import json
import logging

from flask import Blueprint, abort, jsonify, render_template, request, send_file

from core.errors import AsmError, NotFoundError
from services import beta_service, chapter_service

log = logging.getLogger("asm.routes.beta")
bp = Blueprint("beta", __name__)


# ---- v8.9: Beta Review Hub -------------------------------------------------

@bp.route("/beta/")
def hub():
    """Central review dashboard: feedback stats, reader progress, chapter list."""
    data = beta_service.hub_data()
    return render_template("beta_hub.html", data=data, active_nav="beta")


@bp.route("/beta/inbox")
def inbox():
    """Feedback Inbox — every open/resolved comment across the book."""
    status = (request.args.get("status") or "").strip() or None
    reader = (request.args.get("reader") or "").strip() or None
    chapter_id = (request.args.get("chapter") or "").strip() or None
    q = (request.args.get("q") or "").strip() or None
    comments = beta_service.list_all(status=status, reader=reader,
                                     chapter_id=chapter_id, q=q)
    readers = beta_service.list_readers()
    data = beta_service.hub_data()
    from services import ai_service
    return render_template(
        "beta_inbox.html", comments=comments, data=data, readers=readers,
        filters={"status": status or "", "reader": reader or "",
                 "chapter": chapter_id or "", "q": q or ""},
        ai_enabled=ai_service.is_enabled(),
        active_nav="beta")


@bp.route("/beta/inbox/export/<fmt>")
def inbox_export(fmt: str):
    """Export the (filtered) feedback inbox as MD / CSV / JSON."""
    status = (request.args.get("status") or "").strip() or None
    reader = (request.args.get("reader") or "").strip() or None
    chapter_id = (request.args.get("chapter") or "").strip() or None
    q = (request.args.get("q") or "").strip() or None
    content, mime, filename = beta_service.export_feedback(
        fmt, chapter_id=None, status=status, reader=reader, q=q)
    import io
    return send_file(io.BytesIO(content), mimetype=mime,
                     as_attachment=True, download_name=filename)


@bp.route("/beta/<chapter_id>/export/<fmt>")
def chapter_export(chapter_id: str, fmt: str):
    """Export ONE chapter's beta feedback as MD / CSV / JSON."""
    try:
        chapter_service.get_chapter(chapter_id)  # 404 if unknown
        content, mime, filename = beta_service.export_feedback(
            fmt, chapter_id=chapter_id)
        import io
        return send_file(io.BytesIO(content), mimetype=mime,
                         as_attachment=True, download_name=filename)
    except NotFoundError:
        abort(404)
    except AsmError as exc:
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code


# ---- Read progress ----------------------------------------------------------

@bp.route("/beta/<chapter_id>/mark-read", methods=["POST"])
def mark_read(chapter_id: str):
    data = request.get_json(silent=True) or request.form
    reader = (data.get("reader") or "").strip() or "Beta Reader"
    try:
        chapter_service.get_chapter(chapter_id)  # 404 if unknown
        info = beta_service.mark_read(chapter_id, reader)
        return jsonify({"ok": True, **info})
    except NotFoundError:
        abort(404)


@bp.route("/beta/<chapter_id>/mark-unread", methods=["POST"])
def mark_unread(chapter_id: str):
    data = request.get_json(silent=True) or request.form
    reader = (data.get("reader") or "").strip() or "Beta Reader"
    try:
        chapter_service.get_chapter(chapter_id)
        info = beta_service.mark_unread(chapter_id, reader)
        return jsonify({"ok": True, **info})
    except NotFoundError:
        abort(404)


# ---- Conversion + AI assist --------------------------------------------------

@bp.route("/beta/comment/<int:comment_id>/to-note", methods=["POST"])
def comment_to_note(comment_id: int):
    """Convert beta feedback into a linked Note (category: todo)."""
    n = beta_service.to_note(comment_id)
    return jsonify({"ok": True, "note_id": n.id,
                    "url": "/notes/", "title": n.title})


@bp.route("/beta/comment/<int:comment_id>/to-plan", methods=["POST"])
def comment_to_plan(comment_id: int):
    """Convert beta feedback into a Kanban task (status: planned)."""
    p = beta_service.to_plan(comment_id)
    return jsonify({"ok": True, "plan_id": p.id,
                    "url": "/plans/board", "title": p.title})


@bp.route("/beta/comment/<int:comment_id>/ai-suggest", methods=["POST"])
def ai_suggest(comment_id: int):
    """Ask the AI for a concrete revision suggestion for this feedback."""
    try:
        suggestion = beta_service.suggest_fix(comment_id)
        return jsonify({"ok": True, "suggestion": suggestion})
    except AsmError as exc:
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code
    except Exception as exc:  # provider hiccups should not 500 the inbox
        log.exception("AI suggest failed for comment %s", comment_id)
        return jsonify({"ok": False,
                        "error": f"AI request failed: {exc}"}), 502


# ---- Chapter reader (v8.9: Beta Reader 2.0) ---------------------------------

@bp.route("/beta/<chapter_id>")
def reader(chapter_id: str):
    """Beta reader view: read-only chapter + comment sidebar.

    v2.0: prev/next chapter navigation, threaded replies, quote highlights,
    mark-as-read progress, reader identity persistence, feedback export.
    Payload via JSON data tags (v7.5 static-JS architecture) consumed by
    static/js/beta_reader.js.
    """
    try:
        ch = chapter_service.get_chapter(chapter_id)
    except NotFoundError:
        abort(404)

    prev_ch, next_ch = chapter_service.get_neighbors(chapter_id)
    reader_name = (request.args.get("reader") or "").strip()

    # Chapter list for the jump dropdown + position
    chapters, total = chapter_service.list_chapters(per_page=10000)
    index = next((i + 1 for i, c in enumerate(chapters) if c.id == ch.id), 0)

    threaded = beta_service.get_threaded(chapter_id)
    progress = (beta_service.read_progress(reader_name)
                if reader_name else {"read_count": 0, "chapters_total": total,
                                     "read_ids": []})

    from services import ai_service
    payload = {
        "chapter": {
            "id": ch.id, "title": ch.title,
            "word_count": ch.word_count or 0,
            "prev_id": prev_ch.id if prev_ch else None,
            "next_id": next_ch.id if next_ch else None,
            "index": index, "total": total,
        },
        "chapters": [{"id": c.id, "title": c.title} for c in chapters],
        "comments": threaded,
        "reader": reader_name,
        "progress": progress,
        "ai_enabled": ai_service.is_enabled(),
    }
    # '<' escaped so a quote/title can never break out of the script block
    payload_json = json.dumps(payload).replace("<", "\\u003c")

    return render_template(
        "beta_reader.html", chapter=ch, payload_json=payload_json,
        stats=beta_service.stats(chapter_id),
        reader_name=reader_name, active_nav="beta")


# ---- Comment CRUD (unchanged public API) -------------------------------------

@bp.route("/beta/<chapter_id>/comment", methods=["POST"])
def add_comment(chapter_id: str):
    """Add a beta reader comment (top-level)."""
    data = request.get_json(silent=True) or request.form
    comment = (data.get("comment") or "").strip()
    if not comment:
        return jsonify({"ok": False, "error": "Comment required"}), 400
    try:
        c = beta_service.add_comment(
            chapter_id, comment,
            reader_name=data.get("reader_name", "Beta Reader"),
            selected_text=data.get("selected_text", ""),
            position=int(data.get("position", 0)),
        )
        return jsonify({"ok": True, "id": c.id, "reader": c.reader_name,
                        "comment": c.comment, "status": c.status})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/beta/comment/<int:comment_id>/reply", methods=["POST"])
def add_reply(comment_id: int):
    """Add a reply to an existing comment."""
    data = request.get_json(silent=True) or request.form
    comment = (data.get("comment") or "").strip()
    if not comment:
        return jsonify({"ok": False, "error": "Reply text required"}), 400
    reply = beta_service.add_reply(
        comment_id, comment,
        reader_name=data.get("reader_name", "Author"),
        is_author_reply=bool(data.get("is_author_reply", True)),
    )
    return jsonify({"ok": True, "id": reply.id, "comment": reply.comment,
                    "reader": reply.reader_name})


@bp.route("/beta/comment/<int:comment_id>/resolve", methods=["POST"])
def resolve_comment(comment_id: int):
    c = beta_service.resolve_comment(comment_id)
    return jsonify({"ok": True, "status": c.status})


@bp.route("/beta/comment/<int:comment_id>/reopen", methods=["POST"])
def reopen_comment(comment_id: int):
    c = beta_service.reopen_comment(comment_id)
    return jsonify({"ok": True, "status": c.status})


@bp.route("/beta/comment/<int:comment_id>/delete", methods=["POST"])
def delete_comment(comment_id: int):
    beta_service.delete_comment(comment_id)
    return jsonify({"ok": True})


@bp.route("/beta/<chapter_id>/threaded")
def api_threaded(chapter_id: str):
    """Return comments as threaded JSON structure."""
    return jsonify({"ok": True, "comments": beta_service.get_threaded(chapter_id),
                    "stats": beta_service.stats(chapter_id)})


@bp.route("/beta/<chapter_id>/stats")
def api_stats(chapter_id: str):
    return jsonify({"ok": True, **beta_service.stats(chapter_id)})


@bp.route("/beta/<chapter_id>/progress")
def api_progress(chapter_id: str):
    """Read progress for one reader on this chapter (?reader=)."""
    reader = (request.args.get("reader") or "").strip()
    if not reader:
        return jsonify({"ok": False, "error": "reader parameter required"}), 400
    info = beta_service.read_progress(reader)
    info["this_chapter_read"] = chapter_id in info["read_ids"]
    return jsonify({"ok": True, **info})
