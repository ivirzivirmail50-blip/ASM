"""Settings routes — appearance, story metadata, goals, AI (opt-in)."""
from __future__ import annotations

import json
import logging

from flask import Blueprint, jsonify, render_template, request, url_for

from core.db import read_session, write_transaction
from core.errors import AsmError
from models.settings import DEFAULT_SETTINGS, Setting
from services import backup_service, validate_service
from services._common import current_project_id

log = logging.getLogger("asm.routes.settings")
bp = Blueprint("settings", __name__, url_prefix="/settings")


@bp.route("/")
def index():
    with read_session() as s:
        settings = Setting.all_settings(s)
    return render_template("settings.html", settings=settings,
                           active_nav="settings")


@bp.route("/save", methods=["POST"])
def save():
    data = request.get_json(silent=True) or request.form
    # Coerce types from form strings.
    bool_keys = {"auto_backup_enabled", "sidebar_collapsed",
                 "backup_include_media",
                 "backup_incremental"}  # S-03: media; F-09: incremental
    # v7.7: analysis_language — "auto" (per-chapter detection) | "tr" | "en"
    choice_keys = {"analysis_language": ("auto", "tr", "en")}
    int_keys = {"daily_word_goal", "total_word_goal",
                "manuscript_font_size", "autosave_interval_seconds",
                "version_snapshot_interval_minutes", "auto_backup_interval_hours",
                "editor_font_size", "chapter_viewer_font_size",
                "ai.timeout_seconds"}
    with write_transaction() as s:
        for k, v in data.items():
            if k in choice_keys and str(v) not in choice_keys[k]:
                continue  # reject unknown choice values
            if k in bool_keys:
                Setting.set(s, k, bool(v in (True, "true", "1", "on")))
            elif k in int_keys:
                try:
                    Setting.set(s, k, int(v))
                except (ValueError, TypeError):
                    pass
            elif k == "ai.enabled":
                Setting.set(s, "ai.enabled", bool(v in (True, "true", "1", "on")))
            elif k == "ui_language":
                from services.i18n_service import SUPPORTED_LANGUAGES, set_language
                lang = str(v) if v else "en"
                if lang in SUPPORTED_LANGUAGES:
                    set_language(lang)
            elif k.startswith("ai."):
                if k == "ai.api_key" and (not v or v == "********" or str(v).strip() == ""):
                    continue  # Don't overwrite existing key with empty/masked value
                Setting.set(s, k, str(v) if v is not None else "")
            elif k == "backup_password":
                # F-09: same masked-value guard as ai.api_key — an empty or
                # masked submission must not wipe the stored password.
                if v and str(v).strip() not in ("", "********"):
                    Setting.set(s, k, str(v).strip())
                elif str(v).strip() == "" and str(data.get("backup_password_clear", "")).strip():
                    Setting.set(s, k, "")  # explicit clear request
            else:
                Setting.set(s, k, str(v) if v is not None else "")
    return jsonify({"ok": True})


@bp.route("/ai")
def ai_settings():
    with read_session() as s:
        settings = Setting.all_settings(s)
    # Never expose ai.api_key in templates
    settings["ai.api_key"] = "" if not settings.get("ai.api_key") else "********"
    return render_template("settings_ai.html", settings=settings,
                           active_nav="settings")


@bp.route("/ai/test", methods=["POST"])
def ai_test():
    """Quick smoke test: try a tiny generate() call."""
    from services import ai_service
    out = ai_service.generate("Hello.", max_tokens=10)
    return jsonify({"ok": True, "response": out})


@bp.route("/validate")
def validate():
    result = validate_service.validate_all()
    return render_template("settings_validate.html", result=result,
                           active_nav="settings")


@bp.route("/validate/fix-word-counts", methods=["POST"])
def validate_fix_wc():
    fixed = validate_service.fix_word_counts()
    return jsonify({"ok": True, "fixed": fixed})


@bp.route("/validate/rebuild-fts", methods=["POST"])
def rebuild_fts():
    """Rebuild the FTS5 full-text search index from scratch."""
    from core.db import engine
    from models.search import rebuild_fts as _rebuild
    success = _rebuild(engine)
    if success:
        return jsonify({"ok": True, "message": "FTS5 index rebuilt successfully."})
    else:
        return jsonify({"ok": False, "error": "FTS5 rebuild failed. Check logs."}), 500


@bp.route("/backup", methods=["GET", "POST"])
def backup():
    if request.method == "POST":
        try:
            path = backup_service.create_backup()
            return jsonify({"ok": True, "name": path.name})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 500
    backups = backup_service.list_backups()
    return render_template("settings_backup.html", backups=backups,
                           active_nav="settings")


@bp.route("/backup/restore", methods=["POST"])
def backup_restore():
    path = (request.get_json(silent=True) or {}).get("path")
    if not path:
        return jsonify({"ok": False, "error": "Missing path"}), 400
    try:
        backup_service.restore_backup(path)
        return jsonify({"ok": True,
                        "message": "Restore successful. Restart the app."})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/export-json")
def export_json():
    """Export EVERYTHING as portable JSON (v7.5 full-fidelity transfer).

    v7.4 bug fixed here: the old export never wrote the project row
    (book name / genre / target words / deadline / color) nor notes,
    journal, scenes, glossary, ... — so moving data to a new version
    silently lost them. The new project_transfer_service is table-driven
    and covers every user-content table plus ALL books (multi-project).
    """
    from flask import Response

    from services import project_transfer_service as pts
    data = pts.export_all()
    # Friendly filename: include the active book's name when available.
    try:
        with read_session() as s:
            pid = current_project_id(s)
            from models.project import Project
            proj = s.get(Project, pid)
            book = (proj.name if proj else "project") or "project"
    except Exception:
        book = "project"
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in book)[:60] or "project"
    return Response(json.dumps(data, ensure_ascii=False, indent=2,
                                default=str),
                    mimetype="application/json",
                    headers={"Content-Disposition":
                             f"attachment; filename=asm_project_{safe}.json"})


@bp.route("/import-json", methods=["GET", "POST"])
def import_json():
    """Import project from JSON. POST with file upload."""
    if request.method == "POST":
        if "file" not in request.files:
            return jsonify({"ok": False, "error": "No file provided"}), 400
        f = request.files["file"]
        if not f.filename:
            return jsonify({"ok": False, "error": "Empty filename"}), 400
        try:
            content = f.read().decode("utf-8")
            data = json.loads(content)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return jsonify({"ok": False, "error": f"Invalid JSON: {exc}"}), 400
        try:
            result = _import_project_data(data)
            return jsonify({"ok": True, **result}), 200
        except Exception as exc:
            log.exception("Import failed")
            return jsonify({"ok": False, "error": str(exc)}), 500
    # GET: render import form
    return render_template("settings_import.html", active_nav="settings")


def _import_project_data(data: dict) -> dict:
    """Import project data — v7.5 delegates to project_transfer_service.

    The new importer is table-driven (every user-content model), idempotent
    (matched by primary key), backward compatible with asm-v4 files, and
    restores book metadata + notes that the old exporter never shipped.
    """
    from services import project_transfer_service as pts
    version = str(data.get("version", ""))
    counts = pts.import_all(data)
    log.info("Imported project data (format=%s): %s", version or "legacy",
             {k: v for k, v in counts.items() if v})
    return {"counts": counts}


@bp.route("/export-media")
def export_media():
    """S-03: download a ZIP bundle of data/media/ (companion to the JSON
    transfer export — binary media can't ride inside the JSON file)."""
    from flask import Response, send_file

    from services import project_transfer_service as pts
    bundle = pts.export_media_bundle()
    try:
        return send_file(bundle, as_attachment=True,
                         download_name=bundle.name,
                         mimetype="application/zip")
    except Exception as exc:
        log.exception("Media bundle export failed")
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/import-media", methods=["POST"])
def import_media():
    """S-03: upload a media bundle ZIP and extract it into data/media/."""
    from services import project_transfer_service as pts
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "No file provided"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"ok": False, "error": "Empty filename"}), 400
    import tempfile
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            f.save(tmp.name)
            tmp_path = tmp.name
        result = pts.import_media_bundle(tmp_path)
        return jsonify({"ok": True, **result})
    except Exception as exc:
        log.exception("Media bundle import failed")
        return jsonify({"ok": False, "error": str(exc)}), 500
    finally:
        try:
            import os as _os
            _os.unlink(tmp_path)
        except Exception:
            pass


@bp.route("/world-types", methods=["POST"])
def manage_world_types():
    """Add or remove custom world entry types."""
    data = request.get_json(silent=True) or request.form
    action = data.get("action")
    name = data.get("name", "").strip()
    from services import world_service
    if action == "add":
        types = world_service.add_custom_type(name)
        return jsonify({"ok": True, "types": types})
    elif action == "remove":
        types = world_service.remove_custom_type(name)
        return jsonify({"ok": True, "types": types})
    else:
        return jsonify({"ok": False, "error": "Unknown action"}), 400
