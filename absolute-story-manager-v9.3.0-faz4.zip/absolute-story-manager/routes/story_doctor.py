"""Story Doctor — v6.4: one-click manuscript health report."""
from __future__ import annotations

from flask import Blueprint, jsonify, render_template

from services import story_doctor_service

bp = Blueprint("story_doctor", __name__, url_prefix="/story-doctor")


@bp.route("/")
def index():
    report = story_doctor_service.full_checkup()
    return render_template("story_doctor.html",
                           active_nav="story_doctor", report=report)


@bp.route("/api/checkup")
def api_checkup():
    """Fresh checkup as JSON (for a Re-scan button)."""
    report = story_doctor_service.full_checkup()
    return jsonify({"ok": True, "report": report})
