"""v8.1 — Chat 2.0 unified API.

One endpoint family serves all three conversation modes:

  * character  — interview a single character (with real memory now)
  * group      — director mode: several characters in one room; either the
                 user picks who answers or the AI picks the most natural
                 speaker from the participants
  * assistant  — the global writing assistant (story-context aware)

Replies stream over SSE using the same event protocol as the v6.2 endpoints
(`context` → `chunk`… → `done`), so the frontend `asmStream()` helper works
unchanged. The `done` event now also carries the persisted message id so the
UI can attach per-message actions (regenerate / delete / copy).
"""
from __future__ import annotations

import json as _json
from typing import Any

from flask import Blueprint, Response, jsonify, request, stream_with_context

from core.errors import AsmError
from services import chat_service
from services._common import load_json

bp = Blueprint("chat", __name__, url_prefix="/chat")


def _err(exc: Exception, code: int = 500):
    return jsonify({"ok": False, "error": str(exc)}), code


# --------------------------------------------------------------------------
# Session CRUD
# --------------------------------------------------------------------------

@bp.route("/api/sessions")
def api_list_sessions():
    mode = request.args.get("mode") or None
    q = request.args.get("q") or None
    try:
        return jsonify({"ok": True, "sessions": chat_service.list_sessions(mode=mode, search=q)})
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions", methods=["POST"])
def api_create_session():
    data = request.get_json(silent=True) or {}
    try:
        sess = chat_service.create_session(
            mode=data.get("mode", "character"),
            character_ids=data.get("character_ids") or [],
            chapter_id=data.get("chapter_id") or None,
            settings=data.get("settings") or {},
            title=data.get("title") or "",
        )
        return jsonify({"ok": True, "session": chat_service.session_dict(sess),
                        "messages": []})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>")
def api_get_session(sid: str):
    try:
        sess = chat_service.get_session(sid)
        return jsonify({"ok": True, "session": chat_service.session_dict(sess),
                        "messages": chat_service.get_messages(sid)})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>", methods=["PATCH"])
def api_update_session(sid: str):
    data = request.get_json(silent=True) or {}
    try:
        if "title" in data:
            chat_service.rename_session(sid, data.get("title") or "")
        if "pinned" in data:
            chat_service.set_pinned(sid, bool(data.get("pinned")))
        if "settings" in data and isinstance(data.get("settings"), dict):
            chat_service.set_settings(sid, data["settings"])
        sess = chat_service.get_session(sid)
        return jsonify({"ok": True, "session": chat_service.session_dict(sess)})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>", methods=["DELETE"])
def api_delete_session(sid: str):
    try:
        chat_service.delete_session(sid)
        return jsonify({"ok": True})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/messages/<int:mid>", methods=["DELETE"])
def api_delete_message(mid: int):
    try:
        n = chat_service.delete_message(mid)
        return jsonify({"ok": True, "removed": n})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


# --------------------------------------------------------------------------
# Transcript / export
# --------------------------------------------------------------------------

@bp.route("/api/sessions/<sid>/export")
def api_export_markdown(sid: str):
    try:
        md = chat_service.session_to_markdown(sid)
        return jsonify({"ok": True, "markdown": md})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>/export/note", methods=["POST"])
def api_export_note(sid: str):
    try:
        result = chat_service.export_to_note(sid)
        return jsonify({"ok": True, **result})
    except AsmError as exc:
        return _err(exc, 404)
    except Exception as exc:
        return _err(exc)


# --------------------------------------------------------------------------
# v8.2 — Chat → Story actions (options A / B / C)
# --------------------------------------------------------------------------

@bp.route("/api/sessions/<sid>/scene-draft", methods=["POST"])
def api_scene_draft(sid: str):
    """A — generate a scene draft from the conversation (preview only)."""
    from services import chat_actions_service as actions
    try:
        draft = actions.scene_draft(sid)
        return jsonify({"ok": True, "draft": draft})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>/scene-draft/save", methods=["POST"])
def api_scene_draft_save(sid: str):
    """A — persist the previewed draft as a SceneCard."""
    from services import chat_actions_service as actions
    data = request.get_json(silent=True) or {}
    draft = data.get("draft") or {}
    try:
        result = actions.save_scene_draft(sid, draft)
        return jsonify({"ok": True, **result})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>/sync-character", methods=["POST"])
def api_sync_character(sid: str):
    """B — propose character-card updates from the conversation."""
    from services import chat_actions_service as actions
    data = request.get_json(silent=True) or {}
    character_id = data.get("character_id") or ""
    if not character_id:
        return jsonify({"ok": False, "error": "character_id is required"}), 400
    try:
        result = actions.extract_character_updates(sid, character_id)
        return jsonify({"ok": True, "extraction": result})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/characters/<character_id>/sync-character/apply", methods=["POST"])
def api_sync_character_apply(character_id: str):
    """B — apply the writer-approved extraction onto the card."""
    from services import chat_actions_service as actions
    data = request.get_json(silent=True) or {}
    updates = data.get("updates") or {}
    try:
        result = actions.apply_character_updates(character_id, updates)
        return jsonify({"ok": True, **result})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


@bp.route("/api/sessions/<sid>/suggest-questions", methods=["POST"])
def api_suggest_questions(sid: str):
    """C — interview coach: next questions worth asking."""
    from services import chat_actions_service as actions
    try:
        result = actions.suggest_questions(sid)
        return jsonify({"ok": True, **result})
    except AsmError as exc:
        return _err(exc, 400)
    except Exception as exc:
        return _err(exc)


# --------------------------------------------------------------------------
# Reply generation (send + regenerate share this)
# --------------------------------------------------------------------------

def _length_tokens(length: str) -> int:
    return {"brief": 160, "normal": 320, "expansive": 640}.get(length, 320)


def _pick_speaker(participants: list[str], message: str,
                  history_block: str) -> Any:
    """Group mode: choose which character should answer this turn."""
    from services import character_service
    chars = []
    for cid in participants:
        try:
            chars.append(character_service.get_character(cid))
        except Exception:
            continue
    if not chars:
        raise AsmError("No valid participants in this session.")
    if len(chars) == 1:
        return chars[0]
    try:
        from services import ai_service
        names = ", ".join(c.name for c in chars)
        prompt = (
            "A group scene conversation. Choose which character should "
            "answer the new message — pick the one most directly addressed, "
            "most involved, or with the strongest stake.\n\n"
            f"Characters: {names}\n\n"
            f"Scene so far:\n{history_block or '(start of scene)'}\n\n"
            f"New message: \"{message}\"\n\n"
            'Reply ONLY as JSON: {"speaker": "<exact name>"}'
        )
        data = ai_service.complete_json(prompt, max_tokens=40, temperature=0.1)
        name = str(data.get("speaker", "")).strip()
        for c in chars:
            if c.name.lower() == name.lower():
                return c
    except Exception:
        pass  # fall through to default
    return chars[0]


def _prepare_generation(sid: str, data: dict[str, Any]) -> dict[str, Any]:
    """Everything the streaming generator needs, resolved up-front.

    Returns: {session, char(s), voice, context stats, prompt, tokens,
    temperature, speaker_id, speaker_name, length}
    """
    from services import character_service, context_engine, voice_service

    sess = chat_service.get_session(sid)
    settings: dict[str, Any] = load_json(sess.settings, {}) or {}
    settings.update({k: v for k, v in (data.get("settings") or {}).items()
                     if v is not None})

    mode = sess.mode
    length = settings.get("length", "normal")
    temperature = float(settings.get("temperature", 0.8))
    include = {
        "characters": True,
        "relationships": bool(settings.get("ctx_relationships", True)),
        "world": bool(settings.get("ctx_world", True)),
        "glossary": bool(settings.get("ctx_glossary", True)),
        "plot": bool(settings.get("ctx_plot", True)),
    }
    message = (data.get("message") or "").strip()

    # 1. Memory: turns already stored (the current message is added later)
    history = chat_service.build_history(sid)
    speaker_names: dict[str, str] = {}
    participants = sess.participants
    if mode in ("character", "group"):
        for cid in participants:
            try:
                speaker_names[cid] = character_service.get_character(cid).name
            except Exception:
                speaker_names[cid] = "Character"
    history_block = chat_service.render_history(history, speaker_names)

    # 2. Who answers
    char = None
    others: list[Any] = []
    if mode == "character":
        char = character_service.get_character(participants[0])
    elif mode == "group":
        requested = data.get("speaker_id")
        if requested and requested in participants:
            char = character_service.get_character(requested)
        else:
            char = _pick_speaker(participants, message, history_block)
        for cid in participants:
            if cid != char.id:
                try:
                    others.append(character_service.get_character(cid))
                except Exception:
                    pass

    # 3. Voice + story context
    voice_summary = ""
    if char is not None:
        voice = voice_service.get_profile(char.id)
        voice_summary = voice_service.consistency_summary(char.id) if voice else ""

    context_stats: dict[str, Any] = {}
    context_block = ""
    try:
        seed = " ".join([char.name if char else "", message]) if mode != "assistant" else message
        bundle = context_engine.build_context(
            seed,
            chapter_id=sess.chapter_id,
            include=include,
            extra_characters=[c.id for c in ([char] if char else []) + others] if mode != "assistant" else None,
        )
        context_block = bundle.render()
        context_stats = bundle.stats()
    except Exception:
        context_block, context_stats = "", {}

    # 4. Prompt per mode
    if mode == "assistant":
        prompt = chat_service.build_assistant_prompt(
            context_block=context_block, history_block=history_block,
            message=message)
    elif mode == "group":
        prompt = chat_service.build_group_prompt(
            speaker=char, others=others, voice_summary=voice_summary,
            context_block=context_block, history_block=history_block,
            message=message, length=length)
    else:
        prompt = chat_service.build_character_prompt(
            char=char, voice_summary=voice_summary,
            context_block=context_block, history_block=history_block,
            message=message, length=length)

    return {
        "session": sess,
        "mode": mode,
        "char": char,
        "others": others,
        "prompt": prompt,
        "context_stats": context_stats,
        "max_tokens": _length_tokens(length),
        "temperature": temperature,
        "speaker_id": char.id if char is not None else None,
        "speaker_name": char.name if char is not None else "Assistant",
        "length": length,
    }


def _stream_reply(sid: str, data: dict[str, Any], *, persist_user: bool):
    """Shared SSE generator for send + regenerate."""
    try:
        prep = _prepare_generation(sid, data)
    except AsmError as exc:
        yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"
        return
    except Exception as exc:
        yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"
        return

    message = (data.get("message") or "").strip()
    if persist_user and message:
        try:
            chat_service.add_message(sid, role="user", content=message)
        except Exception:
            pass

    from services import ai_service

    def sse(obj: dict) -> str:
        return f"data: {_json.dumps(obj, ensure_ascii=False)}\n\n"

    yield sse({"type": "context",
               "context": {**prep["context_stats"], "speaker": prep["speaker_name"]},
               "character": prep["speaker_name"], "mode": prep["mode"]})

    full = ""
    try:
        for chunk, is_final in ai_service.generate_streaming(
            prep["prompt"], max_tokens=prep["max_tokens"],
            temperature=prep["temperature"],
        ):
            if chunk:
                full += chunk
                yield sse({"type": "chunk", "text": chunk})
            if is_final:
                break
    except Exception as exc:
        # keep partial text if any
        if full.strip():
            try:
                chat_service.add_message(
                    sid, role="assistant", content=full.strip(),
                    speaker_id=prep["speaker_id"],
                    speaker_name=prep["speaker_name"],
                    context_stats=prep["context_stats"],
                    meta={"temperature": prep["temperature"],
                          "length": prep["length"], "partial": True})
            except Exception:
                pass
        yield sse({"type": "error", "message": str(exc)})
        return

    saved_id = None
    if full.strip():
        try:
            saved = chat_service.add_message(
                sid, role="assistant", content=full.strip(),
                speaker_id=prep["speaker_id"],
                speaker_name=prep["speaker_name"],
                context_stats=prep["context_stats"],
                meta={"temperature": prep["temperature"],
                      "length": prep["length"]})
            saved_id = saved["id"]
        except Exception:
            pass
    yield sse({"type": "done", "message_id": saved_id,
               "speaker_name": prep["speaker_name"]})


@bp.route("/api/sessions/<sid>/send", methods=["POST"])
def api_send(sid: str):
    data = request.get_json(silent=True) or {}
    if not (data.get("message") or "").strip():
        return jsonify({"ok": False, "error": "message is required"}), 400
    try:
        chat_service.get_session(sid)
    except AsmError as exc:
        return _err(exc, 404)
    return Response(
        stream_with_context(_stream_reply(sid, data, persist_user=True)),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@bp.route("/api/sessions/<sid>/regenerate", methods=["POST"])
def api_regenerate(sid: str):
    """Re-roll the last AI reply: drop trailing assistant turns, re-ask."""
    try:
        chat_service.get_session(sid)
    except AsmError as exc:
        return _err(exc, 404)
    # The last user message becomes the message to re-send
    msgs = chat_service.get_messages(sid)
    last_user = None
    for m in reversed(msgs):
        if m["role"] == "user":
            last_user = m
            break
    if last_user is None:
        return jsonify({"ok": False, "error": "nothing to regenerate"}), 400
    chat_service.truncate_after_last_user(sid)
    data = request.get_json(silent=True) or {}
    data["message"] = last_user["content"]
    return Response(
        stream_with_context(_stream_reply(sid, data, persist_user=False)),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
