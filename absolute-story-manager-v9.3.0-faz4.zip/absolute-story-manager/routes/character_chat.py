"""Character AI Chat — talk to your characters as if they were real.

v6.0: the character no longer answers in a vacuum. The Context Engine feeds
their relationships, the world they live in, their voice profile, and what
recently happened in the plot — so answers stay consistent with the story.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, redirect, render_template, request, url_for

from core.db import read_session
from models.settings import Setting
from services import ai_service, character_service, context_engine, voice_service

bp = Blueprint("character_chat", __name__, url_prefix="/character-chat")


def _ai_enabled():
    with read_session() as s:
        return Setting.get(s, "ai.enabled", "false") in (True, "true", "1", "on")


@bp.route("/")
def index():
    if not _ai_enabled():
        return redirect(url_for("settings.ai_settings"))
    characters = character_service.list_characters()
    from services import chapter_service
    chapters, _ = chapter_service.list_chapters(per_page=10000)
    # v8.1 — pre-serialized cast payload for the static-JS architecture
    # (character_chat.js reads it from the #ccCharacters JSON tag).
    import json as _json
    characters_json = _json.dumps([
        {
            "id": c.id, "name": c.name, "role": c.role,
            "avatar_color": c.avatar_color or "var(--accent)",
            "initial": (c.name or "?")[:1].upper(),
        } for c in characters
    ], ensure_ascii=False).replace("<", "\\u003c")
    return render_template("character_chat/index.html", active_nav="character_chat",
                           characters=characters, chapters=chapters,
                           characters_json=characters_json)


@bp.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json(silent=True) or request.form
    char_id = data.get("character_id")
    message = data.get("message", "")
    chapter_id = data.get("chapter_id") or None
    try:
        char = character_service.get_character(char_id)
        voice = voice_service.get_profile(char_id)
        voice_summary = voice_service.consistency_summary(char_id) if voice else ""

        include = {
            "characters": True,
            "relationships": bool(data.get("ctx_relationships", True)),
            "world": bool(data.get("ctx_world", True)),
            "glossary": bool(data.get("ctx_glossary", True)),
            "plot": bool(data.get("ctx_plot", True)),
        }

        # Build story context around the character + the user's message
        bundle = context_engine.build_context(
            f"{char.name} {message}",
            chapter_id=chapter_id,
            include=include,
            extra_characters=[char.id],
        )
        context_block = bundle.render()

        parts = [
            f"You ARE {char.name}, a {char.role or 'character'} in this story. "
            f"Answer as {char.name} would — first person, in character, never break the fourth wall.",
            f"CHARACTER BACKGROUND: {char.background or 'Unknown'}",
            f"PERSONALITY: {char.psychology or 'Complex'}",
            f"HOW YOU SPEAK: {voice_summary or char.voice or 'Speak naturally, in your own style'}",
        ]
        if context_block:
            parts.append(
                "=== STORY CONTEXT (you know all of this as {name}) ===\n{ctx}\n=== END CONTEXT ===".format(
                    name=char.name, ctx=context_block)
            )
        parts.append(
            f"A reader asks you:\n\"{message}\"\n\n"
            f"Respond as {char.name} in 2-5 sentences. Use your voice. "
            "Stay consistent with everything in the context."
        )
        prompt = "\n\n".join(parts)
        result = ai_service.complete(prompt, max_tokens=int(data.get("max_tokens", 250)))
        return jsonify({
            "ok": True,
            "response": result,
            "character": char.name,
            "context": bundle.stats(),
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/api/chat-stream", methods=["POST"])
def api_chat_stream():
    """v6.2: streaming character chat — the reply flows in live.

    SSE protocol: context event first, then chunks, then done.
    """
    import json as _json

    from flask import Response, stream_with_context

    data = request.get_json(silent=True) or request.form
    char_id = data.get("character_id")
    message = data.get("message", "")
    chapter_id = data.get("chapter_id") or None
    try:
        char = character_service.get_character(char_id)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500

    voice = voice_service.get_profile(char_id)
    voice_summary = voice_service.consistency_summary(char_id) if voice else ""

    include = {
        "characters": True,
        "relationships": bool(data.get("ctx_relationships", True)),
        "world": bool(data.get("ctx_world", True)),
        "glossary": bool(data.get("ctx_glossary", True)),
        "plot": bool(data.get("ctx_plot", True)),
    }

    try:
        bundle = context_engine.build_context(
            f"{char.name} {message}",
            chapter_id=chapter_id,
            include=include,
            extra_characters=[char.id],
        )
        context_block = bundle.render()
    except Exception:
        bundle = context_engine.ContextBundle()
        context_block = ""

    parts = [
        f"You ARE {char.name}, a {char.role or 'character'} in this story. "
        f"Answer as {char.name} would — first person, in character, never break the fourth wall.",
        f"CHARACTER BACKGROUND: {char.background or 'Unknown'}",
        f"PERSONALITY: {char.psychology or 'Complex'}",
        f"HOW YOU SPEAK: {voice_summary or char.voice or 'Speak naturally, in your own style'}",
    ]
    if context_block:
        parts.append(
            "=== STORY CONTEXT (you know all of this as {name}) ===\n{ctx}\n=== END CONTEXT ===".format(
                name=char.name, ctx=context_block)
        )
    parts.append(
        f"A reader asks you:\n\"{message}\"\n\n"
        f"Respond as {char.name} in 2-5 sentences. Use your voice. "
        "Stay consistent with everything in the context."
    )
    prompt = "\n\n".join(parts)
    max_tokens = int(data.get("max_tokens", 250))

    def generate():
        yield f"data: {_json.dumps({'type': 'context', 'context': bundle.stats(), 'character': char.name})}\n\n"
        try:
            for chunk, is_final in ai_service.generate_streaming(
                prompt, max_tokens=max_tokens, temperature=0.8,
            ):
                if chunk:
                    yield f"data: {_json.dumps({'type': 'chunk', 'text': chunk})}\n\n"
                if is_final:
                    yield f"data: {_json.dumps({'type': 'done'})}\n\n"
                    return
            yield f"data: {_json.dumps({'type': 'done'})}\n\n"
        except Exception as exc:
            yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
