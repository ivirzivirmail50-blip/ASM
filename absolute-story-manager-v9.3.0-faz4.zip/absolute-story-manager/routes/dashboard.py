"""Dashboard routes — Story Cockpit (v7.0: writer home with book hero)."""
from __future__ import annotations

from datetime import date

from flask import Blueprint, render_template

from core.db import read_session
from models.project import Project
from models.settings import Setting
from services import stats_service
from services._common import current_project_id

bp = Blueprint("dashboard", __name__)


@bp.route("/")
def index():
    stats = stats_service.all_dashboard_stats()

    # v7.0 — active book context for the writer hero
    book: dict = {}
    needs_onboarding = False
    try:
        with read_session() as s:
            pid = current_project_id(s)
            p = s.get(Project, pid)
            onboarded = Setting.get(s, "onboarded", "false")
            chapter_count = stats.get("counts", {}).get("chapters", 0)
            needs_onboarding = (onboarded not in (True, "true", "1")
                                and chapter_count == 0)
            if p:
                daily_goal = int(Setting.get(s, "daily_word_goal", 500) or 500)
                book = {
                    "id": p.id,
                    "name": p.name,
                    "subtitle": p.subtitle,
                    "genre": p.genre,
                    "target_words": p.target_words,
                    "deadline": p.deadline.isoformat() if p.deadline else None,
                    "deadline_str": p.deadline.strftime("%d %b %Y") if p.deadline else None,
                    "days_left": (p.deadline - date.today()).days if p.deadline else None,
                    "color": p.color or "var(--accent)",
                    "daily_goal": daily_goal,
                }
    except Exception:
        book = {}

    return render_template("dashboard.html", stats=stats, book=book,
                           needs_onboarding=needs_onboarding,
                           active_nav="dashboard")
