"""Universal import routes (v8.6) — preview + execute for ASM JSON exports.

The Import Center page itself lives at ``/chapters/import-center`` (historic
home); these two API endpoints power its new "ASM Export Bundle" card and
close the export/import round-trip that v8.5 opened.
"""
from __future__ import annotations

import json
import logging

from flask import Blueprint, jsonify, request

from core.errors import AsmError
from services import import_service

log = logging.getLogger("asm.routes.imports")
bp = Blueprint("imports", __name__, url_prefix="/import")

# Upload ceiling — same as the rest of the Import Center.
MAX_UPLOAD_BYTES = 25 * 1024 * 1024

# Where each entity kind should link to after a successful import.
_ENTITY_URLS = {
    "character": ("characters.detail", "character_id"),
    "world_entry": ("world.detail", "entry_id"),
    "scene": ("scenes.index", None),
    "glossary": ("glossary.index", None),
    "reference": ("references.index", None),
}


def _read_upload() -> bytes:
    f = request.files.get("file")
    if f is None or not f.filename:
        raise AsmError("No file provided.", status_code=400,
                       code="upload_error")
    raw = f.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise AsmError("File too large (max 25 MB).", status_code=413,
                       code="upload_error")
    if not f.filename.lower().endswith(".json"):
        raise AsmError("Only .json files are supported here.",
                       status_code=400, code="upload_error")
    return raw


@bp.route("/preview", methods=["POST"])
def preview():
    """Dry-run an ASM JSON export: what exists, what is new, what clashes."""
    try:
        data = import_service.parse_json_bytes(_read_upload())
        strategy = request.form.get("strategy", "skip")
        payload = import_service.preview_import(data, strategy=strategy)
        payload["ok"] = True
        return jsonify(payload)
    except AsmError as exc:
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code
    except Exception as exc:  # noqa: BLE001 — surfaced as JSON, never a 500 page
        log.exception("import preview failed")
        return jsonify({"ok": False, "error": f"Preview failed: {exc}"}), 400


@bp.route("/execute", methods=["POST"])
def execute():
    """Run the import for real. Form fields:
    file (required), strategy (skip|overwrite|duplicate),
    exclude (JSON array of row indexes to leave out).
    """
    try:
        data = import_service.parse_json_bytes(_read_upload())
        strategy = request.form.get("strategy", "skip")
        exclude_raw = request.form.get("exclude", "")
        exclude: set[int] = set()
        if exclude_raw:
            try:
                vals = json.loads(exclude_raw)
                if isinstance(vals, list):
                    exclude = {int(v) for v in vals if str(v).lstrip("-").isdigit()}
            except (json.JSONDecodeError, TypeError, ValueError):
                raise AsmError("exclude must be a JSON array of row indexes.",
                               status_code=400, code="validation_error")
        result = import_service.execute_import(
            data, strategy=strategy, exclude=exclude)
        result["ok"] = True
        # attach navigation-friendly urls
        for r in result.get("results", []):
            spec = _ENTITY_URLS.get(r.get("entity") or "")
            if not spec or not r.get("id"):
                r["url"] = None
                continue
            endpoint, kw = spec
            try:
                from flask import url_for
                r["url"] = url_for(endpoint, **({kw: r["id"]} if kw else {}))
            except Exception:
                r["url"] = None
        return jsonify(result)
    except AsmError as exc:
        return jsonify({"ok": False, "error": exc.user_message}), exc.status_code
    except Exception as exc:  # noqa: BLE001
        log.exception("import execute failed")
        return jsonify({"ok": False, "error": f"Import failed: {exc}"}), 400
