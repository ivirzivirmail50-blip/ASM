"""AI routes — invisible (404) when AI disabled."""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, request

from core.db import write_transaction
from core.errors import AiDisabledError, AsmError
from services import ai_history_service, ai_service
from services._common import log_activity, new_uuid

log = logging.getLogger("asm.routes.ai")
bp = Blueprint("ai", __name__, url_prefix="/ai")


def _guard():
    """Return an error response if AI is disabled."""
    if not ai_service.is_enabled():
        from flask import abort
        abort(404)




@bp.route("/auto-detect")
def auto_detect():
    """Auto-detect a running Ollama instance and return available models."""
    try:
        import requests as req
        # Try localhost:11434
        for host in ["http://localhost:11434", "http://127.0.0.1:11434"]:
            try:
                resp = req.get(f"{host}/api/tags", timeout=3)
                if resp.status_code == 200:
                    data = resp.json()
                    models = [m["name"] for m in data.get("models", [])]
                    # Recommend models good for creative writing
                    recommended = [m for m in models if any(k in m.lower() for k in
                        ["llama", "mistral", "qwen", "gemma", "phi", "command"])]
                    return jsonify({
                        "ok": True,
                        "detected": True,
                        "host": host,
                        "models": models,
                        "recommended": recommended[:5],
                    })
            except (req.RequestException, req.ConnectionError):
                continue
        return jsonify({"ok": True, "detected": False, "models": [], "recommended": []})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/models")
def list_models():
    """Fetch available models from the configured provider."""
    _guard()
    try:
        # v9.0.1 (S-04): was `_get_config(None)` which crashed with
        # AttributeError (None.query) whenever AI was ENABLED — the exact
        # opposite of what the settings page needed. The no-arg call opens
        # (and closes) its own read_session before any network I/O.
        # v9.2.0 (F-01): provider dispatch (Ollama / OpenAI-compat /
        # Anthropic / Gemini), retry + timeout policy all live in
        # ai_service.list_models() → services/ai_providers.py.
        models = ai_service.list_models()
        return jsonify({"ok": True, "models": models})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@bp.route("/status")
def status():
    if not ai_service.is_enabled():
        return jsonify({"enabled": False})
    return jsonify({"enabled": True})


@bp.route("/continue", methods=["POST"])
def continue_writing():
    _guard()
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    out = ai_service.continue_writing(text,
                                      max_tokens=int(data.get("max_tokens", 400)))
    ai_history_service.save("continue", out,
                            prompt_summary="Basic continuation")
    return jsonify({"ok": True, "response": out})


@bp.route("/continue-context", methods=["POST"])
def continue_with_context():
    """Context-aware AI continuation — powered by the v6.0 Context Engine.

    Sends characters mentioned/linked, their relationships, world entries,
    glossary terms, and plot memory (previous chapter synopses).
    """
    _guard()
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    chapter_id = data.get("chapter_id")
    tone = data.get("tone", "")
    from services import context_engine

    instruction = (
        "You are a skilled fiction writer. Continue the story in the same "
        "style, tense, and voice. Return ONLY the continuation text — no "
        "preamble, no commentary."
        + (f"\nDESIRED TONE: {tone}" if tone else "")
    )
    prompt, bundle = context_engine.build_prompt(
        instruction, text,
        chapter_id=chapter_id,
        include={
            "characters": bool(data.get("ctx_characters", True)),
            "relationships": bool(data.get("ctx_relationships", True)),
            "world": bool(data.get("ctx_world", True)),
            "glossary": bool(data.get("ctx_glossary", True)),
            "plot": bool(data.get("ctx_plot", True)),
        },
        tail_chars=1500,
    )
    out = ai_service.generate(prompt, max_tokens=int(data.get("max_tokens", 500)),
                              temperature=0.8)
    _log_ai_action_ctx(chapter_id, bundle)
    ai_history_service.save("continue_context", out,
                            entity_type="chapter", entity_id=chapter_id or "",
                            prompt_summary="Context-aware continuation",
                            metadata=bundle.stats())
    return jsonify({"ok": True, "response": out,
                    "context": bundle.stats()})


def _log_ai_action_ctx(chapter_id, bundle) -> None:
    """Log the context size for analytics (no prompt text, as always)."""
    try:
        with write_transaction() as s:
            log_activity(
                s, entity_type="ai_action", entity_id=chapter_id or new_uuid(),
                entity_title="continue_with_context",
                action="continue_with_context",
                details={"context": bundle.stats()},
            )
    except Exception:
        pass


@bp.route("/summarize", methods=["POST"])
def summarize():
    _guard()
    data = request.get_json(silent=True) or {}
    out = ai_service.summarize(data.get("text", ""))
    return jsonify({"ok": True, "response": out})


@bp.route("/rewrite", methods=["POST"])
def rewrite():
    _guard()
    data = request.get_json(silent=True) or {}
    out = ai_service.rewrite(data.get("text", ""), data.get("tone", "neutral"))
    return jsonify({"ok": True, "response": out})


@bp.route("/suggest-tags", methods=["POST"])
def suggest_tags():
    _guard()
    data = request.get_json(silent=True) or {}
    out = ai_service.suggest_tags(data.get("text", ""))
    return jsonify({"ok": True, "tags": out})


@bp.route("/suggest-synopsis", methods=["POST"])
def suggest_synopsis():
    _guard()
    data = request.get_json(silent=True) or {}
    out = ai_service.suggest_synopsis(data.get("text", ""))
    return jsonify({"ok": True, "synopsis": out})


@bp.route("/generate-name", methods=["POST"])
def generate_name():
    _guard()
    data = request.get_json(silent=True) or {}
    culture = data.get("culture", "fantasy")
    kind = data.get("kind", "character")
    out = ai_service.generate_name(culture=culture, kind=kind)
    ai_history_service.save("name_gen", "\n".join(out),
                            prompt_summary=f"{culture} {kind} names",
                            metadata={"culture": culture, "kind": kind})
    return jsonify({"ok": True, "names": out})


@bp.route("/generate-dialogue", methods=["POST"])
def generate_dialogue():
    """Generate dialogue in a character's voice."""
    _guard()
    data = request.get_json(silent=True) or {}
    character_id = data.get("character_id")
    # Fetch character profile
    from services import character_service
    ch = character_service.get_character(character_id)
    out = ai_service.generate_dialogue(
        character_name=ch.name,
        character_voice=ch.voice or "",
        character_psychology=ch.psychology or "",
        other_character=data.get("other_character", ""),
        scene_context=data.get("scene_context", ""),
        emotion=data.get("emotion", "neutral"),
        entity_id=character_id,
    )
    ai_history_service.save("dialogue", out,
                            entity_type="character", entity_id=character_id,
                            entity_title=ch.name,
                            prompt_summary=f"Dialogue for {ch.name} ({data.get('emotion', 'neutral')})",
                            metadata={"emotion": data.get("emotion", "neutral"),
                                      "other": data.get("other_character", "")})
    return jsonify({"ok": True, "dialogue": out,
                    "character": ch.name})


@bp.route("/consistency-check", methods=["POST"])
def consistency_check():
    """Run a consistency check across chapters vs character/world DB."""
    _guard()
    from services import chapter_service, character_service, world_service
    from services._common import load_json
    chapters = chapter_service.list_chapters(sort="sort_order",
                                             with_content=True)[0]
    chapter_texts = [{"title": c.title, "content": c.content}
                     for c in chapters[:10]]
    characters = character_service.list_characters()
    char_profiles = [{"name": c.name, "physical": c.physical,
                      "psychology": c.psychology, "background": c.background}
                     for c in characters]
    world = world_service.list_entries()[0]  # list_entries now returns (entries, total)
    world_entries = [{"name": w.name, "type": w.type,
                      "description": w.description, "content": w.content}
                     for w in world]
    findings = ai_service.consistency_check(
        chapter_texts, char_profiles, world_entries,
    )
    import json as _json
    ai_history_service.save("consistency", _json.dumps(findings, indent=2),
                            prompt_summary=f"Consistency check ({len(findings)} findings)")
    return jsonify({"ok": True, "findings": findings,
                    "count": len(findings)})


@bp.route("/continue-stream", methods=["POST"])
def continue_stream():
    """Streaming version of /ai/continue — yields text chunks via SSE.

    v6.2: chunks are JSON-encoded so newlines survive the wire (the old
    implementation replaced \n with spaces, destroying paragraph structure).
    """
    _guard()
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    import json as _json

    from flask import Response, stream_with_context

    def generate():
        try:
            prompt = (
                "Continue the following story text in the same style and tone. "
                "Return only the continuation, no preamble.\n\n"
                f"...{text[-1000:]}"
            )
            for chunk, is_final in ai_service.generate_streaming(
                prompt, max_tokens=int(data.get("max_tokens", 400)),
                temperature=0.8,
            ):
                if chunk:
                    yield f"data: {_json.dumps({'type': 'chunk', 'text': chunk})}\n\n"
                if is_final:
                    yield f"data: {_json.dumps({'type': 'done'})}\n\n"
                    return
            yield f"data: {_json.dumps({'type': 'done'})}\n\n"
        except AsmError as exc:
            yield f"data: {_json.dumps({'type': 'error', 'message': exc.user_message})}\n\n"
        except Exception as exc:
            yield f"data: {_json.dumps({'type': 'error', 'message': str(exc)})}\n\n"

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
