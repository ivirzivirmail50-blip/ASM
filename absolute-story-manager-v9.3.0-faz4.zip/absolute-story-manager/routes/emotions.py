"""Emotion Arc routes (v8.0) — "Duygu Yayı".

Page renders the first chapter's analysis server-side; the chapter selector
switches via the JSON API without a reload (static js/emotion.js, v7.5
architecture: no inline Jinja-processed script blocks).
"""
from __future__ import annotations

import json
import logging

from flask import Blueprint, jsonify, render_template, request

from services import emotion_service as svc

log = logging.getLogger("asm.routes.emotions")
bp = Blueprint("emotions", __name__, url_prefix="/emotions")


def _first_chapter_id() -> str | None:
    chapters = svc.chapters_with_emotions()
    return chapters[0]["id"] if chapters else None


def _json_safe(obj) -> str:
    """Serialize for embedding in <script type=application/json>: a literal
    ``</script>`` inside chapter excerpts would terminate the tag early."""
    return json.dumps(obj, ensure_ascii=False).replace("<", "\\u003c")


@bp.route("/")
def index():
    chapters = svc.chapters_with_emotions()
    selected_id = request.args.get("chapter") or (chapters[0]["id"] if chapters else None)
    analysis = svc.analyze_chapter(selected_id) if selected_id else None
    book = svc.book_curve()
    return render_template(
        "emotions/index.html",
        active_nav="emotions",
        chapters=chapters,
        selected_id=selected_id,
        analysis=analysis,
        book=book,
        # JSON payloads serialized server-side: Jinja dict-literal inside
        # comprehension is NOT supported (v7.8 lesson) and |tojson|e is a
        # no-op on Markup (v7.8 lesson) — so we dumps() here and |e there.
        analysis_json=_json_safe(analysis),
        book_json=_json_safe(book),
        chapters_json=_json_safe(chapters),
    )


@bp.route("/api/chapter/<chapter_id>")
def api_chapter(chapter_id: str):
    result = svc.analyze_chapter(chapter_id)
    if result is None:
        return jsonify({"ok": False, "error": "chapter_not_found"}), 404
    return jsonify({"ok": True, "analysis": result})


@bp.route("/api/book")
def api_book():
    return jsonify({"ok": True, **svc.book_curve()})


@bp.route("/api/chapters")
def api_chapters():
    return jsonify({"ok": True, "chapters": svc.chapters_with_emotions()})
