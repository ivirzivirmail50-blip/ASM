"""Corkboard Outline 2.0 — unified manuscript outline view.

v7.3 — Deep Writing Experience:
  Shows ALL chapters as visual cards in a single corkboard grid, with drag-drop
  reorder (calls existing chapter reorder API), per-chapter synopsis + word count
  + status + scene count + tag chips. Filter by status/tag. SVG icons throughout.
  Distinct from /scenes/ (which is chapter-scoped and per-scene).
"""
from __future__ import annotations

import logging

from flask import Blueprint, render_template, request

from core.db import read_session
from models.chapter import Chapter
from models.settings import Setting
from services import chapter_service, scene_service
from services._common import current_project_id, load_json

log = logging.getLogger("asm.routes.outline")
bp = Blueprint("outline", __name__, url_prefix="/outline")


@bp.route("/")
def index():
    """Unified corkboard outline of the whole manuscript."""
    chapters, _ = chapter_service.list_chapters(per_page=10000, sort="sort_order")
    status_filter = request.args.get("status", "all")
    tag_filter = (request.args.get("tag") or "").strip().lower()

    # Scene counts per chapter
    scene_counts: dict[str, int] = {}
    try:
        stats = scene_service.stats()
        scene_counts = dict(stats.get("by_chapter") or {})
    except Exception:
        pass

    # All tags across chapters (for the filter dropdown)
    all_tags: set[str] = set()
    enriched = []
    for ch in chapters:
        tags = load_json(getattr(ch, "tags", "[]"), [])
        if not isinstance(tags, list):
            tags = []
        for t in tags:
            if isinstance(t, str) and t.strip():
                all_tags.add(t.strip())
        # Apply filters
        if status_filter != "all" and (ch.status or "draft") != status_filter:
            continue
        if tag_filter and tag_filter not in [t.lower() for t in tags if isinstance(t, str)]:
            continue
        enriched.append({
            "id": ch.id,
            "title": ch.title,
            "status": ch.status or "draft",
            "word_count": ch.word_count or 0,
            "sort_order": ch.sort_order,
            "synopsis": ch.synopsis or "",
            "tags": tags,
            "scene_count": scene_counts.get(ch.id, 0),
            "pov_character_id": getattr(ch, "pov_character_id", None),
            "location": getattr(ch, "location", None),
        })

    # Daily goal for the inline mini-stat
    try:
        with read_session() as s:
            daily_goal = int(Setting.get(s, "daily_word_goal", 500) or 500)
    except Exception:
        daily_goal = 500

    total_words = sum(c["word_count"] for c in enriched)
    project_id = None
    try:
        with read_session() as s:
            project_id = current_project_id(s)
    except Exception:
        pass

    return render_template(
        "outline.html",
        active_nav="outline",
        chapters=enriched,
        all_tags=sorted(all_tags),
        total_words=total_words,
        total_chapters=len(enriched),
        avg_words=(total_words // len(enriched)) if enriched else 0,
        daily_goal=daily_goal,
        current_status=status_filter,
        current_tag=tag_filter,
    )
