"""SSE (Server-Sent Events) kanalı — F-04, v9.3.0.

GET /events → text/event-stream akışı:
  * ``core.events.bus`` aboneliği (her istemci kendi kuyruğunu alır)
  * 15 sn'de bir ``: ping`` yorum satırı (proxy timeout koruması)
  * bağlantı koptuğunda abonelik temizlenir (finally)
  * retry: 3000 → tarayıcı kopunca 3 sn'de yeniden bağlanır

Olay üreticileri (şimdilik):
  * F-05 görev kuyruğu: task.enqueued / task.progress / task.done /
    task.failed / task.recovered — task_queue_service.register_publisher
    ile bu modülde bağlanır.
Yol haritası: AI akış ilerlemesi, yedekleme durumu aynı kanaldan (kart
metni: "tek SSE yardımcısı").
"""
from __future__ import annotations

import json
import queue

from flask import Blueprint, Response

from core.events import bus

bp = Blueprint("events", __name__, url_prefix="/events")

# SSE süresiz akış — geliştirme sunucusunda thread başına bir istemci;
# tek kullanıcılı yerel uygulama için 1-2 sekme = 1-2 thread, kabul.
_HEARTBEAT_SECONDS = 15.0


# F-05 köprüsü: görev kuyruğu olaylarını veri yoluna yayınla.
# İçe aktarma sırasında kaydet — blueprint auto-discovery bu modülü app
# kurulumunda yükler; task_queue_service döngüsel ithal etmez.
def _wire_task_queue() -> None:
    try:
        from services import task_queue_service

        task_queue_service.register_publisher(bus.publish)
    except Exception:  # noqa: BLE001 - SSE ek olsun, uygulma zorunlu değil
        pass


_wire_task_queue()


@bp.route("")
def stream():
    def generate():
        q = bus.subscribe()
        try:
            # İlk satırlar: tarayıcıya yeniden bağlanma politikası + açılış
            yield "retry: 3000\n\n"
            yield "event: hello\ndata: {\"event\": \"hello\"}\n\n"
            while True:
                try:
                    event = q.get(timeout=_HEARTBEAT_SECONDS)
                    payload = json.dumps(event, default=str)
                    name = event.get("event", "message")
                    yield f"event: {name}\ndata: {payload}\n\n"
                except queue.Empty:
                    # Keepalive yorum satırı — akışı canlı tutar.
                    yield ": ping\n\n"
        finally:
            bus.unsubscribe(q)

    resp = Response(generate(), mimetype="text/event-stream")
    resp.headers["Cache-Control"] = "no-cache"
    resp.headers["X-Accel-Buffering"] = "no"
    resp.headers["Connection"] = "keep-alive"
    return resp
