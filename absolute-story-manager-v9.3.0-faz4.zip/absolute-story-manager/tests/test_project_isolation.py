"""M-02 — project isolation for the AI context engine and search (v9.1.0).

Acceptance criteria from the plan:
  - with two seeded books, the AI prompt contains ONLY the active book's
    characters (asserted on the bundle)
  - search returns results ONLY from the active book
  - existing single-book tests keep passing (default resolution: 'default')
"""
from __future__ import annotations

import pytest

from core.db import read_session, write_transaction
from models.chapter import Chapter
from models.character import Character
from models.glossary import GlossaryEntry
from models.project import Project
from models.settings import Setting
from models.world import WorldEntry
from services import context_engine, search_service


def _set_active_project(pid: str) -> None:
    with write_transaction() as s:
        row = s.query(Setting).filter_by(key="active_project_id").first()
        if row:
            row.value = pid
        else:
            s.add(Setting(key="active_project_id", value=pid))


@pytest.fixture()
def two_books():
    """Seed two isolated books with distinct but searchable content."""
    with write_transaction() as s:
        # Flush projects first: without ORM relationships SQLAlchemy cannot
        # infer insert order, and the chapters FK would fire before the
        # projects rows exist.
        s.add(Project(id="book1", name="Book One"))
        s.add(Project(id="book2", name="Book Two"))
        s.flush()
        # Shared keyword 'dragon' in both books makes isolation observable
        # in search results.
        s.add(Character(id="c-elara", project_id="book1", name="Elara",
                        background="Elara raised a dragon in the north."))
        s.add(Character(id="c-kael", project_id="book1", name="Kael",
                        background="Kael the cartographer."))
        s.add(Character(id="c-zephyr", project_id="book2", name="Zephyr",
                        background="Zephyr fought a dragon in the south."))
        s.add(WorldEntry(id="w-storm", project_id="book1", name="Stormhaven",
                         type="location",
                         description="A storm-lashed harbor city."))
        s.add(WorldEntry(id="w-raven", project_id="book2", name="Ravenhold",
                         type="location",
                         description="A mountain fortress."))
        s.add(GlossaryEntry(id="g-ash", project_id="book1", term="Ashbound",
                            definition="Mark of the old order."))
        s.add(GlossaryEntry(id="g-sunk", project_id="book2", term="Sunken Pact",
                            definition="An oath beneath the waves."))
        s.add(Chapter(id="ch1-1", project_id="book1", title="One: Arrival",
                      sort_order=1, synopsis="Elara arrives at Stormhaven."))
        s.add(Chapter(id="ch1-2", project_id="book1", title="One: The Mark",
                      sort_order=2, synopsis="The Ashbound mark awakens."))
        s.add(Chapter(id="ch2-1", project_id="book2", title="Two: Siege",
                      sort_order=1, synopsis="Zephyr defends Ravenhold."))
    _set_active_project("book1")
    return {"book1": ["Elara", "Kael"], "book2": ["Zephyr"]}


# ---------------------------------------------------------------------------
# Context engine
# ---------------------------------------------------------------------------

class TestContextIsolation:

    def test_prompt_contains_only_active_book_characters(self, two_books):
        bundle = context_engine.build_context(
            "Elara and Zephyr met at Stormhaven to discuss the Ashbound mark."
        )
        names = {c["name"] for c in bundle.characters}
        assert "Elara" in names          # active book character (mentioned)
        assert "Zephyr" not in names     # OTHER book — must not leak
        world_names = {w["name"] for w in bundle.world}
        assert "Stormhaven" in world_names
        assert "Ravenhold" not in world_names
        gloss_terms = {g["term"] for g in bundle.glossary}
        assert "Ashbound" in gloss_terms
        assert "Sunken Pact" not in gloss_terms

    def test_switching_active_book_switches_context(self, two_books):
        _set_active_project("book2")
        bundle = context_engine.build_context(
            "Elara and Zephyr met at Ravenhold to discuss the Sunken Pact."
        )
        names = {c["name"] for c in bundle.characters}
        assert "Zephyr" in names
        assert "Elara" not in names
        assert "Kael" not in names

    def test_explicit_project_id_overrides_active(self, two_books):
        bundle = context_engine.build_context(
            "Elara and Zephyr quarrelled about the Sunken Pact.",
            project_id="book2",
        )
        names = {c["name"] for c in bundle.characters}
        assert "Zephyr" in names
        assert "Elara" not in names
        assert bundle.stats()["project_id"] == "book2"

    def test_stats_reports_active_project(self, two_books):
        bundle = context_engine.build_context("Elara walked.")
        assert bundle.stats()["project_id"] == "book1"

    def test_chapter_from_other_project_is_ignored(self, two_books):
        # Anchor chapter belongs to book2 while book1 is active: the anchor
        # must resolve to None (no plot memory, no location leak).
        bundle = context_engine.build_context(
            "A tense meeting.",
            chapter_id="ch2-1",
        )
        assert bundle.plot == []
        # No chapter -> 'last chapters' fallback also stays book-scoped.
        assert all("Siege" not in (p["title"] or "") for p in [])

    def test_plot_memory_is_project_scoped(self, two_books):
        bundle = context_engine.build_context(
            "The mark burns.", chapter_id="ch1-2"
        )
        titles = [p["title"] for p in bundle.plot]
        assert "One: Arrival" in titles          # preceding book1 chapter
        assert not any("Siege" in t for t in titles)  # book2 chapter absent

    def test_no_anchor_uses_last_chapters_of_active_book(self, two_books):
        bundle = context_engine.build_context("Fresh scene, no anchor.")
        titles = [p["title"] for p in bundle.plot]
        # plot_depth=3, book1 has 2 chapters — both, in reading order.
        assert titles == ["One: Arrival", "One: The Mark"]
        assert "Two: Siege" not in titles


# ---------------------------------------------------------------------------
# Search service
# ---------------------------------------------------------------------------

class TestSearchIsolation:

    def test_fts_search_scoped_to_active_book(self, two_books):
        # 'dragon' appears in Elara's (book1) and Zephyr's (book2) background.
        results = search_service.search_characters("dragon")
        names = [r["title"] for r in results]
        assert "Elara" in names
        assert "Zephyr" not in names

    def test_search_switches_with_active_book(self, two_books):
        _set_active_project("book2")
        results = search_service.search_characters("dragon")
        names = [r["title"] for r in results]
        assert "Zephyr" in names
        assert "Elara" not in names

    def test_search_explicit_project_id(self, two_books):
        results = search_service.search_characters("dragon", project_id="book2")
        names = [r["title"] for r in results]
        assert names == ["Zephyr"]

    def test_search_all_scopes_every_module(self, two_books):
        results = search_service.search_all("dragon")
        assert all(
            "Zephyr" not in (r["title"] + r["snippet"])
            for r in results["characters"]
        )

    def test_chapter_search_scoped(self, two_books):
        results = search_service.search_chapters("Arrival")
        titles = [r["title"] for r in results]
        assert "One: Arrival" in titles
        results2 = search_service.search_chapters("Siege")
        assert results2 == []  # book2 chapter not reachable from book1

    def test_world_search_scoped(self, two_books):
        results = search_service.search_world("fortress")
        names = [r["title"] for r in results]
        assert names == []  # Ravenhold is book2; active is book1
        results2 = search_service.search_world("harbor")
        assert [r["title"] for r in results2] == ["Stormhaven"]

    def test_like_fallback_is_scoped(self, two_books, monkeypatch):
        # Force the LIKE path (FTS query disabled) — the fallback SQL must
        # still carry the project filter.
        monkeypatch.setattr(search_service, "_escape_fts", lambda q: "")
        results = search_service.search_characters("dragon")
        names = [r["title"] for r in results]
        assert "Elara" in names
        assert "Zephyr" not in names

    def test_regex_search_is_scoped(self, two_books):
        # Regex flow = LIKE prefilter (literal substring) + regex post-filter
        # on title/snippet. 'e' appears in every name (Elara, Kael, Zephyr),
        # so without the project scope both books would return rows.
        results = search_service.search_characters("e", regex=True)
        names = {r["title"] for r in results}
        assert {"Elara", "Kael"} <= names
        assert "Zephyr" not in names


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------

class TestBackwardCompatibility:

    def test_default_resolution_for_single_book(self):
        # No active_project_id row mutation: 'default' project, empty DB of
        # entities — build_context still works and scopes to 'default'.
        bundle = context_engine.build_context("Some text.")
        assert bundle.stats()["project_id"] == "default"
        assert bundle.characters == []

    def test_build_prompt_passes_project_id(self, two_books):
        prompt, bundle = context_engine.build_prompt(
            "Continue the story.", "Elara and Zephyr met.",
            project_id="book2",
        )
        assert bundle.project_id == "book2"
        assert "Zephyr" in prompt
        assert "Elara is a" not in prompt  # book1 character absent
        # The active-book stat is reported for the UI panel.
        assert bundle.stats()["project_id"] == "book2"

    def test_bundle_stats_shape_unchanged_plus_project(self, two_books):
        stats = context_engine.build_context("Elara.").stats()
        expected_keys = {"characters", "relationships", "world", "glossary",
                         "plot", "chars_used", "project_id"}
        assert set(stats.keys()) == expected_keys

    def test_setting_helper_reads_active_project(self, two_books):
        with read_session() as s:
            from services._common import current_project_id
            assert current_project_id(s) == "book1"
