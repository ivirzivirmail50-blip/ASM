"""ASM v6.2 Writer's Flow tests — streaming SSE endpoints (mocked provider),
newline preservation, context stats events, editor/chat UI hooks."""
import json
from unittest.mock import patch

import pytest

from core.errors import AiProviderError
from services import ai_providers, ai_service


def _enable_ai(model="test-model"):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", "openai")
        Setting.set(s, "ai.model", model)


def _fake_stream_chunks(chunks):
    """Patch generate_streaming to yield the given chunks then final."""
    def fake(prompt, *, max_tokens=600, temperature=0.7):
        for c in chunks:
            yield (c, False)
        yield ("", True)
    return patch.object(ai_service, "generate_streaming", side_effect=fake)


def _sse_events(body):
    """Parse an SSE response BODY (string) into a list of event dicts."""
    events = []
    for part in body.split("\n\n"):
        part = part.strip()
        if not part:
            continue
        assert part.startswith("data: "), f"Malformed SSE frame: {part!r}"
        events.append(json.loads(part[len("data: "):]))
    return events


@pytest.fixture
def ctx_story():
    from services import chapter_service, character_service
    ch1 = chapter_service.create_chapter(
        title="Arrival", content="Elara arrived.",
        synopsis="Elara reaches the city.")
    ch2 = chapter_service.create_chapter(
        title="Storm", content="Elara fought the storm.", synopsis="Storm hits.")
    c1 = character_service.create_character(
        name="Elara", role="protagonist", psychology="brave")
    return {"ch1": ch1, "ch2": ch2, "c1": c1}


class TestCopilotStreaming:
    def test_suggest_stream_emits_context_then_chunks_then_done(self, client, ctx_story):
        _enable_ai()
        with _fake_stream_chunks(["The ", "night ", "fell."]):
            rv = client.post("/ai-copilot/api/suggest-stream", json={
                "text": "Elara walked through the city.",
                "action": "continue",
                "chapter_id": ctx_story["ch2"].id,
            })
            # SSE generators are lazy: consume the body INSIDE the patch
            # context, otherwise the real provider call runs.
            body = rv.get_data(as_text=True)
        assert rv.status_code == 200
        assert rv.mimetype == "text/event-stream"
        events = _sse_events(body)
        types = [e["type"] for e in events]
        # First event: context stats
        assert types[0] == "context"
        assert events[0]["context"]["characters"] >= 1
        # Then chunks
        assert types[1:-1] == ["chunk"] * 3
        assert events[1]["text"] == "The "
        # Final: done
        assert types[-1] == "done"

    def test_suggest_stream_preserves_newlines(self, client):
        """Regression: newlines must survive the SSE wire (v6.2 bugfix)."""
        _enable_ai()
        para = "Line one.\n\nLine two paragraph."
        with _fake_stream_chunks([para]):
            rv = client.post("/ai-copilot/api/suggest-stream", json={
                "text": "some text", "action": "continue",
            })
            body = rv.get_data(as_text=True)
        events = _sse_events(body)
        chunks = [e["text"] for e in events if e["type"] == "chunk"]
        assert "\n" in "".join(chunks), "newline lost in transport!"

    def test_suggest_stream_error_event(self, client):
        _enable_ai()

        def boom(prompt, **kw):
            raise AiProviderError("boom")

        with patch.object(ai_service, "generate_streaming", side_effect=boom):
            rv = client.post("/ai-copilot/api/suggest-stream", json={
                "text": "text", "action": "continue",
            })
            body = rv.get_data(as_text=True)
        events = _sse_events(body)
        assert events[-1]["type"] == "error"
        assert "boom" in events[-1]["message"]

    def test_continue_stream_newline_safe(self, client):
        """/ai/continue-stream also JSON-encodes chunks now."""
        _enable_ai()
        with _fake_stream_chunks(["a\n\nb"]):
            rv = client.post("/ai/continue-stream", json={"text": "x"})
            body = rv.get_data(as_text=True)
        events = _sse_events(body)
        chunks = [e["text"] for e in events if e["type"] == "chunk"]
        assert chunks == ["a\n\nb"]
        assert events[-1]["type"] == "done"


class TestCharacterChatStreaming:
    def test_chat_stream_context_and_chunks(self, client, ctx_story):
        _enable_ai()
        with _fake_stream_chunks(["I am ", "Elara."]):
            rv = client.post("/character-chat/api/chat-stream", json={
                "character_id": ctx_story["c1"].id,
                "message": "Who are you?",
            })
            body = rv.get_data(as_text=True)
        events = _sse_events(body)
        assert events[0]["type"] == "context"
        assert events[0]["character"] == "Elara"
        assert events[-1]["type"] == "done"
        text = "".join(e["text"] for e in events if e["type"] == "chunk")
        assert text == "I am Elara."

    def test_chat_stream_unknown_character_returns_500_json(self, client):
        _enable_ai()
        rv = client.post("/character-chat/api/chat-stream", json={
            "character_id": "nope", "message": "hi",
        })
        assert rv.status_code == 500
        data = rv.get_json()
        assert data["ok"] is False


class TestSuggestUnchanged:
    """The non-streaming /api/suggest must still work (fallback path)."""

    def test_suggest_json_endpoint(self, client, ctx_story):
        _enable_ai()
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          return_value="A fine continuation."):
            rv = client.post("/ai-copilot/api/suggest", json={
                "text": "Elara walked through the city.",
                "action": "continue",
                "chapter_id": ctx_story["ch2"].id,
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["suggestion"] == "A fine continuation."
        assert data["context"]["characters"] >= 1


class TestChatNonStreamingFallback:
    def test_chat_json_endpoint_still_works(self, client, ctx_story):
        _enable_ai()
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          return_value="I am Elara."):
            rv = client.post("/character-chat/api/chat", json={
                "character_id": ctx_story["c1"].id,
                "message": "Who are you?",
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["response"] == "I am Elara."


class TestStreamUIAssets:
    def test_asm_stream_helper_in_app_js(self, client):
        rv = client.get("/static/js/app.js")
        assert b"asmStream" in rv.data
        assert b"AbortController" in rv.data
        # v6.2 fix: onStart fires immediately so Stop can abort in-flight streams
        assert b"onStart" in rv.data

    def test_copilot_page_references_stream_endpoint(self, client):
        _enable_ai()
        rv = client.get("/ai-copilot/")
        assert b"suggest-stream" in rv.data
        assert b"stopStreamBtn" in rv.data
        # The stop handle must be wired via onStart, not after the await
        assert b"onStart(handle)" in rv.data

    def test_chat_page_references_stream_endpoint(self, client, ctx_story):
        # The chat script only renders when characters exist (empty state otherwise)
        _enable_ai()
        rv = client.get("/character-chat/")
        # v8.1: the page moved to the unified /chat API (still SSE under
        # the hood via asmStream in static/js/character_chat.js); the legacy
        # /character-chat/api/chat-stream endpoint itself remains available.
        assert b"character_chat.js" in rv.data
        legacy = client.post("/character-chat/api/chat-stream", json={
            "character_id": "missing", "message": "hi"})
        assert legacy.status_code == 500  # route still registered (not 404)

    def test_polish_css_has_writer_flow_layer(self, client):
        rv = client.get("/static/css/polish.css")
        assert b"WRITER'S FLOW" in rv.data
        assert b".sprint-bar" in rv.data
        assert b".CodeMirror" in rv.data
        assert b".cp-caret" in rv.data
