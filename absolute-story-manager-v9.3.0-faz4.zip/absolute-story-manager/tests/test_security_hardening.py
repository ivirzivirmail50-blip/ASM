"""S-01/S-02 — security hardening regression tests.

S-01: the app binds to 127.0.0.1 by default (network exposure is a
      conscious choice via ASM_HOST/HOST).
S-02: the blanket CSRF exemption is granted ONLY on loopback deployments;
      any other bind host enforces CSRF on every write request.
"""
from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolate_csrf_state():
    """Snapshot/clear/restore the module-level CSRFProtect state.

    ``core.csrf.csrf`` is a process-wide singleton and blueprint objects are
    module-level singletons too — exemptions granted while building one app
    leak into every other app built in the same process (a full-suite run
    builds dozens of loopback apps before this file executes). We therefore
    CLEAR both exemption sets before each test here and restore the snapshot
    afterwards, so each test observes only its own exemptions.
    """
    from core.csrf import csrf
    saved_views = set(csrf._exempt_views)
    saved_bps = set(csrf._exempt_blueprints)
    csrf._exempt_views.clear()
    csrf._exempt_blueprints.clear()
    yield
    csrf._exempt_views.clear()
    csrf._exempt_views.update(saved_views)
    csrf._exempt_blueprints.clear()
    csrf._exempt_blueprints.update(saved_bps)


def _clear_host_env(monkeypatch):
    """Ensure neither ASM_HOST nor HOST leaks from the environment."""
    monkeypatch.delenv("ASM_HOST", raising=False)
    monkeypatch.delenv("HOST", raising=False)


def _make_live_app():
    """Create the app WITHOUT the test CSRF bypass.

    ``create_app(testing=True)`` disables CSRF entirely; for these tests we
    need the production CSRF wiring, so we build a normal app and only flip
    TESTING afterwards (which does not touch WTF_CSRF_ENABLED).
    """
    from app import create_app
    app = create_app()
    app.config["TESTING"] = True
    return app


# ---------------------------------------------------------------------------
# S-01 — bind host defaults to loopback
# ---------------------------------------------------------------------------

class TestBindHostDefault:
    def test_default_host_is_loopback(self, monkeypatch):
        _clear_host_env(monkeypatch)
        from config import resolve_bind_host
        assert resolve_bind_host() == "127.0.0.1"

    def test_asm_host_overrides_legacy_host(self, monkeypatch):
        monkeypatch.setenv("HOST", "0.0.0.0")
        monkeypatch.setenv("ASM_HOST", "10.0.0.5")
        from config import resolve_bind_host
        assert resolve_bind_host() == "10.0.0.5"

    def test_legacy_host_still_honoured(self, monkeypatch):
        _clear_host_env(monkeypatch)
        monkeypatch.setenv("HOST", "192.168.1.10")
        from config import resolve_bind_host
        assert resolve_bind_host() == "192.168.1.10"

    def test_start_bat_does_not_expose_network(self):
        """The Windows launcher must not force a non-loopback bind host."""
        from pathlib import Path
        bat = Path(__file__).resolve().parent.parent / "start.bat"
        content = bat.read_text(encoding="utf-8", errors="replace")
        active = [ln for ln in content.splitlines()
                  if ln.strip().lower().startswith("set host=")]
        assert active, "start.bat must set HOST explicitly"
        for ln in active:
            assert "0.0.0.0" not in ln, f"start.bat exposes the app: {ln!r}"


# ---------------------------------------------------------------------------
# S-02 — CSRF exemption is loopback-conditional
# ---------------------------------------------------------------------------

class TestCsrfLoopbackLock:
    def test_loopback_hosts_detected(self, monkeypatch):
        _clear_host_env(monkeypatch)
        from config import is_loopback_deployment
        for host in ("127.0.0.1", "localhost", "::1", "[::1]", "LOCALHOST"):
            assert is_loopback_deployment(host), host

    def test_public_hosts_not_loopback(self):
        from config import is_loopback_deployment
        for host in ("0.0.0.0", "192.168.1.10", "example.com", ""):
            assert not is_loopback_deployment(host), host

    def test_default_deployment_is_loopback(self, monkeypatch):
        _clear_host_env(monkeypatch)
        from config import is_loopback_deployment
        assert is_loopback_deployment() is True

    def test_loopback_app_exempts_blueprints(self, monkeypatch, fresh_db):
        """Default (loopback) deployment keeps local-first ergonomics."""
        _clear_host_env(monkeypatch)
        from core.csrf import csrf
        app = _make_live_app()
        assert csrf._exempt_blueprints, (
            "loopback deployment should exempt the blueprints"
        )

    def test_public_bind_enforces_csrf_on_writes(self, monkeypatch, fresh_db):
        """ASM_HOST=0.0.0.0 → a tokenless write request must be rejected."""
        _clear_host_env(monkeypatch)
        monkeypatch.setenv("ASM_HOST", "0.0.0.0")
        app = _make_live_app()
        client = app.test_client()
        # Any write endpoint works: the CSRF guard fires before the view.
        resp = client.post("/settings/save",
                           data={"daily_word_goal": "600"},
                           follow_redirects=False)
        assert resp.status_code == 400, (
            "non-loopback deployment must reject tokenless POSTs"
        )
        assert b"CSRF" in resp.data

    def test_public_bind_still_accepts_valid_token(self, monkeypatch, fresh_db):
        """With a valid token (as asmFetch/forms send), writes succeed."""
        _clear_host_env(monkeypatch)
        monkeypatch.setenv("ASM_HOST", "0.0.0.0")
        app = _make_live_app()
        client = app.test_client()
        # Grab a real token from a rendered page (meta tag in base.html).
        page = client.get("/settings/")
        html = page.get_data(as_text=True)
        token = html.split('name="csrf-token" content="', 1)[1].split('"', 1)[0]
        assert token, "base.html must expose the csrf token"
        resp = client.post(
            "/settings/save",
            data={"daily_word_goal": "600"},
            headers={"X-CSRFToken": token},
        )
        assert resp.status_code == 200, resp.data[:200]

    def test_loopback_write_without_token_still_works(self, monkeypatch,
                                                      fresh_db):
        """Loopback deployments keep the historical exemption (no regression
        for the 1.750-test suite and local-first usage)."""
        _clear_host_env(monkeypatch)
        app = _make_live_app()
        client = app.test_client()
        resp = client.post("/settings/save",
                           data={"daily_word_goal": "600"})
        assert resp.status_code == 200
