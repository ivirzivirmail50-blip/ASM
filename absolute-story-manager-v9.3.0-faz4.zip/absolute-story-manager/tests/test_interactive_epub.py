"""M-08 — interactive EPUB route coverage (22% → 70%+)."""
from __future__ import annotations

import io
import zipfile


def _seed():
    from services import chapter_service, character_service
    chapter_service.create_chapter(
        title="Birinci Bölüm", content="Ayşe kıyıya yürüdü.",
        synopsis="açılış")
    chapter_service.create_chapter(
        title="İkinci Bölüm", content="Deniz onu çağırdı.")
    character_service.create_character(
        name="Ayşe", role="protagonist", background="Denizi sever.")
    character_service.create_character(name="Mihri", role="supporting")


class TestInteractiveEpub:

    def test_index_renders(self, client):
        _seed()
        r = client.get("/interactive-epub/")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        # Summary card: counts + download wiring.
        assert "Interactive EPUB Export" in html
        assert "Chapters</div>" in html
        assert "/interactive-epub/download" in html

    def test_download_produces_valid_epub_structure(self, client):
        _seed()
        r = client.get("/interactive-epub/download")
        assert r.status_code == 200
        assert "epub" in (r.headers.get("Content-Type") or "")

        zf = zipfile.ZipFile(io.BytesIO(r.data))
        names = zf.namelist()
        # EPUB skeleton rules.
        assert names[0] == "mimetype"
        assert zf.read("mimetype").decode() == "application/epub+zip"
        assert "META-INF/container.xml" in names
        assert "OEBPS/content.opf" in names

        opf = zf.read("OEBPS/content.opf").decode()
        assert "asm-interactive-" in opf  # unique identifier (M-05: time())
        assert "chapter1.xhtml" in opf
        assert "character1.xhtml" in opf  # character cards are in the spine

        ch1 = zf.read("OEBPS/chapter1.xhtml").decode()
        assert "Ayşe" in ch1

        card = zf.read("OEBPS/character1.xhtml").decode()
        assert "Ayşe" in card
        assert "protagonist" in card

    def test_download_empty_library_still_valid(self, client):
        r = client.get("/interactive-epub/download")
        assert r.status_code == 200
        zf = zipfile.ZipFile(io.BytesIO(r.data))
        # Skeleton exists even with no chapters.
        assert zf.namelist()[0] == "mimetype"
        assert "OEBPS/content.opf" in zf.namelist()
