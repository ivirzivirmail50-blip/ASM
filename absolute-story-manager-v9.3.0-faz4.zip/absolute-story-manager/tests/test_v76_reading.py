"""v7.6 Reading Mode 2.0 tests — page render + static JS + API + features."""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))


@pytest.fixture
def app():
    from app import create_app
    return create_app()


@pytest.fixture
def client(app):
    return app.test_client()


# ---- Page render ----

def test_reading_page_renders(client):
    r = client.get('/reading/')
    assert r.status_code == 200
    body = r.data.decode()
    assert 'Reading Mode' in body
    assert 'id="readerContent"' in body
    assert 'id="readingControls"' in body


def test_reading_page_loads_static_js(client):
    """Critical: reading page must load its JS via /static/js/reading_mode.js.
    v7.5/v7.6 root-architecture rule: NO large inline scripts in the template."""
    r = client.get('/reading/')
    body = r.data.decode()
    assert '/static/js/reading_mode.js' in body
    # Old inline function definitions must be gone
    for marker in ['async function loadChapters', 'function renderChapters',
                   'function attachChapterObserver']:
        assert marker not in body, f"Old inline function still present: {marker}"


def test_reading_page_has_new_v76_widgets(client):
    """v7.6 added: bookmark button, highlight toolbar, bookmarks panel, reading time."""
    r = client.get('/reading/')
    body = r.data.decode()
    # Highlight toolbar
    assert 'id="highlightToolbar"' in body
    # Bookmarks panel
    assert 'id="bookmarksPanel"' in body
    # Bookmarks button in controls
    assert 'id="btnBookmarks"' in body
    # Three panes: bookmarks, highlights, reading-time
    assert 'id="rbpBookmarks"' in body
    assert 'id="rbpHighlights"' in body
    assert 'id="rbpReadingTime"' in body


def test_reading_chapter_api(client):
    r = client.get('/reading/api/chapters')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'chapters' in data
    assert 'total' in data
    assert isinstance(data['chapters'], list)


# ---- Static JS file integrity ----

def test_reading_js_is_syntactically_valid():
    import subprocess
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    result = subprocess.run(['node', '--check', js_path],
                           capture_output=True, text=True)
    assert result.returncode == 0, f"SyntaxError: {result.stderr[:300]}"


def test_reading_js_no_python_slice_syntax():
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    assert '[:' not in content, "reading_mode.js contains `[:` Python slice syntax"


def test_reading_js_has_bookmark_api():
    """Static JS must expose toggleBookmark + window.readingJumpToChapter."""
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    assert 'toggleBookmark' in content
    assert 'window.readingJumpToChapter' in content
    assert 'state.bookmarks' in content
    assert 'localStorage' in content
    assert 'asm:reading:bookmarks' in content


def test_reading_js_has_highlight_api():
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    assert 'applyHighlightToSelection' in content
    assert 'restoreHighlights' in content
    assert 'state.highlights' in content
    assert 'asm:reading:highlights' in content


def test_reading_template_has_highlight_color_buttons():
    """The HTML template must contain the 4 highlight color buttons + clear."""
    tpl_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                              'templates', 'reading.html')
    with open(tpl_path) as f:
        content = f.read()
    # Highlight colors (4 + clear)
    assert '#fde68a' in content  # yellow
    assert '#bbf7d0' in content  # green
    assert '#bfdbfe' in content  # blue
    assert '#fbcfe8' in content  # pink
    assert 'hl-clear' in content


def test_reading_js_has_time_tracking():
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    assert 'state.chapterTimeMs' in content
    assert 'state.sessionActiveMs' in content
    assert 'startTimeTracker' in content
    assert 'asm:reading:chapter_times' in content
    assert 'renderReadingTimePanel' in content


def test_reading_js_keyboard_shortcuts():
    """v7.6 keyboard: Ctrl+D bookmark, Ctrl+Shift+H highlight, B bookmarks panel."""
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    # Ctrl+D bookmark
    assert "'d'" in content and 'e.ctrlKey' in content
    # Arrow keys for chapter nav
    assert 'ArrowLeft' in content
    assert 'ArrowRight' in content
    # F fullscreen
    assert "'f'" in content or "'F'" in content
    # B bookmarks panel
    assert "'b'" in content or "'B'" in content


def test_reading_js_uses_csrf_token():
    """All POST requests must include CSRF token via asmFetch.

    v9.1.0 (M-05): reading_mode.js no longer defines its own asmFetch —
    it consumes the canonical one from core.js, which sends X-CSRFToken.
    """
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'reading_mode.js')
    with open(js_path) as f:
        content = f.read()
    assert 'asmFetch' in content
    assert 'function asmFetch' not in content  # single source: core.js
    core_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                             'static', 'js', 'core.js')
    with open(core_path) as f:
        core_content = f.read()
    assert 'X-CSRFToken' in core_content  # the header lives in core.js now


def test_reading_css_styles_present():
    """polish.css must contain the new reading-* styles."""
    css_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                              'static', 'css', 'polish.css')
    with open(css_path) as f:
        content = f.read()
    assert '.reading-highlight-toolbar' in content
    assert '.reading-bookmarks-panel' in content
    assert '.rbp-stat' in content
    assert '@keyframes asm-slide-in' in content


def test_reading_template_no_longer_has_220_line_inline_script():
    """Verify reading.html no longer has the 220-line inline script (now external)."""
    tpl_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                             'templates', 'reading.html')
    with open(tpl_path) as f:
        content = f.read()
    # The template should be under 200 lines now (down from 334)
    assert len(content.split('\n')) < 200, "reading.html grew beyond expected — check inline scripts"
    # Must NOT contain the big inline block markers
    assert 'let _chapters = []' not in content
    assert 'function attachChapterObserver' not in content
    assert 'function renderChapters' not in content
    # Must reference the external JS file
    assert 'reading_mode.js' in content
