"""v7.4 — Hierarchy route + reparent endpoint tests."""
import pytest

from services import world_service


@pytest.fixture
def a_location():
    return world_service.create_entry(type_="location", name="Planet Aurelia")


def test_hierarchy_route_lists_tree(client, a_location):
    rv = client.get("/world/hierarchy")
    assert rv.status_code == 200
    assert a_location.name.encode() in rv.data
    # v7.4 — type switcher + stats should be present
    assert b"Type" in rv.data
    assert b"total" in rv.data


def test_hierarchy_route_supports_type_query(client, a_location):
    # Create a faction to verify type filter
    world_service.create_entry(type_="faction", name="Test Faction")
    rv = client.get("/world/hierarchy?type=faction")
    assert rv.status_code == 200
    assert b"Test Faction" in rv.data
    # Should NOT contain the location entry
    assert a_location.name.encode() not in rv.data


def test_reparent_route_changes_parent(client, a_location):
    b = world_service.create_entry(type_="location", name="Child B")
    # Move B under a_location
    rv = client.post(f"/world/{b.id}/reparent",
                     json={"parent_id": a_location.id})
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True
    assert data["parent_id"] == a_location.id


def test_reparent_route_to_root(client, a_location):
    b = world_service.create_entry(type_="location", name="Sub",
                                    parent_id=a_location.id)
    rv = client.post(f"/world/{b.id}/reparent", json={"parent_id": ""})
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True
    assert data["parent_id"] is None


def test_reparent_route_rejects_cycle(client, a_location):
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a_location.id)
    c = world_service.create_entry(type_="location", name="C",
                                    parent_id=b.id)
    # Try to move A under C (would create cycle)
    rv = client.post(f"/world/{a_location.id}/reparent",
                     json={"parent_id": c.id})
    assert rv.status_code == 400
    data = rv.get_json()
    assert data["ok"] is False
    assert "cycle" in data["error"].lower() or "descendant" in data["error"].lower()


def test_api_parents_route_returns_candidates(client, a_location):
    rv = client.get("/world/api/parents?type=location")
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True
    assert isinstance(data["candidates"], list)
    assert any(c["id"] == a_location.id for c in data["candidates"])
    assert "count" in data


def test_api_parents_route_with_entry_id(client, a_location):
    """Should exclude entry_id and its descendants from candidates."""
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a_location.id)
    rv = client.get(f"/world/api/parents?type=location&entry_id={a_location.id}")
    assert rv.status_code == 200
    data = rv.get_json()
    ids = [c["id"] for c in data["candidates"]]
    assert a_location.id not in ids
    assert b.id not in ids


def test_api_parents_route_empty_type(client):
    rv = client.get("/world/api/parents?type=nonexistent_type")
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True
    assert data["count"] == 0
    assert data["candidates"] == []


def test_new_route_passes_parent_candidates(client, a_location):
    """The /world/new page should receive parent_candidates list."""
    rv = client.get("/world/new")
    assert rv.status_code == 200
    # The parent picker should be present and contain a_location
    assert a_location.name.encode() in rv.data


def test_edit_route_passes_parent_candidates(client, a_location):
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a_location.id)
    rv = client.get(f"/world/{b.id}/edit")
    assert rv.status_code == 200
    # The parent picker should show a_location as the selected parent
    assert a_location.name.encode() in rv.data
    # Should have 'selected' on the a_location option
    assert b'selected' in rv.data
