"""v7.6 Story Atlas tests — page render + APIs + pin CRUD + tree structure."""
from __future__ import annotations

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))


@pytest.fixture
def app():
    from app import create_app
    return create_app()


@pytest.fixture
def client(app):
    return app.test_client()


# ---- Page render ----

def test_atlas_page_renders(client):
    r = client.get('/atlas/')
    assert r.status_code == 200
    body = r.data.decode()
    assert 'Story Atlas' in body
    assert 'id="atlasTree"' in body
    assert 'id="atlasPinsList"' in body
    assert 'id="atlasRoutesList"' in body
    assert 'id="atlasPinBackdrop"' in body
    assert '/static/js/atlas.js' in body


def test_atlas_sidebar_link(client):
    r = client.get('/atlas/')
    body = r.data.decode()
    assert 'Story Atlas' in body
    assert '/atlas/"' in body or 'href="/atlas/"' in body


def test_atlas_page_uses_static_js(client):
    r = client.get('/atlas/')
    body = r.data.decode()
    assert '/static/js/atlas.js' in body
    # Inline script functions should not be in the rendered page
    assert 'function renderTree' not in body
    assert 'function renderPins' not in body


# ---- APIs ----

def test_api_full(client):
    r = client.get('/atlas/api/full')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'tree' in data
    assert 'pins' in data
    assert 'routes' in data


def test_api_tree(client):
    r = client.get('/atlas/api/tree')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'roots' in data
    assert 'stats' in data
    assert 'total_locations' in data['stats']
    assert 'max_depth' in data['stats']
    assert 'pin_kinds' in data


def test_api_pins(client):
    r = client.get('/atlas/api/pins')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'pins' in data
    assert 'pin_kinds' in data


def test_api_routes(client):
    r = client.get('/atlas/api/routes')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'routes' in data


def test_api_candidates(client):
    r = client.get('/atlas/api/candidates')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'characters' in data
    assert 'locations' in data
    assert 'pin_kinds' in data


# ---- Pin CRUD with seeded data ----

@pytest.fixture
def seeded_atlas(app):
    """Seed a character + 2 nested locations for atlas tests."""
    from core.db import write_transaction
    from models.char_location_pin import PIN_KINDS, CharacterLocationPin
    from models.character import Character
    from models.world import WorldEntry
    # Cleanup any stale state
    with write_transaction() as s:
        for pin in s.query(CharacterLocationPin).filter(
                CharacterLocationPin.character_id == 'atlas_seed_char').all():
            s.delete(pin)
        for eid in ['atlas_seed_loc2', 'atlas_seed_loc']:
            obj = s.get(WorldEntry, eid)
            if obj:
                s.delete(obj)
        obj = s.get(Character, 'atlas_seed_char')
        if obj:
            s.delete(obj)

    with write_transaction() as s:
        from services._common import current_project_id
        pid = current_project_id(s)
        s.add(Character(id='atlas_seed_char', project_id=pid,
                        name='Atlas Hero', role='protagonist',
                        avatar_color='#ff6b6b'))
        s.add(WorldEntry(id='atlas_seed_loc', project_id=pid,
                          type='location', name='Atlas City', category='capital'))
        s.add(WorldEntry(id='atlas_seed_loc2', project_id=pid,
                          type='location', name='Atlas Cave', category='hideout',
                          parent_id='atlas_seed_loc'))
    yield
    # Cleanup after
    with write_transaction() as s:
        for pin in s.query(CharacterLocationPin).filter(
                CharacterLocationPin.character_id == 'atlas_seed_char').all():
            s.delete(pin)
        for eid in ['atlas_seed_loc2', 'atlas_seed_loc']:
            obj = s.get(WorldEntry, eid)
            if obj:
                s.delete(obj)
        obj = s.get(Character, 'atlas_seed_char')
        if obj:
            s.delete(obj)


def test_pin_create_and_delete_roundtrip(client, seeded_atlas):
    # Create pin
    r = client.post('/atlas/api/pin',
                    data=json.dumps({
                        'character_id': 'atlas_seed_char',
                        'location_id': 'atlas_seed_loc2',
                        'kind': 'hiding',
                        'note': 'after the duel'
                    }),
                    content_type='application/json')
    assert r.status_code == 200
    pdata = r.get_json()
    assert pdata['ok']
    pin_id = pdata['id']

    # Pin appears in pins list
    r = client.get('/atlas/api/pins')
    pins_data = r.get_json()
    found = next((p for p in pins_data['pins'] if p['id'] == pin_id), None)
    assert found is not None
    assert found['kind'] == 'hiding'
    assert found['location']['name'] == 'Atlas Cave'

    # Pin count shows in tree
    r = client.get('/atlas/api/tree')
    tree_data = r.get_json()
    def walk(nodes, target_id):
        for n in nodes:
            if n['id'] == target_id:
                return n
            sub = walk(n.get('children', []), target_id)
            if sub:
                return sub
        return None
    node = walk(tree_data['roots'], 'atlas_seed_loc2')
    assert node is not None
    assert node['pins'] == 1

    # Delete
    r = client.delete(f'/atlas/api/pin/{pin_id}')
    assert r.status_code == 200
    assert r.get_json()['ok']

    # Pin gone
    r = client.get('/atlas/api/pins')
    pins_data = r.get_json()
    assert not any(p['id'] == pin_id for p in pins_data['pins'])


def test_pin_create_validation_empty(client):
    r = client.post('/atlas/api/pin',
                    data=json.dumps({}),
                    content_type='application/json')
    assert r.status_code == 400
    data = r.get_json()
    assert not data['ok']
    assert 'required' in data['error']


def test_pin_create_validation_bad_kind(client, seeded_atlas):
    r = client.post('/atlas/api/pin',
                    data=json.dumps({
                        'character_id': 'atlas_seed_char',
                        'location_id': 'atlas_seed_loc',
                        'kind': 'INVALID_KIND'
                    }),
                    content_type='application/json')
    assert r.status_code == 400


def test_pin_delete_not_found(client):
    r = client.delete('/atlas/api/pin/nonexistent_pin')
    assert r.status_code == 404


# ---- Tree structure ----

def test_tree_nested_locations_have_parent_chain(client, seeded_atlas):
    r = client.get('/atlas/api/tree')
    tree_data = r.get_json()
    # Find root → check its children include atlas_seed_loc2
    def walk(nodes, target_id):
        for n in nodes:
            if n['id'] == target_id:
                return n
            sub = walk(n.get('children', []), target_id)
            if sub:
                return sub
        return None
    # atlas_seed_loc is a root, atlas_seed_loc2 is its child
    root_node = walk(tree_data['roots'], 'atlas_seed_loc')
    assert root_node is not None
    assert len(root_node['children']) >= 1
    child = next((c for c in root_node['children'] if c['id'] == 'atlas_seed_loc2'), None)
    assert child is not None


def test_pin_kinds_constant():
    from models.char_location_pin import PIN_KINDS
    assert 'current_residence' in PIN_KINDS
    assert 'origin' in PIN_KINDS
    assert 'hiding' in PIN_KINDS
    assert 'visiting' in PIN_KINDS
    assert 'temporary' in PIN_KINDS
    # Each kind has label, color
    for k, v in PIN_KINDS.items():
        assert 'label' in v
        assert 'color' in v


def test_atlas_js_is_syntactically_valid():
    import subprocess
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'atlas.js')
    result = subprocess.run(['node', '--check', js_path],
                           capture_output=True, text=True)
    assert result.returncode == 0, f"SyntaxError: {result.stderr[:300]}"


def test_atlas_js_no_python_slice_syntax():
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'atlas.js')
    with open(js_path) as f:
        content = f.read()
    assert '[:' not in content, "atlas.js contains `[:` Python slice syntax"


# ---- v7.6.1 regression: stale data-pins re-render bug ----
# Live-browser testing caught this: the delete handler filtered the in-memory
# pin array, then renderPins() re-parsed the STALE server-rendered data-pins
# attribute — so a deleted pin instantly re-appeared in the list (while the
# server had actually deleted it). The add flow papered over the same flaw
# with a full window.location.reload(). Both flows must now refresh from the
# server and re-render in place.

def test_atlas_js_delete_refreshes_from_server():
    """The delete handler must call refreshPins() (server re-fetch), not just
    filter the in-memory array before a renderPins() that re-reads stale data."""
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                           'static', 'js', 'atlas.js')
    with open(js_path) as f:
        js = f.read()
    assert 'function refreshPins()' in js, \
        "refreshPins() helper missing — delete would re-render stale data"
    # delete handler delegates to the refresh helpers
    assert 'refreshPins();' in js and 'refreshTree();' in js
    assert 'refreshStats();' in js
    # the old broken pattern (filter in memory, then renderPins which
    # re-parses the stale attribute) must be gone
    assert 'state.pins.filter' not in js, \
        "delete still filters in memory instead of re-fetching from the server"


def test_atlas_js_add_pin_no_full_reload():
    """atlasSubmitPin must update in place (refreshPins/Tree/Stats), not
    window.location.reload() — reload loses scroll, expansion state, and
    hides failures."""
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                           'static', 'js', 'atlas.js')
    with open(js_path) as f:
        js = f.read()
    assert 'window.location.reload()' not in js, \
        "atlas submit still does a full page reload"
    assert 'atlasClosePinModal();' in js, \
        "submit must close the modal before refreshing in place"


def test_atlas_stats_have_updateable_ids(client):
    """The stats strip numbers need stable IDs so refreshStats() can update
    them after a pin add/delete."""
    r = client.get('/atlas/')
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    for stat_id in ('atlasStatLocations', 'atlasStatPinnedChars',
                    'atlasStatPins', 'atlasStatDepth', 'atlasStatRoutes'):
        assert f'id="{stat_id}"' in html, f"stats element #{stat_id} missing"
