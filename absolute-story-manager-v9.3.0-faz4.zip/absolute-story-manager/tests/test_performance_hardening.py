"""M-03 — N+1 + cache package tests (v9.1.0).

Acceptance criteria from the plan:
  - page-request scenario shows a query-count DROP (word_count N+1 gone,
    repeated Setting.get SELECTs gone, globals served from TTL cache)
  - settings changes are visible immediately (snapshot invalidation)
  - reorder_chapters persists order without per-chapter SELECTs
  - existing tests stay green (behavior preserved)
"""
from __future__ import annotations

import pytest
from sqlalchemy import event

from core.db import read_session, write_transaction
from models.chapter import Chapter
from models.project import Project
from models.settings import Setting, invalidate_settings_snapshot
from services import chapter_service


class QueryCounter:
    """Count SELECT statements issued on an engine."""

    def __init__(self, engine):
        self.engine = engine
        self.statements: list[str] = []

    def __enter__(self):
        event.listen(self.engine, "before_cursor_execute", self._catch)
        return self

    def __exit__(self, *exc):
        event.remove(self.engine, "before_cursor_execute", self._catch)

    def _catch(self, conn, cursor, statement, parameters, *args):
        if statement.lstrip().upper().startswith("SELECT"):
            self.statements.append(statement)

    @property
    def count(self) -> int:
        return len(self.statements)


@pytest.fixture()
def three_projects():
    """Three projects with chapters + nonzero word counts."""
    with write_transaction() as s:
        # 'default' already exists (conftest seeds it) — just add two more.
        s.add(Project(id="p2", name="Second"))
        s.add(Project(id="p3", name="Third"))
        s.flush()
        for pid, n in (("default", 2), ("p2", 3), ("p3", 1)):
            for i in range(n):
                s.add(Chapter(id=f"{pid}-ch{i}", project_id=pid,
                              title=f"{pid} chapter {i}",
                              sort_order=i + 1, word_count=(i + 1) * 100))
    return "default", "p2", "p3"


# ---------------------------------------------------------------------------
# Settings snapshot cache
# ---------------------------------------------------------------------------

class TestSettingsSnapshot:

    def test_get_hits_db_once_then_serves_from_snapshot(self):
        import core.db

        invalidate_settings_snapshot()
        with read_session() as s:
            Setting.get(s, "theme")
        counter = QueryCounter(core.db.engine)
        with counter, read_session() as s:
            for _ in range(20):
                Setting.get(s, "theme")
        # 20 gets, ZERO queries — all served from the snapshot.
        assert counter.count == 0

    def test_set_invalidates_snapshot(self):
        with write_transaction() as s:
            Setting.set(s, "editor_font", "sans")
        with read_session() as s:
            assert Setting.get(s, "editor_font") == "sans"
        # A new write is immediately visible.
        with write_transaction() as s:
            Setting.set(s, "editor_font", "serif")
        with read_session() as s:
            assert Setting.get(s, "editor_font") == "serif"

    def test_get_semantics_preserved_for_missing_keys(self):
        with read_session() as s:
            # Missing row -> caller default (not DEFAULT_SETTINGS!).
            assert Setting.get(s, "no_such_key", "fallback") == "fallback"

    def test_all_settings_merges_defaults_and_rows(self):
        with write_transaction() as s:
            Setting.set(s, "story_title", "Snapshotted")
        with read_session() as s:
            merged = Setting.all_settings(s)
        assert merged["story_title"] == "Snapshotted"
        assert "daily_word_goal" in merged  # from DEFAULT_SETTINGS

    def test_rollback_invalidates_snapshot(self):
        # Write a value, then roll the transaction back via an exception —
        # the snapshot must not keep the phantom value.
        with write_transaction() as s:
            Setting.set(s, "story_title", "committed")
        try:
            with write_transaction() as s:
                Setting.set(s, "story_title", "phantom")
                with read_session() as rs:
                    Setting.get(rs, "story_title")  # load snapshot in-txn
                raise RuntimeError("force rollback")
        except RuntimeError:
            pass
        with read_session() as s:
            assert Setting.get(s, "story_title") == "committed"


# ---------------------------------------------------------------------------
# _inject_globals: single session, GROUP BY, TTL cache
# ---------------------------------------------------------------------------

class TestInjectGlobals:

    def _make_app(self):
        from app import create_app
        app = create_app()
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
        return app

    def _get_processor(self, app):
        # The context processor is registered by create_app; fetch it.
        for fn in app.template_context_processors[None]:
            if fn.__name__ == "_inject_globals":
                return fn
        raise AssertionError("_inject_globals processor not found")

    def test_word_counts_via_single_group_by(self, three_projects):
        import core.db

        app = self._make_app()
        processor = self._get_processor(app)
        invalidate_settings_snapshot()
        from core.cache import cache
        cache.clear()

        counter = QueryCounter(core.db.engine)
        with counter:
            payload = processor()
        # Books + word sums correct.
        words = {b["id"]: b["words"] for b in payload["books"]}
        assert words["default"] == 100 + 200
        assert words["p2"] == 100 + 200 + 300
        assert words["p3"] == 100
        # Query budget: settings + group-by + projects = 3 selects,
        # INDEPENDENT of the project count (that is the N+1 test).
        assert counter.count <= 4, counter.statements
        for stmt in counter.statements:
            # No per-project word_count SELECTs allowed.
            if "SUM" in stmt.upper() or "sum" in stmt:
                assert "GROUP BY" in stmt.upper()

    def test_second_call_served_from_ttl_cache(self, three_projects):
        import core.db

        app = self._make_app()
        processor = self._get_processor(app)
        invalidate_settings_snapshot()
        from core.cache import cache
        cache.clear()

        processor()  # warm the cache
        counter = QueryCounter(core.db.engine)
        with counter:
            payload2 = processor()
        assert counter.count == 0
        assert payload2["story_title"] in ("Main", "My Story", "Test Story")

    def test_setting_write_invalidates_globals_cache(self, three_projects):
        app = self._make_app()
        processor = self._get_processor(app)
        invalidate_settings_snapshot()
        from core.cache import cache
        cache.clear()

        first = processor()
        assert first["story_title"] in ("Test Story", "Main", "My Story")
        # The REAL UX path: switching the active book must invalidate the
        # cached globals immediately (no 60 s staleness on book switch).
        with write_transaction() as s:
            Setting.set(s, "active_project_id", "p2")
        second = processor()
        assert second["story_title"] == "Second"
        assert second["story_title"] != first["story_title"]


# ---------------------------------------------------------------------------
# reorder_chapters bulk UPDATE
# ---------------------------------------------------------------------------

class TestReorderChapters:

    def _seed(self):
        with write_transaction() as s:
            for i in range(5):
                s.add(Chapter(id=f"rch{i}", project_id="default",
                              title=f"Rch {i}", sort_order=i + 1))

    def test_reorder_persists_new_order(self):
        self._seed()
        chapter_service.reorder_chapters(
            ["rch3", "rch1", "rch4", "rch0", "rch2"]
        )
        with read_session() as s:
            got = {c.id: c.sort_order for c in s.query(Chapter).all()}
        assert got == {"rch3": 1, "rch1": 2, "rch4": 3, "rch0": 4, "rch2": 5}

    def test_reorder_issues_no_per_chapter_selects(self):
        import core.db

        self._seed()
        counter = QueryCounter(core.db.engine)
        with counter:
            chapter_service.reorder_chapters(
                ["rch4", "rch3", "rch2", "rch1", "rch0"]
            )
        # No SELECT touching the chapters table: one bulk UPDATE does the
        # work (log_activity's own settings/activity SELECTs are fine).
        chapter_selects = [st for st in counter.statements
                           if "FROM chapters" in st]
        assert chapter_selects == []

    def test_reorder_unknown_ids_are_ignored(self):
        self._seed()
        # Unknown ids consume a position (legacy semantics, preserved).
        chapter_service.reorder_chapters(["rch1", "ghost", "rch0"])
        with read_session() as s:
            got = {c.id: c.sort_order for c in s.query(Chapter).all()}
        assert got["rch1"] == 1
        assert got["rch0"] == 3  # 'ghost' took position 2
        assert "ghost" not in got


# ---------------------------------------------------------------------------
# Plot memory defers content
# ---------------------------------------------------------------------------

class TestPlotMemoryDefer:

    def test_plot_query_skips_content_column(self):
        import core.db

        with write_transaction() as s:
            s.add(Chapter(id="pv1", project_id="default", title="PV 1",
                          sort_order=1, synopsis="First.",
                          content="X" * 50_000))
            s.add(Chapter(id="pv2", project_id="default", title="PV 2",
                          sort_order=2, content="Y" * 50_000))

        from services import context_engine

        counter = QueryCounter(core.db.engine)
        with counter:
            bundle = context_engine.build_context(
                "New scene.", chapter_id="pv2"
            )
        # Only the multi-row plot-memory queries (ORDER BY sort_order) must
        # skip the content column; the single anchor-chapter row query is a
        # different statement and stays as-is (out of the M-03 card's scope).
        plot_selects = [
            st for st in counter.statements
            if "FROM chapters" in st and "ORDER BY" in st
        ]
        assert plot_selects, "expected the plot-memory chapter query"
        for st in plot_selects:
            assert "chapters.content" not in st, st
        # Synopses still arrive (functional check).
        titles = [p["title"] for p in bundle.plot]
        assert "PV 1" in titles
