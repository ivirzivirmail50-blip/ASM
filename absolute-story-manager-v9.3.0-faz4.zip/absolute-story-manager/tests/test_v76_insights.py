"""v7.6 Insights Dashboard tests — page render + APIs + service layer."""
from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))


@pytest.fixture
def app():
    from app import create_app
    return create_app()


@pytest.fixture
def client(app):
    return app.test_client()


# ---- Page render ----

def test_insights_page_renders(client):
    """The /insights/ page loads and shows the dashboard."""
    r = client.get('/insights/')
    assert r.status_code == 200
    body = r.data.decode()
    assert 'Writing Insights' in body
    assert 'Year Activity Heatmap' in body
    assert 'Cross-Book Progress' in body
    assert 'id="yearHeatmap"' in body
    assert 'id="velocityChart"' in body
    assert '/static/js/insights.js' in body
    assert 'active_nav' in body or 'insights' in body


def test_insights_page_uses_static_js(client):
    """Critical: insights page must load its JS from /static/js/insights.js, NOT inline.
    v7.5 root-architecture rule."""
    r = client.get('/insights/')
    body = r.data.decode()
    assert '/static/js/insights.js' in body
    # Inline scripts that bootstrap reading state must be small init only.
    # Specifically, the insights page should NOT contain function definitions for
    # its own rendering logic (they should be in the external file).
    assert 'function renderHeatmap' not in body
    assert 'function renderVelocity' not in body


def test_insights_sidebar_link(client):
    """Sidebar must include the Insights Dashboard link."""
    r = client.get('/insights/')
    body = r.data.decode()
    assert '/insights/"' in body or 'href="/insights/"' in body or "url_for('insights.index')" in body
    assert 'Insights Dashboard' in body


# ---- APIs ----

def test_api_dashboard(client):
    r = client.get('/insights/api/dashboard')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'year_heatmap' in data
    assert 'velocity' in data
    assert 'today' in data
    assert 'cross_book' in data


def test_api_heatmap(client):
    r = client.get('/insights/api/heatmap')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'days' in data
    assert 'max' in data
    assert 'writing_days' in data
    assert 'streak_current' in data
    assert 'streak_longest' in data
    assert 'total_days' in data
    # Days array should have 365 entries (or close, with timezone)
    assert 360 <= len(data['days']) <= 366


def test_api_today(client):
    r = client.get('/insights/api/today')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'today_words' in data
    assert 'daily_goal' in data
    assert 'weekday_name' in data
    assert 'tip' in data
    assert isinstance(data['tip'], str) and len(data['tip']) > 5


def test_api_cross_book(client):
    r = client.get('/insights/api/cross-book')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'books' in data
    assert 'totals' in data
    assert 'words' in data['totals']
    assert 'books_count' in data['totals']


def test_api_velocity(client):
    r = client.get('/insights/api/velocity')
    assert r.status_code == 200
    data = r.get_json()
    assert data['ok']
    assert 'series' in data
    assert 'avg' in data
    assert 'max' in data
    assert 'trend' in data
    assert data['trend'] in ('up', 'down', 'flat')


# ---- Service layer ----

def test_heatmap_levels_are_0_to_4():
    from services import insights_service as svc
    assert svc._level(0) == 0
    assert svc._level(50) == 1
    assert svc._level(200) == 2
    assert svc._level(700) == 3
    assert svc._level(1500) == 4


def test_streaks_computation():
    from services import insights_service as svc
    # Empty
    assert svc._streaks([]) == (0, 0)
    # One day, today
    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).date().isoformat()
    assert svc._streaks([today]) == (1, 1)
    # Three consecutive days ending today
    from datetime import timedelta
    d1 = (datetime.now(timezone.utc).date() - timedelta(days=2)).isoformat()
    d2 = (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()
    d3 = today
    cur, longest = svc._streaks([d1, d2, d3])
    assert cur == 3
    assert longest == 3
    # Gap then 2-day run ending yesterday (not today → current=0 or 1)
    g1 = (datetime.now(timezone.utc).date() - timedelta(days=10)).isoformat()
    g2 = (datetime.now(timezone.utc).date() - timedelta(days=5)).isoformat()
    g3 = (datetime.now(timezone.utc).date() - timedelta(days=4)).isoformat()
    cur, longest = svc._streaks([g1, g2, g3])
    assert longest == 2  # the 5-day-ago + 4-day-ago pair


def test_compose_tip_meets_goal():
    from services import insights_service as svc
    tip = svc._compose_tip(weekday=2, best_hour=14,
                            today_words=600, daily_goal=500, current_streak=3)
    assert 'met' in tip.lower() or 'streak' in tip.lower()


def test_compose_tip_no_streak():
    from services import insights_service as svc
    tip = svc._compose_tip(weekday=2, best_hour=None,
                            today_words=0, daily_goal=500, current_streak=0)
    assert 'streak' in tip.lower()


# ---- Inline JS safety ----

def test_insights_js_is_syntactically_valid():
    """Static insights.js must pass `node --check`."""
    import subprocess
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'insights.js')
    result = subprocess.run(['node', '--check', js_path],
                           capture_output=True, text=True)
    assert result.returncode == 0, f"SyntaxError: {result.stderr[:300]}"


def test_insights_js_does_not_use_python_slice_syntax():
    """The v7.5 root-cause class of bug: Python slice [:10] leaked into JS.
    Static insights.js must NOT contain `[:` patterns."""
    js_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            'static', 'js', 'insights.js')
    with open(js_path) as f:
        content = f.read()
    # Look for `[:` pattern (Python slice syntax) — would be a syntax error in JS
    # Exception: array access like arr[0] is fine; `[:` is suspicious.
    assert '[:' not in content, "insights.js contains `[:` Python slice syntax"
