"""F-02 — real i18n (v9.2.0).

Pins the acceptance criteria of the Faz 3 F-02 card:
- translations live in translations/*.json (not an inline Python dict)
- get_translation_dict is cached
- sidebar/base render {{ t('nav.x') }} server-side — no navMap DOM hack,
  no flash of English on non-English pages (E2E assert below)
- latin-ext font subsets exist on disk + MANIFEST + unicode-range CSS
- the command palette searches translated labels via window.ASM_T
- a new t('nav.x') usage without a translation key FAILS CI (audit test)
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
I18N_DIR = ROOT / "translations"
TEMPLATES = ROOT / "templates"
VENDOR = ROOT / "static" / "vendor"


# ---------------------------------------------------------------------------
# JSON translation store
# ---------------------------------------------------------------------------

class TestJsonTranslationStore:

    def test_json_files_exist_for_all_languages(self):
        from services.i18n_service import SUPPORTED_LANGUAGES
        for lang in SUPPORTED_LANGUAGES:
            assert (I18N_DIR / f"{lang}.json").exists(), f"missing {lang}.json"

    def test_translate_from_json(self):
        from services import i18n_service as svc
        svc.reload_translations()
        assert svc.translate("nav.dashboard", "tr") == "Panel"
        assert svc.translate("action.save", "de") == "Speichern"
        assert svc.translate("nonexistent.key", "tr") == "nonexistent.key"

    def test_get_translation_dict_is_cached(self):
        """F-02: the context processor calls this on every render — the
        result object must be cached per language."""
        from services import i18n_service as svc
        svc.reload_translations()
        d1 = svc.get_translation_dict("tr")
        d2 = svc.get_translation_dict("tr")
        assert d1 is d2

    def test_set_language_invalidates_dict_cache(self):
        from services import i18n_service as svc
        svc.reload_translations()
        d_en = svc.get_translation_dict("en")
        svc.set_language("tr")
        try:
            d_tr = svc.get_translation_dict()
            assert d_tr is not d_en
            assert d_tr["nav.dashboard"] == "Panel"
        finally:
            svc.set_language("en")

    def test_missing_translations_audit_clean(self):
        """Audit hook: every key exists in every language file."""
        from services import i18n_service as svc
        svc.reload_translations()
        report = svc.missing_translations()
        assert report == {}, f"missing translations: {report}"


# ---------------------------------------------------------------------------
# Server-rendered translations — FOUC is gone
# ---------------------------------------------------------------------------

class TestServerRenderedI18n:

    @pytest.fixture()
    def turkish(self, fresh_db):
        from services import i18n_service as svc
        svc.set_language("tr")
        yield
        svc.set_language("en")

    def test_homepage_renders_turkish_sidebar(self, client, turkish):
        """E2E (kabul kriteri): dil değişince sayfa İLK boyamada Türkçe —
        yanıp sönen İngilizce yok (navMap DOM hack'i kaldırıldı)."""
        resp = client.get("/")
        assert resp.status_code == 200
        html = resp.get_data(as_text=True)
        # Sidebar nav + section labels, server-rendered:
        assert "Panel" in html            # nav.dashboard
        assert "Bölümler" in html         # nav.chapters
        assert "Karakterler" in html      # nav.characters
        assert "Ayarlar" in html          # nav.settings
        # ...ve sidebar İngilizce etiketi artık BOYAMADA yok (breadcrumb
        # sayfa başlıkları nav çevirisi değildir — çıplak span formu bakılır)
        assert "<span>Dashboard</span>" not in html
        assert "<span>Settings</span>" not in html

    def test_english_homepage_renders_english(self, client):
        resp = client.get("/")
        html = resp.get_data(as_text=True)
        assert ">Dashboard<" in html or "Dashboard" in html

    def test_asm_t_exposed_to_js(self, client, turkish):
        """window.ASM_T: komut paleti çevrilmiş etiketleri buradan alır."""
        resp = client.get("/")
        html = resp.get_data(as_text=True)
        assert "window.ASM_T" in html
        assert '"nav.dashboard": "Panel"' in html

    def test_search_placeholder_translated(self, client, turkish):
        resp = client.get("/")
        html = resp.get_data(as_text=True)
        assert 'placeholder="Ara' in html  # action.search → "Ara…"

    def test_navmap_hack_removed_from_base(self):
        """navMap DOM-çeviri script'i kaldırıldı (kaynak taraması)."""
        base = (TEMPLATES / "base.html").read_text(encoding="utf-8")
        assert "navMap" not in base
        assert "/i18n/api/translations?lang" not in base

    def test_sidebar_uses_t_function(self):
        sidebar = (TEMPLATES / "components" / "sidebar.html").read_text(
            encoding="utf-8")
        assert "{{ t('nav.dashboard') }}" in sidebar
        assert "{{ t('nav.settings') }}" in sidebar
        # Raw English labels are gone (logo excepted)
        assert "<span>Dashboard</span>" not in sidebar
        assert "<span>Settings</span>" not in sidebar

    def test_translations_api_still_works(self, client):
        resp = client.get("/i18n/api/translations?lang=tr")
        data = resp.get_json()
        assert data["ok"] is True
        assert data["translations"]["nav.dashboard"] == "Panel"


# ---------------------------------------------------------------------------
# CI audit: template t() keys must exist in translation files
# ---------------------------------------------------------------------------

class TestTemplateKeyAudit:

    def test_every_template_key_exists_in_translations(self):
        """Kabul kriteri: yeni bir nav linki çeviri dosyasına anahtar
        eklemeyi gerektiriyor — eksik anahtar CI'da bu testi düşürür."""
        from services import i18n_service as svc
        svc.reload_translations()
        table = svc._ensure_loaded()
        used = svc.used_template_keys()
        assert used, "used_template_keys() found nothing — scanner broken?"
        missing = sorted(k for k in used if k not in table)
        assert not missing, (
            f"templates use t() keys with no translation entry: {missing}")

    def test_used_template_keys_finds_sidebar(self):
        from services import i18n_service as svc
        used = svc.used_template_keys()
        assert "nav.dashboard" in used
        assert "action.search" in used


# ---------------------------------------------------------------------------
# latin-ext fonts (Turkish glyph consistency)
# ---------------------------------------------------------------------------

class TestLatinExtFonts:

    EXT_FILES = [
        "inter-ext.woff2", "inter-bold-ext.woff2",
        "noto-serif-ext.woff2", "jetbrains-mono-ext.woff2",
    ]

    def test_latin_ext_files_on_disk(self):
        for name in self.EXT_FILES:
            path = VENDOR / "fonts" / name
            assert path.exists(), f"missing {name} — run fetch_vendor.py"
            assert path.stat().st_size > 1000  # real font data, not a stub

    def test_latin_ext_in_manifest(self):
        manifest = (VENDOR / "MANIFEST.txt").read_text(encoding="utf-8")
        for name in self.EXT_FILES:
            assert f"fonts/{name}" in manifest, f"{name} not in MANIFEST"

    def test_fetch_vendor_declares_latin_ext(self):
        src = (ROOT / "scripts" / "fetch_vendor.py").read_text(encoding="utf-8")
        for name in self.EXT_FILES:
            assert name in src

    def test_css_fontface_unicode_range_covers_turkish(self):
        """Turkish glyphs (U+0100-02AF latin-ext) must map to -ext files."""
        css = (ROOT / "static" / "css" / "main.css").read_text(encoding="utf-8")
        for name in self.EXT_FILES:
            assert name in css, f"{name} not referenced in main.css"
        # unicode-range on the ext blocks must cover ş(015F)/ğ(011F)/İ(0130)
        for family_file in ("inter-ext.woff2", "noto-serif-ext.woff2"):
            idx = css.find(family_file)
            block = css[idx:idx + 400]  # unicode-range follows the src line
            assert "unicode-range" in block
            assert "U+0100-02AF" in block
        # 8 @font-face blocks: 4 families x (latin + latin-ext)
        assert css.count("@font-face") == 8

    def test_manifest_all_entries_present_on_disk(self):
        """Startup check pre-flight: every manifest line exists on disk."""
        manifest = (VENDOR / "MANIFEST.txt").read_text(encoding="utf-8")
        for line in manifest.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 4:
                continue
            rel = parts[3].replace("static/", "", 1)
            assert (ROOT / "static" / rel).exists(), f"manifest asset missing: {rel}"


# ---------------------------------------------------------------------------
# Command palette speaks the UI language
# ---------------------------------------------------------------------------

class TestCommandPaletteI18n:

    def test_palette_uses_asm_t(self):
        src = (ROOT / "static" / "js" / "command_palette.js").read_text(
            encoding="utf-8")
        assert "window.ASM_T" in src
        # Hard-coded action labels are gone — all resolve via i18n keys
        assert 'label: "New Chapter"' not in src
        assert 'i18n: "palette.new_chapter"' in src

    def test_palette_keys_exist_in_translations(self):
        src = (ROOT / "static" / "js" / "command_palette.js").read_text(
            encoding="utf-8")
        import re
        keys = set(re.findall(r'i18n: "([a-z0-9_.]+)"', src))
        keys |= set(re.findall(r'T\("([a-z0-9_.]+)"', src))
        assert keys, "no palette i18n keys found"
        for lang in ("en", "tr", "es", "fr", "de"):
            data = json.loads((I18N_DIR / f"{lang}.json").read_text(
                encoding="utf-8"))
            missing = sorted(k for k in keys if k not in data)
            assert not missing, f"{lang}.json missing palette keys: {missing}"
