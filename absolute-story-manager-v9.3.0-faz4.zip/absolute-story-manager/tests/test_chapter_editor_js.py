"""M-06 — editor inline JS migration tests (v9.1.0).

Acceptance criteria from the plan:
  - templates/chapters/edit.html has NO executable inline script left
    (only the #editor-data application/json block + external src scripts)
  - node --check guards the extracted chapter_editor.js
  - the data block parses and carries the full contract
  - the editor page renders and loads the module
  - the inline_js_guard covers the editor page too
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TPL = PROJECT_ROOT / "templates" / "chapters" / "edit.html"
JS = PROJECT_ROOT / "static" / "js" / "chapter_editor.js"

# v9.2.0 (F-03): editorEngine joined the contract ("codemirror" default,
# "easymde" rollback flag) — chapter_editor.js dispatches on it.
DATA_KEYS = {"chapterId", "aiEnabled", "autosaveInterval", "targetWordCount",
             "editorEngine"}


def _node_check_file(path: Path) -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("node not available")
    r = subprocess.run([node, "--check", str(path)],
                       capture_output=True, text=True, timeout=30)
    assert r.returncode == 0, r.stderr


# ---------------------------------------------------------------------------
# Template-level rules
# ---------------------------------------------------------------------------

class TestTemplateClean:

    def test_no_executable_inline_script_in_template(self):
        """edit.html must contain ZERO executable <script> bodies.

        Allowed: <script src=...> and <script type="application/json">.
        """
        src = TPL.read_text(encoding="utf-8")
        executable = re.findall(
            r'<script(?![^>]*\bsrc=)'
            r'(?![^>]*type=["\']application/(?:json|ld\+json)["\'])'
            r'(?![^>]*type=["\']text/plain["\'])[^>]*>(.*?)</script>',
            src, re.S,
        )
        assert executable == [], (
            f"executable inline scripts remain: "
            f"{[b[:80] for b in executable]}"
        )

    def test_data_block_and_module_referenced(self):
        src = TPL.read_text(encoding="utf-8")
        assert 'id="editor-data"' in src
        assert "js/chapter_editor.js" in src
        # The old 878-line block must be gone from the template.
        assert len(src.splitlines()) < 300

    def test_editor_js_is_syntax_valid(self):
        _node_check_file(JS)

    def test_editor_js_reads_data_block_not_jinja(self):
        src = JS.read_text(encoding="utf-8")
        assert 'document.getElementById("editor-data")' in src
        # No Jinja interpolation may leak into the JS file.
        assert not re.search(r"\{\{[^}]*\}\}", src)
        # All four data contract keys are consumed.
        for key in ("ED.chapterId", "ED.aiEnabled",
                    "ED.autosaveInterval", "ED.targetWordCount"):
            assert key in src, key

    def test_editor_js_uses_core_asmfetch(self):
        """M-05 synergy: the editor uses the canonical asmFetch/escapeHtml
        from core.js instead of defining its own."""
        src = JS.read_text(encoding="utf-8")
        assert "function asmFetch" not in src
        assert "function escapeHtml" not in src


# ---------------------------------------------------------------------------
# Rendered-page behavior
# ---------------------------------------------------------------------------

class TestRenderedPage:

    @pytest.fixture()
    def editor_page(self, client):
        from services import chapter_service
        ch = chapter_service.create_chapter(
            title="Editor Migration", content="bir iki üç",
            target_word_count=1500,
        )
        r = client.get(f"/chapters/{ch.id}/edit")
        assert r.status_code == 200
        return r.get_data(as_text=True), ch.id

    def test_data_block_parses_with_contract(self, editor_page):
        html, ch_id = editor_page
        m = re.search(
            r'<script type="application/json" id="editor-data">(.*?)</script>',
            html, re.S,
        )
        assert m, "editor-data block missing"
        data = json.loads(m.group(1))
        assert set(data.keys()) == DATA_KEYS
        assert data["chapterId"] == ch_id
        assert data["targetWordCount"] == 1500
        assert data["aiEnabled"] is False
        assert data["autosaveInterval"] == 3

    def test_module_script_tag_present(self, editor_page):
        html, _ = editor_page
        assert "js/chapter_editor.js" in html

    def test_content_flows_via_text_plain_block(self, editor_page):
        html, _ = editor_page
        # v9.0 mechanism preserved: chapter content reaches the JS through
        # the #initialContent text/plain block, never inline code.
        assert 'id="initialContent"' in html


# ---------------------------------------------------------------------------
# Guard extension: the editor page joins the syntax-guarded set
# ---------------------------------------------------------------------------

def test_editor_page_inline_js_is_syntax_clean(client):
    """inline_js_guard-style check for the editor page (M-06 requirement)."""
    import shutil as _shutil

    from services import chapter_service
    ch = chapter_service.create_chapter(
        title="Guard 'quotes' & <chars>", content="x — y ✨",
    )
    r = client.get(f"/chapters/{ch.id}/edit")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    blocks = re.findall(
        r'<script(?![^>]*\bsrc=)'
        r'(?![^>]*type=["\']application/(?:json|ld\+json)["\'])'
        r'(?![^>]*type=["\']text/plain["\'])[^>]*>(.*?)</script>',
        html, re.S,
    )
    node = _shutil.which("node")
    if not node:
        pytest.skip("node not available")
    for i, b in enumerate(blocks):
        # Base.html's small inline scripts (sidebar scroll, ASM namespace)
        # still exist on every page — they must simply stay syntax-valid.
        with tempfile.NamedTemporaryFile(
                "w", suffix=".js", delete=False, encoding="utf-8") as f:
            f.write(b)
            path = f.name
        try:
            res = subprocess.run([node, "--check", path],
                                 capture_output=True, text=True, timeout=30)
            assert res.returncode == 0, (
                f"inline block #{i} on editor page is broken:\n{res.stderr}"
                f"\n---\n{b[:300]}"
            )
        finally:
            Path(path).unlink(missing_ok=True)
