"""M-08 — chapters route coverage boost (53% → 75%+).

Targets the endpoints the existing suites skip: version history pages,
compare/restore/save, diff export, cycle-status, checklist endpoints,
import-center, and the compare page.
"""
from __future__ import annotations


def _mk_chapter(content: str = "birinci satır\nikinci satır"):
    from services import chapter_service
    return chapter_service.create_chapter(title="Kapsam Bölümü",
                                          content=content)


def _mk_versions(ch, n=3):
    from services import chapter_service
    for i in range(n):
        chapter_service.update_chapter(
            ch.id, content=f"revize {i}\nikinci satır", create_version=True)
    _, vs = chapter_service.get_chapter_with_versions(ch.id)
    return vs


class TestVersionRoutes:

    def test_versions_page(self, client):
        ch = _mk_chapter()
        _mk_versions(ch, 2)
        r = client.get(f"/chapters/{ch.id}/versions")
        assert r.status_code == 200
        assert "Kapsam" in r.get_data(as_text=True)

    def test_versions_page_404(self, client):
        r = client.get("/chapters/ghost/versions")
        assert r.status_code == 404

    def test_versions_compare(self, client):
        ch = _mk_chapter()
        vs = _mk_versions(ch, 2)
        ids = sorted(v.id for v in vs)[:2]
        r = client.get(f"/chapters/{ch.id}/versions/compare"
                       f"?v1={ids[0]}&v2={ids[1]}")
        assert r.status_code == 200

    def test_versions_compare_invalid_ids(self, client):
        ch = _mk_chapter()
        _mk_versions(ch, 1)
        r = client.get(f"/chapters/{ch.id}/versions/compare"
                       f"?v1=bad&v2=worse")
        assert r.status_code == 400

    def test_latest_version_content_json(self, client):
        ch = _mk_chapter()
        _mk_versions(ch, 1)
        r = client.get(f"/chapters/{ch.id}/versions/latest/content")
        assert r.status_code == 200
        data = r.get_json()
        assert "revize" in data["content"]

    def test_restore_version(self, client):
        ch = _mk_chapter()
        vs = _mk_versions(ch, 2)
        oldest = sorted(vs, key=lambda v: v.version_number)[0]
        r = client.post(f"/chapters/{ch.id}/versions/{oldest.id}/restore")
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

    def test_save_version_endpoint(self, client):
        ch = _mk_chapter()
        # The save route snapshots when content DIFFERS from the last
        # version — emulate an autosave-only edit first.
        from services import chapter_service
        chapter_service.update_chapter(
            ch.id, content="değişen içerik", create_version=False)
        r = client.post(f"/chapters/{ch.id}/versions/save")
        assert r.status_code == 200
        _, vs = chapter_versions(ch.id)
        assert len(vs) >= 2  # original + manual save

    def test_diff_export_txt_and_html(self, client):
        ch = _mk_chapter()
        vs = _mk_versions(ch, 2)
        ids = sorted(v.id for v in vs)[:2]
        r1 = client.post(f"/chapters/{ch.id}/diff/export",
                         json={"v1": ids[0], "v2": ids[1], "format": "txt"})
        assert r1.status_code == 200
        assert r1.headers["Content-Disposition"].endswith(".txt")
        r2 = client.post(f"/chapters/{ch.id}/diff/export",
                         json={"v1": ids[0], "v2": ids[1], "format": "html"})
        assert r2.status_code == 200
        assert "text/html" in r2.headers["Content-Type"]

    def test_diff_export_invalid_ids(self, client):
        ch = _mk_chapter()
        r = client.post(f"/chapters/{ch.id}/diff/export",
                        json={"v1": "x", "v2": "y"})
        assert r.status_code == 400
        assert r.get_json()["ok"] is False

    def test_compare_page(self, client):
        ch = _mk_chapter()
        vs = _mk_versions(ch, 2)
        ids = ",".join(sorted(v.id for v in vs)[:2])
        r = client.get(f"/chapters/compare?ids={ids}")
        assert r.status_code == 200


class TestChapterActionRoutes:

    def test_cycle_status(self, client):
        ch = _mk_chapter()
        r = client.post(f"/chapters/{ch.id}/cycle-status")
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

    def test_api_content(self, client):
        ch = _mk_chapter()
        r = client.get(f"/chapters/{ch.id}/api/content")
        assert r.status_code == 200
        assert "birinci" in r.get_json()["content"]

    def test_reorder_endpoint(self, client):
        from services import chapter_service
        a = chapter_service.create_chapter(title="A", content="a")
        b = chapter_service.create_chapter(title="B", content="b")
        r = client.post("/chapters/reorder", json={"ids": [b.id, a.id]})
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

    def test_import_center_page(self, client):
        r = client.get("/chapters/import-center")
        assert r.status_code == 200

    def test_delete_via_route(self, client):
        ch = _mk_chapter()
        r = client.post(f"/chapters/{ch.id}/delete")
        assert r.status_code == 200


class TestChapterChecklistRoutes:

    def test_checklist_page(self, client):
        ch = _mk_chapter()
        r = client.get(f"/chapters/{ch.id}/checklist")
        assert r.status_code == 200
        assert "advance the main plot" in r.get_data(as_text=True)

    def test_checklist_add_toggle_delete(self, client):
        ch = _mk_chapter()
        r = client.post(f"/chapters/{ch.id}/checklist/add",
                        json={"text": "rota kontrolü", "category": "plot"})
        assert r.status_code == 200
        item_id = r.get_json()["id"]

        r2 = client.post(f"/chapters/checklist/{item_id}/toggle")
        assert r2.status_code == 200
        assert r2.get_json()["checked"] is True

        r3 = client.post(f"/chapters/checklist/{item_id}/delete")
        assert r3.status_code == 200


def chapter_versions(chapter_id):
    from services import chapter_service
    return chapter_service.get_chapter_with_versions(chapter_id)
