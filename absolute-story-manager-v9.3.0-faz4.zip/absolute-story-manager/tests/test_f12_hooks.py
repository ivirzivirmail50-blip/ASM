"""F-12 — eklenti yüzeyi (hook noktaları) testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * Varsayılan KAPALI: hooks_enabled olmadan hiçbir betik çalışmaz
  * Betik stdin'de {"event": ..., **payload} JSON alır, exit 0 = ok
  * Olay filtresi: yalnız ilgili olaya abone betikler koşar
  * Betik hatası / yok komut ana akışı BOZMAZ (fire asla raise etmez)
  * Tetik noktaları: after_chapter_save (update_chapter),
    after_export (kuyruk executor), after_backup (create_backup)
  * hooks_scripts JSON'u geçersizse sessiz yoksayılır
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core import hooks  # noqa: E402
from core.db import read_session, write_transaction  # noqa: E402


def _set(key: str, value) -> None:
    from models.settings import Setting

    with write_transaction() as s:
        Setting.set(s, key, value)


@pytest.fixture(autouse=True)
def _hooks_off():
    _set("hooks_enabled", False)
    _set("hooks_scripts", "[]")
    yield
    _set("hooks_enabled", False)
    _set("hooks_scripts", "[]")


class TestFire:

    def test_disabled_by_default_runs_nothing(self, tmp_path):
        marker = tmp_path / "ran.txt"
        _set("hooks_scripts", json.dumps([{
            "name": "probe", "events": ["after_export"],
            "command": f"touch {marker}",
        }]))
        result = hooks.fire("after_export", {"x": 1})
        assert result == []
        assert not marker.exists()

    def test_enabled_script_runs_with_json_stdin(self, tmp_path):
        out = tmp_path / "payload.json"
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "capture",
            "events": ["after_export"],
            # stdin'i dosyaya yaz (sh'ın her yerinde çalışan taşınabilir yol)
            "command": f"{sys.executable} -c "
                       f"\"import sys;open(r'{out}','w').write(sys.stdin.read())\"",
        }]))
        result = hooks.fire("after_export", {"filename": "book.docx"})
        assert len(result) == 1 and result[0]["ok"] is True
        payload = json.loads(out.read_text(encoding="utf-8"))
        assert payload["event"] == "after_export"
        assert payload["filename"] == "book.docx"

    def test_event_filter_only_matching_scripts(self, tmp_path):
        ran = tmp_path / "ran.txt"
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "only-chapters", "events": ["after_chapter_save"],
            "command": f"touch {ran}",
        }]))
        result = hooks.fire("after_export", {})
        assert result == []  # abone değil → koşmadı
        assert not ran.exists()

    def test_failing_script_does_not_raise(self):
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "boom", "events": ["after_backup"],
            "command": "exit 3",
        }]))
        result = hooks.fire("after_backup", {})  # yükselmemeli
        assert len(result) == 1
        assert result[0]["ok"] is False
        assert "3" in str(result[0].get("output", "")) or \
            result[0].get("exit_code") == 3 or not result[0]["ok"]

    def test_unknown_command_fails_gracefully(self):
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "ghost", "events": ["after_backup"],
            "command": "böyle-bir-komut-yok-12345",
        }]))
        result = hooks.fire("after_backup", {})
        assert result[0]["ok"] is False

    def test_invalid_hooks_scripts_json_ignored(self):
        _set("hooks_enabled", True)
        _set("hooks_scripts", "{geçersiz json")
        assert hooks.fire("after_backup", {}) == []

    def test_unknown_event_ignored(self):
        _set("hooks_enabled", True)
        assert hooks.fire("after_moon_landing", {}) == []


# ---------------------------------------------------------------------------
# Tetik noktaları (entegrasyon)
# ---------------------------------------------------------------------------

class TestTriggerPoints:

    def test_after_chapter_save_fires(self, tmp_path, client):
        out = tmp_path / "chapter_hook.json"
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "chapter-watcher", "events": ["after_chapter_save"],
            "command": f"{sys.executable} -c "
                       f"\"import sys;open(r'{out}','w').write(sys.stdin.read())\"",
        }]))
        client.post("/chapters/new", data={"title": "Hook Bölümü"})
        # bölüm oluştur + kaydet (içerik güncelle)
        from services import chapter_service
        ch = chapter_service.create_chapter(title="Hook Testi",
                                            content="ilk")
        chapter_service.update_chapter(ch.id, content="güncel metin")
        assert out.exists()
        payload = json.loads(out.read_text(encoding="utf-8"))
        assert payload["event"] == "after_chapter_save"
        assert payload["chapter_id"] == ch.id

    def test_after_export_fires_from_queue(self, tmp_path):
        from services import task_queue_service as q

        out = tmp_path / "export_hook.json"
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "export-watcher", "events": ["after_export"],
            "command": f"{sys.executable} -c "
                       f"\"import sys;open(r'{out}','w').write(sys.stdin.read())\"",
        }]))
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        q.execute_one()
        assert q.get_task(t.id).status == "done"
        assert out.exists()
        payload = json.loads(out.read_text(encoding="utf-8"))
        assert payload["event"] == "after_export"
        assert payload["task_id"] == t.id

    def test_after_backup_fires(self, tmp_path):
        from services import backup_service

        out = tmp_path / "backup_hook.json"
        _set("hooks_enabled", True)
        _set("hooks_scripts", json.dumps([{
            "name": "backup-watcher", "events": ["after_backup"],
            "command": f"{sys.executable} -c "
                       f"\"import sys;open(r'{out}','w').write(sys.stdin.read())\"",
        }]))
        backup_service.create_backup()
        assert out.exists()
        payload = json.loads(out.read_text(encoding="utf-8"))
        assert payload["event"] == "after_backup"
        assert payload["encrypted"] is False
