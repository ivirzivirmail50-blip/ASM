"""F-06 — veri modeli sağlamlaştırma testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * FK CASCADE: parent silinince çocuklar otomatik gider
  * FK SET NULL: opsiyonel referanslar parent silinince boşa çekilir
  * Yetim ekleme reddedilir (IntegrityError)
  * Doğal anahtar unique'ları (project_id + term/word/date/key...)
  * CHECK kısıtları (boolean'lar, negatif olmayan sayaçlar, enum'lar)
  * Boolean kolon tipleri (INTEGER -> BOOLEAN)
  * Legacy kirli veri: asm0003 purge/dedupe/backfill + fk_check temiz
  * FTS trigger'ları rebuild'den sağ çıkıyor
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.exc import IntegrityError

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import core.db  # noqa: E402 — engine per-test monkeypatch edilir; dinamik kullan
from core.errors import ValidationError  # noqa: E402

# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------

def _sql(stmt: str, params: dict | None = None):
    with core.db.engine.begin() as c:
        c.execute(text(stmt), params or {})


def _one(stmt: str, params: dict | None = None):
    with core.db.engine.connect() as c:
        return c.execute(text(stmt), params or {}).scalar()


def _seed_parent_rows() -> None:
    _sql("DELETE FROM chapters WHERE id LIKE 'f06-%'")
    _sql("DELETE FROM characters WHERE id LIKE 'f06-%'")
    _sql("INSERT INTO chapters (id, project_id, title, word_count, sort_order) "
         "VALUES ('f06-ch', 'default', 'F06 Bölüm', 10, 0)")
    _sql("INSERT INTO chapter_versions (id, chapter_id, version_number, "
         "word_count, is_pinned) VALUES ('f06-cv', 'f06-ch', 1, 10, 0)")
    _sql("INSERT INTO chapter_checklists (id, chapter_id, item_text, "
         "is_checked, sort_order) VALUES ('f06-ckl', 'f06-ch', 'm', 0, 0)")


# ---------------------------------------------------------------------------
# FK CASCADE
# ---------------------------------------------------------------------------

class TestFkCascade:

    def test_chapter_delete_cascades_versions_and_checklists(self):
        _seed_parent_rows()
        _sql("DELETE FROM chapters WHERE id='f06-ch'")
        assert _one("SELECT COUNT(*) FROM chapter_versions "
                    "WHERE chapter_id='f06-ch'") == 0
        assert _one("SELECT COUNT(*) FROM chapter_checklists "
                    "WHERE chapter_id='f06-ch'") == 0

    def test_project_delete_wipes_scoped_rows(self):
        _sql("DELETE FROM projects WHERE id='f06-proj'")
        _sql("INSERT INTO projects (id, name) VALUES ('f06-proj', 'P')")
        _sql("INSERT INTO chapters (id, project_id, title, word_count, "
             "sort_order) VALUES ('f06-ch2', 'f06-proj', 'X', 0, 0)")
        _sql("INSERT INTO notes (id, project_id, title) "
             "VALUES ('f06-note', 'f06-proj', 'N')")
        _sql("DELETE FROM projects WHERE id='f06-proj'")
        assert _one("SELECT COUNT(*) FROM chapters "
                    "WHERE project_id='f06-proj'") == 0
        assert _one("SELECT COUNT(*) FROM notes "
                    "WHERE project_id='f06-proj'") == 0

    def test_session_delete_cascades_messages(self):
        _sql("DELETE FROM chat_sessions WHERE id='f06-ses'")
        _sql("INSERT INTO chat_sessions (id, project_id, mode, title, "
             "character_ids, settings, pinned, message_count) "
             "VALUES ('f06-ses', 'default', 'character', 'S', '', '{}', 0, 0)")
        _sql("INSERT INTO chat_messages (session_id, role, content) "
             "VALUES ('f06-ses', 'user', 'merhaba')")
        _sql("DELETE FROM chat_sessions WHERE id='f06-ses'")
        assert _one("SELECT COUNT(*) FROM chat_messages "
                    "WHERE session_id='f06-ses'") == 0


# ---------------------------------------------------------------------------
# FK SET NULL
# ---------------------------------------------------------------------------

class TestFkSetNull:

    def test_chapter_delete_nulls_submission_link(self):
        _sql("DELETE FROM submissions WHERE id='f06-sub'")
        _seed_parent_rows()
        _sql("INSERT INTO submissions (id, project_id, title, market_name, "
             "chapter_id) VALUES ('f06-sub', 'default', 'T', 'M', 'f06-ch')")
        _sql("DELETE FROM chapters WHERE id='f06-ch'")
        assert _one("SELECT chapter_id FROM submissions "
                    "WHERE id='f06-sub'") is None

    def test_chapter_delete_nulls_chat_session_anchor(self):
        _sql("DELETE FROM chat_sessions WHERE id='f06-ses2'")
        _seed_parent_rows()
        _sql("INSERT INTO chat_sessions (id, project_id, mode, title, "
             "character_ids, settings, pinned, message_count, chapter_id) "
             "VALUES ('f06-ses2', 'default', 'assistant', 'S', '', '{}', "
             "0, 0, 'f06-ch')")
        _sql("DELETE FROM chapters WHERE id='f06-ch'")
        assert _one("SELECT chapter_id FROM chat_sessions "
                    "WHERE id='f06-ses2'") is None


# ---------------------------------------------------------------------------
# Yetim reddi + unique + CHECK
# ---------------------------------------------------------------------------

class TestConstraintEnforcement:

    def test_orphan_message_rejected(self):
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO chat_messages (session_id, role, content) "
                 "VALUES ('f06-ghost-ses', 'user', 'yetim')")

    def test_duplicate_custom_word_rejected(self):
        _sql("DELETE FROM custom_words WHERE word='f06kelime'")
        _sql("INSERT INTO custom_words (id, project_id, word) "
             "VALUES ('f06-w1', 'default', 'f06kelime')")
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO custom_words (id, project_id, word) "
                 "VALUES ('f06-w2', 'default', 'f06kelime')")

    def test_duplicate_glossary_term_rejected(self):
        _sql("DELETE FROM glossary_entries WHERE term='f06terim'")
        _sql("INSERT INTO glossary_entries (id, project_id, term, "
             "case_sensitive) VALUES ('f06-g1', 'default', 'f06terim', 0)")
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO glossary_entries (id, project_id, term, "
                 "case_sensitive) VALUES ('f06-g2', 'default', 'f06terim', 0)")

    def test_negative_word_count_rejected(self):
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO chapters (id, project_id, title, word_count, "
                 "sort_order) VALUES ('f06-ch3', 'default', 'N', -1, 0)")

    def test_nonbool_pinned_rejected(self):
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO notes (id, project_id, title, pinned, done) "
                 "VALUES ('f06-n1', 'default', 'N', 5, 0)")

    def test_bad_chat_role_rejected(self):
        _sql("DELETE FROM chat_sessions WHERE id='f06-ses3'")
        _sql("INSERT INTO chat_sessions (id, project_id, mode, title, "
             "character_ids, settings, pinned, message_count) "
             "VALUES ('f06-ses3', 'default', 'character', 'S', '', '{}', 0, 0)")
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO chat_messages (session_id, role, content) "
                 "VALUES ('f06-ses3', 'qa', 'rol')")

    def test_bad_chat_mode_rejected(self):
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO chat_sessions (id, project_id, mode, title, "
                 "character_ids, settings, pinned, message_count) "
                 "VALUES ('f06-ses4', 'default', 'telepati', 'S', '', '{}', "
                 "0, 0)")

    def test_energy_range_enforced(self):
        _sql("DELETE FROM journal_entries WHERE entry_date='2026-03-03'")
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO journal_entries (id, project_id, entry_date, "
                 "energy) VALUES ('f06-j1', 'default', '2026-03-03', 9)")

    def test_journal_date_unique_per_project_only(self):
        """v7 çoklu-kitap düzeltmesi: aynı tarih İKİ projede serbest, tek
        projede yasak (eski global unique(entry_date) kusuruydu)."""
        _sql("DELETE FROM journal_entries WHERE entry_date='2026-04-04'")
        _sql("DELETE FROM projects WHERE id='f06-proj2'")
        _sql("INSERT INTO projects (id, name) VALUES ('f06-proj2', 'P2')")
        _sql("INSERT INTO journal_entries (id, project_id, entry_date) "
             "VALUES ('f06-j2', 'default', '2026-04-04')")
        # ikinci proje — serbest
        _sql("INSERT INTO journal_entries (id, project_id, entry_date) "
             "VALUES ('f06-j3', 'f06-proj2', '2026-04-04')")
        # aynı proje — yasak
        with pytest.raises(IntegrityError):
            _sql("INSERT INTO journal_entries (id, project_id, entry_date) "
                 "VALUES ('f06-j4', 'default', '2026-04-04')")

    def test_glossary_service_rejects_duplicate_cleanly(self):
        """Servis katmanı temiz ValidationError döner (500 değil)."""
        from services.glossary_service import create_entry
        _sql("DELETE FROM glossary_entries WHERE term='f06svc'")
        create_entry(term="f06svc", category="other")
        with pytest.raises(ValidationError):
            create_entry(term="f06svc", category="other")

    def test_snippet_service_rejects_duplicate_cleanly(self):
        from services.snippet_service import create_snippet
        _sql("DELETE FROM snippets WHERE name='f06snippet'")
        create_snippet("f06snippet", "içerik")
        with pytest.raises(ValidationError):
            create_snippet("f06snippet", "başka içerik")


# ---------------------------------------------------------------------------
# Şema şekli
# ---------------------------------------------------------------------------

class TestSchemaShape:

    def test_fk_pragma_on_for_app_engine(self):
        with core.db.engine.connect() as c:
            assert c.execute(text("PRAGMA foreign_keys")).scalar() == 1

    def test_boolean_columns_typed(self):
        insp = inspect(core.db.engine)
        expect = {
            "notes": {"pinned", "done"},
            "chat_sessions": {"pinned"},
            "chapter_versions": {"is_pinned"},
            "saved_inspirations": {"pinned", "used"},
        }
        for table, cols in expect.items():
            got = {c["name"]: str(c["type"]) for c in insp.get_columns(table)}
            for col in cols:
                assert got[col] == "BOOLEAN", f"{table}.{col} -> {got[col]}"

    def test_foreign_key_check_clean(self):
        with core.db.engine.connect() as c:
            assert c.execute(text("PRAGMA foreign_key_check")).fetchall() == []

    def test_fts_triggers_present(self):
        with core.db.engine.connect() as c:
            names = {
                r[0] for r in c.execute(text(
                    "SELECT name FROM sqlite_master WHERE type='trigger'"))
            }
        for trg in ("chapters_ai", "chapters_ad", "chapters_au",
                    "characters_ai", "world_ai"):
            assert trg in names, f"FTS trigger missing: {trg}"


# ---------------------------------------------------------------------------
# Legacy kirli veri benimsemesi (asm0001 -> asm0003)
# ---------------------------------------------------------------------------

class TestLegacyDirtyAdoption:

    def _build_legacy(self, tmp_path):
        from alembic.config import Config as AlembicConfig

        from alembic import command
        from core.migrations import ALEMBIC_INI

        eng = create_engine(f"sqlite:///{tmp_path / 'f06legacy.db'}",
                            future=True)
        cfg = AlembicConfig(str(ALEMBIC_INI))
        cfg.set_main_option("script_location", str(ALEMBIC_INI.parent / "alembic"))
        cfg.set_main_option("sqlalchemy.url", str(eng.url))
        cfg.attributes["configure_logger"] = False
        command.upgrade(cfg, "asm0001")  # eski, kısıtsız şema
        with eng.connect() as c:
            c.execute(text("INSERT INTO projects (id, name) "
                           "VALUES ('default', 'L')"))
            # kirli veri
            c.execute(text("INSERT INTO chat_messages (session_id, role, "
                           "content) VALUES ('ghost', 'user', 'yetim')"))
            c.execute(text("INSERT INTO custom_words (id, project_id, word) "
                           "VALUES ('a', 'default', 'dup')"))
            c.execute(text("INSERT INTO custom_words (id, project_id, word) "
                           "VALUES ('b', 'default', 'dup')"))
            c.execute(text("INSERT INTO notes (id, project_id, title, pinned, "
                           "done) VALUES ('n', 'default', 'N', 5, 2)"))
            c.execute(text("INSERT INTO notes (id, project_id, title) "
                           "VALUES ('n2', NULL, 'NULL-p')"))
            c.execute(text("DROP TABLE alembic_version"))
            c.commit()
        return eng

    def test_dirty_legacy_is_cleaned_and_adopted(self, tmp_path):
        from core.migrations import get_current_revision, run_db_migrations

        eng = self._build_legacy(tmp_path)
        report = run_db_migrations(eng)
        assert report["action"] == "legacy-adopt"
        assert report["to"] == "asm0005"
        assert get_current_revision(eng) == "asm0005"

        with eng.connect() as c:
            # yetim mesaj silindi
            assert c.execute(text(
                "SELECT COUNT(*) FROM chat_messages")).scalar() == 0
            # çift kelime tekilleşti
            assert c.execute(text(
                "SELECT COUNT(*) FROM custom_words")).scalar() == 1
            # boolean dışı değerler normalize edildi
            pinned, done = c.execute(text(
                "SELECT pinned, done FROM notes WHERE id='n'")).fetchone()
            assert (pinned, done) == (0, 0)
            # NULL project_id 'default'a geri dolgu yapıldı
            assert c.execute(text(
                "SELECT project_id FROM notes WHERE id='n2'")).scalar() \
                == "default"
            # bütünlük denetimi temiz
            assert c.execute(text("PRAGMA foreign_key_check")).fetchall() == []
            # FTS trigger'ları migration sonrası yerinde
            trg = c.execute(text(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' "
                "AND name='chapters_ai'")).scalar()
            assert trg == 1

    def test_dirty_rowcount_purge_is_iterative_for_self_ref(self, tmp_path):
        """Kendine-referanslı yetim zinciri (beta_comments) tam temizlenir."""
        from core.migrations import get_current_revision, run_db_migrations

        eng = self._build_legacy(tmp_path)
        with eng.connect() as c:
            c.execute(text("INSERT INTO beta_comments (id, chapter_id, "
                           "comment, parent_id) "
                           "VALUES (1, 'yok', 'yetim', 99)"))
            c.execute(text("INSERT INTO beta_comments (id, chapter_id, "
                           "comment, parent_id) VALUES (2, 'yok', 'cocuk', 1)"))
            c.commit()
        run_db_migrations(eng)
        assert get_current_revision(eng) == "asm0005"
        with eng.connect() as c:
            assert c.execute(text(
                "SELECT COUNT(*) FROM beta_comments")).scalar() == 0
            assert c.execute(text("PRAGMA foreign_key_check")).fetchall() == []
