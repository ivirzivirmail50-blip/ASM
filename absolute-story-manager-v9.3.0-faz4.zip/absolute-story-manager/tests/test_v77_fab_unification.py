"""v7.7 regression tests — unified Quick Capture surface.

USER REPORT: "sol alt tarafta + butonu diğer tuşların üzerine geliyor"
(the bottom-left + button sits on top of other buttons).

ROOT CAUSE (reproduced live with agent-browser geometry):
  The legacy ``.fab-capture`` FAB was fixed at ``bottom: 1.5rem; left: 1.5rem``
  — INSIDE the 240px sidebar's footprint. Its bounding box overlapped the
  sidebar's last nav links ("Kanban", "Corkboard") and the sidebar footer
  (daily words counter + version), blocking their clicks.

FIX (architectural, not cosmetic):
  * The legacy bottom-left ``.fab-capture`` button is REMOVED from base.html.
  * The v7.3 Quick Capture composer (static/js/quick_capture.js — 4 capture
    types: Note/Chapter/Journal/Snippet) becomes the SINGLE capture surface.
  * Its FAB (``#qcFab``, bottom-right, outside the sidebar) now shows the
    ``+`` icon the user knows, with both hotkeys in the tooltip.
  * ``window.asmQuickCapture`` public API added; Ctrl+N (app.js), Quick
    Switch "quickNote" action, and the header "+ New → Quick Capture" menu
    all route to the rich composer, falling back to the legacy note-only
    modal only if the module failed to load.
"""
import re

# ----------------------------------------------------------- template shape


def test_v77_legacy_fab_removed_from_base_template():
    """The overlapping bottom-left button must not exist anymore."""
    src = open("templates/base.html", encoding="utf-8").read()
    assert 'class="fab-capture"' not in src
    assert 'id="fabCapture"' not in src


def test_v77_legacy_fab_css_gone():
    """All three stylesheets must be free of .fab-capture rules."""
    for p in ("static/css/main.css", "static/css/polish.css", "static/css/ui-v2.css"):
        css = open(p, encoding="utf-8").read()
        assert ".fab-capture" not in css, f"{p} still styles .fab-capture"


def test_v77_header_menu_routes_to_rich_composer():
    """The header '+ New → Quick Capture' entry prefers asmQuickCapture."""
    src = open("templates/base.html", encoding="utf-8").read()
    m = re.search(r'onclick="[^"]*asmQuickCapture[^"]*"', src)
    assert m, "header menu should call window.asmQuickCapture with fallback"
    assert "openGlobalNoteCapture" in m.group(0), "fallback must stay"


def test_v77_quick_capture_fab_uses_plus_icon():
    """qc-fab now carries the + icon (what the user recognizes) + both hotkeys."""
    src = open("static/js/quick_capture.js", encoding="utf-8").read()
    assert 'fab.innerHTML = icon("plus");' in src
    assert 'fab.innerHTML = icon("zap")' not in src   # FAB no longer uses zap
    assert "Ctrl+N or Ctrl+Shift+N" in src   # tooltip documents both hotkeys


def test_v77_quick_capture_exports_public_api():
    """window.asmQuickCapture must be exported for cross-module routing."""
    src = open("static/js/quick_capture.js", encoding="utf-8").read()
    assert "window.asmQuickCapture = open;" in src


def test_v77_ctrl_n_routes_to_rich_composer():
    """app.js Ctrl+N prefers the 4-type composer, legacy modal as fallback."""
    src = open("static/js/app.js", encoding="utf-8").read()
    assert "window.asmQuickCapture || openGlobalNoteCapture" in src


def test_v77_single_ctrl_n_binding():
    """Only ONE document-level Ctrl+N branch may exist (the old top handler
    redirected to /chapters/new and silently won over the capture handler —
    dead code that contradicted the shortcuts modal docs)."""
    src = open("static/js/app.js", encoding="utf-8").read()
    # the legacy redirects must be gone
    assert 'window.location.href = "/chapters/new"' not in src
    assert 'window.location.href = "/characters/new"' not in src
    # exactly one _openCapture call site inside keydown handlers
    assert src.count("_openCapture();") == 1


def test_v77_ctrl_shift_n_owned_by_quick_capture():
    """Ctrl+Shift+N is bound ONLY in quick_capture.js (toggle). If app.js
    also bound it, both document-level listeners would race open/close."""
    app_src = open("static/js/app.js", encoding="utf-8").read()
    qc_src = open("static/js/quick_capture.js", encoding="utf-8").read()
    assert "shiftKey" in qc_src and "open()" in qc_src   # toggle lives here
    # app.js main handler must not bind shift+N (note: !e.shiftKey guard is fine)
    assert "&& e.shiftKey && e.key.toLowerCase() === \"n\"" not in app_src
    assert "e.shiftKey && (e.key === \"N\"" not in app_src


# ------------------------------------------------------ rendered page checks


def test_v77_no_bottom_left_fab_on_rendered_pages(client):
    """Rendered HTML across core pages must not contain the legacy FAB button.

    (The v7.7 removal NOTE comment in base.html legitimately mentions the
    old class name — so we assert on the button markup, not the raw string.)
    """
    for url in ("/", "/notes/", "/chapters/", "/journal/"):
        r = client.get(url)
        assert r.status_code == 200, f"{url} → {r.status_code}"
        assert b'class="fab-capture"' not in r.data, f"legacy FAB still on {url}"
        assert b'id="fabCapture"' not in r.data, f"legacy FAB id still on {url}"


def test_v77_quick_capture_js_served(client):
    """The static module that injects the (single) FAB is served."""
    r = client.get("/static/js/quick_capture.js")
    assert r.status_code == 200
    assert b"asmQuickCapture" in r.data
    assert b'icon("plus")' in r.data


def test_v77_qc_fab_css_still_present():
    """The surviving FAB keeps its styling.

    v7.8 UPDATE: the FAB no longer positions itself — it lives inside the
    unified bottom-right dock (.br-dock) which owns the fixed positioning.
    The user-facing intent is preserved: bottom-right, never left (sidebar).
    """
    css = open("static/css/polish.css", encoding="utf-8").read()
    m = re.search(r"\.qc-fab \{[^}]*\}", css, re.S)
    assert m, "base .qc-fab rule must exist"
    block = m.group(0)
    assert "position: fixed" not in block, (
        "v7.8: .qc-fab must NOT self-position — it is a .br-dock child; "
        "fixed positioning belongs to .br-dock only (single anchor point)"
    )
    assert "left:" not in block, "qc-fab must never be positioned left (sidebar area)"
    # The dock owns the bottom-right anchor now
    main_css = open("static/css/main.css", encoding="utf-8").read()
    dm = re.search(r"\.br-dock \{[^}]*\}", main_css, re.S)
    assert dm, ".br-dock container rule must exist in main.css"
    dblock = dm.group(0)
    assert "position: fixed" in dblock
    assert "right" in dblock and "bottom" in dblock
    assert "left" not in dblock, "dock must anchor right, never left (sidebar)"
