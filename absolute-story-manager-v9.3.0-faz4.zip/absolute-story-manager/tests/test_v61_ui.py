"""ASM v6.1 UI polish tests — icon system, polished sidebar, accordion,
default UI version, polish.css, i18n section keys."""
import pytest


class TestIconSystem:
    def test_sprite_rendered_on_every_page(self, client):
        rv = client.get("/")
        assert rv.status_code == 200
        # The hidden SVG sprite is present once, right after <body>
        assert b'id="i-home"' in rv.data
        assert b'style="display:none"' in rv.data

    def test_icons_used_instead_of_emoji_in_sidebar(self, client):
        rv = client.get("/")
        data = rv.data
        # Sidebar links reference the sprite via <use>
        assert b'use href="#i-home"' in data
        assert b'use href="#i-file-text"' in data
        assert b'use href="#i-users"' in data
        # Legacy emoji glyphs are gone from the nav
        assert b'<span class="nav-icon">\u26bd</span>' not in data  # no unicode balls
        assert b'<span class="nav-icon">\xf0\x9f\x93\x96' not in data  # no book emoji bytes

    def test_polish_css_served(self, client):
        rv = client.get("/static/css/polish.css")
        assert rv.status_code == 200
        assert b"prefers-reduced-motion" in rv.data

    def test_polish_css_linked_in_head(self, client):
        rv = client.get("/")
        assert b"polish.css" in rv.data


class TestPolishedSidebar:
    def test_sidebar_component_included(self, client):
        rv = client.get("/")
        # Section labels carry the accordion affordance
        assert b'data-section="workspace"' in rv.data
        assert b'data-section="system"' in rv.data
        assert b"asmToggleNavSection" in rv.data

    def test_nav_groups_wrap_links(self, client):
        rv = client.get("/")
        assert b'class="nav-group"' in rv.data
        assert b"nav-group-inner" in rv.data

    def test_today_progress_widget_present(self, client):
        rv = client.get("/")
        assert b'id="sidebarTodayBar"' in rv.data
        assert b"today-bar" in rv.data

    def test_footer_shows_current_version(self, client):
        rv = client.get("/")
        assert b"ASM v9.0" in rv.data  # updated each release (v9.0 now)

    def test_theme_toggle_has_sun_moon_icons(self, client):
        rv = client.get("/")
        assert b'theme-sun' in rv.data
        assert b'theme-moon' in rv.data


class TestDefaultUiVersion:
    def test_v2_is_default(self, client):
        rv = client.get("/")
        assert b'data-ui-version="v2"' in rv.data

    def test_legacy_option_still_available(self, client):
        rv = client.get("/settings/")
        assert b'value="legacy"' in rv.data
        assert b"value=\"v2\"" in rv.data


class TestI18nSectionKeys:
    def test_new_section_keys_exist(self):
        from services.i18n_service import TRANSLATIONS
        for key in ("nav.section_tools", "nav.section_analytics", "nav.section_export"):
            assert key in TRANSLATIONS
            # All 5 languages have the entry
            assert set(TRANSLATIONS[key].keys()) == {"en", "tr", "es", "fr", "de"}
