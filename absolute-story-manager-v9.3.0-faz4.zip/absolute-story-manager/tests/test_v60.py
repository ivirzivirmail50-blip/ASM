"""ASM v6.0 integration tests — thinking cleanup, JSON rescue, name
generation, model routing, and context-aware AI routes (AI mocked)."""
import json
from unittest.mock import MagicMock, patch

import pytest

from core.errors import AiProviderError
from services import ai_providers, ai_service

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _enable_ai(model="test-model", fast=""):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", "openai")
        Setting.set(s, "ai.model", model)
        if fast:
            Setting.set(s, "ai.model_fast", fast)


def _mock_provider_return(text):
    """Patch the OpenAI-compat adapter's generate to return the given raw text."""
    return patch.object(ai_providers.OpenAICompatAdapter, "generate", return_value=text)


# ---------------------------------------------------------------------------
# Thinking-block cleanup v2
# ---------------------------------------------------------------------------

class TestThinkingCleanupV2:
    def test_xml_think_block(self):
        assert ai_service._clean_thinking("<think>reasoning</think>Kael") == "Kael"

    def test_reasoning_block(self):
        assert ai_service._clean_thinking("<reasoning>x</reasoning>Seraphine") == "Seraphine"

    def test_anthropic_style(self):
        assert ai_service._clean_thinking("<antThinking>hmm</antThinking>Lyra") == "Lyra"

    def test_md_think_fence(self):
        assert ai_service._clean_thinking("```think\nsecret\n```\nThorne") == "Thorne"

    def test_plain_header(self):
        out = ai_service._clean_thinking("Reasoning:\nI should pick a name\n\n\n**Answer:** Elara")
        assert "I should pick" not in out
        assert "Elara" in out

    def test_generate_strips_thinking(self):
        _enable_ai()
        with _mock_provider_return("<think>chain of thought</think>The real answer"):
            assert ai_service.generate("p") == "The real answer"

    def test_generate_raises_when_only_thinking(self):
        _enable_ai()
        with _mock_provider_return("<think>only thinking, budget exhausted</think>"):
            with pytest.raises(AiProviderError):
                ai_service.generate("p")


# ---------------------------------------------------------------------------
# JSON rescue pipeline
# ---------------------------------------------------------------------------

class TestCompleteJson:
    def test_valid_json_passthrough(self):
        _enable_ai()
        with _mock_provider_return('{"name": "Kael"}'):
            assert ai_service.complete_json("p") == {"name": "Kael"}

    def test_json_with_thinking_and_prose(self):
        _enable_ai()
        raw = ('<think>picking a character…</think>'
               'Sure! Here is your character:\n'
               '```json\n{"name": "Lyra", "age": "27",}\n```\n'
               'Hope this helps!')
        with _mock_provider_return(raw):
            result = ai_service.complete_json("p")
            assert result["name"] == "Lyra"
            assert result["age"] == "27"

    def test_json_array_from_prose(self):
        _enable_ai()
        raw = 'Findings below:\n[{"severity": "warning"}, {"severity": "error"}]\nDone.'
        with _mock_provider_return(raw):
            result = ai_service.complete_json("p")
            assert isinstance(result, list) and len(result) == 2

    def test_json_python_booleans_repaired(self):
        _enable_ai()
        raw = '{"active": True, "tags": None}'
        with _mock_provider_return(raw):
            result = ai_service.complete_json("p")
            assert result["active"] is True
            assert result["tags"] is None

    def test_json_failure_raises(self):
        _enable_ai()
        with _mock_provider_return("no json here at all, just words"):
            with pytest.raises(AiProviderError):
                ai_service.complete_json("p")


# ---------------------------------------------------------------------------
# Name generation (the reported bug)
# ---------------------------------------------------------------------------

class TestNameGenerator:
    def test_names_survive_reasoning_models(self):
        """Reasoning model returns thinking + valid names — only names remain."""
        _enable_ai()
        raw = ("<think>Let me brainstorm fantasy names. The user wants 5. "
               "I'll pick short memorable ones.</think>\n"
               "Kael\nSeraphine\nThorne\nLyra\nRagnar")
        with _mock_provider_return(raw):
            names = ai_service.generate_name("fantasy", "character")
        assert "Kael" in names
        assert all(len(n) <= 48 for n in names)
        assert not any("brainstorm" in n.lower() for n in names)

    def test_garbage_names_filtered(self):
        """A model that returns prose instead of names yields empty list."""
        _enable_ai()
        raw = ("Sure, I'd be happy to suggest names! Here are some options "
               "that might work well for your story.")
        with _mock_provider_return(raw):
            names = ai_service.generate_name("fantasy", "character")
        assert names == []

    def test_numbered_names_cleaned(self):
        _enable_ai()
        raw = "1. Kael\n2. Lyra\n3. Thorne"
        with _mock_provider_return(raw):
            names = ai_service.generate_name("fantasy", "character")
        assert names == ["Kael", "Lyra", "Thorne"]

    def test_bad_result_not_cached(self):
        _enable_ai()
        from core.cache import cache
        raw = "I cannot generate names, sorry."
        with _mock_provider_return(raw):
            ai_service.generate_name("scifi", "ship")
        assert cache.get("ai:name_gen:scifi:ship") is None


# ---------------------------------------------------------------------------
# Model routing (fast model)
# ---------------------------------------------------------------------------

class TestModelRouting:
    def test_fast_model_used_for_name_gen(self):
        _enable_ai(model="big-reasoning-model", fast="small-fast-model")
        captured = {}

        def fake_call(cfg, prompt, max_tokens, temperature):
            captured["model"] = cfg["model"]
            return "Kael\nLyra\nThorne\nMira\nVoss"

        with patch.object(ai_providers.OpenAICompatAdapter, "generate", side_effect=fake_call):
            ai_service.generate_name("fantasy", "character")
        assert captured["model"] == "small-fast-model"

    def test_main_model_used_for_writing(self):
        _enable_ai(model="big-reasoning-model", fast="small-fast-model")
        captured = {}

        def fake_call(cfg, prompt, max_tokens, temperature):
            captured["model"] = cfg["model"]
            return "The night was cold."

        with patch.object(ai_providers.OpenAICompatAdapter, "generate", side_effect=fake_call):
            ai_service.generate("continue the story", task=None)
        assert captured["model"] == "big-reasoning-model"

    def test_no_fast_model_falls_back(self):
        _enable_ai(model="only-model")
        captured = {}

        def fake_call(cfg, prompt, max_tokens, temperature):
            captured["model"] = cfg["model"]
            return "Kael\nLyra\nThorne\nMira\nVoss"

        with patch.object(ai_providers.OpenAICompatAdapter, "generate", side_effect=fake_call):
            ai_service.generate_name("fantasy", "character")
        assert captured["model"] == "only-model"


# ---------------------------------------------------------------------------
# Context-aware AI routes
# ---------------------------------------------------------------------------

@pytest.fixture
def ctx_story():
    from services import chapter_service, character_service, world_service
    ch1 = chapter_service.create_chapter(
        title="Arrival", content="Elara arrived.",
        synopsis="Elara reaches the city.")
    ch2 = chapter_service.create_chapter(
        title="Storm", content="Elara fought the storm.", synopsis="Storm hits.")
    c1 = character_service.create_character(
        name="Elara", role="protagonist", psychology="brave")
    w1 = world_service.create_entry(type_="location", name="Stormhaven",
                                    description="Harbor city.")
    return {"ch1": ch1, "ch2": ch2, "c1": c1, "w1": w1}


class TestContextAwareRoutes:
    def test_copilot_suggest_returns_context_stats(self, client, ctx_story):
        _enable_ai()
        with _mock_provider_return("Elara gripped the rope."):
            rv = client.post("/ai-copilot/api/suggest", json={
                "text": "Elara walked through Stormhaven.",
                "action": "continue",
                "chapter_id": ctx_story["ch2"].id,
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["context"]["characters"] >= 1
        assert data["context"]["world"] >= 1
        assert data["context"]["plot"] >= 1  # previous chapter summary

    def test_copilot_context_preview(self, client, ctx_story):
        rv = client.post("/ai-copilot/api/context-preview", json={
            "text": "Elara walked through Stormhaven.",
            "chapter_id": ctx_story["ch2"].id,
        })
        data = rv.get_json()
        assert data["ok"] is True
        assert "Elara" in data["context_text"]
        assert "Stormhaven" in data["context_text"]
        assert "Arrival" in data["context_text"]  # plot memory

    def test_character_chat_uses_context(self, client, ctx_story):
        _enable_ai()
        with _mock_provider_return("I am Elara. The sea took everything."):
            rv = client.post("/character-chat/api/chat", json={
                "character_id": ctx_story["c1"].id,
                "message": "Who are you?",
                "chapter_id": ctx_story["ch2"].id,
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["character"] == "Elara"
        assert data["context"]["characters"] >= 1

    def test_character_generator_ai_structured(self, client):
        _enable_ai()
        raw = json.dumps({
            "name": "Vesper Quill", "role": "supporting", "age": "34",
            "physical": "Lean, ink-stained fingers.",
            "personality": "Obsessive, curious.",
            "background": "A cartographer who mapped the under-city.",
            "motivation": "find the last blank page",
            "fear": "being finished",
            "quirk": "smells every book",
        })
        with _mock_provider_return(raw):
            rv = client.post("/character-generator/api/generate", json={
                "use_ai": True, "setting": "fantasy",
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["character"]["ai_generated"] is True
        assert data["character"]["name"] == "Vesper Quill"
        assert data["character"]["motivation"] == "find the last blank page"

    def test_character_generator_falls_back_on_ai_garbage(self, client):
        _enable_ai()
        with _mock_provider_return("<think>budget spent thinking</think>"):
            rv = client.post("/character-generator/api/generate", json={
                "use_ai": True, "setting": "fantasy",
            })
        data = rv.get_json()
        assert data["ok"] is True
        # Fallback random character still produced
        assert data["character"]["ai_generated"] is False
        assert data["character"]["name"]

    def test_continue_context_uses_engine(self, client, ctx_story):
        _enable_ai()
        with _mock_provider_return("The storm swallowed the pier."):
            rv = client.post("/ai/continue-context", json={
                "text": "Elara fought the storm in Stormhaven.",
                "chapter_id": ctx_story["ch2"].id,
            })
        data = rv.get_json()
        assert data["ok"] is True
        assert data["context"]["characters"] >= 1


# ---------------------------------------------------------------------------
# Settings accept new keys
# ---------------------------------------------------------------------------

class TestV60Settings:
    def test_fast_model_setting_roundtrip(self, client):
        rv = client.post("/settings/save", json={"ai.model_fast": "gemma2:9b"})
        assert rv.get_json()["ok"] is True
        from core.db import read_session
        from models.settings import Setting
        with read_session() as s:
            assert Setting.get(s, "ai.model_fast", "") == "gemma2:9b"


# ---------------------------------------------------------------------------
# Command palette + new JS assets served
# ---------------------------------------------------------------------------

class TestV60Assets:
    def test_command_palette_js_served(self, client):
        rv = client.get("/static/js/command_palette.js")
        assert rv.status_code == 200
        assert b"Command Palette" in rv.data

    def test_base_includes_palette_script(self, client):
        rv = client.get("/")
        assert b"command_palette.js" in rv.data

    def test_base_includes_kbd_hint(self, client):
        # The cheatsheet (with the Ctrl+K entry) lives in app.js
        rv = client.get("/static/js/app.js")
        assert "Ctrl/⌘ + K".encode() in rv.data
