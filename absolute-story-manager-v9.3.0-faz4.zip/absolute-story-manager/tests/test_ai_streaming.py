"""M-08 — ai_service streaming + thinking-filter coverage (57% → 80%+).

Starts the real scripts/mock_ai_server.py in a background thread and
exercises generate_streaming end-to-end over HTTP, plus the
thinking/reasoning filters (stateful, chunk-crossing) and JSON completion.
"""
from __future__ import annotations

import json
import threading
from http.server import HTTPServer

import pytest

from services import ai_service


@pytest.fixture(scope="module")
def mock_ai():
    """Run the mock OpenAI-compatible server on an ephemeral port."""
    import importlib.util
    from pathlib import Path

    spec = importlib.util.spec_from_file_location(
        "mock_ai_server",
        Path(__file__).resolve().parent.parent / "scripts" / "mock_ai_server.py",
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    server = HTTPServer(("127.0.0.1", 0), mod.Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.fixture()
def ai_enabled(mock_ai):
    """Enable the OpenAI-compat provider pointed at the mock server."""
    from core.db import write_transaction
    from models.settings import Setting

    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", "openai")
        Setting.set(s, "ai.api_base", mock_ai)
        Setting.set(s, "ai.api_key", "test-key")
        Setting.set(s, "ai.model", "mock-model")
    yield
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", False)


# ---------------------------------------------------------------------------
# Thinking filter (pure functions — no server needed)
# ---------------------------------------------------------------------------

class TestCleanThinking:

    def test_removes_think_block(self):
        out = ai_service._clean_thinking(
            "<think>secret reasoning</think>Final answer here")
        assert out.strip() == "Final answer here"

    def test_removes_unclosed_think(self):
        out = ai_service._clean_thinking("visible text <think>ramble forever")
        assert "ramble" not in out
        assert "visible text" in out

    def test_removes_reasoning_flavors(self):
        for tag in ("reasoning", "thought", "analysis", "scratchpad"):
            out = ai_service._clean_thinking(
                "before <" + tag + ">hidden</" + tag + "> after")
            assert "hidden" not in out
            assert "before" in out and "after" in out

    def test_empty_and_plain_text_pass_through(self):
        assert ai_service._clean_thinking("") == ""
        assert ai_service._clean_thinking("sadece düz metin") == \
            "sadece düz metin"

    def test_json_strips_thinking(self):
        out = ai_service._clean_thinking(
            '<think>plan</think>{"speaker": "Ayşe"}')
        assert json.loads(out) == {"speaker": "Ayşe"}


class TestThinkingStreamFilter:

    def test_stateful_filter_across_chunks(self):
        f = ai_service._ThinkingStreamFilter()
        pieces = ["<thi", "nk>reasoning ", "part</thi", "nk>real ", "text"]
        out = "".join(f.feed(p) for p in pieces) + f.flush()
        assert out.strip() == "real text"

    def test_no_thinking_passthrough(self):
        f = ai_service._ThinkingStreamFilter()
        out = f.feed("plain chunk ") + f.flush()
        assert out == "plain chunk "


# ---------------------------------------------------------------------------
# Live streaming against the mock server
# ---------------------------------------------------------------------------

class TestStreaming:

    def test_generate_streaming_yields_chunks(self, ai_enabled):
        chunks = list(ai_service.generate_streaming(
            "Continue this scene: the harbor at dusk", max_tokens=80))
        assert chunks, "no chunks yielded"
        final_text = "".join(c for c, done in chunks)
        assert len(final_text) > 10
        assert chunks[-1][1] is True  # is_final on the last chunk
        # Turkish mock prose actually flowed through.
        assert any(("hikâye" in final_text) or ("test" in final_text)
                   for _ in [0])

    def test_generate_non_streaming_over_http(self, ai_enabled):
        out = ai_service.generate("Continue this scene", max_tokens=80)
        assert isinstance(out, str) and len(out) > 10

    def test_complete_json_parses(self, ai_enabled):
        out = ai_service.complete_json(
            'Give a character card. Reply only with JSON: '
            '{"speaker": "..."}', max_tokens=100)
        assert isinstance(out, dict)
        assert out.get("speaker") == "Ayşe Yılmazoğlu"

    def test_summarize_flow(self, ai_enabled):
        out = ai_service.summarize("Some chapter text about the Bosphorus.",
                                   max_tokens=60)
        assert isinstance(out, str)

    def test_disabled_raises(self):
        from core.errors import AiDisabledError
        with pytest.raises(AiDisabledError):
            next(ai_service.generate_streaming("x"))

    def test_no_model_raises(self, ai_enabled):
        from core.db import write_transaction
        from core.errors import AiProviderError
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.model", "")
        with pytest.raises(AiProviderError):
            next(ai_service.generate_streaming("x"))
