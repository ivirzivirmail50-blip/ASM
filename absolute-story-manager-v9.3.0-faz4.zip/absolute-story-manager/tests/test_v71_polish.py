"""ASM v7.1 polish tests — notes read modal, character builder, nested locations."""
import pytest

from services import world_service


@pytest.fixture
def a_location():
    return world_service.create_entry(type_="location", name="Planet Aurelia")


class TestNotesReadModal:
    def test_notes_page_has_read_modal_handler(self, client):
        rv = client.get("/notes/")
        assert rv.status_code == 200
        # v7.5: the read-modal handler lives in static/js/notes.js (the page
        # references it) instead of a fragile inline <script> block.
        assert b"js/notes.js" in rv.data
        # The old inline expand handler is gone
        assert b"this.style.maxHeight = \"none\"" not in rv.data
        # No large inline script may return (source-level fix for dead pages).
        # base.html's shared i18n/book-switcher scripts are fine — only
        # notes-specific logic must not regress into an inline block.
        import re
        blocks = re.findall(rb"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>",
                            rv.data, re.S)
        for b in blocks:
            assert b"openNewNoteModal" not in b and b"notesGrid" not in b, \
                "notes page regressed to a large inline <script> block"


class TestCharacterBuilder:
    def test_page_uses_two_column_layout(self, client):
        rv = client.get("/characters/new")
        assert rv.status_code == 200
        assert b"char-builder-grid" in rv.data
        assert b"char-form-col" in rv.data
        assert b"char-preview-col" in rv.data

    def test_live_preview_widgets(self, client):
        rv = client.get("/characters/new")
        assert b"char-preview-avatar" in rv.data
        assert b'previewName' in rv.data
        assert b'previewRole' in rv.data
        assert b"data-preview=" in rv.data

    def test_quick_templates_present(self, client):
        rv = client.get("/characters/new")
        assert b"data-template=\"protagonist\"" in rv.data
        assert b"data-template=\"antagonist\"" in rv.data
        assert b"data-template=\"mentor\"" in rv.data
        assert b"TEMPLATES" in rv.data

    def test_all_original_fields_preserved(self, client):
        rv = client.get("/characters/new")
        for field in (b'name="name"', b'name="role"', b'name="avatar_color"',
                      b'name="age"', b'name="gender"', b'name="aliases"',
                      b'name="physical"', b'name="psychology"',
                      b'name="background"', b'name="philosophy"',
                      b'name="voice"', b'name="story_role"',
                      b'name="notes"', b'name="quotes"'):
            assert field in rv.data, f"missing field: {field}"

    def test_create_still_works(self, client):
        rv = client.post("/characters/new", data={
            "name": "Test Hero", "role": "protagonist",
            "avatar_color": "#22c55e", "physical": "tall and lean",
        })
        data = rv.get_json()
        assert data["ok"] is True
        assert data.get("url", "").startswith("/characters/")


class TestNestedLocations:
    def test_new_route_accepts_parent_param(self, client, a_location):
        rv = client.get(f"/world/new?parent={a_location.id}")
        assert rv.status_code == 200
        assert b'name="parent_id"' in rv.data
        assert a_location.name.encode() in rv.data  # parent name shown
        assert b'Child of' in rv.data

    def test_new_route_without_parent_has_no_parent_field(self, client):
        # v7.4 — without ?parent=, the page now shows an interactive parent picker
        #        dropdown (named parent_id) so the user can choose any existing
        #        location as parent. The hidden parent_id input only appears when
        #        ?parent= is set (the dropdown is replaced by a banner).
        rv = client.get("/world/new")
        assert rv.status_code == 200
        # The parent picker dropdown should be present
        assert b'name="parent_id"' in rv.data
        # It should NOT have a hidden pre-set value (no parent preselected)
        assert b'value=""' in rv.data or b'<option value=""' in rv.data

    def test_create_child_with_parent(self, client, a_location):
        rv = client.post("/world/new", data={
            "type": "location", "name": "City of Borealis",
            "parent_id": a_location.id,
        })
        data = rv.get_json()
        assert data["ok"] is True
        # Verify the parent_id is stored
        e = world_service.get_entry(data["id"])
        assert e.parent_id == a_location.id

    def test_hierarchy_shows_add_child_button(self, client, a_location):
        rv = client.get("/world/hierarchy")
        assert b"+ Child" in rv.data
        assert a_location.id.encode() in rv.data

    def test_detail_shows_add_child_for_locations(self, client, a_location):
        rv = client.get(f"/world/{a_location.id}")
        assert b"+ Child Location" in rv.data

    def test_detail_no_add_child_for_non_locations(self, client):
        e = world_service.create_entry(type_="lore", name="The Old Magic")
        rv = client.get(f"/world/{e.id}")
        assert b"+ Child Location" not in rv.data

    def test_parent_chain_appears_in_hierarchy(self, client, a_location):
        child = world_service.create_entry(
            type_="location", name="Harbor District", parent_id=a_location.id)
        grandchild = world_service.create_entry(
            type_="location", name="The Salt Inn", parent_id=child.id)
        rv = client.get("/world/hierarchy")
        # All three names must appear; tree renders nested
        assert a_location.name.encode() in rv.data
        assert child.name.encode() in rv.data
        assert grandchild.name.encode() in rv.data
