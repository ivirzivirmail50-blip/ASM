"""Tests for v7.3 — Floating Quick Capture (Deep Writing Experience).

Covers:
  - JS module shipped at static/js/quick_capture.js
  - base.html includes the script
  - polish.css has qc-* classes + FAB styles
  - Quick capture API supports all 4 types (note/chapter/journal/snippet)
  - Title-optional: body alone is enough
  - Empty body returns 400
  - Unknown type returns 400
  - Ctrl+Shift+N hotkey is referenced in JS
  - FAB element markup exists
  - ESC closes composer (logic check)
"""
from __future__ import annotations

import pytest


@pytest.fixture
def app_v73():
    from app import create_app
    app = create_app()
    yield app


@pytest.fixture
def client(app_v73):
    return app_v73.test_client()


# ---------------------------------------------------------------- route shape


def test_v73_qc_module_shipped(app_v73):
    from pathlib import Path
    p = Path(app_v73.root_path) / "static" / "js" / "quick_capture.js"
    assert p.exists(), "quick_capture.js not shipped"
    src = p.read_text()
    # Hotkey wired
    assert '"n"' in src.lower() or "'n'" in src.lower()
    assert "Ctrl+Shift+N" in src or "Shift" in src
    # 4 type tabs
    for t in ("note", "chapter", "journal", "snippet"):
        assert f'data-type="{t}"' in src
    # Reuses the existing endpoint
    assert "/quick-capture/api/capture" in src
    # FAB present
    assert "qc-fab" in src
    # Composer shell
    assert "qc-shell" in src
    assert "qc-modal" in src


def test_v73_qc_script_in_base_html(app_v73, client):
    r = client.get("/")
    body = r.data.decode()
    assert "quick_capture.js" in body
    # Sprite is loaded on every page (for SVG icons in composer)
    assert 'id="i-zap"' in body  # one of the icons used by composer
    assert 'id="i-bulb"' in body  # used as FAB icon if present


def test_v73_qc_polish_css_layer(app_v73):
    from pathlib import Path
    css = (Path(app_v73.root_path) / "static" / "css" / "polish.css").read_text()
    for cls in (".qc-fab", ".qc-shell", ".qc-backdrop", ".qc-modal",
                ".qc-header", ".qc-types", ".qc-type", ".qc-body",
                ".qc-footer", ".qc-close"):
        assert cls in css
    # Body scroll lock class
    assert "body.qc-lock" in css
    # Reduced motion rule
    assert "prefers-reduced-motion" in css


# ---------------------------------------------------------------- API behavior


def test_v73_qc_capture_note(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "note", "title": "Test", "body": "Hello",
                          "category": "idea"})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert j["type"] == "note"
    assert "id" in j
    assert j["url"] == "/notes/"


def test_v73_qc_capture_chapter(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "chapter", "title": "Quick Chapter",
                          "body": "It was a dark and stormy night."})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert j["type"] == "chapter"
    assert j["url"].startswith("/chapters/")


def test_v73_qc_capture_journal(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "journal", "body": "Struggling today.",
                          "mood": "struggling"})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert j["type"] == "journal"


def test_v73_qc_capture_snippet(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "snippet", "title": "Good line",
                          "body": "The night was young, the road was long."})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert j["type"] == "snippet"


def test_v73_qc_body_only_works(client):
    """Title is optional; body alone should suffice."""
    r = client.post("/quick-capture/api/capture",
                    json={"type": "note", "body": "Just a stray thought."})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True


def test_v73_qc_empty_body_rejected(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "note", "title": "", "body": ""})
    assert r.status_code == 400
    j = r.get_json()
    assert j["ok"] is False


def test_v73_qc_unknown_type_rejected(client):
    r = client.post("/quick-capture/api/capture",
                    json={"type": "wildcard", "body": "nope"})
    assert r.status_code == 400
    j = r.get_json()
    assert j["ok"] is False


# ---------------------------------------------------------------- composer flow


def test_v73_qc_module_esc_handler(app_v73):
    """The JS module should reference Escape key for closing the composer."""
    from pathlib import Path
    src = (Path(app_v73.root_path) / "static" / "js" / "quick_capture.js").read_text()
    assert "Escape" in src


def test_v73_qc_module_ctrl_enter_shortcut(app_v73):
    """Ctrl+Enter to save should be wired up."""
    from pathlib import Path
    src = (Path(app_v73.root_path) / "static" / "js" / "quick_capture.js").read_text()
    assert "Enter" in src
    assert "ctrlKey" in src or "metaKey" in src


def test_v73_qc_module_type_toggle(app_v73):
    """Clicking a type tab toggles the active class and shows/hides contextual options."""
    from pathlib import Path
    src = (Path(app_v73.root_path) / "static" / "js" / "quick_capture.js").read_text()
    assert "active" in src
    assert "qcCategoryWrap" in src or "qcCategory" in src
    assert "qcMoodWrap" in src or "qcMood" in src


def test_v73_qc_module_only_one_instance(app_v73):
    """The module guards against double-initialization."""
    from pathlib import Path
    src = (Path(app_v73.root_path) / "static" / "js" / "quick_capture.js").read_text()
    assert "window.__asmQuickCapture" in src
