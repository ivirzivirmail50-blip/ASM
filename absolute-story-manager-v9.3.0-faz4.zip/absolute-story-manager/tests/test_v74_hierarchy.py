"""v7.4 — Hierarchy + reparenting tests."""
import pytest

from core.errors import NotFoundError, ValidationError
from services import world_service


def test_hierarchy_with_descendants():
    """get_hierarchy should compute depth, descendant_count, breadcrumb."""
    a = world_service.create_entry(type_="location", name="Planet A")
    b = world_service.create_entry(type_="location", name="City B",
                                    parent_id=a.id)
    c = world_service.create_entry(type_="location", name="Building C",
                                    parent_id=b.id)
    tree = world_service.get_hierarchy(type_="location")
    assert len(tree) == 1, "Should have one root"
    root = tree[0]
    assert root["entry"].id == a.id
    assert root["depth"] == 0
    assert root["descendant_count"] == 2, "A should have 2 descendants (B, C)"
    assert root["breadcrumb"] == ["Planet A"]
    assert len(root["children"]) == 1
    b_node = root["children"][0]
    assert b_node["depth"] == 1
    assert b_node["descendant_count"] == 1
    assert b_node["breadcrumb"] == ["Planet A", "City B"]
    c_node = b_node["children"][0]
    assert c_node["depth"] == 2
    assert c_node["descendant_count"] == 0
    assert c_node["breadcrumb"] == ["Planet A", "City B", "Building C"]


def test_list_possible_parents_excludes_self_and_descendants():
    """When editing an entry, it AND its descendants should be excluded as
    candidate parents (otherwise a cycle would be created)."""
    a = world_service.create_entry(type_="location", name="A")
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a.id)
    c = world_service.create_entry(type_="location", name="C",
                                    parent_id=b.id)
    # Editing A: A's descendants are B and C — all three should be excluded
    cand = world_service.list_possible_parents(entry_id=a.id, type_="location")
    ids = [c["id"] for c in cand]
    assert a.id not in ids, "Should not list entry itself as candidate parent"
    assert b.id not in ids, "Should not list descendant as candidate parent (cycle)"
    assert c.id not in ids, "Should not list descendant as candidate parent (cycle)"
    # Editing B: candidates should exclude B AND C (descendant of B), but include A
    cand = world_service.list_possible_parents(entry_id=b.id, type_="location")
    ids = [c["id"] for c in cand]
    assert b.id not in ids
    assert c.id not in ids, "Should not list descendant as candidate parent (would create cycle)"
    assert a.id in ids
    # Editing C (leaf): only C itself should be excluded; A and B available
    cand = world_service.list_possible_parents(entry_id=c.id, type_="location")
    ids = [c["id"] for c in cand]
    assert c.id not in ids
    assert a.id in ids
    assert b.id in ids


def test_reparent_entry_valid():
    """Reparent should move an entry under a new parent."""
    a = world_service.create_entry(type_="location", name="A")
    b = world_service.create_entry(type_="location", name="B")
    c = world_service.create_entry(type_="location", name="C")
    # Move B under A
    e = world_service.reparent_entry(b.id, a.id)
    assert e.parent_id == a.id
    # Verify in tree
    tree = world_service.get_hierarchy(type_="location")
    # Two roots: A and C (B is now under A)
    roots = [n["entry"].id for n in tree]
    assert set(roots) == {a.id, c.id}


def test_reparent_entry_to_root():
    """Reparent with None should move entry to top-level."""
    a = world_service.create_entry(type_="location", name="A")
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a.id)
    e = world_service.reparent_entry(b.id, None)
    assert e.parent_id is None


def test_reparent_entry_self_loop_rejected():
    """Cannot make entry its own parent."""
    a = world_service.create_entry(type_="location", name="A")
    with pytest.raises(ValidationError):
        world_service.reparent_entry(a.id, a.id)


def test_reparent_entry_cycle_rejected():
    """Cannot move an entry under its own descendant."""
    a = world_service.create_entry(type_="location", name="A")
    b = world_service.create_entry(type_="location", name="B",
                                    parent_id=a.id)
    c = world_service.create_entry(type_="location", name="C",
                                    parent_id=b.id)
    # Try to move A under C — should fail (cycle)
    with pytest.raises(ValidationError):
        world_service.reparent_entry(a.id, c.id)


def test_reparent_entry_type_mismatch_rejected():
    """Parent must be same type as entry."""
    a = world_service.create_entry(type_="location", name="Loc")
    f = world_service.create_entry(type_="faction", name="Faction")
    with pytest.raises(ValidationError):
        world_service.reparent_entry(f.id, a.id)


def test_reparent_entry_not_found():
    """Reparent on non-existent entry should raise NotFoundError."""
    with pytest.raises(NotFoundError):
        world_service.reparent_entry("nonexistent-id", None)


def test_reparent_entry_parent_not_found():
    """Reparent with non-existent parent should raise NotFoundError."""
    a = world_service.create_entry(type_="location", name="A")
    with pytest.raises(NotFoundError):
        world_service.reparent_entry(a.id, "nonexistent-parent-id")


def test_hierarchy_empty_type_returns_empty():
    """Hierarchy for a type with no entries should be empty list."""
    tree = world_service.get_hierarchy(type_="nonexistent_type")
    assert tree == []


def test_hierarchy_supports_other_types():
    """Hierarchy should work for any type, not just 'location'."""
    f1 = world_service.create_entry(type_="faction", name="Main Guild")
    f2 = world_service.create_entry(type_="faction", name="Sub Guild",
                                     parent_id=f1.id)
    tree = world_service.get_hierarchy(type_="faction")
    assert len(tree) == 1
    assert tree[0]["entry"].id == f1.id
    assert len(tree[0]["children"]) == 1
    assert tree[0]["children"][0]["entry"].id == f2.id


def test_list_possible_parents_empty_returns_empty():
    """If no entries of that type, candidates should be empty list."""
    cand = world_service.list_possible_parents(entry_id=None,
                                                type_="nonexistent_type")
    assert cand == []


def test_list_possible_parents_includes_breadcrumb():
    """Each candidate should include a breadcrumb path."""
    a = world_service.create_entry(type_="location", name="Alpha")
    b = world_service.create_entry(type_="location", name="Beta",
                                    parent_id=a.id)
    cand = world_service.list_possible_parents(entry_id=None,
                                                type_="location")
    # Find Beta in candidates
    beta = next(c for c in cand if c["id"] == b.id)
    assert "breadcrumb" in beta
    assert "Alpha" in beta["breadcrumb"]
    assert "Beta" in beta["breadcrumb"]
    assert "›" in beta["breadcrumb"]
