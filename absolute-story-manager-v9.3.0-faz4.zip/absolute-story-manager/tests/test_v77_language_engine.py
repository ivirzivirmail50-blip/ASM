"""v7.7 tests — Turkish Language Engine (language-aware analysis).

RESEARCH FINDING: every analyzer was English-centric, so a Turkish
manuscript got English analysis:
  * lint repeated-words regex ``\\b[a-z]{3,}\\b`` — ASCII-only → Turkish
    words with ç/ğ/ı/ö/ş/ü were INVISIBLE ("gölge" ×5 in one paragraph:
    zero findings)
  * pacing tension dictionary English-only → Turkish tension curve flat 0
  * word-freq stopwords English-only → ve/bir/bu/da/de dominate reports
  * spellcheck ~1000-word English list → every Turkish word "misspelled"
"""
import pytest

# ------------------------------------------------------------ lang_service


def _tr_paragraph(repeats=5):
    return "Gölge " * repeats + "kılıç ürkütücü çığlık."


class TestDetectLanguage:
    def test_turkish_diacritics_detected(self):
        from services.lang_service import detect_language
        assert detect_language("Gölge ürkütücüydü ve Aylin kılıcını çekti.") == "tr"

    def test_english_detected(self):
        from services.lang_service import detect_language
        assert detect_language("The shadow was terrifying and she drew her sword quickly.") == "en"

    def test_plain_turkish_function_words(self):
        # No diacritics at all — function words must still win
        from services.lang_service import detect_language
        assert detect_language("bir bu ve için ile gibi ama sonra") == "tr"

    def test_english_function_words(self):
        from services.lang_service import detect_language
        assert detect_language("It was a dark and stormy night in the old house.") == "en"

    def test_ascii_i_is_not_turkish(self):
        # REGRESSION: "İ".lower() decomposes to "i"+U+0307 in Python, which
        # previously made plain ASCII "i" count as a Turkish letter →
        # English sentences with ≥2 i's were detected as Turkish!
        from services.lang_service import detect_language
        assert detect_language("It is his will to win in spring.") == "en"

    def test_empty_defaults_english(self):
        from services.lang_service import detect_language
        assert detect_language("") == "en"

    def test_resolve_language_explicit_override(self):
        from services.lang_service import resolve_language
        assert resolve_language("The shadow was terrifying.", "tr") == "tr"
        assert resolve_language("Gölge ürkütücüydü.", "en") == "en"
        assert resolve_language("Gölge ürkütücüydü.", "auto") == "tr"
        assert resolve_language("Gölge ürkütücüydü.", None) == "tr"
        assert resolve_language("anything", "bogus") in ("tr", "en")


class TestTokenizer:
    def test_turkish_words_preserved(self):
        from services.lang_service import tokenize_words
        tokens = tokenize_words("Aylin'in kılıcı gölgede parıldadı")
        assert tokens == ["Aylin", "kılıcı", "gölgede", "parıldadı"]

    def test_english_words_unchanged(self):
        from services.lang_service import tokenize_words
        assert tokenize_words("she drew her sword quickly") == [
            "she", "drew", "her", "sword", "quickly"]


class TestPerLanguageResources:
    def test_turkish_stopwords(self):
        from services.lang_service import stopwords_for
        stops = stopwords_for("tr")
        assert "ve" in stops and "bir" in stops and "bu" in stops
        assert "kılıç" not in stops

    def test_english_stopwords(self):
        from services.lang_service import stopwords_for
        stops = stopwords_for("en")
        assert "the" in stops and "was" in stops
        assert "sword" not in stops

    def test_turkish_tension_words(self):
        from services.lang_service import tension_words_for
        tr = tension_words_for("tr")
        assert "kılıç" in tr and "korku" in tr and "kaç" in tr
        assert "fight" not in tr

    def test_turkish_adverbs(self):
        from services.lang_service import adverbs_in
        hits = adverbs_in(["sessizce", "hızlıca", "ve", "kılıç"], "tr")
        assert hits == ["sessizce", "hızlıca"]

    def test_english_adverb_suffix(self):
        from services.lang_service import adverbs_in
        assert adverbs_in(["quickly", "family", "ran"], "en") == ["quickly"]

    def test_turkish_passive(self):
        from services.lang_service import passive_hits
        hits = passive_hits("Mektup yazıldı ve kapı açıldı.", "tr")
        assert len(hits) == 2

    def test_english_passive(self):
        from services.lang_service import passive_hits
        assert len(passive_hits("The door was opened and the letter was written.", "en")) == 2


# --------------------------------------------------------------- lint


class TestLintTurkish:
    """The headline bug: repeated Turkish words were invisible."""

    def test_repeated_turkish_word_detected(self):
        from services.lint_service import _check_repeated_words
        class FakeCh:
            id, title = "c1", "Test"
        findings = _check_repeated_words(FakeCh, _tr_paragraph(5), lang="tr")
        assert findings, "repeated Turkish word 'gölge' must be flagged"
        assert findings[0]["type"] == "repeated_word"
        assert "gölge" in findings[0]["message"]

    def test_turkish_stopwords_not_flagged(self):
        from services.lint_service import _check_repeated_words
        class FakeCh:
            id, title = "c1", "Test"
        # 've' repeated — a stopword, must NOT be flagged
        text = "ve " * 6 + "kılıç gölge."
        assert _check_repeated_words(FakeCh, text, lang="tr") == []

    def test_turkish_adverb_overuse(self):
        from services.lint_service import _check_adverb_overuse
        class FakeCh:
            id, title = "c1", "Test"
        # ~4% Turkish adverbs in a 150-word paragraph → over threshold
        filler = "kılıç " * 70 + "gölge " * 50
        text = "sessizce hızlıca aniden derhal " + filler
        findings = _check_adverb_overuse(FakeCh, text, lang="tr")
        assert findings and findings[0]["type"] == "adverb_overuse"

    def test_turkish_passive_flagged(self):
        from services.lang_service import passive_hits
        text = " ".join(f"mektup{i} yazıldı." for i in range(6))
        assert len(passive_hits(text, "tr")) >= 6

    def test_turkish_dialogue_tags(self):
        from services.lint_service import _check_dialogue_tags
        class FakeCh:
            id, title = "c1", "Test"
        # 12 'dedi' tags → monotony finding with Turkish vocabulary
        text = " ".join('"Bir şey", dedi.' for _ in range(12))
        findings = _check_dialogue_tags(FakeCh, text, lang="tr")
        assert findings and findings[0]["type"] == "dialogue_tags"
        assert "dedi" in findings[0]["message"]

    def test_english_lint_still_works(self):
        from services.lint_service import _check_repeated_words
        class FakeCh:
            id, title = "c1", "Test"
        text = "shadow " * 5 + "blade scream."
        findings = _check_repeated_words(FakeCh, text, lang="en")
        assert findings and "shadow" in findings[0]["message"]


# --------------------------------------------------------------- pacing


class TestPacingTurkish:
    def test_tension_score_nonzero_for_turkish(self):
        from services.pacing_service import _analyze_chapter
        tr_tense = ("Kılıç korkusu ve savaş. Kaç, kaç, kaç! Kan ve ateş. " * 8)
        result = _analyze_chapter(tr_tense, lang="tr")
        assert result["tension_score"] > 0, \
            "Turkish tension words must produce a non-flat curve"

    def test_english_tension_unchanged(self):
        from services.pacing_service import _analyze_chapter
        en_tense = ("Blood and fire! Fight, flee, escape! Sword and death. " * 8)
        result = _analyze_chapter(en_tense, lang="en")
        assert result["tension_score"] > 0

    def test_turkish_dialogue_with_typographic_quotes(self):
        from services.pacing_service import _analyze_chapter
        text = "Ali \u201cbugün gidelim\u201d dedi ve \u201ctamam\u201d cevabını aldı. " * 5
        result = _analyze_chapter(text, lang="tr")
        assert result["dialogue_pct"] > 0


# ------------------------------------------------------------ word freq


class TestWordFreqTurkish:
    def test_tokenizer_turkish_words(self):
        from services.word_freq_service import _tokenize
        tokens = _tokenize("gölge kılıç ürkütücü şimşek")
        assert tokens == ["gölge", "kılıç", "ürkütücü", "şimşek"]

    def test_turkish_stopwords_filtered_in_top_words(self):
        from services.lang_service import stopwords_for
        # the analysis path uses stopwords_for(lang); direct contract test
        stops = stopwords_for("tr")
        for w in ("ve", "bir", "bu", "için", "gibi", "kadar"):
            assert w in stops

    def test_phrases_turkish(self):
        from services.word_freq_service import _extract_phrases
        phrases = _extract_phrases("kılıç gölge kılıç gölge", 2)
        assert "kılıç gölge" in phrases


# ------------------------------------------------------------- spellcheck


class TestSpellcheckTurkish:
    def test_turkish_text_skips_english_dictionary(self, fresh_db, app):
        """Turkish chapters must not flag every word against the English list."""
        from core.db import write_transaction
        from models.chapter import Chapter
        from services.spellcheck_service import check_chapter
        tr_body = "Gölge ürkütücüydü ve Aylin kılıcını çekti. Kapı sessizce açıldı."
        with write_transaction() as s:
            ch = Chapter(id="tr-ch", project_id="default", title="Türkçe Bölüm",
                         content=tr_body, word_count=len(tr_body.split()))
            s.add(ch)
        result = check_chapter("tr-ch")
        # English-dictionary false positives must be gone; with no custom
        # dictionary and no glossary, a clean Turkish chapter flags nothing
        assert result["flagged"] == [], \
            f"Turkish words wrongly flagged: {[f['word'] for f in result['flagged']]}"

    def test_english_still_checked(self, fresh_db, app):
        from core.db import write_transaction
        from models.chapter import Chapter
        from services.spellcheck_service import check_chapter
        en_body = "The quick brown fox jumpz over the lazy dog."
        with write_transaction() as s:
            ch = Chapter(id="en-ch", project_id="default", title="English Chapter",
                         content=en_body, word_count=len(en_body.split()))
            s.add(ch)
        result = check_chapter("en-ch")
        words = [f["word"] for f in result["flagged"]]
        assert "jumpz" in words


# ------------------------------------------------------------ settings UI


class TestAnalysisLanguageSetting:
    def test_settings_page_offers_language_choice(self, client):
        r = client.get("/settings/")
        assert r.status_code == 200
        body = r.data.decode()
        assert 'name="analysis_language"' in body
        assert 'value="tr"' in body
        assert 'value="auto"' in body

    def test_save_valid_choice(self, client):
        r = client.post("/settings/save",
                        json={"analysis_language": "tr"},
                        content_type="application/json")
        assert r.status_code == 200
        from core.db import read_session
        from models.settings import Setting
        with read_session() as s:
            assert Setting.get(s, "analysis_language") == "tr"

    def test_save_rejects_unknown_choice(self, client):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "analysis_language", "auto")
        r = client.post("/settings/save",
                        json={"analysis_language": "klingon"},
                        content_type="application/json")
        assert r.status_code == 200  # save succeeds but ignores bad value
        from core.db import read_session
        with read_session() as s:
            assert Setting.get(s, "analysis_language") == "auto"

    def test_lint_respects_pinned_language(self, fresh_db, app):
        """Explicit analysis_language=tr forces Turkish analyzers even on
        diacritic-free Turkish text."""
        from core.db import write_transaction
        from models.chapter import Chapter
        from models.settings import Setting
        from services.lint_service import lint_all
        # 'aksam' has no diacritics; repeated 6× — Turkish stopword check
        # doesn't know it, so it must be flagged as repeated word
        body = "aksam " * 6 + "kapı pencere."
        with write_transaction() as s:
            Setting.set(s, "analysis_language", "tr")
            s.add(Chapter(id="pin-ch", project_id="default", title="Pinned",
                          content=body, word_count=12))
        result = lint_all()
        repeated = [f for f in result["findings"] if f["type"] == "repeated_word"]
        assert repeated, "pinned Turkish language must analyse the chapter"
