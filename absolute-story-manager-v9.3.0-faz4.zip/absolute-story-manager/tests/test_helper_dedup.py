"""M-05 — helper dedup tests (v9.1.0).

Acceptance criteria from the plan:
  - rg duplicate count is ZERO (single source)
  - markdown output stays byte-identical (golden tests)
  - the three historical safe_filename behaviors are preserved exactly
  - JS guard tests keep passing (single asmFetch/escapeHtml in core.js)
"""
from __future__ import annotations

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent

from services._common import (  # noqa: E402
    SAFE_FILENAME_EXPORT,
    SAFE_FILENAME_SCRIV,
    SAFE_FILENAME_SLUG,
    md_to_html,
    md_to_html_minimal,
    safe_filename,
)

# ---------------------------------------------------------------------------
# Golden behavior: the three historical _safe_filename variants
# ---------------------------------------------------------------------------

class TestSafeFilenameGolden:

    @pytest.mark.parametrize(("raw", "expected"), [
        ("My Great Novel", "my-great-novel"),           # slug: lower + hyphen
        ("  Spaces  and   Dashes ", "spaces-and-dashes"),
        ("?!?", "manuscript"),                          # post-truncate fallback
        ("", "manuscript"),                             # input fallback
        (None, "manuscript"),
        ("Ünal & Karaca: İkinci Kitap", "ünal-karaca-i̇kinci-kitap"),  # \w is UNICODE: İ/Ü survive
        ("A" * 100, "a" * 60),                          # truncation at 60
    ])
    def test_slug_variant_matches_old_compile_copy(self, raw, expected):
        assert safe_filename(raw, **SAFE_FILENAME_SLUG) == expected

    @pytest.mark.parametrize(("raw", "expected"), [
        ("My Scriv Project", "My_Scriv_Project"),       # underscores, keeps case
        ("?!?", "untitled"),
        ("", "untitled"),
        ("A" * 100, "A" * 60),
    ])
    def test_scriv_variant_matches_old_scrivener_copy(self, raw, expected):
        assert safe_filename(raw, **SAFE_FILENAME_SCRIV) == expected

    @pytest.mark.parametrize(("raw", "expected"), [
        # ':' and '!' are each disallowed; runs collapse to one '_' (+).
        ("Report: Final!", "Report_ Final_"),
        ("?!?", "_"),            # one disallowed RUN -> single underscore
        ("", "export"),
        (None, "export"),
        ("B" * 200, "B" * 180),   # truncation at 180
        ("dotted.name.v2", "dotted.name.v2"),  # dots preserved
    ])
    def test_export_variant_matches_old_export_copy(self, raw, expected):
        assert safe_filename(raw, **SAFE_FILENAME_EXPORT) == expected


# ---------------------------------------------------------------------------
# Golden behavior: both markdown converters
# ---------------------------------------------------------------------------

class TestMarkdownGolden:

    def test_md_to_html_uses_markdown_lib(self):
        # Former export copy: markdown package with extra + nl2br.
        out = md_to_html("Hello **world**\n\nSecond para")
        assert "<strong>world</strong>" in out
        assert out.count("<p>") == 2

    def test_md_to_html_minimal_matches_old_compile_copy(self):
        # Former compile copy: escape first, then ONE bold replacement and
        # ONE italic replacement (count=1 — a quirk, but the historical
        # golden output; preserved byte-identically).
        assert md_to_html_minimal("") == ""
        out = md_to_html_minimal("**bold** and *italic*\nline2")
        assert out == "<p><strong>bold<em>* and *italic*<br>line2</p>"
        # HTML in source text is ESCAPED (unlike the markdown lib):
        out2 = md_to_html_minimal("<script>x</script>")
        assert "&lt;script&gt;" in out2
        assert "<script>" not in out2
        # Plain text is the common, well-formed path:
        assert md_to_html_minimal("plain text only") == "<p>plain text only</p>"


# ---------------------------------------------------------------------------
# Single-source guards (rg-equivalent scans)
# ---------------------------------------------------------------------------

class TestSingleSource:

    def _scan(self, pattern: str, root: str = None) -> list[Path]:
        import re
        rx = re.compile(pattern, re.MULTILINE)
        hits = []
        base = PROJECT_ROOT / (root or "")
        for py in base.rglob("*.py"):
            if (".venv" in py.parts or "site-packages" in py.parts
                    or "tests" in py.parts):
                # tests/ excluded: this file itself contains the patterns.
                continue
            try:
                src = py.read_text(encoding="utf-8")
            except OSError:
                continue
            # Strip # comments so explanatory notes don't trigger guards.
            stripped = "\n".join(
                ln.split("#", 1)[0] if "#" in ln else ln
                for ln in src.splitlines()
            )
            if rx.search(stripped):
                hits.append(py)
        return hits

    def test_only_one_safe_filename_definition(self):
        hits = self._scan(r"^def safe_filename\(", "services")
        assert hits == [PROJECT_ROOT / "services" / "_common.py"]

    def test_no_local_md_to_html_copies_in_services(self):
        # Only delegating wrappers may reference the name; no independent
        # implementations (markdown.markdown call must exist only in _common).
        hits = self._scan(r"markdown\.markdown\(", "services")
        assert hits == [PROJECT_ROOT / "services" / "_common.py"]

    def test_no_dunder_import_smell_left(self):
        hits = self._scan(r'__import__\("(?:re|time|threading|sqlalchemy|docx)"\)')
        assert hits == []

    def test_ai_service_has_normal_re_import(self):
        src = (PROJECT_ROOT / "services" / "ai_service.py").read_text(
            encoding="utf-8")
        stripped = "\n".join(
            ln.split("#", 1)[0] for ln in src.splitlines()
        )
        assert "import re" in stripped
        assert '__import__("re")' not in stripped


# ---------------------------------------------------------------------------
# Frontend single-source guards
# ---------------------------------------------------------------------------

class TestFrontendSingleSource:

    def _js_files(self):
        return [
            p for p in (PROJECT_ROOT / "static" / "js").glob("*.js")
            if p.name != "core.js"
        ]

    def test_asm_fetch_defined_only_in_core(self):
        offenders = [
            p for p in self._js_files()
            if "function asmFetch" in p.read_text(encoding="utf-8")
        ]
        assert offenders == []

    def test_escape_html_defined_only_in_core(self):
        offenders = [
            p for p in self._js_files()
            if "function escapeHtml" in p.read_text(encoding="utf-8")
        ]
        assert offenders == []

    def test_core_js_is_valid_and_complete(self):
        src = (PROJECT_ROOT / "static" / "js" / "core.js").read_text(
            encoding="utf-8")
        assert "window.asmFetch" in src
        assert "window.escapeHtml" in src
        # No invisible characters.
        assert "\u200b" not in src

    def test_base_html_loads_core_before_app(self):
        src = (PROJECT_ROOT / "templates" / "base.html").read_text(
            encoding="utf-8")
        core_idx = src.find("js/core.js")
        app_idx = src.find("js/app.js")
        assert core_idx != -1 and app_idx != -1
        assert core_idx < app_idx

    def test_reading_mode_uses_core_contract(self):
        src = (PROJECT_ROOT / "static" / "js" / "reading_mode.js").read_text(
            encoding="utf-8")
        # The migrated call site checks resp.res.ok (modern contract).
        assert "resp.res.ok" in src
        assert "resp.ok ||" not in src.replace("resp.res.ok", "")

    @pytest.mark.parametrize("js", [
        "static/js/core.js", "static/js/app.js",
        "static/js/reading_mode.js", "static/js/command_palette.js",
    ], ids=lambda p: p.split("/")[-1])
    def test_js_syntax_valid(self, js):
        import subprocess
        import sys
        r = subprocess.run(
            ["node", "--check", str(PROJECT_ROOT / js)],
            capture_output=True, text=True, timeout=30,
        )
        assert r.returncode == 0, f"{js}: {r.stderr}"
