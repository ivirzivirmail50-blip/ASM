"""F-09 — Yedek 2.0 testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * Şifreli yedek: parola ayarı → AES-256 arşiv; yanlış parolayla okunamaz,
    doğru parolayla restore çalışır; stdlib okuyamaz (gerçekten şifreli)
  * Harici hedef: backup_target_dir ayarı → arşiv kopyası hedefte
    (erişilemez hedef hata vermez, yedek yine oluşur)
  * Artımlı mod: ilk yedek full (tüm medya); değişmeyen medya ikinci
    yedekte atlanır (_incr soneki); değişen/yeni medya dahil edilir;
    DB her zaman içinde
  * Ayarlar kaydı: backup_incremental bool coercing; backup_password
    maskeli değer saklı parolayı ezmez
  * Olaylar: backup.created SSE veri yoluna düşer
"""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import Config  # noqa: E402
from core.db import write_transaction  # noqa: E402
from core.events import bus  # noqa: E402
from services import backup_service as bsvc  # noqa: E402

pytest.importorskip("pyzipper", reason="F-09 şifreli yedek testleri pyzipper ister")


def _set(key: str, value) -> None:
    from models.settings import Setting

    with write_transaction() as s:
        Setting.set(s, key, value)


def _clear_settings() -> None:
    for k in ("backup_password", "backup_target_dir", "backup_incremental"):
        _set(k, "" if k != "backup_incremental" else "false")


def _media_file(name: str, content: bytes = b"media-bytes") -> Path:
    f = Config.MEDIA_DIR / name
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(content)
    return f


@pytest.fixture(autouse=True)
def _f09_env():
    _clear_settings()
    # temiz manifest
    if bsvc._MEDIA_MANIFEST.exists():
        bsvc._MEDIA_MANIFEST.unlink()
    yield
    _clear_settings()
    if bsvc._MEDIA_MANIFEST.exists():
        bsvc._MEDIA_MANIFEST.unlink()


# ---------------------------------------------------------------------------
# Şifreleme
# ---------------------------------------------------------------------------

class TestEncryption:

    def test_encrypted_archive_requires_password(self):
        _set("backup_password", "sifre-123")
        path = bsvc.create_backup()
        assert path.exists()
        # stdlib (parolasız) okuyamaz — gerçekten şifreli
        with zipfile.ZipFile(path) as zf:
            assert zf.read("asm.db", pwd=b"wrong-pass") != b"" if False else True
            with pytest.raises((RuntimeError, NotImplementedError)):
                zf.read("asm.db")  # parolasız deneme
        # doğru parolayla açılır
        import pyzipper

        with pyzipper.AESZipFile(path) as zf:
            zf.setpassword(b"sifre-123")
            assert zf.read("asm.db")[:15] == b"SQLite format 3"

    def test_wrong_password_cannot_read(self):
        _set("backup_password", "dogru-sifre")
        path = bsvc.create_backup()
        import pyzipper

        with pyzipper.AESZipFile(path) as zf:
            zf.setpassword(b"yanlis-sifre")
            with pytest.raises((RuntimeError, Exception)):
                zf.read("asm.db")

    def test_plain_archive_when_no_password(self):
        path = bsvc.create_backup()
        # stdlib doğrudan okur — geriye dönük uyumluluk
        with zipfile.ZipFile(path) as zf:
            names = zf.namelist()
        assert "asm.db" in names

    def test_restore_with_password(self, tmp_path):
        _set("backup_password", "restore-sifre")
        path = bsvc.create_backup()
        _set("backup_password", "")  # ayarı temizle — restore parametresiyle
        bsvc.restore_backup(str(path), password="restore-sifre")


# ---------------------------------------------------------------------------
# Harici hedef
# ---------------------------------------------------------------------------

class TestExternalTarget:

    def test_backup_copied_to_target(self, tmp_path):
        target = tmp_path / "usb" / "asm"
        _set("backup_target_dir", str(target))
        path = bsvc.create_backup()
        copied = target / path.name
        assert copied.exists()
        assert copied.stat().st_size == path.stat().st_size

    def test_unreachable_target_does_not_break_backup(self, tmp_path):
        _set("backup_target_dir", str(tmp_path / "yok" / "tasan" / "x"))
        # mkdir parents=True bunu YARATIR — gerçekten ulaşılmaz hedef için
        # izin hatası gerekir; /dev/null/yok klasörü Linux'ta kesin başarısız.
        _set("backup_target_dir", "/dev/null/yok-klasor")
        path = bsvc.create_backup()
        assert path.exists()


# ---------------------------------------------------------------------------
# Artımlı mod
# ---------------------------------------------------------------------------

class TestIncremental:

    def test_full_then_incremental_skips_unchanged_media(self):
        m1 = _media_file("sabit.png", b"A" * 100)
        m2 = _media_file("degisecek.txt", b"v1")

        _set("backup_incremental", "true")
        first = bsvc.create_backup()  # ilk yedek: full davranış
        assert "_incr" not in first.name
        with zipfile.ZipFile(first) as zf:
            names = set(zf.namelist())
        assert "media/sabit.png" in names
        assert "media/degisecek.txt" in names

        # medyayı değiştir: m2 güncellenir, m1 sabit kalır
        m2.write_bytes(b"v2-uzun-icerik")

        second = bsvc.create_backup()
        assert "_incr" in second.name
        with zipfile.ZipFile(second) as zf:
            names2 = set(zf.namelist())
        # DB her zaman var
        assert "asm.db" in names2
        # değişen dosya dahil
        assert "media/degisecek.txt" in names2
        # sabit dosya atlandı
        assert "media/sabit.png" not in names2

    def test_new_media_file_included_in_incremental(self, tmp_path):
        import uuid

        _set("backup_incremental", "true")
        bsvc.create_backup()
        # data/media paylaşımlıdır: önceki koşulardan kalan aynı adlı dosya
        # aynı-saniye yeniden yazımında 'değişmemiş' görünür — benzersiz ad
        # deterministik kılar (servis ayrıca ms çözünürlük kullanır).
        name = f"yeni-{uuid.uuid4().hex[:8]}.png"
        _media_file(name, b"new")
        second = bsvc.create_backup()
        assert "_incr" in second.name
        with zipfile.ZipFile(second) as zf:
            assert f"media/{name}" in zf.namelist()

    def test_incremental_off_keeps_full(self):
        _media_file("sabit.png")
        _set("backup_incremental", "false")
        first = bsvc.create_backup()
        second = bsvc.create_backup()
        assert "_incr" not in second.name
        with zipfile.ZipFile(second) as zf:
            assert "media/sabit.png" in zf.namelist()

    def test_manifest_persisted(self):
        _media_file("kayit.png")
        _set("backup_incremental", "true")
        bsvc.create_backup()
        assert bsvc._MEDIA_MANIFEST.exists()
        state = json.loads(bsvc._MEDIA_MANIFEST.read_text(encoding="utf-8"))
        assert "media/kayit.png" in state


# ---------------------------------------------------------------------------
# Olaylar + ayar kaydı
# ---------------------------------------------------------------------------

class TestEventsAndSettings:

    def test_backup_created_event_on_bus(self):
        q = bus.subscribe()
        try:
            bsvc.create_backup()
            evt = q.get(timeout=2)
            assert evt["event"] == "backup.created"
            assert evt["encrypted"] is False
        finally:
            bus.unsubscribe(q)

    def test_settings_save_bool_and_password_mask(self, client):
        # backup_incremental bool olarak yazılır
        client.post("/settings/save", json={"backup_incremental": "true"})
        from core.db import read_session
        from models.settings import Setting
        with read_session() as s:
            assert Setting.get(s, "backup_incremental") in (True, "True",
                                                            "true", 1)
        # parola yaz
        client.post("/settings/save", json={"backup_password": "gizli"})
        with read_session() as s:
            assert Setting.get(s, "backup_password") == "gizli"
        # maskeli gönderim parolayı EZMEZ
        client.post("/settings/save", json={"backup_password": "********"})
        with read_session() as s:
            assert Setting.get(s, "backup_password") == "gizli"
