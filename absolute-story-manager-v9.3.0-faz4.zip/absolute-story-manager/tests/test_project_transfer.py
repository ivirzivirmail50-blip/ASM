"""v7.5 — Full-fidelity project export/import round-trip tests.

The v7.4 bug: /settings/export-json never exported the project row (book
name, genre, target words, deadline, color) nor notes — so carrying a "full
data export" into a new version silently lost both. These tests pin the fix:
a complete round-trip must preserve books AND notes AND everything else.
"""
import json
from datetime import date, datetime, timezone

import pytest


@pytest.fixture
def rich_app(fresh_db):
    """App seeded with a fully-loaded book."""
    from app import create_app
    from core.db import current_session, write_transaction
    from models.chapter import Chapter
    from models.char_location_pin import CharacterLocationPin
    from models.character import Character
    from models.glossary import GlossaryEntry
    from models.journal import JournalEntry
    from models.note import Note
    from models.project import Project
    from models.scene import SceneCard
    from models.settings import Setting
    from models.world import WorldEntry

    with write_transaction() as s:
        s.add(Project(id="book1", name="Güneşin Kızı", subtitle="Bir Fantastik Roman",
                      genre="Fantasy", target_words=95000,
                      deadline=date(2027, 3, 1), color="#f59e0b"))
        # SQLAlchemy 2.x flushes mappers in name order (Chapter < Project),
        # so the parent must be flushed before children are added.
        s.flush()
        s.add(Chapter(id="ch1", project_id="book1", title="Birinci Bölüm",
                      content="Elara kapıyı açtı.", synopsis="Açılış",
                      status="draft", word_count=3, sort_order=0,
                      created_at=datetime(2026, 1, 1),
                      updated_at=datetime(2026, 1, 2)))
        s.add(Note(id="n1", project_id="book1",
                   title='Türkçe "alıntı" ve apostrof\'',
                   body="# Not\n\n- madde\n\nşğıöçü ✨",
                   category="idea", tags='["fantastik", "elara"]',
                   pinned=1, done=0, links="[]",
                   created_at=datetime(2026, 2, 1),
                   updated_at=datetime(2026, 2, 1)))
        s.add(Note(id="n2", project_id="book1", title="İkinci not",
                   body="gövde 2", category="todo", tags="[]",
                   pinned=0, done=1, links="[]",
                   created_at=datetime(2026, 2, 2),
                   updated_at=datetime(2026, 2, 2)))
        s.add(WorldEntry(id="w1", project_id="book1", type="location",
                         name="Aurelia", category="city",
                         description="Sisli liman şehri", content="# Aurelia",
                         parent_id=None,
                         created_at=datetime(2026, 1, 5),
                         updated_at=datetime(2026, 1, 5)))
        s.add(WorldEntry(id="w2", project_id="book1", type="location",
                         name="Kral Sarayı", category="landmark",
                         description="Aurelia'nın kalbi", parent_id="w1",
                         created_at=datetime(2026, 1, 6),
                         updated_at=datetime(2026, 1, 6)))
        s.add(JournalEntry(id="j1", project_id="book1", entry_date=date(2026, 2, 3),
                           mood="great", wins="1000 kelime",
                           notes="Bugün 1000 kelime yazdım",
                           created_at=datetime(2026, 2, 3)))
        s.add(SceneCard(id="sc1", project_id="book1", chapter_id="ch1",
                        title="Kapı sahnesi", summary="Elara kapıyı açar",
                        sort_order=0,
                        created_at=datetime(2026, 1, 3)))
        s.add(GlossaryEntry(id="g1", project_id="book1", term="Aurelia",
                            definition="Sisli liman şehri",
                            created_at=datetime(2026, 1, 7)))
        # v7.6 Story Atlas: a character pinned to a nested location.
        # (flush first: SQLAlchemy 2.x flushes mappers in NAME order, and
        #  CharacterLocationPin < WorldEntry alphabetically — without this
        #  flush the pins would be INSERTed before their FK parents.)
        s.add(Character(id="c1", project_id="book1", name="Elara",
                        role="protagonist",
                        created_at=datetime(2026, 1, 4),
                        updated_at=datetime(2026, 1, 4)))
        s.flush()
        s.add(CharacterLocationPin(
            id="pin1", project_id="book1", character_id="c1",
            location_id="w2", kind="current_residence",
            note="Sarayın kuzey kulesinde kalır",
            chapter_id=None, sort_order=0,
            created_at=datetime(2026, 2, 10)))
        s.add(CharacterLocationPin(
            id="pin2", project_id="book1", character_id="c1",
            location_id="w1", kind="origin", note=None,
            chapter_id=None, sort_order=0,
            created_at=datetime(2026, 2, 11)))
        Setting.set(s, "story_title", "Güneşin Kızı")
        Setting.set(s, "ai.api_key", "sk-SECRET-KEY")

    app = create_app()
    app.config["TESTING"] = True
    app.config["WTF_CSRF_ENABLED"] = False
    yield app


def _export(app):
    with app.test_client() as c:
        r = c.get("/settings/export-json")
        assert r.status_code == 200
        return json.loads(r.get_data(as_text=True))


def _import_raw(app, payload):
    """POST an import using the same code path the UI uses."""
    import io
    with app.test_client() as c:
        data = {"file": (io.BytesIO(json.dumps(payload, ensure_ascii=False).encode("utf-8")),
                         "backup.json")}
        r = c.post("/settings/import-json", data=data, content_type="multipart/form-data")
        return r


# ---- export contents -----------------------------------------------------------

def test_export_contains_project_book_metadata(rich_app):
    data = _export(rich_app)
    projects = data["projects"]
    assert any(p["id"] == "book1" and p["name"] == "Güneşin Kızı"
               and p["genre"] == "Fantasy" and p["target_words"] == 95000
               and p["color"] == "#f59e0b" for p in projects), \
        "book metadata (name/genre/target/color) missing from export"


def test_export_contains_notes(rich_app):
    data = _export(rich_app)
    notes = data["notes"]
    assert len(notes) == 2
    n1 = next(n for n in notes if n["id"] == "n1")
    assert n1["title"] == 'Türkçe "alıntı" ve apostrof\''
    assert "# Not" in n1["body"]
    assert n1["pinned"] == 1


def test_export_contains_all_content_tables(rich_app):
    data = _export(rich_app)
    for key in ("chapters", "world_entries", "journal_entries", "scenes",
                "glossary_entries", "projects", "notes",
                "character_location_pins"):
        assert key in data, f"export missing table: {key}"
    assert any(w["id"] == "w2" and w["parent_id"] == "w1" for w in data["world_entries"]), \
        "world hierarchy (parent_id) not exported"


def test_export_schema_version(rich_app):
    data = _export(rich_app)
    assert data["version"] == "asm-v7.5"


def test_export_never_leaks_api_key(rich_app):
    data = _export(rich_app)
    assert data["settings"].get("ai.api_key", "") == ""


def test_export_filename_contains_book_name(rich_app):
    with rich_app.test_client() as c:
        r = c.get("/settings/export-json")
        cd = r.headers.get("Content-Disposition", "")
        assert "G_ne_in_K_z_" in cd or "asm_project" in cd


# ---- round-trip -----------------------------------------------------------------

import tempfile
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def _empty_target_db():
    """Swap core.db onto a brand-new EMPTY database — simulates installing
    the next version on a fresh machine. Restores the original afterwards."""
    from sqlalchemy import create_engine, event
    from sqlalchemy.orm import scoped_session, sessionmaker

    import core.db
    from models import Base

    db_path = Path(tempfile.mkdtemp(prefix="asm-target-")) / "target.db"
    engine = create_engine(f"sqlite:///{db_path}", future=True)

    @event.listens_for(engine, "connect")
    def _prag(dbapi_conn, _rec):
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()

    factory = sessionmaker(bind=engine, expire_on_commit=False, future=True)
    SessionLocal = scoped_session(factory)
    old = (core.db.engine, core.db.SessionLocal, core.db.session_factory)
    core.db.engine = engine
    core.db.SessionLocal = SessionLocal
    core.db.session_factory = factory
    Base.metadata.create_all(engine)
    try:
        yield
    finally:
        SessionLocal.remove()
        core.db.engine, core.db.SessionLocal, core.db.session_factory = old
        engine.dispose()


def _fresh_target_app():
    """A brand-new app instance (simulates installing the next version)."""
    from app import create_app
    app = create_app()
    app.config["TESTING"] = True
    app.config["WTF_CSRF_ENABLED"] = False
    return app


def test_round_trip_preserves_book_and_notes(rich_app, fresh_db):
    payload = _export(rich_app)          # export from the SOURCE database
    target = _fresh_target_app()
    with _empty_target_db():             # genuine migration target
        r = _import_raw(target, payload)
        assert r.status_code == 200
        body = r.get_json()
        assert body["ok"] is True

        from core.db import current_session
        from models.note import Note
        from models.project import Project
        from models.world import WorldEntry

        with target.app_context():
            s = current_session()
            # BOOK NAME — the user's #1 complaint
            p = s.get(Project, "book1")
            assert p is not None, "project row was not imported"
            assert p.name == "Güneşin Kızı"
            assert p.genre == "Fantasy"
            assert p.target_words == 95000
            assert str(p.deadline) == "2027-03-01"
            assert p.color == "#f59e0b"
            # NOTES — the user's #2 complaint
            notes = s.query(Note).filter_by(project_id="book1").all()
            assert len(notes) == 2
            n1 = next(n for n in notes if n.id == "n1")
            assert n1.title == 'Türkçe "alıntı" ve apostrof\''
            assert "# Not" in n1.body
            assert n1.pinned == 1
            assert n1.tags == '["fantastik", "elara"]'
            # world hierarchy survives
            w2 = s.get(WorldEntry, "w2")
            assert w2.parent_id == "w1"


def test_round_trip_preserves_atlas_pins(rich_app, fresh_db):
    """v7.6 regression: Story Atlas pins must survive a full transfer.

    A pin links a character to a (nested) location — losing it on export
    would silently strip the atlas of every author placement.
    """
    payload = _export(rich_app)
    assert len(payload["character_location_pins"]) == 2
    target = _fresh_target_app()
    with _empty_target_db():
        r = _import_raw(target, payload)
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

        from core.db import current_session
        from models.char_location_pin import CharacterLocationPin

        with target.app_context():
            s = current_session()
            pins = s.query(CharacterLocationPin).filter_by(project_id="book1").all()
            assert len(pins) == 2, "atlas pins were lost in transfer"
            pin1 = next(p for p in pins if p.id == "pin1")
            assert pin1.character_id == "c1"
            assert pin1.location_id == "w2"      # nested location survives
            assert pin1.kind == "current_residence"
            assert pin1.note == "Sarayın kuzey kulesinde kalır"
            pin2 = next(p for p in pins if p.id == "pin2")
            assert pin2.kind == "origin"
            # idempotent re-import must not duplicate pins
            r2 = _import_raw(target, payload)
            assert r2.status_code == 200
            s2 = current_session()
            assert s2.query(CharacterLocationPin).filter_by(project_id="book1").count() == 2


def test_round_trip_import_is_idempotent(rich_app, fresh_db):
    payload = _export(rich_app)
    target = _fresh_target_app()
    with _empty_target_db():
        r1 = _import_raw(target, payload)
        assert r1.get_json()["ok"] is True
        r2 = _import_raw(target, payload)  # import the same file again
        assert r2.get_json()["ok"] is True
        from core.db import current_session
        from models.note import Note
        with target.app_context():
            s = current_session()
            assert s.query(Note).count() == 2, "re-import must not duplicate rows"


def test_import_never_blanks_stored_api_key(rich_app, fresh_db):
    payload = _export(rich_app)          # api_key stripped to ""
    target = _fresh_target_app()
    from core.db import current_session, write_transaction
    from models.settings import Setting
    with _empty_target_db():
        with target.app_context():
            with write_transaction() as s:
                Setting.set(s, "ai.api_key", "sk-EXISTING")
        _import_raw(target, payload)
        with target.app_context():
            s2 = current_session()
            assert Setting.get(s2, "ai.api_key") == "sk-EXISTING"


def test_import_legacy_v4_format(fresh_db):
    """Old asm-v4 files (singular 'project' key, no notes) still import."""
    from app import create_app
    legacy = {
        "version": "asm-v4",
        "settings": {"story_title": "Eski Hikaye"},
        "project": {"id": "oldbook", "name": "Eski Hikaye"},
        "chapters": [{"id": "oc1", "project_id": "oldbook", "title": "Eski Bölüm",
                      "content": "eski metin", "status": "draft", "word_count": 2,
                      "sort_order": 0}],
        "chapter_versions": [],
        "characters": [],
        "character_groups": [],
        "character_group_members": [],
        "character_relationships": [],
        "character_arcs": [],
        "plans": [],
        "plan_subtasks": [],
        "world_entries": [],
        "world_entry_versions": [],
        "world_relations": [],
    }
    target = create_app()
    target.config["TESTING"] = True
    with _empty_target_db():
        r = _import_raw(target, legacy)
        assert r.status_code == 200
        assert r.get_json()["ok"] is True
        from core.db import current_session
        from models.chapter import Chapter
        from models.project import Project
        with target.app_context():
            s = current_session()
            assert s.get(Project, "oldbook").name == "Eski Hikaye"
            assert s.get(Chapter, "oc1").title == "Eski Bölüm"


def test_import_skips_malformed_rows(rich_app, fresh_db):
    """One bad row must not abort the whole import."""
    payload = _export(rich_app)
    payload["notes"].append({"title": "kötü satır, id yok"})
    payload["notes"].append("tamamen yanlış tip")
    target = _fresh_target_app()
    with _empty_target_db():
        r = _import_raw(target, payload)
        assert r.status_code == 200
        assert r.get_json()["ok"] is True
        from core.db import current_session
        from models.note import Note
        with target.app_context():
            s = current_session()
            assert s.query(Note).count() == 2  # only the 2 good rows


def test_service_level_round_trip(rich_app, fresh_db):
    """Direct service round-trip with no HTTP layer."""
    from services import project_transfer_service as pts
    data = pts.export_all()
    summary = pts.export_summary(data)
    assert summary["projects"] == 2          # 'default' (conftest) + 'book1'
    assert summary["notes"] == 2
    assert summary["world_entries"] == 2

    target = _fresh_target_app()
    with _empty_target_db():
        with target.app_context():
            counts = pts.import_all(data)
            assert counts["projects"] == 2      # default + book1 on a blank DB
            assert counts["notes"] == 2
            assert counts["world_entries"] == 2
            # importing again creates nothing new
            counts2 = pts.import_all(data)
            assert counts2["projects"] == 0
            assert counts2["notes"] == 0
