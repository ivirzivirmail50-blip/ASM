"""ASM v7.0 Multi-Book Workspace tests — model metadata + auto-migration,
topbar switcher, story_title single source of truth, books hub, project CRUD
with metadata, dashboard writer hero, onboarding."""
import pytest


@pytest.fixture
def second_book(client):
    rv = client.post("/projects/new", json={
        "name": "The Ember Ship", "genre": "Fantasy",
        "target_words": 90000, "deadline": "2027-12-31",
        "color": "#22c55e",
    })
    data = rv.get_json()
    assert data["ok"] is True
    return data


class TestProjectModel:
    def test_new_columns_exist(self):
        from models.project import Project
        cols = {c.name for c in Project.__table__.columns}
        assert {"genre", "target_words", "deadline", "color"} <= cols

    def test_create_project_with_metadata(self, second_book):
        from core.db import read_session
        from models.project import Project
        with read_session() as s:
            p = s.get(Project, second_book["id"])
            assert p is not None
            assert p.name == "The Ember Ship"
            assert p.genre == "Fantasy"
            assert p.target_words == 90000
            assert p.color == "#22c55e"
            assert p.deadline is not None
            assert p.deadline.year == 2027 and p.deadline.month == 12

    def test_invalid_deadline_ignored(self, client):
        rv = client.post("/projects/new", json={
            "name": "Bad Date Book", "deadline": "not-a-date"})
        assert rv.get_json()["ok"] is True
        from core.db import read_session
        from models.project import Project
        with read_session() as s:
            p = s.query(Project).filter_by(name="Bad Date Book").first()
            assert p.deadline is None

    def test_invalid_target_words_ignored(self, client):
        rv = client.post("/projects/new", json={
            "name": "Bad Target Book", "target_words": "abc"})
        assert rv.get_json()["ok"] is True
        from core.db import read_session
        from models.project import Project
        with read_session() as s:
            p = s.query(Project).filter_by(name="Bad Target Book").first()
            assert p.target_words is None


class TestTopbarSwitcher:
    def test_switcher_rendered_on_pages(self, client):
        rv = client.get("/")
        assert b'book-switcher' in rv.data
        assert b'book-menu' in rv.data
        assert b'switchBook' in rv.data

    def test_switcher_lists_books_with_words(self, client, second_book):
        rv = client.get("/")
        assert b"The Ember Ship" in rv.data
        assert b"New Book" in rv.data
        assert b"Manage Books" in rv.data


class TestStoryTitleSingleSource:
    def test_story_title_follows_active_project(self, client, second_book):
        """story_title in every page comes from the ACTIVE project name."""
        rv = client.get("/")
        assert b"The Ember Ship" in rv.data  # switched on creation
        # legacy default book name must NOT be shown as the active title anymore
        assert b"My Story</title>" not in rv.data

    def test_switch_back_updates_title(self, client, second_book):
        rv = client.post("/projects/default/switch", json={})
        assert rv.get_json()["ok"] is True
        rv2 = client.get("/")
        # conftest seeds the default book as "Test Story"
        assert b"Test Story" in rv2.data
        # the switcher button (active name) must NOT show the other book
        assert b'book-switcher-name">The Ember Ship<' not in rv2.data
        # other books still listed in the dropdown menu
        assert b'The Ember Ship' in rv2.data

    def test_switch_returns_book_name(self, client, second_book):
        rv = client.post(f"/projects/{second_book['id']}/switch", json={})
        data = rv.get_json()
        assert data["ok"] is True
        assert data["name"] == "The Ember Ship"


class TestBooksHub:
    def test_page_renders_with_metadata(self, client, second_book):
        rv = client.get("/projects")
        assert rv.status_code == 200
        assert b"The Ember Ship" in rv.data
        assert b"Fantasy" in rv.data
        assert b"90,000" in rv.data or b"90000" in rv.data

    def test_edit_updates_metadata(self, client, second_book):
        rv = client.post(f"/projects/{second_book['id']}/edit", json={
            "name": "The Ember Ship II", "genre": "Sci-Fi",
            "target_words": 120000, "deadline": "2028-06-30",
            "color": "#ec4899"})
        assert rv.get_json()["ok"] is True
        from core.db import read_session
        from models.project import Project
        with read_session() as s:
            p = s.get(Project, second_book["id"])
            assert p.name == "The Ember Ship II"
            assert p.genre == "Sci-Fi"
            assert p.target_words == 120000
            assert p.color == "#ec4899"

    def test_progress_computed(self, client, second_book):
        from services import chapter_service
        chapter_service.create_chapter(
            title="Ch1",
            content="word " * 900)  # 900 words
        rv = client.get("/projects")
        assert b"1%" in rv.data  # 900/90000 = 1%

    def test_deadline_days_left(self, client, second_book):
        rv = client.get("/projects")
        assert b"days left" in rv.data or b"d left" in rv.data


class TestDashboardWriterHome:
    def test_hero_shows_active_book(self, client, second_book):
        rv = client.get("/")
        assert b"writer-hero" in rv.data
        assert b"The Ember Ship" in rv.data
        assert b"Fantasy" in rv.data

    def test_goal_ring_present(self, client):
        rv = client.get("/")
        assert b"goal-ring-num" in rv.data
        assert b"today" in rv.data

    def test_streak_badge_zero_hidden(self, client):
        rv = client.get("/")
        # No writing history → no streak badge
        assert b"-day streak" not in rv.data

    def test_book_progress_bar_when_target_set(self, client, second_book):
        rv = client.get("/")
        assert b"book-progress-fill" in rv.data

    def test_chapters_in_other_book_not_counted(self, client, second_book):
        """Word counts in the hero must respect the ACTIVE book."""
        from core.db import write_transaction
        from models.settings import Setting
        from services import chapter_service
        # Write 500 words in the DEFAULT book, then switch to it
        chapter_service.create_chapter(title="Default ch", content="a " * 500)
        with write_transaction() as s:
            Setting.set(s, "active_project_id", "default")
        rv = client.get("/")
        # default book ("Test Story" in conftest) is now active
        assert b'book-switcher-name">Test Story<' in rv.data
        assert b'book-switcher-name">The Ember Ship<' not in rv.data


class TestOnboarding:
    def test_wizard_shown_on_fresh_db(self, client):
        rv = client.get("/")
        assert b"Welcome to ASM" in rv.data

    def test_wizard_hidden_after_onboarded(self, client):
        rv = client.post("/settings/save", json={"onboarded": "true"})
        assert rv.get_json()["ok"] is True
        rv2 = client.get("/")
        assert b"Welcome to ASM" not in rv2.data

    def test_wizard_hidden_when_chapters_exist(self, client):
        from services import chapter_service
        chapter_service.create_chapter(title="First", content="Hello world.")
        rv = client.get("/")
        assert b"Welcome to ASM" not in rv.data

    def test_onboarded_default_false(self):
        from models.settings import DEFAULT_SETTINGS
        assert DEFAULT_SETTINGS.get("onboarded") == "false"


class TestSwitchIsolation:
    def test_chapters_isolated_between_books(self, client, second_book):
        """A chapter created while book B is active belongs to book B."""
        from core.db import read_session
        from models.chapter import Chapter
        from services import chapter_service
        ch = chapter_service.create_chapter(
            title="Ember chapter", content="ember words")
        with read_session() as s:
            row = s.get(Chapter, ch.id)
            assert row.project_id == second_book["id"]
