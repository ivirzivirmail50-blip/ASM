"""M-08 — quickswitch route coverage (27% → 80%+)."""
from __future__ import annotations


def _seed_world():
    from services import chapter_service, character_service, plan_service
    chapter_service.create_chapter(title="Boğaz Geceleri",
                                   content="deneme")
    character_service.create_character(name="Ayşe", role="protagonist")
    plan_service.create_plan(title="Sahne 12 revizyonu",
                             description="tempoyu hızlandır")


class TestQuickSwitch:

    def test_empty_query_returns_nav_items(self, client):
        r = client.get("/search-all")
        assert r.status_code == 200
        data = r.get_json()
        assert "results" in data
        results = data["results"]
        assert results, "nav shortcuts must always be present"
        assert all(x["type"] == "nav" for x in results)
        urls = {x["url"] for x in results}
        assert "/" in urls and "/settings/" in urls

    def test_query_matches_chapter(self, client):
        _seed_world()
        r = client.get("/search-all?q=boğaz")
        results = r.get_json()["results"]
        chapters = [x for x in results if x["type"] == "chapter"]
        assert chapters and "Boğaz" in chapters[0]["title"]
        assert chapters[0]["url"].startswith("/chapters/")

    def test_query_matches_character(self, client):
        _seed_world()
        r = client.get("/search-all?q=ayşe")
        results = r.get_json()["results"]
        chars = [x for x in results if x["type"] == "character"]
        assert chars and chars[0]["title"] == "Ayşe"

    def test_query_matches_plan(self, client):
        _seed_world()
        r = client.get("/search-all?q=revizyon")
        results = r.get_json()["results"]
        plans = [x for x in results if x["type"] == "plan"]
        assert plans and "Sahne" in plans[0]["title"]

    def test_query_matches_world_entry(self, client):
        from services import world_service
        world_service.create_entry(type_="location", name="Sisli Liman",
                                   description="sis")
        r = client.get("/search-all?q=sisli")
        results = r.get_json()["results"]
        world = [x for x in results if x["type"] == "world_entry"]
        assert world and world[0]["title"] == "Sisli Liman"

    def test_nav_filtered_by_query(self, client):
        r = client.get("/search-all?q=settings")
        results = r.get_json()["results"]
        navs = [x for x in results if x["type"] == "nav"]
        assert navs and any("Settings" in x["title"] for x in navs)

    def test_results_capped(self, client):
        r = client.get("/search-all?q=e")
        results = r.get_json()["results"]
        assert len(results) <= 30

    def test_unknown_query_still_ok(self, client):
        r = client.get("/search-all?q=zzzznothing")
        assert r.status_code == 200
        assert "results" in r.get_json()
