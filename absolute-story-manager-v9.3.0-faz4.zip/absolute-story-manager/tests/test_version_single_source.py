"""S-06 — single-source version + .env protection."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestVersionSingleSource:
    def test_core_version_exists(self):
        from core.version import __version__
        assert re.fullmatch(r"\d+\.\d+\.\d+", __version__)

    def test_pyproject_reads_from_core(self):
        """pyproject.toml must derive its version from core.version."""
        text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        assert 'version = {attr = "core.version.__version__"}' in text
        assert not re.search(r'^version\s*=\s*"\d', text, re.M), (
            "pyproject.toml must not carry a hardcoded version"
        )

    def test_start_bat_banner_not_stale(self):
        """start.bat banner fallback must equal core.version.__version__."""
        from core.version import __version__
        bat = (ROOT / "start.bat").read_text(encoding="utf-8",
                                             errors="replace")
        m = re.search(r"if not defined ASM_VERSION set ASM_VERSION=(\S+)",
                      bat)
        assert m, "start.bat must carry a version fallback"
        assert m.group(1) == __version__

    def test_no_divergent_hardcoded_versions(self):
        """No other module may hardcode a competing 'vX.Y.Z' banner."""
        from core.version import __version__
        offenders = []
        for py in ROOT.glob("*.py"):
            text = py.read_text(encoding="utf-8", errors="replace")
            for found in re.findall(r"Manager v(\d+\.\d+(?:\.\d+)?)", text):
                if found != __version__:
                    offenders.append(f"{py.name}: v{found}")
        assert not offenders, f"stale version banners: {offenders}"


class TestEnvProtection:
    def test_gitignore_covers_env_files(self):
        gi = (ROOT / ".gitignore").read_text(encoding="utf-8")
        assert re.search(r"^\.env$", gi, re.M)
        assert re.search(r"^!\.env\.example$", gi, re.M)

    def test_env_example_has_no_real_secrets(self):
        example = (ROOT / ".env.example").read_text(encoding="utf-8")
        for line in example.splitlines():
            if "=" in line and not line.strip().startswith("#"):
                _, _, value = line.partition("=")
                value = value.strip().lower()
                assert "change-me" in value or value == "", (
                    f".env.example ships a real-looking value: {line}"
                )

    def test_env_would_be_ignored_by_git(self):
        """git check-ignore equivalent: the .gitignore pattern matches .env."""
        gi = (ROOT / ".gitignore").read_text(encoding="utf-8")
        patterns = [ln.strip() for ln in gi.splitlines()
                    if ln.strip() and not ln.startswith("#")]
        assert ".env" in patterns
