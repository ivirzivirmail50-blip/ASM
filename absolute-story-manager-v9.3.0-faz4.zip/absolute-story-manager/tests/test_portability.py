"""S-08 — portable scripts: start.sh + no hardcoded absolute paths."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestStartSh:
    def test_start_sh_exists_and_is_executable(self):
        sh = ROOT / "start.sh"
        assert sh.exists(), "start.sh missing"
        # On Windows checkouts the exec bit may be lost; tolerate +x OR 644
        # but the file must exist and be valid POSIX sh.
        assert sh.stat().st_size > 0

    def test_start_sh_defaults_to_loopback(self):
        """S-01/S-08: the launcher must not expose the app by default."""
        text = (ROOT / "start.sh").read_text(encoding="utf-8")
        active = re.findall(r'^\s*export\s+ASM_HOST="?([^"\s]+)"?', text, re.M)
        assert active, "start.sh must export ASM_HOST explicitly"
        for h in active:
            # Accept literal 127.0.0.1 or ${ASM_HOST:-127.0.0.1} expansion.
            default = re.search(r"\$\{[^:]*:-([^}]*)\}", h)
            value = default.group(1) if default else h
            assert value == "127.0.0.1", f"non-loopback default: {h}"
        # 0.0.0.0 may only appear in commented-out guidance.
        for line in text.splitlines():
            if "0.0.0.0" in line:
                assert line.strip().startswith("#"), line

    def test_start_sh_mirrors_start_bat_features(self):
        text = (ROOT / "start.sh").read_text(encoding="utf-8")
        for token in ("venv", "requirements.txt", "init_db.py", "app.py"):
            assert token in text, f"start.sh missing step: {token}"

    def test_start_bat_exists(self):
        assert (ROOT / "start.bat").exists()


class TestPortablePaths:
    def test_no_hardcoded_user_paths_in_scripts(self):
        """Scripts must run from any checkout location (S-08)."""
        offenders = []
        for py in (ROOT / "scripts").glob("*.py"):
            text = py.read_text(encoding="utf-8", errors="replace")
            for m in re.findall(r'["\'](/home/[^"\']*|/Users/[^"\']*'
                                r'|C:\\\\[^"\']*)["\']', text):
                offenders.append(f"{py.name}: {m}")
        assert not offenders, f"hardcoded absolute paths: {offenders}"

    def test_integration_test_path_is_file_anchored(self):
        text = (ROOT / "scripts" / "integration_test.py").read_text()
        m = re.search(r'sys\.path\.insert\(0,\s*(.+)\)', text)
        assert m, "integration_test.py must set sys.path"
        assert "Path(__file__)" in m.group(1), (
            "sys.path must be anchored to the file, not a hardcoded dir"
        )

    def test_integration_test_imports_app_from_any_cwd(self, tmp_path,
                                                      monkeypatch):
        """Smoke: the path setup lets us import from a foreign cwd."""
        import subprocess
        import sys as _sys
        result = subprocess.run(
            [_sys.executable, "-c",
             "import sys; sys.path.insert(0, ''); "
             "from pathlib import Path; "
             "sys.path.insert(0, str(Path('.').resolve())); "
             "import app; print('OK')"],
            cwd=ROOT, capture_output=True, text=True, timeout=60,
        )
        assert "OK" in result.stdout, result.stderr[-400:]
