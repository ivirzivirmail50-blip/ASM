"""v7.5 — Systemic inline-JS guard for EVERY core page.

The user reported the notes-page death happening "again and again": each fix
addressed the current error, but nothing prevented the NEXT Jinja/JS
collision from silently killing another page. This suite is the systemic
guard: it renders a broad set of pages with tricky data and syntax-checks
every inline <script> block with node --check. If any template ever emits
invalid JavaScript again, CI fails HERE with the exact page + error — before
any user ever sees a dead page.
"""
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Pages to guard: (route, requires_seed)
CORE_PAGES = [
    "/",
    "/chapters/",
    "/notes/",
    "/scenes/",
    "/plans/",
    "/journal/",
    "/characters/",
    "/world/",
    "/world/hierarchy",
    "/outline/",
    "/search/",
    "/export/",
    "/settings/",
    "/analytics/",
    "/snippets/",
    "/glossary/",
    "/inspiration/",
    "/milestones/",
    "/submissions/",
    "/references/",
    "/emotions/",
    "/chronology/",
    "/storage/",
]


def _inline_scripts(html: str) -> list[str]:
    # v8.0: skip data blocks (type="application/json") — they are payloads,
    # not code; node --check would false-fail on object literals.
    return re.findall(
        r'<script(?![^>]*\bsrc=)(?![^>]*type=["\']application/(?:json|ld\+json)["\'])[^>]*>(.*?)</script>',
        html, re.S)


def _node_check(js: str) -> tuple[bool, str]:
    node = shutil.which("node")
    if not node:
        pytest.skip("node not available for JS syntax check")
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(js)
        path = f.name
    try:
        r = subprocess.run([node, "--check", path], capture_output=True,
                           text=True, timeout=30)
        return r.returncode == 0, r.stderr
    finally:
        Path(path).unlink(missing_ok=True)


@pytest.fixture
def seeded(client):
    """Seed tricky content that historically broke JS rendering."""
    from services import chapter_service as chapters
    from services import character_service as chars
    from services import note_service as notes
    from services import world_service as world

    notes.create_note(title='Not "tırnak" ile', body="# md\n\n`kod` & <b>html</b>",
                      category="idea", tags=["x"])
    chapters.create_chapter(title="Bölüm 'tek' tırnak", content="İçerik — em dash ✨",
                            synopsis="sent<ez> & \"quotes\"")
    chars.create_character(name="Elara", role="protagonist")
    world.create_entry(type_="location", name="Aurelia",
                       description="Sis'li şehir")
    return client


@pytest.mark.parametrize("route", CORE_PAGES)
def test_every_core_page_inline_js_parses(seeded, route):
    r = seeded.get(route)
    # 404/redirects are structural issues, not JS issues — but we still
    # syntax-check whatever HTML came back when it is a 200.
    assert r.status_code in (200, 302, 404), f"{route} → {r.status_code}"
    if r.status_code != 200:
        pytest.skip(f"{route} returned {r.status_code} (no JS to guard)")
    html = r.get_data(as_text=True)
    blocks = _inline_scripts(html)
    for i, b in enumerate(blocks):
        ok, err = _node_check(b)
        assert ok, (
            f"Inline script #{i} on {route} has a syntax error "
            f"(this is the 'dead page' bug class):\n{err}\n---\n{b[:500]}"
        )


def test_no_python_slice_syntax_on_any_core_page(seeded):
    """Python slice syntax (x[:10]) inside JS is the exact v7.4 notes bug."""
    for route in CORE_PAGES:
        r = seeded.get(route)
        if r.status_code != 200:
            continue
        for b in _inline_scripts(r.get_data(as_text=True)):
            code = re.sub(r"//[^\n]*", "", b)
            code = re.sub(r"/\*.*?\*/", "", code, flags=re.S)
            assert not re.search(r"\w\[:\d+\]", code), \
                f"Python slice syntax leaked into JS on {route}"


def test_notes_page_functions_defined_in_browser(seeded):
    """notes.js must be referenced and its API must exist — pinned via the
    script tag presence (function presence is covered by notes.js tests)."""
    r = seeded.get("/notes/")
    assert r.status_code == 200
    assert b"static/js/notes.js" in r.data or b"js/notes.js" in r.data


def test_all_static_js_files_parse():
    """Every JS file under static/js must be valid JavaScript — guards the
    whole client layer, not just notes."""
    node = shutil.which("node")
    if not node:
        pytest.skip("node not available")
    js_dir = PROJECT_ROOT / "static" / "js"
    files = sorted(js_dir.glob("*.js"))
    assert files, "no static JS files found?"
    for f in files:
        r = subprocess.run([node, "--check", str(f)], capture_output=True,
                           text=True, timeout=30)
        assert r.returncode == 0, f"{f.name} does not parse:\n{r.stderr}"
