"""F-01 — AI provider adapter layer (v9.2.0).

Pins the acceptance criteria of the Faz 3 F-01 card:
- four providers (Ollama / OpenAI-compat / Anthropic native / Gemini) speak
  one adapter interface
- ALL HTTP goes through a shared requests.Session with exponential-backoff
  retry: 3 attempts, retrying only connection errors / timeouts / 5xx
- an explicit (connect, read) timeout policy
- after 2 retries the user gets a clear AiProviderError (not a raw 500)
- the settings page offers all four providers

Live tests run against the real scripts/mock_ai_server.py (which now speaks
all four provider dialects) started in a background thread.
"""
from __future__ import annotations

import threading
from http.server import HTTPServer

import pytest
import requests as req

from core.errors import AiProviderError
from services import ai_providers, ai_service

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def mock_ai():
    """Run the real multi-provider mock server on an ephemeral port."""
    import importlib.util
    from pathlib import Path

    spec = importlib.util.spec_from_file_location(
        "mock_ai_server",
        Path(__file__).resolve().parent.parent / "scripts" / "mock_ai_server.py",
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    server = HTTPServer(("127.0.0.1", 0), mod.Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.fixture()
def enable_provider(mock_ai, request):
    """Enable AI with a given provider pointed at the mock server."""
    from core.db import write_transaction
    from models.settings import Setting

    provider = request.param

    def _enable(provider):
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", True)
            Setting.set(s, "ai.provider", provider)
            Setting.set(s, "ai.api_base", mock_ai)
            Setting.set(s, "ai.api_key", "test-key")
            Setting.set(s, "ai.model", "mock-model")

    _enable(provider)
    yield provider
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", False)


# ---------------------------------------------------------------------------
# Adapter factory
# ---------------------------------------------------------------------------

class TestAdapterFactory:

    def test_four_known_providers(self):
        for name in ("ollama", "openai", "anthropic", "gemini"):
            adapter = ai_providers.get_adapter(name)
            assert adapter.name == name

    @pytest.mark.parametrize("name", [None, "", "  ", "typo-provider"])
    def test_unknown_provider_falls_back_to_openai_compat(self, name):
        """Historical behavior preserved: non-Ollama speaks /v1/chat/completions."""
        adapter = ai_providers.get_adapter(name)
        assert isinstance(adapter, ai_providers.OpenAICompatAdapter)

    def test_shared_session_is_reused(self):
        s1 = ai_providers.get_session()
        s2 = ai_providers.get_session()
        assert s1 is s2
        assert isinstance(s1, req.Session)


# ---------------------------------------------------------------------------
# Retry / timeout policy (mocked session)
# ---------------------------------------------------------------------------

class _Resp:
    def __init__(self, status=200, payload=None):
        self.status_code = status
        self._payload = payload or {}

    def raise_for_status(self):
        if self.status_code >= 400:
            raise req.HTTPError(f"{self.status_code}", response=self)

    def json(self):
        return self._payload


class _FlakySession:
    """Session stub that fails N times then succeeds (or fails forever)."""

    def __init__(self, failures, exc=None, final=None):
        self.failures = failures
        self.exc = exc
        self.final = final
        self.calls = []

    def request(self, method, url, timeout=None, **kwargs):
        self.calls.append((method, url, timeout, kwargs))
        if len(self.calls) <= self.failures:
            raise self.exc or req.exceptions.ConnectionError("boom")
        return self.final or _Resp()


CFG = {"api_base": "http://mock:1", "model": "m", "timeout": 60}


class TestRetryPolicy:

    def test_retry_then_success(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=2, final=_Resp(payload={"response": "ok"}))
        monkeypatch.setattr(ai_providers, "_session", session)
        out = ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        assert out == "ok"
        assert len(session.calls) == 3  # 1 + 2 retries

    def test_connection_error_clear_message_after_3_attempts(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=99,
                                exc=req.exceptions.ConnectionError("refused"))
        monkeypatch.setattr(ai_providers, "_session", session)
        with pytest.raises(AiProviderError) as ei:
            ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        msg = str(ei.value)
        assert "3 attempt" in msg
        assert "refused" in msg
        assert "http://mock:1" in msg  # actionable: where it tried
        assert len(session.calls) == 3

    def test_timeout_is_retryable(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(
            failures=99, exc=req.exceptions.Timeout("read timed out"))
        monkeypatch.setattr(ai_providers, "_session", session)
        with pytest.raises(AiProviderError):
            ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        assert len(session.calls) == 3

    def test_4xx_not_retried(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=0, final=_Resp(status=401))
        monkeypatch.setattr(ai_providers, "_session", session)
        with pytest.raises(AiProviderError):
            ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        # Client errors are terminal — ONE attempt only.
        assert len(session.calls) == 1

    def test_5xx_is_retried(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=99, final=_Resp(status=503))
        monkeypatch.setattr(ai_providers, "_session", session)
        with pytest.raises(AiProviderError):
            ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        assert len(session.calls) == 3

    def test_timeout_tuple_policy(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=0, final=_Resp(payload={"response": "x"}))
        monkeypatch.setattr(ai_providers, "_session", session)
        # read timeout 60 → (connect=10 capped, read=60)
        ai_providers.OllamaAdapter().generate(CFG, "p", 10, 0.5)
        assert session.calls[0][2] == (10, 60)
        # read timeout 5 → (connect=5, read=5) — connect capped by read
        cfg2 = dict(CFG, timeout=5)
        session2 = _FlakySession(failures=0, final=_Resp(payload={"response": "x"}))
        monkeypatch.setattr(ai_providers, "_session", session2)
        ai_providers.OllamaAdapter().generate(cfg2, "p", 10, 0.5)
        assert session2.calls[0][2] == (5, 5)

    def test_retry_attempts_respected_from_cfg(self, monkeypatch):
        monkeypatch.setattr(ai_providers, "BACKOFF_BASE", 0.0)
        session = _FlakySession(failures=99,
                                exc=req.exceptions.ConnectionError("down"))
        monkeypatch.setattr(ai_providers, "_session", session)
        cfg = dict(CFG, retry_attempts=1)
        with pytest.raises(AiProviderError):
            ai_providers.OllamaAdapter().generate(cfg, "p", 10, 0.5)
        assert len(session.calls) == 1


# ---------------------------------------------------------------------------
# Anthropic / Gemini wire formats (mocked session)
# ---------------------------------------------------------------------------

class _WireSession:
    """Records the request; returns a canned payload."""

    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def request(self, method, url, timeout=None, headers=None, json=None, **kw):
        self.calls.append({"method": method, "url": url,
                           "headers": headers, "json": json})
        return _Resp(payload=self.payload)


CFG_ANTHROPIC = {"api_base": "https://api.anthropic.com", "model": "claude-x",
                 "api_key": "sk-ant-test", "timeout": 30}
CFG_GEMINI = {"api_base": "https://generativelanguage.googleapis.com",
              "model": "gemini-x", "api_key": "g-key", "timeout": 30}


class TestAnthropicAdapter:

    def test_generate_wire_format(self, monkeypatch):
        session = _WireSession({"content": [{"type": "text", "text": "Merhaba"}]})
        monkeypatch.setattr(ai_providers, "_session", session)
        out = ai_providers.AnthropicAdapter().generate(
            CFG_ANTHROPIC, "naber", 100, 0.7)
        assert out == "Merhaba"
        call = session.calls[0]
        assert call["method"] == "POST"
        assert call["url"].endswith("/v1/messages")
        assert call["headers"]["x-api-key"] == "sk-ant-test"
        assert call["headers"]["anthropic-version"] == "2023-06-01"
        body = call["json"]
        assert body["model"] == "claude-x"
        assert body["max_tokens"] == 100
        assert body["messages"] == [{"role": "user", "content": "naber"}]

    def test_thinking_blocks_excluded(self, monkeypatch):
        session = _WireSession({"content": [
            {"type": "thinking", "thinking": "internal reasoning"},
            {"type": "text", "text": "final answer"},
        ]})
        monkeypatch.setattr(ai_providers, "_session", session)
        out = ai_providers.AnthropicAdapter().generate(
            CFG_ANTHROPIC, "p", 100, 0.7)
        assert out == "final answer"

    def test_only_thinking_raises_clear_error(self, monkeypatch):
        session = _WireSession({"content": [
            {"type": "thinking", "thinking": "no final text"},
        ]})
        monkeypatch.setattr(ai_providers, "_session", session)
        with pytest.raises(AiProviderError, match="no text content"):
            ai_providers.AnthropicAdapter().generate(CFG_ANTHROPIC, "p", 100, 0.7)

    def test_stream_events_parsed(self, monkeypatch):
        lines = [
            b'data: {"type": "message_start"}',
            b'',
            b'data: {"type": "content_block_delta", "index": 0,'
            b' "delta": {"type": "text_delta", "text": "Ne"}}',
            b'data: {"type": "content_block_delta", "index": 0,'
            b' "delta": {"type": "thinking_delta", "thinking": "hmm"}}',
            b'data: {"type": "content_block_delta", "index": 0,'
            b' "delta": {"type": "text_delta", "text": " oldun"}}',
            b'data: {"type": "message_stop"}',
        ]

        class _StreamResp(_Resp):
            def iter_lines(self):
                return iter(lines)

        class _S:
            def request(self, method, url, timeout=None, headers=None,
                        json=None, **kw):
                return _StreamResp()

        monkeypatch.setattr(ai_providers, "_session", _S())
        chunks = list(ai_providers.AnthropicAdapter().stream(
            CFG_ANTHROPIC, "p", 100, 0.7))
        # thinking_delta skipped; final ("", True) sentinel included
        texts = [c for c, fin in chunks if c]
        assert "".join(texts) == "Ne oldun"
        assert chunks[-1] == ("", True)

    def test_list_models_url_and_header(self, monkeypatch):
        session = _WireSession({"data": [{"id": "claude-a"}, {"id": "claude-b"}]})
        monkeypatch.setattr(ai_providers, "_session", session)
        models = ai_providers.AnthropicAdapter().list_models(CFG_ANTHROPIC)
        assert models == ["claude-a", "claude-b"]
        assert session.calls[0]["method"] == "GET"
        assert session.calls[0]["url"].endswith("/v1/models")


class TestGeminiAdapter:

    def test_generate_wire_format(self, monkeypatch):
        session = _WireSession({"candidates": [
            {"content": {"parts": [{"text": "Selam"}], "role": "model"}}]})
        monkeypatch.setattr(ai_providers, "_session", session)
        out = ai_providers.GeminiAdapter().generate(CFG_GEMINI, "merhaba", 80, 0.3)
        assert out == "Selam"
        call = session.calls[0]
        assert call["method"] == "POST"
        assert call["url"].endswith("/v1beta/models/gemini-x:generateContent")
        assert call["headers"]["x-goog-api-key"] == "g-key"
        body = call["json"]
        assert body["contents"] == [{"role": "user",
                                     "parts": [{"text": "merhaba"}]}]
        assert body["generationConfig"]["maxOutputTokens"] == 80

    def test_thought_parts_excluded(self, monkeypatch):
        session = _WireSession({"candidates": [
            {"content": {"parts": [
                {"text": "gizli dusunce", "thought": True},
                {"text": "gorunen cevap"},
            ]}}]})
        monkeypatch.setattr(ai_providers, "_session", session)
        out = ai_providers.GeminiAdapter().generate(CFG_GEMINI, "p", 80, 0.3)
        assert out == "gorunen cevap"

    def test_stream_url_uses_alt_sse(self, monkeypatch):
        captured = {}

        class _StreamResp(_Resp):
            def iter_lines(self):
                return iter([
                    b'data: {"candidates": [{"content":'
                    b' {"parts": [{"text": "A"}]}}]}',
                    b'data: {"candidates": [{"finishReason": "STOP"}]}',
                ])

        class _S:
            def request(self, method, url, timeout=None, headers=None,
                        json=None, **kw):
                captured["url"] = url
                return _StreamResp()

        monkeypatch.setattr(ai_providers, "_session", _S())
        chunks = list(ai_providers.GeminiAdapter().stream(
            CFG_GEMINI, "p", 80, 0.3))
        assert captured["url"].endswith(
            "/v1beta/models/gemini-x:streamGenerateContent?alt=sse")
        texts = [c for c, fin in chunks if c]
        assert "".join(texts) == "A"
        assert chunks[-1] == ("", True)

    def test_list_models_strips_prefix(self, monkeypatch):
        session = _WireSession({"models": [
            {"name": "models/gemini-flash"},
            {"name": "models/gemini-pro"},
        ]})
        monkeypatch.setattr(ai_providers, "_session", session)
        models = ai_providers.GeminiAdapter().list_models(CFG_GEMINI)
        assert models == ["gemini-flash", "gemini-pro"]


# ---------------------------------------------------------------------------
# Live end-to-end against the real mock server (all four dialects)
# ---------------------------------------------------------------------------

class TestLiveMockServer:

    @pytest.mark.parametrize("enable_provider", ["ollama"], indirect=True)
    def test_ollama_generate(self, enable_provider):
        out = ai_service.generate("Continue this story")
        assert "hikâye" in out or len(out) > 10

    @pytest.mark.parametrize("enable_provider", ["openai"], indirect=True)
    def test_openai_generate(self, enable_provider):
        out = ai_service.generate("Continue this story")
        assert len(out) > 10

    @pytest.mark.parametrize("enable_provider", ["anthropic"], indirect=True)
    def test_anthropic_generate(self, enable_provider):
        out = ai_service.generate("Continue this story")
        assert len(out) > 10

    @pytest.mark.parametrize("enable_provider", ["gemini"], indirect=True)
    def test_gemini_generate(self, enable_provider):
        out = ai_service.generate("Continue this story")
        assert len(out) > 10

    @pytest.mark.parametrize("enable_provider",
                             ["ollama", "openai", "anthropic", "gemini"],
                             indirect=True)
    def test_streaming_all_providers(self, enable_provider):
        chunks = list(ai_service.generate_streaming("Continue this story"))
        texts = [c for c, fin in chunks if c]
        assert len("".join(texts)) > 10
        assert chunks[-1] == ("", True)

    @pytest.mark.parametrize("enable_provider", ["ollama"], indirect=True)
    def test_ollama_list_models(self, enable_provider):
        models = ai_service.list_models()
        assert "mock-llama3" in models

    @pytest.mark.parametrize("enable_provider", ["openai"], indirect=True)
    def test_openai_list_models(self, enable_provider):
        models = ai_service.list_models()
        assert "mock-gpt" in models

    @pytest.mark.parametrize("enable_provider", ["anthropic"], indirect=True)
    def test_anthropic_list_models(self, enable_provider):
        models = ai_service.list_models()
        assert "mock-claude" in models

    @pytest.mark.parametrize("enable_provider", ["gemini"], indirect=True)
    def test_gemini_list_models(self, enable_provider):
        models = ai_service.list_models()
        assert "mock-gemini-flash" in models

    @pytest.mark.parametrize("enable_provider", ["anthropic"], indirect=True)
    def test_anthropic_models_route(self, client, enable_provider):
        resp = client.get("/ai/models")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["ok"] is True
        assert "mock-claude" in data["models"]

    @pytest.mark.parametrize("enable_provider", ["gemini"], indirect=True)
    def test_gemini_models_route(self, client, enable_provider):
        resp = client.get("/ai/models")
        assert resp.status_code == 200
        assert "mock-gemini-pro" in resp.get_json()["models"]


# ---------------------------------------------------------------------------
# Settings page offers all four providers (source-scan lock)
# ---------------------------------------------------------------------------

class TestSettingsProviderSelector:

    def test_select_has_four_provider_options(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parent.parent
               / "templates" / "settings_ai.html").read_text(encoding="utf-8")
        for value in ('value="ollama"', 'value="openai"',
                      'value="anthropic"', 'value="gemini"'):
            assert value in src, f"provider option missing: {value}"
        # Presets for the two new providers exist too
        assert "anthropic:" in src
        assert "gemini:" in src
        assert "https://api.anthropic.com" in src
        assert "https://generativelanguage.googleapis.com" in src

    def test_provider_dialects_in_mock_server(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parent.parent
               / "scripts" / "mock_ai_server.py").read_text(encoding="utf-8")
        for marker in ("/v1/messages", ":generateContent",
                       ":streamGenerateContent", "/api/generate",
                       "/api/tags", "/v1beta/models"):
            assert marker in src, f"mock dialect missing: {marker}"
