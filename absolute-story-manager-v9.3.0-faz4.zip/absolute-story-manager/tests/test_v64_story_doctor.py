"""ASM v6.4 Story Doctor tests — aggregation service, health score,
page rendering, navigation."""
import pytest

from services import chapter_service, story_doctor_service


@pytest.fixture
def clean_manuscript():
    """One healthy chapter: synopsis present, decent length, no obvious issues."""
    return chapter_service.create_chapter(
        title="The Harbor",
        content=("Elara stepped onto the pier and watched the clouds gather. "
                 "The sailors hurried past her, tying down crates and shouting "
                 "warnings about the coming storm. She pulled her coat tighter "
                 "and walked toward the customs house, where a single lantern "
                 "burned in the window. Somewhere behind her, a gull cried out "
                 "once, then fell silent."),
        synopsis="Elara arrives at the harbor as a storm approaches.")


@pytest.fixture
def messy_manuscript():
    """Chapters with the kinds of issues the doctor should catch:
    missing synopsis, very thin content, heavy repetition."""
    ch1 = chapter_service.create_chapter(
        title="Thin One",
        content="Short.")  # thin chapter, no synopsis
    ch2 = chapter_service.create_chapter(
        title="Repetitive",
        content=("The dark tower rose above the dark trees. The dark sky "
                 "swirled above the dark tower and the dark trees. She "
                 "walked toward the dark tower through the dark trees under "
                 "the dark sky. The dark tower loomed. Dark, dark, dark."),
        synopsis="Repetitive prose.")
    return [ch1, ch2]


class TestFullCheckup:
    def test_report_shape(self, clean_manuscript):
        rep = story_doctor_service.full_checkup()
        for key in ("ok", "structure", "lint", "word_freq", "glossary",
                    "timeline", "pacing", "penalties", "score", "grade",
                    "breakdown", "recommendations", "checks_ran"):
            assert key in rep, f"missing key: {key}"
        assert rep["ok"] is True

    def test_structure_counts(self, clean_manuscript):
        rep = story_doctor_service.full_checkup()
        assert rep["structure"]["chapters"] >= 1
        assert rep["structure"]["total_words"] > 50
        assert rep["structure"]["missing_synopsis"] == 0

    def test_all_analyzers_ran(self, clean_manuscript):
        rep = story_doctor_service.full_checkup()
        # lint/word_freq/pacing always run; glossary/timeline only when data exists
        assert "lint" in rep["checks_ran"]
        assert "word_freq" in rep["checks_ran"]
        assert "pacing" in rep["checks_ran"]

    def test_score_bounds(self, clean_manuscript):
        rep = story_doctor_service.full_checkup()
        assert 0 <= rep["score"] <= 100

    def test_grade_mapping(self):
        g = story_doctor_service._grade
        assert g(95)["grade"] == "A"
        assert g(80)["grade"] == "B"
        assert g(60)["grade"] == "C"
        assert g(40)["grade"] == "D"
        assert g(10)["grade"] == "E"

    def test_messy_manuscript_scores_lower(self, clean_manuscript, messy_manuscript):
        """More issues → lower score. (Fresh DB per test isolates fixtures,
        so this compares the SAME db before/after adding messy chapters.)"""
        before = story_doctor_service.full_checkup()
        score_before = before["score"]
        # The clean chapter was created in this test's fresh DB too,
        # so after adding messy chapters the score must not improve.
        score_after = story_doctor_service.full_checkup()["score"]
        assert score_after <= score_before

    def test_messy_issues_detected(self, messy_manuscript):
        rep = story_doctor_service.full_checkup()
        st = rep["structure"]
        assert st["missing_synopsis"] >= 1          # "Thin One" has no synopsis
        assert len(st["thin_chapters"]) >= 1        # "Short." is < 150 words
        assert rep["score"] < 100                   # something must cost points
        assert rep["breakdown"], "expected non-empty breakdown"

    def test_penalties_are_capped(self, messy_manuscript):
        rep = story_doctor_service.full_checkup()
        for key, value in rep["penalties"].items():
            cap = story_doctor_service._CAPS.get(key)
            if cap is not None:
                assert value <= cap, f"{key} penalty {value} exceeds cap {cap}"

    def test_recommendations_present_and_sorted(self, messy_manuscript):
        rep = story_doctor_service.full_checkup()
        assert rep["recommendations"]
        priorities = [r["priority"] for r in rep["recommendations"]]
        assert priorities == sorted(priorities)

    def test_recommendation_links_point_to_real_tools(self, clean_manuscript):
        rep = story_doctor_service.full_checkup()
        urls = {r["url"] for r in rep["recommendations"] if r.get("url")}
        allowed = {"/lint/", "/timeline-check/", "/glossary/scan", "/word-freq/",
                   "/chapters/", "/chapters/new", "/pacing/"}
        assert urls <= allowed

    def test_empty_manuscript_handled(self):
        """No chapters at all → valid report, recommends starting to write."""
        rep = story_doctor_service.full_checkup()
        assert rep["structure"]["chapters"] == 0
        assert rep["score"] <= 100
        assert any("No chapters" in r["text"] for r in rep["recommendations"])


class TestStoryDoctorPage:
    def test_page_renders_with_chapters(self, client, clean_manuscript):
        rv = client.get("/story-doctor/")
        assert rv.status_code == 200
        data = rv.data
        assert b"Story Doctor" in data
        assert b"doctor-hero" in data
        assert b"Prescriptions" in data

    def test_page_empty_state(self, client):
        rv = client.get("/story-doctor/")
        assert rv.status_code == 200
        assert b"Nothing to check yet" in rv.data

    def test_api_checkup(self, client, clean_manuscript):
        rv = client.get("/story-doctor/api/checkup")
        data = rv.get_json()
        assert data["ok"] is True
        assert "score" in data["report"]

    def test_sidebar_link_present(self, client):
        rv = client.get("/")
        assert b"/story-doctor/" in rv.data

    def test_heart_pulse_icon_in_sprite(self, client):
        rv = client.get("/")
        assert b'id="i-heart-pulse"' in rv.data

    def test_polish_css_doctor_layer(self, client):
        rv = client.get("/static/css/polish.css")
        assert b".doctor-hero" in rv.data
        assert b".score-arc" in rv.data
        assert b".doctor-rec" in rv.data

    def test_i18n_key_exists(self):
        from services.i18n_service import TRANSLATIONS
        assert "nav.story_doctor" in TRANSLATIONS
        assert set(TRANSLATIONS["nav.story_doctor"].keys()) == {"en", "tr", "es", "fr", "de"}
