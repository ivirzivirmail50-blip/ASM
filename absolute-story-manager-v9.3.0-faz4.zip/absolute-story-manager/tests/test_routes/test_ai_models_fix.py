"""S-04 — /ai/models regression + integration tests.

The route used to call ``ai_service._get_config(None)`` which crashed with
``AttributeError: 'NoneType' object has no attribute 'query'`` whenever AI
was ENABLED (the settings page's model picker 500'd). These tests pin the
fix: enabled → 200 with a mocked provider; disabled → 404 by design
("invisible when AI disabled"), never a 500.
"""
from __future__ import annotations

import pytest


def _enable_ai(monkeypatch, provider="ollama", api_base="http://localhost:11434"):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", provider)
        Setting.set(s, "ai.api_base", api_base)
        Setting.set(s, "ai.model", "llama3")


class _FakeResp:
    def __init__(self, payload):
        self.status_code = 200
        self._payload = payload

    def raise_for_status(self):
        pass

    def json(self):
        return self._payload


class _FakeSession:
    """Stands in for the shared ai_providers requests.Session."""

    def __init__(self, payload):
        self._payload = payload
        self.calls = []

    def request(self, method, url, timeout=None, headers=None, **kwargs):
        self.calls.append((method, url, headers))
        return _FakeResp(self._payload)


class TestAiModelsRoute:
    def test_enabled_ollama_returns_models(self, client, monkeypatch):
        """AI açıkken endpoint 200 dönmeli (eski davranış: 500)."""
        _enable_ai(monkeypatch)
        fake = _FakeSession({"models": [{"name": "llama3"}, {"name": "qwen2"}]})
        monkeypatch.setattr("services.ai_providers._session", fake)
        resp = client.get("/ai/models")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["ok"] is True
        assert sorted(data["models"]) == ["llama3", "qwen2"]
        # v9.2.0 (F-01): Ollama model list comes from GET /api/tags
        assert fake.calls[0][1].endswith("/api/tags")

    def test_enabled_openai_compatible_returns_models(self, client, monkeypatch):
        _enable_ai(monkeypatch, provider="openai",
                   api_base="http://fake:1234/v1")
        fake = _FakeSession({"data": [{"id": "gpt-fake"}, {"id": "glm-fake"}]})
        monkeypatch.setattr("services.ai_providers._session", fake)
        resp = client.get("/ai/models")
        assert resp.status_code == 200
        data = resp.get_json()
        assert sorted(data["models"]) == ["glm-fake", "gpt-fake"]
        # v9.2.0 (F-01): OpenAI-compat model list comes from GET /v1/models
        assert fake.calls[0][1].endswith("/v1/models")

    def test_disabled_returns_404_not_500(self, client):
        """AI kapalıyken tasarım gereği 404 — ama asla 500 değil."""
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", False)
        resp = client.get("/ai/models")
        assert resp.status_code == 404

    def test_service_get_config_none_is_safe(self, fresh_db):
        """The root cause: ``_get_config(None)`` must not crash anymore."""
        from services import ai_service
        cfg = ai_service._get_config(None)   # used to raise AttributeError
        assert cfg["provider"] in ("ollama", "openai", "anthropic", "gemini")
        assert cfg["enabled"] is False
        cfg2 = ai_service._get_config()      # no-arg form used by the route
        assert cfg2["provider"] == cfg["provider"]

    def test_service_get_config_reads_overrides(self, fresh_db):
        from core.db import write_transaction
        from models.settings import Setting
        from services import ai_service
        with write_transaction() as s:
            Setting.set(s, "ai.provider", "openai")
            Setting.set(s, "ai.model", "test-model")
        cfg = ai_service._get_config()
        assert cfg["provider"] == "openai"
        assert cfg["model"] == "test-model"
