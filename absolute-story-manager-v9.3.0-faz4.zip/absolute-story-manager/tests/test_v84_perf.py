"""v8.4 — Performance & Storage tests.

Covers the three pillars:
  1. Deferred content loading (list_chapters with_content=False)
  2. Version retention (auto-prune on save, pinned/v1 survival, limit=0)
  3. Storage service + route (stats, vacuum, checkpoint, prune actions,
     backup retention + WAL-checkpoint-before-zip correctness)
"""
from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from core.db import read_session, write_transaction
from models.chapter import ChapterVersion
from models.settings import Setting

# ---------------------------------------------------------------- helpers

def _set_setting(key: str, value: str) -> None:
    with write_transaction() as s:
        Setting.set(s, key, value)


def _make_chapter(idx: int, words: int = 200) -> str:
    from services import chapter_service
    ch = chapter_service.create_chapter(
        title=f"Bölüm {idx}",
        content=("kelime " * words) + f"bölüm-{idx}",
    )
    return ch.id


# ============================ 1. Deferred content =========================

def test_list_chapters_defers_content_by_default():
    from services import chapter_service
    _make_chapter(1)
    chapters, _ = chapter_service.list_chapters(per_page=10)
    assert len(chapters) == 1
    # Detached instance + deferred column → accessing .content raises.
    # This is the proof that the chapter body never left SQLite.
    with pytest.raises(Exception):
        _ = chapters[0].content


def test_list_chapters_with_content_loads_body():
    from services import chapter_service
    _make_chapter(2)
    chapters, _ = chapter_service.list_chapters(per_page=10,
                                                with_content=True)
    assert "bölüm-2" in (chapters[0].content or "")


def test_list_metadata_survives_without_content():
    """Everything list pages actually render must still be loaded."""
    from services import chapter_service
    ch_id = _make_chapter(3)
    from core.db import read_session
    with read_session() as s:
        from models.chapter import Chapter
        s.get(Chapter, ch_id).synopsis = "Özet metni"
        s.commit()
    chapters, total = chapter_service.list_chapters(per_page=10)
    assert total == 1
    c = chapters[0]
    assert c.title == "Bölüm 3"
    assert c.synopsis == "Özet metni"
    assert c.word_count > 0
    assert c.status == "draft"


def test_reading_api_still_serves_content(client):
    """The reading mode needs full text — with_content=True path."""
    from services import chapter_service
    chapter_service.create_chapter(title="Okuma", content="tam metin burada")
    r = client.get("/reading/api/chapters")
    assert r.status_code == 200
    data = r.get_json()
    assert data["chapters"], "no chapters returned"
    assert "tam metin burada" in data["chapters"][0]["content"]


# ============================ 2. Version retention ========================

def test_version_prune_on_save_keeps_limit_plus_v1():
    from services import chapter_service
    _set_setting("version_history_limit", "5")
    ch_id = _make_chapter(10)
    for i in range(12):
        chapter_service.update_chapter(
            ch_id, content=f"güncelleme {i} " + "kelime " * 50)
    with read_session() as s:
        vnums = [v.version_number for v in s.query(ChapterVersion)
                 .filter_by(chapter_id=ch_id)
                 .order_by(ChapterVersion.version_number).all()]
    # 5 newest + the original v1
    assert len(vnums) == 6
    assert vnums[0] == 1
    assert vnums[-1] == 13  # 1 (create) + 12 updates


def test_version_prune_preserves_pinned():
    from sqlalchemy import text

    from services import chapter_service
    _set_setting("version_history_limit", "3")
    ch_id = _make_chapter(11)
    for i in range(6):
        chapter_service.update_chapter(
            ch_id, content=f"güncelleme {i} " + "kelime " * 30)
    # Pin an old, non-kept version. After 6 updates with limit=3 the
    # survivors are [1, 5, 6, 7] — pin v6, then prune again below.
    with write_transaction() as s:
        s.execute(text(
            "UPDATE chapter_versions SET is_pinned=1 "
            "WHERE chapter_id=:c AND version_number=6"), {"c": ch_id})
    # Force more saves → pruning runs again
    for i in range(100, 103):
        chapter_service.update_chapter(
            ch_id, content=f"daha fazla {i} " + "kelime " * 30)
    with read_session() as s:
        rows = s.query(ChapterVersion).filter_by(chapter_id=ch_id).all()
        vnums = sorted(r.version_number for r in rows)
        pinned = [r.version_number for r in rows if r.is_pinned]
    assert 6 in vnums, "pinned version must survive pruning"
    assert 6 in pinned
    assert 1 in vnums, "original v1 must survive"


def test_version_limit_zero_is_unlimited():
    from services import chapter_service
    _set_setting("version_history_limit", "0")
    ch_id = _make_chapter(12)
    for i in range(8):
        chapter_service.update_chapter(
            ch_id, content=f"güncelleme {i} " + "kelime " * 20)
    with read_session() as s:
        n = s.query(ChapterVersion).filter_by(chapter_id=ch_id).count()
    assert n == 9  # 1 create snapshot + 8 updates — old behaviour


def test_prune_versions_service_and_estimate():
    from services import chapter_service, storage_service
    _set_setting("version_history_limit", "2")
    ch_id = _make_chapter(13)
    for i in range(9):
        chapter_service.update_chapter(
            ch_id, content=f"güncelleme {i} " + "kelime " * 20)
    # sanity: auto-prune already ran on every save
    with read_session() as s:
        live = s.query(ChapterVersion).filter_by(chapter_id=ch_id).count()
    assert live == 3  # 2 newest + v1
    # now raise the limit and prune manually via the service (no-op path)
    _set_setting("version_history_limit", "2")
    result = storage_service.prune_versions(chapter_id=ch_id)
    assert result["deleted"] == 0


def test_default_settings_ship_retention_values():
    from models.settings import DEFAULT_SETTINGS
    assert DEFAULT_SETTINGS.get("version_history_limit") == "25"
    assert DEFAULT_SETTINGS.get("backup_retention_count") == "14"


# ============================ 3. Storage route/service ====================

def test_storage_page_renders(client):
    r = client.get("/storage/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    assert "Storage" in html
    assert "Retention policy" in html
    assert "Optimize (VACUUM)" in html


def test_storage_api_stats_shape(client):
    r = client.get("/storage/api/stats")
    assert r.status_code == 200
    stats = r.get_json()["stats"]
    for key in ("db", "wal", "tables", "versions", "backups", "hints"):
        assert key in stats
    assert stats["db"]["mb"] >= 0
    assert isinstance(stats["hints"], list) and stats["hints"]


def test_storage_action_vacuum_and_checkpoint(client):
    r = client.post("/storage/action", json={"action": "checkpoint"})
    assert r.status_code == 200
    assert r.get_json()["ok"] is True
    r = client.post("/storage/action", json={"action": "vacuum"})
    body = r.get_json()
    assert body["ok"] is True
    assert "reclaimed_mb" in body["result"]
    # fresh stats attached
    assert "stats" in body


def test_storage_action_save_settings(client):
    r = client.post("/storage/action", json={
        "action": "save_settings",
        "version_history_limit": 7,
        "backup_retention_count": 2,
    })
    assert r.status_code == 200
    assert r.get_json()["result"] == {
        "version_history_limit": 7, "backup_retention_count": 2}
    with read_session() as s:
        assert Setting.get(s, "version_history_limit") == "7"
        assert Setting.get(s, "backup_retention_count") == "2"


def test_storage_action_unknown_rejected(client):
    r = client.post("/storage/action", json={"action": "nope"})
    assert r.status_code == 400


def test_storage_stats_hint_when_versions_prunable(client):
    """Seeding versions past the limit surfaces a prunable hint."""
    from services import chapter_service
    _set_setting("version_history_limit", "1")
    ch_id = _make_chapter(20)
    for i in range(5):
        chapter_service.update_chapter(
            ch_id, content=f"g {i} " + "kelime " * 10)
    r = client.get("/storage/api/stats")
    stats = r.get_json()["stats"]
    # Auto-prune already bounded it, but estimate should be 0 → healthy
    # hint or versions_prunable both acceptable; assert hint mechanics.
    keys = [h["key"] for h in stats["hints"]]
    assert any(k in keys for k in ("healthy", "versions_prunable"))


def test_backup_retention_applies_on_create(tmp_path, monkeypatch):
    import time

    from config import Config
    from services import backup_service
    monkeypatch.setattr(Config, "BACKUP_DIR", tmp_path)
    monkeypatch.setattr(Config, "RAW_DIR", tmp_path / "raw")
    _set_setting("backup_retention_count", "3")
    # Backup filenames have 1-second resolution — space them out so
    # each create produces a distinct file (else they overwrite).
    for _ in range(4):
        backup_service.create_backup()
        time.sleep(1.05)
    backups = backup_service.list_backups()
    assert len(backups) == 3, f"expected 3, got {len(backups)}"


def test_backup_contains_latest_write(tmp_path, monkeypatch):
    """v8.4 correctness fix: WAL contents must be IN the backup zip.

    Before the fix, the zip only held the main DB file; recent commits
    still sitting in the -wal file were silently missing from backups.
    """
    from config import Config
    from services import backup_service
    monkeypatch.setattr(Config, "BACKUP_DIR", tmp_path)
    monkeypatch.setattr(Config, "RAW_DIR", tmp_path / "raw")
    from services import chapter_service
    ch = chapter_service.create_chapter(
        title="WAL kanıtı", content="bu metin yedekte olmalı")

    backup_path = backup_service.create_backup()
    with zipfile.ZipFile(backup_path) as zf:
        names = zf.namelist()
        assert "asm.db" in names
    # The chapter row must be readable from the zipped DB alone.
    import sqlite3
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        extracted = Path(td) / "asm.db"
        with zipfile.ZipFile(backup_path) as zf:
            zf.extract("asm.db", td)
        con = sqlite3.connect(extracted)
        try:
            row = con.execute(
                "SELECT title FROM chapters WHERE id = ?", (ch.id,)
            ).fetchone()
            assert row is not None, (
                "chapter missing from backup — WAL data was not "
                "checkpointed before zipping (the v8.4 bug)")
            assert row[0] == "WAL kanıtı"
        finally:
            con.close()


def test_maybe_auto_backup_skips_when_db_unchanged(tmp_path, monkeypatch):
    from config import Config
    from services import backup_service
    monkeypatch.setattr(Config, "BACKUP_DIR", tmp_path)
    monkeypatch.setattr(Config, "RAW_DIR", tmp_path / "raw")
    _set_setting("auto_backup_enabled", "true")
    _set_setting("auto_backup_interval_hours", "0")  # always due
    assert backup_service.maybe_auto_backup() is True  # first run
    assert len(backup_service.list_backups()) == 1
    # DB untouched → second call must skip (no churn)
    assert backup_service.maybe_auto_backup() is False
    assert len(backup_service.list_backups()) == 1


# ============================ 4. DB core ==================================

def test_performance_index_created():
    from sqlalchemy import text

    from core.db import engine
    with engine.connect() as conn:
        row = conn.execute(text(
            "SELECT name FROM sqlite_master WHERE type='index' "
            "AND name='ix_chapter_versions_ch_vnum'"
        )).scalar()
    assert row == "ix_chapter_versions_ch_vnum"


def test_wal_journal_size_limit_pragma():
    from sqlalchemy import text

    from core.db import engine
    with engine.connect() as conn:
        val = conn.execute(text("PRAGMA journal_size_limit")).scalar()
    assert int(val) == 67108864  # 64 MB cap


def test_analytics_streaming_results_unchanged():
    """top_words + manuscript_summary must match pre-v8.4 semantics."""
    from services import analytics_service, chapter_service
    chapter_service.create_chapter(
        title="A", content="deniz fener deniz kule deniz")
    chapter_service.create_chapter(
        title="B", content="fener ışık sabah")
    tw = analytics_service.top_words(limit=10)
    words = {w["word"]: w["count"] for w in tw}
    assert words.get("deniz") == 3
    assert words.get("fener") == 2
    ms = analytics_service.manuscript_summary()
    assert ms["chapter_count"] == 2
    # unique across the WHOLE manuscript (not per-chapter sums).
    # Note: the token regex is ASCII-only (pre-v8.4 semantics preserved),
    # so "ışık" doesn't count — survivors: deniz, fener, kule, sabah.
    assert ms["total_unique_words"] == 4
