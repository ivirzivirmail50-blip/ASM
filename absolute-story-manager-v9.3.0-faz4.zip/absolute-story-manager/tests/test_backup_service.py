"""Tests for backup_service: ZIP backup and restore."""
import os
import zipfile
from pathlib import Path

import pytest

from config import Config
from services import backup_service, chapter_service


class TestCreateBackup:
    def test_create_backup_returns_path(self):
        path = backup_service.create_backup()
        assert path.exists()
        assert path.suffix == ".zip"
        assert path.name.startswith("asm_backup_")

    def test_backup_contains_db(self):
        # Add some data first
        chapter_service.create_chapter(title="Backup Test", content="x")
        path = backup_service.create_backup()
        with zipfile.ZipFile(path, "r") as zf:
            names = zf.namelist()
            assert "asm.db" in names

    def test_backup_contains_raw_files(self):
        """If raw files exist, they should be included."""
        # Create a fake raw file
        raw_dir = Config.RAW_DIR / "test_backup" / "abc123"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (raw_dir / "test.txt").write_bytes(b"test content")
        try:
            path = backup_service.create_backup()
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                assert any("test.txt" in n for n in names)
        finally:
            # Cleanup
            import shutil
            shutil.rmtree(Config.RAW_DIR / "test_backup", ignore_errors=True)

    def test_backup_cleanup(self):
        """Backups should be listable and deletable."""
        path = backup_service.create_backup()
        assert path.exists()
        # Cleanup
        path.unlink(missing_ok=True)


class TestListBackups:
    def test_list_backups_returns_list(self):
        backups = backup_service.list_backups()
        assert isinstance(backups, list)

    def test_list_backups_includes_created(self):
        path = backup_service.create_backup()
        try:
            backups = backup_service.list_backups()
            names = [b["name"] for b in backups]
            assert path.name in names
        finally:
            path.unlink(missing_ok=True)

    def test_list_backups_sorted_newest_first(self):
        """Most recent backup should be first."""
        b1 = backup_service.create_backup()
        import time
        time.sleep(0.1)
        b2 = backup_service.create_backup()
        try:
            backups = backup_service.list_backups()
            if len(backups) >= 2:
                assert backups[0]["mtime"] >= backups[1]["mtime"]
        finally:
            b1.unlink(missing_ok=True)
            b2.unlink(missing_ok=True)


class TestRestoreBackup:
    def test_restore_round_trip(self):
        """Create backup → modify DB → restore → verify."""
        # Create initial data + backup
        ch = chapter_service.create_chapter(title="Before Backup", content="original")
        backup_path = backup_service.create_backup()

        # Modify DB (add another chapter)
        chapter_service.create_chapter(title="After Backup", content="added")

        # Restore
        backup_service.restore_backup(str(backup_path))

        # Verify — restored DB should NOT have "After Backup"
        from sqlalchemy import select

        from core.db import read_session
        from models.chapter import Chapter
        with read_session() as s:
            after_count = s.scalar(
                select(Chapter).where(Chapter.title == "After Backup").count()
            ) if hasattr(select(Chapter).where(Chapter.title == "After Backup"), "count") else 0
            # Simpler: just verify the original chapter exists
            original = s.get(Chapter, ch.id)
            assert original is not None
            assert original.title == "Before Backup"

        # Cleanup
        backup_path.unlink(missing_ok=True)

    def test_restore_nonexistent_fails(self):
        with pytest.raises(FileNotFoundError):
            backup_service.restore_backup("/nonexistent/path.zip")


class TestMaybeAutoBackup:
    def test_returns_false_when_disabled(self):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "auto_backup_enabled", False)
        result = backup_service.maybe_auto_backup()
        assert result is False

    def test_returns_true_when_no_backups_exist(self):
        from core.db import write_transaction
        from models.settings import Setting
        # Clear backups dir
        for f in Config.BACKUP_DIR.glob("asm_backup_*.zip"):
            f.unlink()
        with write_transaction() as s:
            Setting.set(s, "auto_backup_enabled", True)
        result = backup_service.maybe_auto_backup()
        assert result is True
        # Cleanup
        for f in Config.BACKUP_DIR.glob("asm_backup_*.zip"):
            f.unlink()


# ===========================================================================
# v9.0.1 (S-03) — media files in backups & transfers
# ===========================================================================

class TestMediaBackup:
    """S-03: data/media/ (maps, avatars, music) must survive backup+restore."""

    def _make_media(self, rel: str, content: bytes) -> Path:
        p = Config.MEDIA_DIR / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(content)
        return p

    def test_backup_contains_media_files_by_default(self):
        f = self._make_media("maps/s03_map.png", b"\x89PNG-fake-map-data")
        try:
            path = backup_service.create_backup()
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                assert "media/maps/s03_map.png" in names
                assert "media_manifest.txt" in names
                manifest = zf.read("media_manifest.txt").decode()
                assert "media/maps/s03_map.png" in manifest
        finally:
            f.unlink(missing_ok=True)
            path.unlink(missing_ok=True)

    def test_backup_excludes_media_when_setting_off(self):
        from core.db import write_transaction
        from models.settings import Setting
        f = self._make_media("avatars/s03_av.png", b"\x89PNG-fake-avatar")
        with write_transaction() as s:
            Setting.set(s, "backup_include_media", False)
        try:
            path = backup_service.create_backup()
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                assert not any(n.startswith("media/") for n in names)
                assert "media_manifest.txt" not in names
                assert "asm.db" in names  # DB still backed up
        finally:
            with write_transaction() as s:
                Setting.set(s, "backup_include_media", True)
            f.unlink(missing_ok=True)
            path.unlink(missing_ok=True)

    def test_media_backup_round_trip_bite_identical(self):
        """Yedekle → sil → restore → dosya birebir (kabul kriteri)."""
        original = b"\x89PNG-fake-roundtrip-\x00\x01\x02"
        f = self._make_media("maps/s03_roundtrip.png", original)
        path = backup_service.create_backup()
        f.unlink()  # simulate the disk failure
        try:
            backup_service.restore_backup(str(path))
            restored = Config.MEDIA_DIR / "maps" / "s03_roundtrip.png"
            assert restored.exists()
            assert restored.read_bytes() == original
        finally:
            (Config.MEDIA_DIR / "maps" / "s03_roundtrip.png").unlink(
                missing_ok=True)
            path.unlink(missing_ok=True)

    def test_media_manifest_in_transfer_export(self):
        from services import project_transfer_service as pts
        f = self._make_media("music/s03_theme.mp3", b"ID3-fake-audio")
        try:
            data = pts.export_all()
            assert "media_files" in data
            paths = [m["path"] for m in data["media_files"]]
            assert "music/s03_theme.mp3" in paths
            entry = next(m for m in data["media_files"]
                         if m["path"] == "music/s03_theme.mp3")
            assert entry["size"] == len(b"ID3-fake-audio")
            # media_files must not break import_all (unknown key is ignored)
            counts = pts.import_all(data)
            assert isinstance(counts, dict)
        finally:
            f.unlink(missing_ok=True)

    def test_media_bundle_export_import_round_trip(self):
        from services import project_transfer_service as pts
        f = self._make_media("maps/s03_bundle.png", b"\x89PNG-bundle")
        try:
            bundle = pts.export_media_bundle()
            assert bundle.exists()
            # Wipe the file, then re-import the bundle
            f.unlink()
            result = pts.import_media_bundle(bundle)
            assert result["imported"] >= 1
            restored = Config.MEDIA_DIR / "maps" / "s03_bundle.png"
            assert restored.read_bytes() == b"\x89PNG-bundle"
        finally:
            (Config.MEDIA_DIR / "maps" / "s03_bundle.png").unlink(
                missing_ok=True)

    def test_media_bundle_blocks_path_traversal(self):
        """A malicious bundle must not write outside data/media/."""
        import tempfile

        from services import project_transfer_service as pts
        evil = Path(tempfile.mkdtemp()) / "evil.zip"
        with zipfile.ZipFile(evil, "w") as zf:
            zf.writestr("../evil_s03.txt", b"pwned")
            zf.writestr("ok_file.txt", b"fine")
        try:
            result = pts.import_media_bundle(evil)
            assert result["skipped"] == 1
            assert result["imported"] == 1
            assert (Config.MEDIA_DIR / "ok_file.txt").exists()
            assert not (Config.DATA_DIR / "evil_s03.txt").exists()
        finally:
            (Config.MEDIA_DIR / "ok_file.txt").unlink(missing_ok=True)
            evil.unlink(missing_ok=True)
            import shutil
            shutil.rmtree(evil.parent, ignore_errors=True)

    def test_settings_save_accepts_backup_include_media(self, client):
        """The settings route persists the toggle (bool coercion)."""
        resp = client.post("/settings/save",
                           data={"backup_include_media": "true"})
        assert resp.status_code == 200
        from core.db import read_session
        from models.settings import Setting
        with read_session() as s:
            assert Setting.get(s, "backup_include_media", None) is True
        resp = client.post("/settings/save",
                           data={"backup_include_media": "false"})
        assert resp.status_code == 200
        with read_session() as s:
            assert Setting.get(s, "backup_include_media", None) is False
