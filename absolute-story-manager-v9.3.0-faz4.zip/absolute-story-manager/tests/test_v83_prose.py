"""v8.3 tests — Style Coach 2.0 (language-aware prose analysis) + AI Rewrite.

RESEARCH FINDING: the old show-don't-tell analysis counted English words
only ("felt"/"was angry"/"saw") — a Turkish manuscript scored zero telling
AND zero sensory indicators, making the ratio meaningless. Same class of
bug as the v7.7 Turkish Language Engine.

v8.3 adds: TR/EN prose lexicons (telling / sensory / filter / cliché),
sentence-rhythm profiling, word variety, calibrated readability, example
sentences with rewrite targets, and the AI Rewrite Studio endpoints.
"""
import json

import pytest

# ------------------------------------------------------- prose lexicons

class TestProseLexicons:
    def test_tr_telling_hits(self):
        from services.lang_service import find_prose_hits
        hits = find_prose_hits("Aylin korkuyordu ve hissettiği dehşet büyüyordu.", "tr", "telling")
        entries = [h["entry"] for h in hits]
        assert "korkuyo" in entries
        assert "hisset" in entries

    def test_tr_sensory_hits(self):
        from services.lang_service import find_prose_hits
        text = "Kalbi hızlandı, eli titredi. Karanlıkta bir hışırtı duyuldu; koku burnuna geldi."
        entries = [h["entry"] for h in find_prose_hits(text, "tr", "sensory")]
        assert "kalbi hızlandı" in entries          # phrase
        assert "eli titredi" in entries              # phrase
        assert "hışırtı" in entries                  # stem
        assert "koku" in entries

    def test_tr_filter_hits(self):
        from services.lang_service import find_prose_hits
        text = "Gördüğü şey karşısında emindi. Fark etti ki her şey değişmişti."
        entries = [h["entry"] for h in find_prose_hits(text, "tr", "filter")]
        assert "gördü" in entries
        assert "fark et" in entries

    def test_tr_cliche_phrase_match(self):
        from services.lang_service import find_prose_hits
        text = "Derin bir nefes aldı. Zaman durmuş gibiydi."
        entries = [h["entry"] for h in find_prose_hits(text, "tr", "cliche")]
        assert "derin bir nefes aldı" in entries
        assert "zaman durmuş gibi" in entries

    def test_en_phrases_match_as_phrases(self):
        """Regression: .split() used to shatter 'was angry' into 'was'+'angry'."""
        from services.lang_service import find_prose_hits
        hits = find_prose_hits("She was angry and felt a surge of panic.", "en", "telling")
        entries = [h["entry"] for h in hits]
        assert "was angry" in entries
        assert "felt a surge" in entries
        assert "was" not in entries      # must not match every 'was'
        assert "a" not in entries        # …nor every 'a'

    def test_no_etraf_ekti_false_positive(self):
        """Regression: 'fark et'.split() gave stem 'et' matching etraf/etki."""
        from services.lang_service import find_prose_hits
        hits = find_prose_hits("Etrafında ağaçlar vardı. Etkileyici bir manzara.", "tr", "telling")
        assert hits == []
        hits2 = find_prose_hits("Etrafında ağaçlar vardı.", "tr", "filter")
        assert hits2 == []

    def test_offsets_point_into_original(self):
        from services.lang_service import find_prose_hits
        text = "Önce korktu sonra sevindi."
        hits = find_prose_hits(text, "tr", "telling")
        for h in hits:
            assert 0 <= h["offset"] < len(text)

    def test_unknown_category_raises(self):
        from services.lang_service import prose_lexicon
        with pytest.raises(ValueError):
            prose_lexicon("nope", "tr")


# ------------------------------------------------------- style coach 2.0

_TR_CHAPTER = """Aylin korkuyordu. Hissettiği şey tarif edilemez bir dehşetti.
Kalbi hızlandı, eli titredi. Karanlıkta bir hışırtı duydu; kokusu burnuna geldi.
Derin bir nefes aldı ve sustu. Zaman durmuş gibiydi. Sanki her şey sona ermişti.
Odadaki ışık titredi, duvardaki gölgeler uzadı. Soğuk bir rüzgar içeri sızdı.
Aylin ürperdi. İçinde büyüyen bir endişe vardı. Fısıltılar duvarlardan geliyordu.
Acı bir tat ağzında kaldı. Yumuşak ama soğuk bir dokunuş, teninde gezindi."""


@pytest.fixture
def tr_chapter(fresh_db):
    from core.db import write_transaction
    from models.chapter import Chapter
    from services._common import new_uuid
    cid = new_uuid()
    # NOTE: commit BEFORE yielding — a pending (uncommitted) row is silently
    # discarded when a Flask request's init_db() calls SessionLocal.remove().
    with write_transaction() as s:
        s.add(Chapter(id=cid, project_id="default", title="TR Bölüm",
                      sort_order=1, content=_TR_CHAPTER,
                      word_count=len(_TR_CHAPTER.split())))
    yield cid


class TestStyleCoach2:
    def test_tr_report_language_and_counts(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        assert r["ok"] is True
        assert r["language"] == "tr"
        # Turkish text must now produce NON-ZERO analysis (v8.2 bug: all zero)
        assert r["telling"]["count"] >= 3
        assert r["sensory"]["count"] >= 5
        assert r["filter"]["count"] >= 1
        assert r["cliches"]["count"] >= 2
        assert r["show_dont_tell_ratio"] > 0

    def test_rhythm_profile(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        rh = r["sentence_rhythm"]
        assert rh["spark_points"]
        assert 0 < len(rh["spark_points"]) <= 120
        assert rh["variation"] in ("monotonous", "moderate", "varied")
        assert rh["stdev"] >= 0

    def test_word_variety_and_readability(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        assert 0 < r["word_variety"]["ratio"] <= 1
        assert r["word_variety"]["label"] in ("repetitive", "typical", "rich")
        read = r["readability"]
        assert 0 <= read["score"] <= 100
        assert read["label"] in ("very easy", "easy", "moderate", "hard", "very hard")
        # Turkish calibration: this flowing prose must NOT score 0 (the raw
        # Flesch formula scored every Turkish text as unreadable)
        assert read["score"] > 20

    def test_rewrite_targets_capped_and_categorized(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        targets = r["rewrite_targets"]
        assert 1 <= len(targets) <= 8
        for t in targets:
            assert t["category"] in ("telling", "filter", "cliche")
            assert t["sentence"].strip()

    def test_example_sentences_carry_entries(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        for ex in r["telling"]["examples"]:
            assert ex["entries"]
            assert ex["sentence"]

    def test_english_chapter_analyzed(self, fresh_db):
        from core.db import write_transaction
        from models.chapter import Chapter
        from services import lint_service
        from services._common import new_uuid
        content = ("She was angry. She felt a surge of panic as the scent of smoke "
                   "filled the room. Her hands trembled. He realized time stood still.")
        cid = new_uuid()
        with write_transaction() as s:
            s.add(Chapter(id=cid, project_id="default", title="EN Chapter",
                          sort_order=1, content=content, word_count=len(content.split())))
        r = lint_service.style_coach(cid)
        assert r["language"] == "en"
        assert r["telling"]["count"] >= 2
        assert r["cliches"]["count"] >= 1
        assert r["readability"]["score"] > 30

    def test_missing_chapter_and_empty_content(self, fresh_db):
        from services import lint_service
        assert lint_service.style_coach("nope")["ok"] is False

    def test_suggestions_include_new_types(self, tr_chapter):
        from services import lint_service
        r = lint_service.style_coach(tr_chapter)
        types = {s["type"] for s in r["suggestions"]}
        assert "cliche" in types  # 'derin bir nefes aldı' + 'zaman durmuş gibi'


# ------------------------------------------------------- routes + template

class TestStyleCoachRoutes:
    def test_lint_page_has_style_coach_launcher(self, client, tr_chapter):
        r = client.get("/lint/")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert "Style Coach 2.0" in html
        assert f"/lint/style-coach/{tr_chapter}" in html

    def test_style_coach_page_renders(self, client, tr_chapter):
        r = client.get(f"/lint/style-coach/{tr_chapter}")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert "scLangBadge" in html
        assert "sc-sparkline" in html
        assert "Telling indicators" in html
        assert "Filter words" in html
        assert "Sensory detail" in html
        assert "Cliché radar" in html

    def test_ai_studio_hidden_when_ai_off(self, client, tr_chapter):
        r = client.get(f"/lint/style-coach/{tr_chapter}")
        assert "AI Rewrite Studio" not in r.get_data(as_text=True)

    def test_rewrite_stream_ai_disabled_error(self, client, tr_chapter):
        r = client.post("/lint/style-rewrite-stream", json={
            "chapter_id": tr_chapter, "sentence": "Aylin korkuyordu.",
            "category": "telling", "lang": "tr"})
        assert r.status_code == 200
        events = [json.loads(l[6:]) for l in
                  r.get_data(as_text=True).split("\n") if l.startswith("data: ")]
        assert events and events[0]["type"] == "error"

    def test_rewrite_apply_validations(self, client, tr_chapter):
        # missing chapter id
        r = client.post("/lint/style-rewrite-apply", json={"original": "x", "replacement": "y"})
        assert r.status_code == 400
        # unknown chapter
        r = client.post("/lint/style-rewrite-apply", json={
            "chapter_id": "ghost", "original": "x", "replacement": "y"})
        assert r.status_code in (400, 404)
        # empty replacement
        r = client.post("/lint/style-rewrite-apply", json={
            "chapter_id": tr_chapter, "original": "Aylin", "replacement": "  "})
        assert r.status_code == 400
        # oversize original
        r = client.post("/lint/style-rewrite-apply", json={
            "chapter_id": tr_chapter, "original": "x" * 700, "replacement": "y"})
        assert r.status_code == 400
        # stale original → 409 conflict
        r = client.post("/lint/style-rewrite-apply", json={
            "chapter_id": tr_chapter, "original": "BU CÜMLE YOK", "replacement": "yeni"})
        assert r.status_code == 409

    def test_rewrite_apply_creates_version_snapshot(self, client, tr_chapter):
        from core.db import read_session
        from models.chapter import Chapter, ChapterVersion
        sentence = "Derin bir nefes aldı ve sustu."
        with read_session() as s:
            assert sentence in (s.get(Chapter, tr_chapter).content or "")
        r = client.post("/lint/style-rewrite-apply", json={
            "chapter_id": tr_chapter,
            "original": sentence,
            "replacement": "Nefesini yarıda kesti; odada yalnızca fenerin çıtırtısı kaldı.",
        })
        assert r.status_code == 200
        assert r.get_json()["ok"] is True
        with read_session() as s:
            assert "Nefesini yarıda kesti" in (s.get(Chapter, tr_chapter).content or "")
            assert s.query(ChapterVersion).filter_by(chapter_id=tr_chapter).count() >= 1

    def test_routes_registered(self, app):
        rules = {str(r) for r in app.url_map.iter_rules()}
        assert "/lint/style-rewrite-stream" in rules
        assert "/lint/style-rewrite-apply" in rules


# ------------------------------------------------------- static assets

class TestStyleCoachAssets:
    def test_static_js_exists_and_is_node_clean(self):
        import shutil
        import subprocess
        import tempfile
        path = "static/js/style_coach.js"
        node = shutil.which("node")
        if not node:
            pytest.skip("node unavailable")
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                         encoding="utf-8") as f:
            f.write(open(path, encoding="utf-8").read())
            tmp = f.name
        out = subprocess.run([node, "--check", tmp], capture_output=True)
        assert out.returncode == 0, out.stderr

    def test_polish_css_has_sc_layer(self):
        css = open("static/css/polish.css", encoding="utf-8").read()
        assert ".sc-sparkline" in css
        assert ".sc-rewrite-result" in css
        assert ".sc-target" in css

    def test_no_inline_jinja_script_in_style_coach_template(self):
        """v7.5 architecture: page JS lives in a static file, not inline."""
        import re
        html = open("templates/style_coach.html", encoding="utf-8").read()
        inline = re.findall(
            r'<script(?![^>]*\bsrc=)(?![^>]*type=["\']application/json["\'])[^>]*>(.*?)</script>',
            html, re.S)
        assert inline == []
