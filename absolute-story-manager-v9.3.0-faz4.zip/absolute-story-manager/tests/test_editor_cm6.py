"""F-03 — editor modernization: EasyMDE → CodeMirror 6 (v9.2.0).

Pins the acceptance criteria of the Faz 3 F-03 card:
- CodeMirror 6 bundle vendored (built locally, committed; npm never needed
  at runtime), declared in MANIFEST + fetch_vendor
- feature flag (editor.engine: codemirror default, easymde rollback) —
  the two engines live side by side for an easy escape hatch
- ONE integration point: chapter_editor.js stays engine-agnostic via the
  EasyMDE-compatible object returned by AsmCM6Editor.create()
- functional parity (the 28-item list below)
- the existing editor page flow keeps passing (edit.html E2E render with
  both engines, data contract, no inline JS)
- preview is server-rendered through the single md_to_html pipeline
- bundle size reported (and capped, so dependency bloat fails CI)
"""
from __future__ import annotations

import gzip
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / "static" / "vendor" / "codemirror" / "codemirror.bundle.min.js"
CM6_JS = ROOT / "static" / "js" / "cm6_editor.js"
CH_EDITOR = ROOT / "static" / "js" / "chapter_editor.js"
EDIT_HTML = ROOT / "templates" / "chapters" / "edit.html"
MANIFEST = ROOT / "static" / "vendor" / "MANIFEST.txt"


def _node_check(path: Path) -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("node not available")
    r = subprocess.run([node, "--check", str(path)],
                       capture_output=True, text=True)
    assert r.returncode == 0, f"node --check failed for {path.name}: {r.stderr}"


# ---------------------------------------------------------------------------
# The 28-item functional parity list (kabul kriteri)
# ---------------------------------------------------------------------------

PARITY_ITEMS = [
    # API surface used by chapter_editor.js (EasyMDE-compatible)
    "value() get / value(text) set", "codemirror.on('change')",
    "execCommand('find')", "execCommand('replace')",
    # toolbar: formatting
    "bold", "italic", "heading", "quote", "unordered-list", "ordered-list",
    "link", "image", "code", "table",
    # toolbar: modes
    "preview", "side-by-side", "fullscreen",
    # toolbar: help
    "shortcuts-help", "guide",
    # toolbar: AI actions (only when ai.enabled — parity with EasyMDE setup)
    "ai-continue", "ai-continue-context", "ai-summarize", "ai-tags",
    # status bar
    "statusbar lines/words/cursor",
    # behavior
    "spellcheck", "tabSize 4", "minHeight 400px", "autofocus",
]


class TestFunctionalParity28:

    def test_parity_list_complete(self):
        """28 maddelik parite listesi — tamamı tanımlı ve kapsanıyor."""
        assert len(PARITY_ITEMS) == 28
        src = CM6_JS.read_text(encoding="utf-8")

        # toolbar commands — each button id exists in cm6_editor.js
        button_ids = [
            "bold", "italic", "heading", "quote", "unordered-list",
            "ordered-list", "link", "image", "code", "table", "find",
            "replace", "preview", "side-by-side", "fullscreen",
            "shortcuts-help", "guide",
        ]
        for bid in button_ids:
            assert f'id: "{bid}"' in src, f"toolbar button missing: {bid}"

        # AI actions consumed from the shared EasyMDE-shaped array
        for cls in ("ai-btn-continue", "ai-btn-context",
                    "ai-btn-summarize", "ai-btn-tags"):
            assert cls in src, f"AI action wiring missing: {cls}"

        # EasyMDE-compatible API
        assert "value(text)" in src or "value(text " in src
        assert "execCommand(cmd)" in src
        assert '"change"' in src
        # statusbar stats
        for stat in ("lines", "words", "cursor"):
            assert f'"{stat}"' in src or f"data-stat=\"{stat}\"" in src
        # behavior knobs
        assert "spellcheck" in src
        assert "tabSize" in src  # passed through to createMarkdownEditor
        # minHeight 400px: set by the bundle theme AND the page CSS
        assert "400px" in BUNDLE.read_text(encoding="utf-8")
        css = (ROOT / "static" / "css" / "main.css").read_text(encoding="utf-8")
        assert "min-height:400px" in css.replace(" ", "")
        assert "focus()" in src

    def test_engine_dispatch_in_chapter_editor(self):
        """Tek entegrasyon noktası: chapter_editor.js motor-bağımsız."""
        src = CH_EDITOR.read_text(encoding="utf-8")
        assert "AsmCM6Editor.create(" in src
        assert 'ED.editorEngine !== "easymde"' in src
        assert "new EasyMDE({" in src  # rollback engine still present
        # AI toolbar items shared by both engines
        assert "aiToolbarItems" in src
        assert "aiActions: aiToolbarItems" in src

    def test_cm6_editor_js_syntax_valid(self):
        _node_check(CM6_JS)

    def test_chapter_editor_js_syntax_valid(self):
        _node_check(CH_EDITOR)

    def test_bundle_syntax_valid(self):
        _node_check(BUNDLE)


# ---------------------------------------------------------------------------
# Vendor bundle + manifest + size report
# ---------------------------------------------------------------------------

class TestVendorBundle:

    def test_bundle_exists_and_sane_size(self):
        assert BUNDLE.exists(), "codemirror.bundle.min.js missing — run scripts/build_cm6.sh"
        size = BUNDLE.stat().st_size
        assert 100_000 < size < 700_000, (
            f"bundle size {size} outside the sane window "
            "(dependency bloat?) — update the report in CHANGELOG if intended")

    def test_bundle_exposes_asmcm_factory(self):
        src = BUNDLE.read_text(encoding="utf-8")
        assert "createMarkdownEditor" in src
        assert "ASMCM" in src

    def test_bundle_size_report_vs_easymde(self):
        """Kabul kriteri: bundle boyutu öncesi/sonrası RAPORLANMIŞ.

        EasyMDE (archived): 326,569 B js + 12,923 B css = 339,492 B
        CodeMirror 6 (this build, no nested code-language parsers):
        see the numbers below — asserted within ±15% of the recorded value
        so a silent re-build with different deps cannot slip in.
        """
        easymde = (ROOT / "static/vendor/easymde/easymde.min.js").stat().st_size
        easymde += (ROOT / "static/vendor/easymde/easymde.min.css").stat().st_size
        cm6 = BUNDLE.stat().st_size
        gz = len(gzip.compress(BUNDLE.read_bytes()))
        print(f"\n[F-03 bundle report] EasyMDE={easymde:,} B | "
              f"CM6={cm6:,} B (gzip {gz:,} B)")
        # recorded at build time (2026-09): 360,094 B
        assert abs(cm6 - 360_094) <= 360_094 * 0.15

    def test_manifest_declares_bundle(self):
        manifest = MANIFEST.read_text(encoding="utf-8")
        assert "codemirror/codemirror.bundle.min.js" in manifest
        assert "local:scripts/build_cm6.sh" in manifest

    def test_fetch_vendor_knows_local_build(self):
        src = (ROOT / "scripts" / "fetch_vendor.py").read_text(encoding="utf-8")
        assert 'url.startswith("local:")' in src
        assert "local:scripts/build_cm6.sh" in src

    def test_build_script_exists(self):
        build = ROOT / "scripts" / "build_cm6.sh"
        assert build.exists()
        r = subprocess.run(["bash", "-n", str(build)],
                           capture_output=True, text=True)
        assert r.returncode == 0


# ---------------------------------------------------------------------------
# Feature flag — engines live side by side
# ---------------------------------------------------------------------------

@pytest.fixture()
def chapter(fresh_db):
    from services import chapter_service
    return chapter_service.create_chapter(
        title="CM6 E2E", content="deneme içerik", target_word_count=100)


class TestFeatureFlag:

    def test_default_engine_is_codemirror(self, client, chapter):
        """Varsayılan: yeni motor — EasyMDE yok, CM6 paketi var."""
        r = client.get(f"/chapters/{chapter.id}/edit")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert "codemirror.bundle.min.js" in html
        assert "cm6_editor.js" in html
        assert "easymde.min.js" not in html
        assert "easymde.min.css" not in html

    def test_data_block_carries_engine(self, client, chapter):
        r = client.get(f"/chapters/{chapter.id}/edit")
        html = r.get_data(as_text=True)
        m = re.search(
            r'<script type="application/json" id="editor-data">(.*?)</script>',
            html, re.S)
        assert m
        data = json.loads(m.group(1))
        assert data["editorEngine"] == "codemirror"
        assert data["chapterId"] == chapter.id

    def test_easymde_rollback_flag(self, client, chapter):
        """editor.engine=easymde → eski motor yüklenir (geri dönüş yolu)."""
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "editor.engine", "easymde")
        r = client.get(f"/chapters/{chapter.id}/edit")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert "easymde.min.js" in html
        assert "easymde.min.css" in html
        assert "codemirror.bundle.min.js" not in html
        m = re.search(
            r'<script type="application/json" id="editor-data">(.*?)</script>',
            html, re.S)
        assert json.loads(m.group(1))["editorEngine"] == "easymde"

    def test_settings_page_offers_engine_choice(self, client):
        r = client.get("/settings/")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert 'name="editor.engine"' in html
        assert 'value="codemirror"' in html
        assert 'value="easymde"' in html


# ---------------------------------------------------------------------------
# Server-rendered preview (single markdown pipeline)
# ---------------------------------------------------------------------------

class TestPreviewEndpoint:

    def test_preview_renders_markdown(self, client):
        r = client.post("/chapters/preview-md",
                        json={"content": "# Başlık\n\n**kalın** ve `kod`"})
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] is True
        assert "<h1" in data["html"]
        assert "<strong>kalın</strong>" in data["html"]
        assert "<code>kod</code>" in data["html"]

    def test_preview_empty_content(self, client):
        r = client.post("/chapters/preview-md", json={"content": ""})
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

    def test_preview_hard_caps_content(self, client):
        r = client.post("/chapters/preview-md",
                        json={"content": "x" * 600_000})
        assert r.status_code == 200  # capped, not exploded

    def test_cm6_preview_uses_endpoint(self):
        src = CM6_JS.read_text(encoding="utf-8")
        assert "/chapters/preview-md" in src


# ---------------------------------------------------------------------------
# No inline executable JS (M-06 rule still holds)
# ---------------------------------------------------------------------------
