"""F-07 — erişilebilirlik paketi testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * Modal bileşeni: role=dialog, aria-modal, aria-labelledby, kapatma
    düğmesinde aria-label, data-static-modal
  * core.js: odak tuzağı (Tab döngüsü, ESC kapama) asmA11y altında
  * Etiket eşleşmesi: görünür alanlarda for=id kapsamı kodmod öncesi
    %66 iken anlamlı ölçüde yükselir; hiçbir for boşa gitmez
    (köprüsüz for = olmayan id'ye bağ)
"""
from __future__ import annotations

import re
import sys
from html.parser import HTMLParser
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


class _FieldScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.labels: dict[str, int] = {}
        self.inputs: list[tuple[str, str | None, bool]] = []
        self._in_script = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "script":
            self._in_script = True
            return
        if self._in_script:
            return
        if tag == "label" and a.get("for"):
            self.labels[a["for"]] = self.labels.get(a["for"], 0) + 1
        if tag in ("input", "select", "textarea"):
            if a.get("type") == "hidden":
                return
            # aria-label counts as a programmatic label (F-07)
            self.inputs.append((tag, a.get("id"), bool(a.get("aria-label"))))

    def handle_endtag(self, tag):
        if tag == "script":
            self._in_script = False


def _scan_all():
    stats = {"total": 0, "with_id": 0, "labeled": 0, "dangling_for": 0}
    per_file: dict[str, int] = {}
    for f in (PROJECT_ROOT / "templates").rglob("*.html"):
        src = f.read_text(encoding="utf-8", errors="replace")
        # Jinja blokları + JS şablon stringlerinin yaşadığı script blokları
        src = re.sub(r"<script\b.*?</script>", "", src, flags=re.S | re.I)
        src = re.sub(r"\{[%{].*?[%}]\}", "", src, flags=re.S)
        p = _FieldScan()
        try:
            p.feed(src)
        except Exception:
            continue
        ids = set(p.labels)
        field_ids: set[str] = set()
        for _tag, fid, _aria in p.inputs:
            stats["total"] += 1
            if fid:
                field_ids.add(fid)
                stats["with_id"] += 1
        for _tag, fid, has_aria in p.inputs:
            if fid and (fid in ids or has_aria):
                stats["labeled"] += 1
        for f_for in p.labels:
            if f_for not in field_ids:
                stats["dangling_for"] += 1
        missing = sum(1 for _t, fid, _a in p.inputs if not fid)
        if missing:
            per_file[str(f.name)] = missing
    return stats, per_file


class TestModalA11y:

    def test_modal_component_has_aria(self):
        src = (PROJECT_ROOT / "templates" / "components" / "modal.html"
               ).read_text(encoding="utf-8")
        assert 'role="dialog"' in src
        assert 'aria-modal="true"' in src
        assert "aria-labelledby" in src
        assert 'aria-label="Close dialog"' in src
        assert "data-static-modal" in src

    def test_core_js_has_focus_trap(self):
        src = (PROJECT_ROOT / "static" / "js" / "core.js").read_text(
            encoding="utf-8")
        assert "window.asmA11y" in src
        assert 'addEventListener("keydown"' in src
        assert "stopImmediatePropagation" in src
        assert "Escape" in src


class TestLabelCoverage:

    def test_label_id_coverage_improved(self):
        stats, per_file = _scan_all()
        # kodmod öncesi: 340 alan / 228 id'siz (%33 id'li). Sınır: %60 üzeri.
        coverage = stats["with_id"] / stats["total"]
        assert coverage >= 0.60, f"id coverage too low: {coverage:.2f}"
        # etiketli alan oranı (öncesi ~%30): Jinja döngüleri içindeki alanlar
        # bilinçli olarak atlandı — id çoğaltmak HTML'i bozardı.
        labeled_ratio = stats["labeled"] / stats["total"]
        assert labeled_ratio >= 0.52, f"label ratio too low: {labeled_ratio:.2f}"

    def test_no_dangling_for(self):
        stats, _ = _scan_all()
        assert stats["dangling_for"] == 0, \
            f"{stats['dangling_for']} label for= points to a non-field id"

    def test_settings_page_fully_labeled(self):
        src = (PROJECT_ROOT / "templates" / "settings.html").read_text(
            encoding="utf-8")
        src = re.sub(r"<script\b.*?</script>", "", src, flags=re.S | re.I)
        src = re.sub(r"\{[%{].*?[%}]\}", "", src, flags=re.S)
        p = _FieldScan()
        p.feed(src)
        unlabeled = [fid for _t, fid, has_aria in p.inputs
                     if fid and fid not in p.labels and not has_aria]
        assert not unlabeled, f"settings.html unlabeled ids: {unlabeled}"


class TestAriaExpandedPattern:

    def test_quickswitch_button_aria(self):
        src = (PROJECT_ROOT / "templates" / "base.html").read_text(
            encoding="utf-8")
        assert 'aria-expanded="false"' in src
        assert 'aria-haspopup="menu"' in src
        # JS tarafı durumu güncelliyor
        assert 'setAttribute("aria-expanded"' in src
