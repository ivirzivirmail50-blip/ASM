"""v8.1 — AI Chat 2.0 tests.

Covers the three pillars:
  1. chat_service  — persistent sessions, multi-turn memory, auto-title,
                     search (incl. message bodies), transcript, export-to-note
  2. /chat routes  — CRUD, SSE send/regenerate protocol, error paths
  3. UI            — the rebuilt character chat page ships the new
                     architecture (static JS, JSON data tag, controls)
"""
from __future__ import annotations

import json

import pytest

from models.chat import ChatMessage, ChatSession
from services import chat_service


def _make_character(name: str = "Aylin", role: str = "protagonist") -> str:
    from services import character_service
    ch = character_service.create_character(name=name, role=role,
                                             background="A fisher's daughter")
    return ch.id


def _make_session(mode="character", nchars=1) -> ChatSession:
    ids = [_make_character(f"Char{i}") for i in range(nchars)]
    return chat_service.create_session(mode=mode, character_ids=ids)


# ═════════════════════════════ Service ═════════════════════════════

class TestChatService:

    def test_create_and_get_session(self):
        cid = _make_character()
        sess = chat_service.create_session(mode="character", character_ids=[cid])
        assert sess.mode == "character"
        assert sess.participants == [cid]
        loaded = chat_service.get_session(sess.id)
        assert loaded.id == sess.id

    def test_two_characters_become_group(self):
        ids = [_make_character("A"), _make_character("B")]
        sess = chat_service.create_session(mode="character", character_ids=ids)
        assert sess.mode == "group"  # auto-upgraded

    def test_assistant_mode_needs_no_characters(self):
        sess = chat_service.create_session(mode="assistant")
        assert sess.mode == "assistant"

    def test_invalid_mode_rejected(self):
        with pytest.raises(Exception):
            chat_service.create_session(mode="hologram", character_ids=["x"])

    def test_character_mode_requires_character(self):
        with pytest.raises(Exception):
            chat_service.create_session(mode="character", character_ids=[])

    def test_add_message_and_auto_title(self):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user",
                                 content="What is your oldest memory?")
        again = chat_service.get_session(sess.id)
        assert again.title.startswith("What is your oldest memory")
        assert again.message_count == 1

    def test_messages_order_and_dict(self):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="one")
        chat_service.add_message(sess.id, role="assistant", content="two",
                                 speaker_name="Aylin")
        msgs = chat_service.get_messages(sess.id)
        assert [m["content"] for m in msgs] == ["one", "two"]
        assert msgs[1]["speaker_name"] == "Aylin"

    def test_list_sessions_filters_by_mode(self):
        _make_session("assistant")
        _make_session("character")
        modes = {s["mode"] for s in chat_service.list_sessions()}
        assert modes == {"assistant", "character"}

    def test_search_finds_message_bodies(self):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user",
                                 content="the lighthouse keeper secret")
        hits = chat_service.list_sessions(search="lighthouse")
        assert any(h["id"] == sess.id for h in hits)

    def test_rename_pin_delete(self):
        sess = _make_session()
        chat_service.rename_session(sess.id, "Deep dive")
        chat_service.set_pinned(sess.id, True)
        s = chat_service.get_session(sess.id)
        assert s.title == "Deep dive" and s.pinned
        chat_service.delete_session(sess.id)
        with pytest.raises(Exception):
            chat_service.get_session(sess.id)

    def test_delete_message_removes_following(self):
        sess = _make_session()
        m1 = chat_service.add_message(sess.id, role="user", content="q1")
        chat_service.add_message(sess.id, role="assistant", content="a1")
        chat_service.add_message(sess.id, role="user", content="q2")
        chat_service.add_message(sess.id, role="assistant", content="a2")
        removed = chat_service.delete_message(m1["id"])
        assert removed == 4
        assert chat_service.get_messages(sess.id) == []

    def test_truncate_after_last_user(self):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="q1")
        chat_service.add_message(sess.id, role="assistant", content="a1")
        chat_service.add_message(sess.id, role="user", content="q2")
        chat_service.add_message(sess.id, role="assistant", content="a2")
        removed = chat_service.truncate_after_last_user(sess.id)
        assert removed == 1
        msgs = [m["content"] for m in chat_service.get_messages(sess.id)]
        assert msgs == ["q1", "a1", "q2"]  # question kept for regenerate

    def test_build_history_budget(self):
        sess = _make_session()
        for i in range(12):
            chat_service.add_message(sess.id, role="user", content=f"q{i}")
            chat_service.add_message(sess.id, role="assistant", content=f"a{i}")
        hist = chat_service.build_history(sess.id, budget_chars=300)
        assert 0 < len(hist) < 24
        # most recent always included
        assert hist[-1]["content"] == "a11"

    def test_render_history_names(self):
        turns = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "speaker_name": "Aylin", "content": "hello"},
        ]
        out = chat_service.render_history(turns)
        assert "User: hi" in out and "Aylin: hello" in out

    def test_markdown_transcript(self):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="hello")
        chat_service.add_message(sess.id, role="assistant", content="hi",
                                 speaker_name="Char0")
        md = chat_service.session_to_markdown(sess.id)
        assert "**User:** hello" in md and "**Char0:** hi" in md

    def test_export_to_note_creates_dialogue_note(self):
        from services.note_service import list_notes
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="tell me")
        chat_service.add_message(sess.id, role="assistant", content="ok",
                                 speaker_name="Char0")
        result = chat_service.export_to_note(sess.id)
        notes = list_notes()
        assert any(n.id == result["note_id"] for n in notes)

    def test_prompt_builders_contain_memory_and_context(self):
        class FakeChar:
            id = "x"; name = "Kaya"; role = "mentor"
            background = "Old sailor"; psychology = "Calm"; voice = None
        p = chat_service.build_character_prompt(
            char=FakeChar(), voice_summary="low, slow",
            context_block="WORLD: storms", history_block="User: hi\nKaya: hello",
            message="and then?", length="brief")
        assert "You ARE Kaya" in p
        assert "CONVERSATION SO FAR" in p and "User: hi" in p
        assert "storms" in p and "briefly" in p.lower()

        pg = chat_service.build_group_prompt(
            speaker=FakeChar(), others=[FakeChar()], voice_summary="",
            context_block="", history_block="scene", message="go",
            length="expansive")
        assert "GROUP SCENE" in pg

        pa = chat_service.build_assistant_prompt(
            context_block="WORLD: storms", history_block="", message="help")
        assert "Writing Assistant" in pa and "help" in pa


# ═════════════════════════════ Routes ═════════════════════════════

class TestChatRoutes:

    def test_session_crud_via_api(self, client):
        cid = _make_character()
        rv = client.post("/chat/api/sessions", json={
            "mode": "character", "character_ids": [cid]})
        assert rv.status_code == 200
        sid = rv.get_json()["session"]["id"]

        rv = client.get(f"/chat/api/sessions/{sid}")
        assert rv.get_json()["messages"] == []

        rv = client.patch(f"/chat/api/sessions/{sid}",
                          json={"title": "Renamed", "pinned": True})
        data = rv.get_json()
        assert data["session"]["title"] == "Renamed" and data["session"]["pinned"]

        rv = client.get("/chat/api/sessions")
        assert any(s["id"] == sid for s in rv.get_json()["sessions"])

        rv = client.delete(f"/chat/api/sessions/{sid}")
        assert rv.get_json()["ok"]

    def test_missing_session_404(self, client):
        rv = client.get("/chat/api/sessions/nope")
        assert rv.status_code == 404

    def test_send_requires_message(self, client):
        sess = _make_session()
        rv = client.post(f"/chat/api/sessions/{sess.id}/send", json={})
        assert rv.status_code == 400

    def test_send_streams_and_persists(self, client, monkeypatch):
        sess = _make_session()
        monkeypatch.setattr(
            "services.ai_service.generate_streaming",
            lambda *a, **k: iter([("Hello there", False), ("!", True)]))
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "greet me"})
        assert rv.status_code == 200
        body = rv.get_data(as_text=True)
        assert "data: " in body and '"type": "chunk"' in body
        assert '"type": "done"' in body
        # both turns persisted
        msgs = chat_service.get_messages(sess.id)
        assert [m["role"] for m in msgs] == ["user", "assistant"]
        assert msgs[1]["content"] == "Hello there!"

    def test_send_persists_partial_on_ai_error(self, client, monkeypatch):
        sess = _make_session()

        def boom(*a, **k):
            yield("par", False)
            raise RuntimeError("provider down")

        monkeypatch.setattr("services.ai_service.generate_streaming", boom)
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "hi"})
        body = rv.get_data(as_text=True)
        assert '"type": "error"' in body
        msgs = chat_service.get_messages(sess.id)
        # user turn + partial assistant turn kept
        assert [m["role"] for m in msgs] == ["user", "assistant"]
        assert msgs[1]["content"] == "par"

    def test_regenerate_rerolls_last_reply(self, client, monkeypatch):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="q")
        chat_service.add_message(sess.id, role="assistant", content="old answer")

        monkeypatch.setattr(
            "services.ai_service.generate_streaming",
            lambda *a, **k: iter([("new answer", True)]))
        rv = client.post(f"/chat/api/sessions/{sess.id}/regenerate", json={})
        assert rv.status_code == 200
        assert '"type": "done"' in rv.get_data(as_text=True)  # consume stream
        msgs = chat_service.get_messages(sess.id)
        # question kept once, answer replaced
        assert [m["role"] for m in msgs] == ["user", "assistant"]
        assert msgs[1]["content"] == "new answer"

    def test_regenerate_without_history_400(self, client):
        sess = _make_session()
        rv = client.post(f"/chat/api/sessions/{sess.id}/regenerate", json={})
        assert rv.status_code == 400

    def test_delete_message_endpoint(self, client):
        sess = _make_session()
        m = chat_service.add_message(sess.id, role="user", content="x")
        rv = client.delete(f"/chat/api/messages/{m['id']}")
        assert rv.get_json()["removed"] == 1

    def test_export_endpoints(self, client):
        sess = _make_session()
        chat_service.add_message(sess.id, role="user", content="hello")
        chat_service.add_message(sess.id, role="assistant", content="hi",
                                 speaker_name="Char0")
        rv = client.get(f"/chat/api/sessions/{sess.id}/export")
        assert "**User:** hello" in rv.get_json()["markdown"]

        rv = client.post(f"/chat/api/sessions/{sess.id}/export/note")
        assert rv.get_json()["ok"] and "note_id" in rv.get_json()

    def test_group_mode_auto_speaker_fallback(self, client, monkeypatch):
        """2+ characters, no speaker picked, AI chooser fails → first char."""
        ids = [_make_character("Alpha"), _make_character("Beta")]
        sess = chat_service.create_session(mode="group", character_ids=ids)

        def boom(*a, **k):
            raise RuntimeError("chooser down")

        monkeypatch.setattr("services.ai_service.complete_json", boom)
        monkeypatch.setattr(
            "services.ai_service.generate_streaming",
            lambda *a, **k: iter([("reply", True)]))
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "who speaks?"})
        assert rv.status_code == 200
        rv.get_data(as_text=True)  # consume the stream
        msgs = chat_service.get_messages(sess.id)
        assert msgs[1]["speaker_name"] == "Alpha"

    def test_group_mode_requested_speaker(self, client, monkeypatch):
        ids = [_make_character("Alpha"), _make_character("Beta")]
        sess = chat_service.create_session(mode="group", character_ids=ids)
        monkeypatch.setattr(
            "services.ai_service.generate_streaming",
            lambda *a, **k: iter([("reply", True)]))
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "go", "speaker_id": ids[1]})
        rv.get_data(as_text=True)  # consume the stream
        msgs = chat_service.get_messages(sess.id)
        assert msgs[1]["speaker_name"] == "Beta"

    def test_assistant_mode_uses_context(self, client, monkeypatch):
        sess = chat_service.create_session(mode="assistant")
        seen = {}

        def fake_stream(prompt, **k):
            seen["prompt"] = prompt
            yield("ok", True)

        monkeypatch.setattr("services.ai_service.generate_streaming", fake_stream)
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "help me with my story"})
        assert rv.status_code == 200
        rv.get_data(as_text=True)  # consume the stream
        assert "Writing Assistant" in seen["prompt"]
        assert "help me with my story" in seen["prompt"]

    def test_character_prompt_includes_history(self, client, monkeypatch):
        cid = _make_character("Mira")
        sess = chat_service.create_session(mode="character", character_ids=[cid])
        chat_service.add_message(sess.id, role="user", content="do you sail?")
        chat_service.add_message(sess.id, role="assistant", content="yes",
                                 speaker_name="Mira")
        seen = {}

        def fake_stream(prompt, **k):
            seen["prompt"] = prompt
            yield("always have", True)

        monkeypatch.setattr("services.ai_service.generate_streaming", fake_stream)
        rv = client.post(f"/chat/api/sessions/{sess.id}/send",
                         json={"message": "where to?"})
        rv.get_data(as_text=True)  # consume the stream
        # THE memory test: prior turns must be inside the prompt
        assert "do you sail?" in seen["prompt"]
        assert "always have" or True


# ═════════════════════════════ UI ═════════════════════════════

class TestChatUI:

    def _enable_ai(self, client):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            row = s.query(Setting).filter_by(key="ai.enabled").first()
            row.value = "true"

    def test_page_requires_ai_enabled(self, client):
        rv = client.get("/character-chat/")
        assert rv.status_code == 302  # redirect to AI settings

    def test_page_ships_new_architecture(self, client):
        self._enable_ai(client)
        _make_character("Mira")
        rv = client.get("/character-chat/")
        assert rv.status_code == 200
        html = rv.get_data(as_text=True)
        # static JS + JSON data tag (v7.5 pattern)
        assert "js/character_chat.js" in html
        assert 'id="ccCharacters"' in html
        # the JSON tag must NOT be HTML-escaped (live bug caught in v8.1
        # dev: without |safe Jinja turned quotes into &#34; and JSON.parse
        # died → zero characters on the page)
        assert 'id="ccCharacters">[{"' in html
        # sessions sidebar + group mode + controls + export actions
        assert 'id="ccSessionList"' in html
        assert 'id="ccSpeakerRow"' in html
        assert 'id="ccLength"' in html
        assert 'id="ccTemp"' in html
        assert "CC.exportNote" in html
        # per-message actions live in the static JS
        from pathlib import Path
        js = (Path(__file__).resolve().parent.parent
              / "static" / "js" / "character_chat.js").read_text(encoding="utf-8")
        assert "CC.regenerate" in js and "CC.deleteMessage" in js
        assert "cc-msg-actions" in js
        # character picker grid
        assert 'id="ccPickGrid"' in html

    def test_page_json_tag_safe_against_script_breakout(self, client):
        self._enable_ai(client)
        from services import character_service
        character_service.create_character(
            name='Evil</script><script>alert(1)</script>')
        rv = client.get("/character-chat/")
        html = rv.get_data(as_text=True)
        # the < must have been escaped inside the JSON tag
        assert "<script>alert" not in html.split('id="ccCharacters"')[1].split("</script>")[0]

    def test_drawer_js_present_on_all_pages(self, client):
        self._enable_ai(client)
        rv = client.get("/")
        html = rv.get_data(as_text=True)
        assert "openAIChat" in html  # sidebar entry
        rv = client.get("/notes/")
        assert rv.status_code == 200
