"""F-10 — Undo/Redo genelleştirme testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * İki yığın: delete → undo (geri gelir) → redo (yine gider) → undo ...
  * Çoklu geçmiş: A sil, B sil → undo(B), undo(A), redo(B), redo(A)
  * Yeni yıkıcı eylem redo yığınını TEMİZLER
  * Generik satır undo: not/glossary/günlük/kaynak/gönderim silmeleri
  * Unique çakışması (aynı tarihli yeni günlük) → ok:False zarfı, 500 yok
  * Snapshot sıkıştırma: z1 öneki + gidiş-dönüş; eski düz JSON okunur
  * Büyüme denetimi: MAX_UNDO satır sınırı aşınca en eski budanır
  * Rotalar: POST /redo, /undo/list stack + can_redo alanları
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from models import undo as um  # noqa: E402
from models.undo import (  # noqa: E402
    UndoOperation,
    _pack,
    _unpack,
    snapshot_row,
)


def _mk_note(title: str):
    from services.note_service import create_note
    return create_note(title=title, body="içerik", category="idea")


def _note_exists(note_id: str) -> bool:
    from core.db import read_session
    from models.note import Note
    with read_session() as s:
        return s.get(Note, note_id) is not None


def _count_undo() -> int:
    from core.db import read_session
    with read_session() as s:
        return s.query(UndoOperation).filter_by(stack="u").count()


def _count_redo() -> int:
    from core.db import read_session
    with read_session() as s:
        return s.query(UndoOperation).filter_by(stack="r").count()


@pytest.fixture(autouse=True)
def _clean_undo():
    from core.db import write_transaction
    with write_transaction() as s:
        s.query(UndoOperation).delete()
    yield
    with write_transaction() as s:
        s.query(UndoOperation).delete()


# ---------------------------------------------------------------------------
# İki yığın çekirdeği
# ---------------------------------------------------------------------------

class TestUndoRedoCycle:

    def test_delete_undo_redo_undo_cycle(self):
        from services.note_service import delete_note

        n = _mk_note("Döngü")
        delete_note(n.id)
        assert not _note_exists(n.id)

        r1 = um.undo_last()
        assert r1["ok"] is True and _note_exists(n.id)

        r2 = um.redo_last()
        assert r2["ok"] is True and not _note_exists(n.id)

        r3 = um.undo_last()
        assert r3["ok"] is True and _note_exists(n.id)
        # undo→r'ye taşındı; redo→u'ya döndü; undo→tekrar r'ye.
        # Son durum: u=0, r=1 (redo yeniden yapılabilir)
        assert _count_redo() == 1
        assert _count_undo() == 0

    def test_two_deletes_interleaved(self):
        from services.note_service import delete_note

        a = _mk_note("A")
        b = _mk_note("B")
        delete_note(b.id)   # önce B
        delete_note(a.id)   # sonra A → yığın: [... delete_B, delete_A]

        # LIFO: ilk undo A'yı geri getirir
        assert um.undo_last()["ok"] and _note_exists(a.id)
        assert not _note_exists(b.id)
        # ikinci undo B'yi
        assert um.undo_last()["ok"] and _note_exists(b.id)
        # redo ters sırada: önce B'yi siler
        assert um.redo_last()["ok"] and not _note_exists(b.id)
        assert _note_exists(a.id)
        # sonra A'yı
        assert um.redo_last()["ok"] and not _note_exists(a.id)

    def test_new_action_clears_redo(self):
        from services.note_service import delete_note

        a = _mk_note("R1")
        b = _mk_note("R2")
        delete_note(a.id)
        um.undo_last()          # redo geçmişi oluştu
        assert _count_redo() == 1

        delete_note(b.id)       # yeni yıkıcı eylem
        assert _count_redo() == 0
        assert um.redo_last() is None

    def test_undo_nothing_returns_none(self):
        assert um.undo_last() is None
        assert um.redo_last() is None


# ---------------------------------------------------------------------------
# Generik satır undo (yeni varlık türleri)
# ---------------------------------------------------------------------------

class TestGenericRowUndo:

    def test_note_delete_undo(self):
        from services.note_service import delete_note
        n = _mk_note("Not")
        delete_note(n.id)
        assert not _note_exists(n.id)
        assert um.undo_last()["ok"] is True
        assert _note_exists(n.id)
        # içerik de geri geldi
        from core.db import read_session
        from models.note import Note
        with read_session() as s:
            assert s.get(Note, n.id).title == "Not"

    def test_glossary_delete_undo(self):
        from services.glossary_service import create_entry, delete_entry
        e = create_entry(term="f10terim", category="other",
                         definition="tanım")
        delete_entry(e.id)
        assert um.undo_last()["ok"] is True
        from core.db import read_session
        from models.glossary import GlossaryEntry
        with read_session() as s:
            row = s.get(GlossaryEntry, e.id)
            assert row is not None and row.term == "f10terim"

    def test_journal_delete_undo(self):
        from services.journal_service import create_or_update_for_date, delete_entry
        d = date(2026, 2, 10)
        e = create_or_update_for_date(d, mood="good", energy=4)
        delete_entry(e.id)
        assert um.undo_last()["ok"] is True
        from core.db import read_session
        from models.journal import JournalEntry
        with read_session() as s:
            row = s.get(JournalEntry, e.id)
            assert row is not None and row.mood == "good"

    def test_reference_and_submission_delete_undo(self):
        from services.reference_service import create_reference, delete_reference
        from services.submission_service import create_submission, delete_submission
        r = create_reference(title="Kaynak", source_type="book")
        delete_reference(r.id)
        assert um.undo_last()["ok"] is True

        sub = create_submission(title="Hikâye", market_name="Dergi")
        delete_submission(sub.id)
        assert um.undo_last()["ok"] is True

    def test_journal_unique_conflict_fails_cleanly(self):
        """Silinen günlük tarihi için YENİ giriş yapıldıysa restore çakışır —
        temiz ok:False zarfı dönmeli (500 değil)."""
        from services.journal_service import create_or_update_for_date, delete_entry, get_by_date
        d = date(2026, 5, 20)
        e1 = create_or_update_for_date(d, mood="good")
        delete_entry(e1.id)
        # aynı tarihe yeni giriş
        e2 = create_or_update_for_date(d, mood="blocked")
        res = um.undo_last()
        assert res is not None and res["ok"] is False
        assert res["action"] == "conflict"
        # yeni giriş duruyor
        assert get_by_date(d).id == e2.id


# ---------------------------------------------------------------------------
# Depolama: sıkıştırma + büyüme denetimi
# ---------------------------------------------------------------------------

class TestStorage:

    def test_pack_roundtrip_and_prefix(self):
        big = {"row": {"content": "abc " * 5000}}
        packed = _pack(big)
        assert packed.startswith(("z1:", "j1:"))
        assert _unpack(packed) == big

    def test_legacy_plain_json_unpacked(self):
        import json as _json
        legacy = {"row": {"x": 1}}
        assert _unpack(_json.dumps(legacy)) == legacy

    def test_recorded_snapshots_are_packed(self):
        from services.note_service import delete_note
        n = _mk_note("Paket")
        delete_note(n.id)
        from core.db import read_session
        with read_session() as s:
            raw = s.query(UndoOperation).filter_by(stack="u").first().snapshot
        assert raw.startswith(("z1:", "j1:"))

    def test_growth_control_prunes_oldest(self):
        from services.note_service import delete_note
        # MAX_UNDO + fazlasını üret
        for i in range(um.MAX_UNDO + 7):
            n = _mk_note(f"budama-{i}")
            delete_note(n.id)
            um.undo_last()  # yığını tüket ki tek kalsın... hayır: undo redo
            # üretir — bunun yerine redo'yu temizlemek için yeni silme
            # (kaydın kendisi redo'yu da temizliyor)
        assert _count_undo() + _count_redo() <= um.MAX_UNDO + 1

    def test_snapshot_row_shape(self):
        n = _mk_note("Şekil")
        snap = snapshot_row(n)
        assert snap["table"] == "notes"
        assert snap["row"]["title"] == "Şekil"
        assert snap["row"]["project_id"] == "default"


# ---------------------------------------------------------------------------
# Rotalar
# ---------------------------------------------------------------------------

class TestRoutes:

    def test_redo_route_lifecycle(self, client):
        from services.note_service import delete_note
        n = _mk_note("Rota")
        delete_note(n.id)
        r = client.post("/undo")
        assert r.status_code == 200 and r.get_json()["ok"] is True
        assert r.get_json()["can_redo"] is True

        r2 = client.post("/redo")
        assert r2.status_code == 200 and r2.get_json()["ok"] is True
        assert not _note_exists(n.id)

    def test_redo_route_empty_400(self, client):
        r = client.post("/redo")
        assert r.status_code == 400

    def test_undo_list_reports_stack_and_redo(self, client):
        from services.note_service import delete_note
        n = _mk_note("Liste")
        delete_note(n.id)
        client.post("/undo")
        r = client.get("/undo/list")
        data = r.get_json()
        assert data["can_redo"] is True
        assert all(op["stack"] in ("u", "r") for op in data["ops"])
