"""ASM v6.3 — In-editor AI Assistant drawer tests.

The drawer appears on the chapter EDIT page only when AI is enabled,
references the streaming endpoint with the CURRENT chapter id, and offers
insert-at-cursor / replace-selection / copy / stop actions.
"""
import pytest

_EDITOR_JS = None


def _editor_js() -> str:
    """Read static/js/chapter_editor.js (cached) — v9.1.0 (M-06): the editor
    page's logic moved from inline HTML to this module."""
    global _EDITOR_JS
    if _EDITOR_JS is None:
        from pathlib import Path
        p = (Path(__file__).resolve().parent.parent
             / "static" / "js" / "chapter_editor.js")
        _EDITOR_JS = p.read_text(encoding="utf-8")
    return _EDITOR_JS


def _enable_ai(model="test-model"):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", "openai")
        Setting.set(s, "ai.model", model)


def _disable_ai():
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", False)


@pytest.fixture
def a_chapter():
    from services import chapter_service
    return chapter_service.create_chapter(
        title="The Harbor", content="Elara stepped onto the pier.")


class TestAIDrawerRendering:
    def test_drawer_present_when_ai_enabled(self, client, a_chapter):
        _enable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        assert rv.status_code == 200
        data = rv.data
        assert b'id="aiDrawer"' in data
        assert b'id="aiDrawerFab"' in data
        assert b"toggleAIDrawer" in data

    def test_drawer_absent_when_ai_disabled(self, client, a_chapter):
        _disable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        assert rv.status_code == 200
        assert b'id="aiDrawer"' not in rv.data
        assert b'id="aiDrawerFab"' not in rv.data

    def test_drawer_has_four_actions_and_context_toggles(self, client, a_chapter):
        _enable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        data = rv.data
        for fn in (b"aiDrawerAction('continue')", b"aiDrawerAction('expand')",
                   b"aiDrawerAction('shorter')", b"aiDrawerAction('dialogue')"):
            assert fn in data
        for cb in (b'id="aiCtxChars"', b'id="aiCtxRel"', b'id="aiCtxWorld"',
                   b'id="aiCtxGloss"', b'id="aiCtxPlot"'):
            assert cb in data

    def test_drawer_uses_streaming_endpoint_with_chapter_id(self, client, a_chapter):
        _enable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        data = rv.data
        assert a_chapter.id.encode() in data  # via the #editor-data JSON block
        # v9.1.0 (M-06): the endpoint wiring lives in chapter_editor.js.
        src = _editor_js()
        assert "/ai-copilot/api/suggest-stream" in src
        # The chapter id is baked into the request body from ED.chapterId.
        assert "ED.chapterId" in src

    def test_drawer_footer_actions(self, client, a_chapter):
        _enable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        data = rv.data
        assert b"aiInsertAtCursor" in data          # insert at cursor
        assert b"aiReplaceSelection" in data        # replace selection
        assert b"aiCopyResult" in data              # copy
        assert b"aiStopStream" in data              # stop streaming
        assert b'id="aiStopBtn"' in data

    def test_alt_a_shortcut_wired(self, client, a_chapter):
        _enable_ai()
        assert "e.altKey" in _editor_js()  # v9.1.0 (M-06): moved to the JS module

    def test_insert_uses_codemirror_and_marks_dirty(self, client, a_chapter):
        _enable_ai()
        src = _editor_js()  # v9.1.0 (M-06): moved to the JS module
        # Insert/replace go through CodeMirror's API and trigger autosave
        assert "replaceSelection" in src
        assert "markDirty()" in src

    def test_polish_css_has_drawer_layer(self, client):
        rv = client.get("/static/css/polish.css")
        assert rv.status_code == 200
        assert b".ai-drawer" in rv.data
        assert b".ai-drawer-fab" in rv.data
        assert b"composition-mode .ai-drawer" in rv.data  # hidden in focus mode


class TestShortcutsCheatsheet:
    def test_alt_a_listed_in_cheatsheet(self, client):
        rv = client.get("/static/js/app.js")
        assert b"Alt + A" in rv.data


class TestDrawerDoesNotLeakElsewhere:
    def test_not_on_chapter_list(self, client, a_chapter):
        _enable_ai()
        rv = client.get("/chapters/")
        assert b'id="aiDrawer"' not in rv.data

    def test_not_on_dashboard(self, client, a_chapter):
        _enable_ai()
        rv = client.get("/")
        assert b'id="aiDrawer"' not in rv.data
