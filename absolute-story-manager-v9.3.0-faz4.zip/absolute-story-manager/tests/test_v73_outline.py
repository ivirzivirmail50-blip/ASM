"""Tests for v7.3 — Corkboard Outline 2.0 (Deep Writing Experience).

Covers:
  - Route /outline/ exists and renders
  - Empty state when no chapters
  - Cards render with title, synopsis, word count, scene count, status
  - Status filter and tag filter work
  - Drag-drop markup (draggable="true") present
  - Sidebar link to outline exists
  - i18n key nav.outline exists in 5 languages
  - polish.css contains outline-* classes
  - scenes.html emoji chrome replaced with SVG sprite refs
"""
from __future__ import annotations

import pytest


@pytest.fixture
def app_v73():
    from app import create_app
    app = create_app()
    yield app


@pytest.fixture
def client(app_v73):
    return app_v73.test_client()


def _make_chapter(title, synopsis="", status="draft", tags=None, words=42):
    from services.chapter_service import create_chapter
    return create_chapter(
        title=title, content="x " * words, synopsis=synopsis,
        status=status, tags=tags or [],
    )


# ---------------------------------------------------------------- route shape


def test_v73_outline_route_renders_empty(app_v73, client):
    r = client.get("/outline/")
    assert r.status_code == 200
    body = r.data.decode()
    assert "Corkboard Outline" in body
    # Empty state
    assert "outline-empty" in body or "Your manuscript is empty" in body


def test_v73_outline_route_renders_cards(app_v73, client):
    _make_chapter("Prologue", synopsis="A cold wind blew.", tags=["intro", "setting"])
    _make_chapter("Chapter 1", synopsis="Elara met Kael.", tags=["intro"])
    r = client.get("/outline/")
    body = r.data.decode()
    assert "outline-corkboard" in body
    assert "Prologue" in body
    assert "Chapter 1" in body
    assert "A cold wind blew." in body
    # Tag chips
    assert "#intro" in body
    assert "#setting" in body
    # SVG icons
    assert 'href="#i-grid"' in body
    assert 'href="#i-book-open"' in body


def test_v73_outline_stats_block(app_v73, client):
    _make_chapter("Ch 1", words=100)
    _make_chapter("Ch 2", words=200)
    r = client.get("/outline/")
    body = r.data.decode()
    # Stats: 2 chapters, 300 total words, 150 avg, daily goal 500 (default)
    assert "Total chapters" in body
    assert "300" in body  # total words (or comma-formatted)
    assert "Total words" in body
    assert "Avg words/chapter" in body


def test_v73_outline_status_filter(app_v73, client):
    _make_chapter("Draft One", status="draft")
    _make_chapter("Final One", status="final")
    r = client.get("/outline/?status=final")
    body = r.data.decode()
    assert "Final One" in body
    assert "Draft One" not in body


def test_v73_outline_tag_filter(app_v73, client):
    _make_chapter("Tagged", tags=["research"])
    _make_chapter("Untagged", tags=["dialogue"])
    r = client.get("/outline/?tag=research")
    body = r.data.decode()
    assert "Tagged" in body
    assert "Untagged" not in body


def test_v73_outline_card_draggable(app_v73, client):
    _make_chapter("Draggable Ch")
    r = client.get("/outline/")
    body = r.data.decode()
    assert 'draggable="true"' in body
    # Drag handle icon
    assert 'outline-drag-handle' in body
    assert 'href="#i-arrows"' in body


def test_v73_outline_card_links_to_chapter_routes(app_v73, client):
    ch = _make_chapter("Linked Ch")
    r = client.get("/outline/")
    body = r.data.decode()
    # Open links to chapters.detail
    assert f'href="/chapters/{ch.id}"' in body
    # Edit links to chapters.edit
    assert f'href="/chapters/{ch.id}/edit"' in body


def test_v73_outline_sidebar_link(client):
    r = client.get("/")
    body = r.data.decode()
    assert 'href="/outline/"' in body
    assert ">Outline<" in body


def test_v73_outline_i18n_keys_exist(app_v73):
    from services.i18n_service import translate
    for lang, expected in (("en", "Outline"), ("tr", "Taslak"),
                           ("es", "Esquema"), ("fr", "Plan"), ("de", "Gliederung")):
        assert translate("nav.outline", lang) == expected


def test_v73_outline_polish_css_layer(app_v73):
    from pathlib import Path
    css = (Path(app_v73.root_path) / "static" / "css" / "polish.css").read_text()
    for cls in (".outline-corkboard", ".outline-card", ".outline-card-title",
                ".outline-synopsis", ".outline-tags", ".outline-card-actions",
                ".outline-empty"):
        assert cls in css


def test_v73_outline_blueprint_registered(app_v73):
    rules = [r.rule for r in app_v73.url_map.iter_rules()]
    assert "/outline/" in rules


# ---------------------------------------------------------------- scenes polish


def test_v73_scenes_emoji_chrome_replaced(client):
    """scenes.html should no longer use 🎬 📍 🗑 ✎ as UI chrome."""
    from services.chapter_service import create_chapter
    ch = create_chapter(title="With Scenes", content="Para one.\n\nPara two.",
                        synopsis="A test chapter.")
    # Extract scene cards so the cards render with action buttons
    client.post(f"/scenes/api/extract/{ch.id}")
    r = client.get("/scenes/")
    body = r.data.decode()
    # The 🎬 was the page-header H1 emoji — now should be SVG
    assert "🎬" not in body
    # The 🗑 delete button emoji — now SVG (x icon)
    assert "🗑" not in body
    # The 📍 location emoji on cards — now SVG (map icon)
    assert "📍" not in body
    # Sprite references present
    assert 'href="#i-clapperboard"' in body
    # If a card rendered, the action buttons should reference i-pen (Edit)
    # and i-x (Delete) from the sprite
    if "scene-card" in body:
        assert 'href="#i-pen"' in body
        assert 'href="#i-x"' in body
