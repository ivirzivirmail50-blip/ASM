"""E2E conftest — üst tests/conftest.py'nin fresh_db otomatik-fixture'ını
gölgeler (canlı sunucu süreci kendi motorunu kullanır) ve gerçek sunucu +
tarayıcı fixture'ları sağlar.

Bu dizin YALNIZCA ayrı koşulmalı: `pytest tests/e2e/` (CI'daki e2e işi
böyledir). Ana süitle birlikte çağrılırsa testler skip eder — motor/DB
çakışmasını önlemek için.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent  # proje kökü

pytest.importorskip("playwright.sync_api",
                    reason="F-08: playwright kurulu değil")


def _e2e_enabled() -> bool:
    # Ayrı koşuşta (yalnız tests/e2e) veya açık bayrakla etkin
    only_e2e = any(a.replace("\\", "/").rstrip("/").endswith("tests/e2e")
                   for a in sys.argv)
    return only_e2e or os.environ.get("ASM_E2E") == "1"


# Ana süitle birlikte çağrılırsa TÜM e2e modülü atlanır — canlı sunucu
# süreci, ana süitin monkeypatch'li motoruyla çakışmasın (CI'daki e2e
# işi bu dizini AYRI koşar: pytest tests/e2e/).
if not _e2e_enabled():
    pytest.skip("E2E ayrı koşulur: pytest tests/e2e/ (veya ASM_E2E=1)",
                allow_module_level=True)


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(autouse=True)
def fresh_db(tmp_path):
    """Üst conftest'in fresh_db'ini gölgele: e2e sunucusu kendi DB'sini
    kullanır; motor monkeypatch'i canlı sürece karışmamalı."""
    yield


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    if not _e2e_enabled():
        pytest.skip("E2E yalnız ayrı koşuşta: pytest tests/e2e/ "
                    "(veya ASM_E2E=1)")
    db_dir = tmp_path_factory.mktemp("e2e")
    db_path = db_dir / "e2e.db"
    port = _free_port()
    env = dict(os.environ)
    env["ASM_DB_URI"] = f"sqlite:///{db_path}"
    env["PYTHONPATH"] = str(ROOT)
    env.setdefault("ASM_HOST", "127.0.0.1")

    proc = subprocess.Popen(
        [sys.executable, str(ROOT / "scripts" / "e2e_server.py"),
         str(port)],
        cwd=str(ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    base = f"http://127.0.0.1:{port}"
    # Hazırlık: GET / 200 (migration + seed bitene dek)
    deadline = time.time() + 60
    ready = False
    while time.time() < deadline:
        if proc.poll() is not None:
            out = proc.stdout.read() if proc.stdout else ""
            pytest.fail(f"e2e sunucusu düştü: {out[-800:]}")
        try:
            with urllib.request.urlopen(base + "/", timeout=3) as r:
                if r.status == 200:
                    ready = True
                    break
        except (urllib.error.URLError, ConnectionError, OSError):
            time.sleep(0.3)
    if not ready:
        proc.terminate()
        pytest.fail("e2e sunucusu 60 sn içinde hazır olmadı")
    yield base
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()


@pytest.fixture(scope="module")
def browser():
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        try:
            b = p.chromium.launch(headless=True)
        except Exception as exc:  # tarayıcı eksikse net skip
            pytest.skip(f"chromium kurulamadı: {exc}")
        yield b
        b.close()


@pytest.fixture
def page(browser, server):
    ctx = browser.new_context(accept_downloads=True)
    pg = ctx.new_page()
    errors: list[str] = []
    pg.on("pageerror", lambda e: errors.append(f"pageerror: {e}"))
    pg.on(
        "console",
        lambda m: errors.append(f"console.{m.type}: {m.text}")
        if m.type == "error" else None,
    )
    pg._asm_errors = errors  # test erişimi için
    try:
        yield pg, server
    finally:
        # Konsol hatası sözleşmesi: ana akış sıfır hata üretmeli.
        assert not errors, f"tarayıcı konsol hataları: {errors[:6]}"
        ctx.close()
