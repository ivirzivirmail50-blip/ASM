"""F-08 — Playwright E2E: ana yazma akışı (v9.3.0).

Akış (kart metni): kurulum → bölüm oluştur → autosave → export.

  1. Kurulum     : gerçek sunucu süreci (migration'lar + seed + worker),
                   gerçek Chromium; sıfır konsol hatası sözleşmesi.
  2. Bölüm oluştur: /chapters/new formu doldurulur (EasyMDE editörü),
                   AJAX kayıt → detail sayfası doğrulanır.
  3. Autosave    : edit sayfasında editöre yazılır (CM6 motoru),
                   POST /chapters/<id>/autosave yanıtı beklenir.
  4. Export      : senkron TXT indirmesi yazılan metni İÇERİR (autosave
                   kalıcılığının uçtan uca kanıtı) + asenkron DOCX
                   (F-05 kuyruğu + F-04 SSE) gerçek indirme olayı.
"""
from __future__ import annotations

import re

UNIQUE = "aetherwind"  # akışa özgü imza kelime


class TestWritingFlow:

    def test_setup_create_autosave_export(self, page):
        pg, base = page

        # ---- 1. Kurulum: ana sayfa canlı ---------------------------------
        pg.goto(base + "/", wait_until="domcontentloaded")
        pg.wait_for_selector("body", timeout=15000)
        assert "Story" in (pg.title() or "") or pg.locator(
            "nav, .sidebar, .card").first.is_visible()

        # ---- 2. Bölüm oluştur (AJAX form → detail sayfasına gider) -------
        pg.goto(base + "/chapters/new", wait_until="domcontentloaded")
        pg.fill("#title", f"E2E Bölüm {UNIQUE}")
        pg.fill("#chapterSynopsis", "Uçtan uca akış testi.")
        # Yeni sayfa EasyMDE kullanır: .CodeMirror içine yaz
        pg.locator(".CodeMirror").first.click()
        pg.keyboard.type(f"İlk paragraf. {UNIQUE} rüzgârı esiyordu.", delay=8)
        with pg.expect_response(
                lambda r: ("/chapters/new" in r.url
                           and r.request.method == "POST"),
                timeout=20000):
            pg.click("button[type=submit]")
        # JS detail sayfasına yönlendirir
        pg.wait_for_url("**/chapters/*", timeout=15000)
        pg.wait_for_selector(f"text=E2E Bölüm {UNIQUE}", timeout=15000)
        chapter_id = pg.url.rstrip("/").split("/")[-1].split("?")[0]

        # ---- 3. Editörde yaz → autosave (POST /chapters/<id>/autosave) ---
        pg.goto(f"{base}/chapters/{chapter_id}/edit",
                wait_until="domcontentloaded")
        # CM6 varsayılan; motor ayarına göre EasyMDE de olabilir
        ed = pg.locator(".cm-content")
        if ed.count() == 0:
            ed = pg.locator(".CodeMirror")
        ed.first.click(timeout=10000)
        pg.keyboard.press("End")
        pg.keyboard.type(f" İkinci paragraf. {UNIQUE} yükseldi.", delay=15)
        # 3 sn'lik varsayılan autosave aralığı tetiklenir; yanıt kanıtı:
        with pg.expect_response(
                lambda r: f"/chapters/{chapter_id}/autosave" in r.url,
                timeout=25000):
            pass

        # ---- 4a. Senkron TXT export — autosave kalıcılık kanıtı ---------
        pg.goto(base + "/export", wait_until="domcontentloaded")
        with pg.expect_download(timeout=30000) as dl_info:
            pg.locator(".card", has_text="Full Manuscript") \
                .locator("a", has_text="TXT").click()
        download = dl_info.value
        txt = download.path().read_text(encoding="utf-8", errors="replace")
        assert UNIQUE in txt, "TXT export, editörde yazılan metni içermiyor"
        assert "İkinci paragraf" in txt, "autosave içeriği export'a ulaşmadı"

        # ---- 4b. Asenkron DOCX — kuyruk + SSE gerçek indirme ------------
        pg.goto(base + "/export", wait_until="domcontentloaded")
        with pg.expect_download(timeout=60000) as dl2:
            pg.locator("button", has_text="DOCX (async)").first.click()
        docx = dl2.value.path()
        assert docx.stat().st_size > 1000, "DOCX export boş/küçük"

    def test_dashboard_renders_without_errors(self, page):
        pg, base = page
        pg.goto(base + "/", wait_until="domcontentloaded")
        pg.wait_for_selector(".card, .card-grid, nav", timeout=15000)
        body = pg.locator("body").inner_text()
        assert re.search(r"Total Chapters|Characters|World", body)
