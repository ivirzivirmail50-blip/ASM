"""F-11 — mypy kademeli sıkılaştırma testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * strict set (v9.3.0 çekirdek modülleri) mypy ile temiz
  * pyproject'ta strict override seti tanımlı (yeni kod zorunlu kuralı)
  * requirements-dev.txt mypy'ı pinler
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

STRICT_MODULES = [
    "core/events.py",
    "core/hooks.py",
    "core/version.py",
    "models/background_task.py",
    "services/task_queue_service.py",
]


class TestMypyStrictSet:

    def test_mypy_available(self):
        result = subprocess.run(
            [sys.executable, "-m", "mypy", "--version"],
            capture_output=True, text=True, timeout=60,
        )
        assert result.returncode == 0, "mypy kurulu değil (dev bağımlılığı)"

    def test_strict_set_is_clean(self):
        """Kabul kriteri: strict set modülleri mypy hatasız."""
        result = subprocess.run(
            [sys.executable, "-m", "mypy", *STRICT_MODULES],
            cwd=ROOT, capture_output=True, text=True, timeout=300,
        )
        assert result.returncode == 0, (
            f"mypy strict set failed:\n"
            f"{result.stdout[-1500:]}{result.stderr[-400:]}"
        )

    def test_pyproject_declares_strict_modules(self):
        src = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        assert "[tool.mypy]" in src
        for mod in ("core.events", "core.hooks", "core.version",
                    "models.background_task", "services.task_queue_service"):
            assert mod in src, f"{mod} strict sette yok"
        # kademeli benimseme: takip sessiz (eski kod hemen kırılmaz)
        assert 'follow_imports = "silent"' in src

    def test_dev_requirements_pin_mypy(self):
        dev = (ROOT / "requirements-dev.txt").read_text(encoding="utf-8")
        assert "mypy" in dev
