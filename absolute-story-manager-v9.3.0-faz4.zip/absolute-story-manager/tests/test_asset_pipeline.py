"""M-07 — vendor lazy-load + cache-busting tests (v9.1.0).

Acceptance criteria from the plan:
  - vis-network / Chart.js / EasyMDE load ONLY on the pages that use them
  - every static asset carries the ?v= version stamp from the single
    `asset()` macro (hand-written ?v=N tags are gone)
  - the service worker cache version is synchronized with __version__
  - per-page network payload shrinks (measured in bytes)
  - offline SW scenario still registers (sw.js parses)
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
STATIC = PROJECT_ROOT / "static"

from core.version import __version__  # noqa: E402

VENDOR_BYTES = {
    "vis": (STATIC / "vendor/vis-network/vis-network.min.js").stat().st_size,
    "chart": (STATIC / "vendor/chartjs/chart.umd.min.js").stat().st_size,
    "mde": (STATIC / "vendor/easymde/easymde.min.js").stat().st_size,
    "sortable": (STATIC / "vendor/sortablejs/Sortable.min.js").stat().st_size,
}


# ---------------------------------------------------------------------------
# Cache-busting macro
# ---------------------------------------------------------------------------

class TestCacheBusting:

    def test_asset_macro_stamps_version(self, client):
        r = client.get("/")
        html = r.get_data(as_text=True)
        stamped = re.findall(r'src="(/static/js/[a-z_]+\.js)\?v=([^"]+)"',
                             html)
        assert stamped, "no stamped script URLs on the home page"
        for _path, v in stamped:
            assert v == __version__

    def test_css_links_stamped(self, client):
        r = client.get("/")
        html = r.get_data(as_text=True)
        css = re.findall(r'href="(/static/css/[a-z\-]+\.css)\?v=([^"]+)"', html)
        assert css, "css links not stamped"
        for _path, v in css:
            assert v == __version__

    def test_all_templates_use_asset_macro(self):
        """No template may reference static files via raw url_for anymore —
        everything goes through the single stamping macro (M-07)."""
        offenders = []
        for tpl in (PROJECT_ROOT / "templates").rglob("*.html"):
            if "url_for('static'" in tpl.read_text(encoding="utf-8"):
                offenders.append(tpl.name)
        assert offenders == []

    def test_no_handwritten_version_tags(self):
        offenders = []
        for tpl in (PROJECT_ROOT / "templates").rglob("*.html"):
            src = tpl.read_text(encoding="utf-8")
            # asset() is the only allowed version stamp.
            if re.search(r"\}\}\?v=", src):
                offenders.append(tpl.name)
        assert offenders == []

    def test_sw_version_matches_app_version(self):
        src = (STATIC / "js" / "sw.js").read_text(encoding="utf-8")
        m = re.search(r'const VERSION = "(v[\d.]+)";', src)
        assert m, "sw.js VERSION not found"
        assert m.group(1) == f"v{__version__}"

    def test_sw_js_syntax_valid(self):
        import subprocess
        r = subprocess.run(
            ["node", "--check", str(STATIC / "js" / "sw.js")],
            capture_output=True, text=True, timeout=30,
        )
        assert r.returncode == 0, r.stderr


# ---------------------------------------------------------------------------
# Lazy-loading rules
# ---------------------------------------------------------------------------

def _script_srcs(html: str) -> list[str]:
    return re.findall(r'<script[^>]*\bsrc="([^"]+)"', html)


class TestVendorLazyLoad:

    def test_base_html_has_no_vendor_scripts(self):
        src = (PROJECT_ROOT / "templates" / "base.html").read_text(
            encoding="utf-8")
        assert "vendor/" not in re.sub(
            r"<!--.*?-->", "", src, flags=re.S,
        ), "base.html still references vendor assets (comments excepted)"

    @pytest.mark.parametrize(("page", "vendor_file"), [
        ("/characters/graph", "vis-network"),
        ("/family-tree/", "vis-network"),
        ("/chapter-deps/", "vis-network"),
        ("/", "chart.umd"),           # dashboard is the landing page
        ("/analytics/", "chart.umd"),
        ("/pacing/", "chart.umd"),
        ("/characters/groups", "sortable"),
    ])
    def test_using_pages_load_their_vendor(self, client, page, vendor_file):
        r = client.get(page)
        if r.status_code == 404:
            pytest.skip(f"{page} not present in this build")
        html = r.get_data(as_text=True)
        srcs = _script_srcs(html)
        assert any(vendor_file in s for s in srcs), (
            f"{page} should load {vendor_file}: {srcs}"
        )

    def test_editor_page_loads_codemirror_default(self, client):
        """v9.2.0 (F-03): default engine is CodeMirror 6 — its bundle
        lazy-loads on the editor page (EasyMDE only with the rollback flag)."""
        from services import chapter_service
        ch = chapter_service.create_chapter(title="Lazy", content="x")
        r = client.get(f"/chapters/{ch.id}/edit")
        assert r.status_code == 200
        srcs = _script_srcs(r.get_data(as_text=True))
        assert any("codemirror.bundle.min.js" in s for s in srcs)
        assert any("cm6_editor.js" in s for s in srcs)

    def test_editor_page_loads_easymde_on_rollback_flag(self, client):
        from services import chapter_service
        ch = chapter_service.create_chapter(title="Lazy2", content="x")
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "editor.engine", "easymde")
        r = client.get(f"/chapters/{ch.id}/edit")
        assert r.status_code == 200
        srcs = _script_srcs(r.get_data(as_text=True))
        assert any("easymde" in s for s in srcs)
        assert not any("codemirror.bundle" in s for s in srcs)

    @pytest.mark.parametrize("page", ["/notes/", "/reading/", "/search/"])
    def test_plain_pages_load_no_vendor(self, client, page):
        r = client.get(page)
        if r.status_code != 200:
            pytest.skip(f"{page} returned {r.status_code}")
        html = r.get_data(as_text=True)
        srcs = _script_srcs(html)
        vendor = [s for s in srcs if "/vendor/" in s]
        assert vendor == [], f"{page} unexpectedly loads vendor: {vendor}"

    def test_notes_page_payload_is_lighter(self, client):
        """The card's measurable win: a plain page ships ZERO vendor bytes
        (previously ~1.5 MB of vis+chart+easymde from base.html)."""
        r = client.get("/notes/")
        assert r.status_code == 200
        srcs = _script_srcs(r.get_data(as_text=True))
        vendor = [s for s in srcs if "/vendor/" in s]
        saved = sum(
            VENDOR_BYTES[k] for k in ("vis", "chart", "mde", "sortable")
        )
        assert vendor == []
        assert saved > 1_000_000  # >1 MB no longer shipped to plain pages
