"""ASM v7.2 — World builder redesign + AI auto-fill in chapter editor."""
from pathlib import Path

import pytest


def _enable_ai(model="test-model"):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", True)
        Setting.set(s, "ai.provider", "openai")
        Setting.set(s, "ai.model", model)


def _disable_ai():
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "ai.enabled", False)


@pytest.fixture
def a_chapter():
    from services import chapter_service
    return chapter_service.create_chapter(
        title="Stormhaven Arrival",
        content="Elara stepped off the boat at Stormhaven pier as the rain started.")


class TestWorldBuilder:
    def test_uses_two_column_layout(self, client):
        rv = client.get("/world/new")
        assert rv.status_code == 200
        assert b"char-builder-grid" in rv.data
        assert b"char-form-col" in rv.data
        assert b"char-preview-col" in rv.data

    def test_live_preview_widgets(self, client):
        rv = client.get("/world/new")
        assert b"worldPreview" in rv.data
        assert b'previewName' in rv.data
        assert b'data-preview="name"' in rv.data
        assert b'data-preview="description"' in rv.data

    def test_world_templates_present(self, client):
        rv = client.get("/world/new")
        for t in (b'data-wtemplate="kingdom"', b'data-wtemplate="city"',
                  b'data-wtemplate="dungeon"', b'data-wtemplate="faction"',
                  b'data-wtemplate="lore"'):
            assert t in rv.data
        assert b"W_TEMPLATES" in rv.data

    def test_all_original_fields_preserved(self, client):
        rv = client.get("/world/new")
        for field in (b'name="type"', b'name="name"', b'name="category"',
                      b'name="description"', b'name="content"',
                      b'name="notes"', b'csrf_token'):
            assert field in rv.data, f"missing field: {field}"

    def test_parent_id_still_supported(self, client):
        from services import world_service
        parent = world_service.create_entry(type_="location", name="Aurelia")
        rv = client.get(f"/world/new?parent={parent.id}")
        assert b'name="parent_id"' in rv.data
        assert b"Aurelia" in rv.data
        assert b"Child of" in rv.data

    def test_create_still_works(self, client):
        rv = client.post("/world/new", data={
            "type": "location", "name": "Blackwood Forest",
            "description": "A dark forest on the kingdom's edge.",
        })
        data = rv.get_json()
        assert data["ok"] is True


class TestChapterAIButtons:
    def test_ai_buttons_present_when_ai_enabled(self, client, a_chapter):
        _enable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        assert b'id="aiFillSynopsis"' in rv.data
        assert b'id="aiFillTags"' in rv.data
        # v9.1.0 (M-06): the handlers moved to static/js/chapter_editor.js —
        # the page must load that module, and the module must wire the
        # buttons (previously these were inline-script assertions).
        assert b"js/chapter_editor.js" in rv.data
        editor_js = Path(__file__).resolve().parent.parent / \
            "static" / "js" / "chapter_editor.js"
        src = editor_js.read_text(encoding="utf-8")
        assert "async function aiFillSynopsis()" in src
        assert "async function aiFillTags()" in src
        assert 'getElementById("aiFillSynopsis")' in src
        assert 'getElementById("aiFillTags")' in src

    def test_ai_buttons_absent_when_ai_disabled(self, client, a_chapter):
        _disable_ai()
        rv = client.get(f"/chapters/{a_chapter.id}/edit")
        assert b'id="aiFillSynopsis"' not in rv.data
        assert b'id="aiFillTags"' not in rv.data

    def test_ai_synopsis_calls_correct_endpoint(self, client, a_chapter):
        _enable_ai()
        rv = client.post("/ai/summarize", json={"text": "Some chapter text."})
        # Provider not reachable in test env — should return a graceful error
        assert rv.status_code in (200, 400, 500, 502, 503)

    def test_ai_tags_calls_correct_endpoint(self, client, a_chapter):
        _enable_ai()
        rv = client.post("/ai/suggest-tags", json={"text": "Some chapter text."})
        assert rv.status_code in (200, 400, 500, 502, 503)

    def test_synopsis_filled_via_ai_mock(self, client, a_chapter):
        _enable_ai()
        from unittest.mock import patch

        from services import ai_providers, ai_service
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          return_value="A storm-battered arrival."):
            rv = client.post("/ai/summarize", json={"text": "Elara arrived in Stormhaven."})
        data = rv.get_json()
        assert data["ok"] is True
        assert "storm" in data["response"].lower()

    def test_tags_filled_via_ai_mock(self, client, a_chapter):
        _enable_ai()
        from unittest.mock import patch

        from services import ai_providers, ai_service
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          return_value="storm, harbor, arrival, mystery"):
            rv = client.post("/ai/suggest-tags", json={"text": "Elara arrived in Stormhaven."})
        data = rv.get_json()
        assert data["ok"] is True
        assert "storm" in data["tags"]
