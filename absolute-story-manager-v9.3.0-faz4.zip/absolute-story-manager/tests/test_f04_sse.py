"""F-04 — merkezi SSE kanalı testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * EventBus: subscribe/publish/unsubscribe; dolu kuyrukta sessiz düşürme
  * /events akışı: retry satırı + hello çerçevesi + olay çerçevesi
    (event: <ad>\\ndata: <json>) + doğru SSE başlıkları
  * İstemci kopunca abonelik temizlenir (subscriber_count 0'a döner)
  * F-05 köprüsü: görev kuyruğu olayları veri yoluna düşer
  * core.js tüketici: asmEvents/EventSource sunucuda tanımlı
"""
from __future__ import annotations

import json
import queue as _queue
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.events import bus  # noqa: E402

# ---------------------------------------------------------------------------
# EventBus (birim)
# ---------------------------------------------------------------------------

class TestEventBus:

    def test_subscribe_publish_receive(self):
        q = bus.subscribe()
        try:
            delivered = bus.publish({"event": "task.done", "x": 1})
            assert delivered == 1
            got = q.get(timeout=1)
            assert got == {"event": "task.done", "x": 1}
        finally:
            bus.unsubscribe(q)

    def test_unsubscribe_stops_delivery(self):
        q = bus.subscribe()
        bus.unsubscribe(q)
        assert bus.publish({"event": "gone"}) == 0
        assert q.qsize() == 0
        assert bus.subscriber_count == 0

    def test_publish_never_blocks_on_full_backlog(self):
        import threading
        q = bus.subscribe()
        # kuyruğu bilinçli doldur
        for i in range(300):
            bus.publish({"event": "spam", "i": i})
        # hiçbiri bloklamadı, kuyruk max 200
        assert q.qsize() <= 200
        bus.unsubscribe(q)

    def test_publish_multiple_subscribers(self):
        q1 = bus.subscribe()
        q2 = bus.subscribe()
        try:
            assert bus.publish({"event": "multi"}) == 2
            assert q1.get(timeout=1) == {"event": "multi"}
            assert q2.get(timeout=1) == {"event": "multi"}
        finally:
            bus.unsubscribe(q1)
            bus.unsubscribe(q2)


# ---------------------------------------------------------------------------
# /events SSE akışı
# ---------------------------------------------------------------------------

class TestSseRoute:

    def _open(self, client):
        resp = client.get("/events", buffered=False)
        assert resp.status_code == 200
        assert resp.mimetype == "text/event-stream"
        assert resp.headers["Cache-Control"] == "no-cache"
        return resp

    def test_stream_hello_then_event_frame(self, client):
        resp = self._open(client)
        it = resp.response
        try:
            first = next(it).decode()
            assert first.startswith("retry: 3000")
            second = next(it).decode()
            assert "event: hello" in second
            # abonelik kuruldu
            assert bus.subscriber_count == 1
            # bir olay yayınla → çerçeve gelsin
            bus.publish({"event": "task.progress", "progress": 42,
                         "stage": "Yarında"})
            frame = next(it).decode()
            assert "event: task.progress" in frame
            payload = json.loads(
                frame.split("data: ", 1)[1].strip())
            assert payload["progress"] == 42
        finally:
            resp.close()
        # istemci kapandı → abonelik temizlendi
        assert bus.subscriber_count == 0

    def test_multiple_clients_each_get_events(self, client):
        r1 = self._open(client)
        r2 = self._open(client)
        try:
            next(r1.response); next(r1.response)
            next(r2.response); next(r2.response)
            assert bus.subscriber_count == 2
            assert bus.publish({"event": "task.done"}) == 2
        finally:
            r1.close()
            r2.close()
        assert bus.subscriber_count == 0


# ---------------------------------------------------------------------------
# F-05 köprüsü: kuyruk → veri yolu
# ---------------------------------------------------------------------------

class TestTaskQueueBridge:

    def test_task_lifecycle_publishes_to_bus(self):
        from services import task_queue_service as q

        qsub = bus.subscribe()
        try:
            t = q.enqueue("export", {"entity_type": "manuscript",
                                     "fmt": "txt"})
            q.execute_one()
            # olay akışını topla (timeout'lu)
            events = []
            deadline_frames = 8
            for _ in range(deadline_frames):
                try:
                    events.append(qsub.get(timeout=0.5))
                except _queue.Empty:
                    break
            names = [e.get("event") for e in events]
            assert "task.enqueued" in names
            assert "task.done" in names
            done = next(e for e in events if e["event"] == "task.done")
            assert done["task_id"] == t.id
        finally:
            bus.unsubscribe(qsub)


# ---------------------------------------------------------------------------
# Statik tüketicici (core.js) + rota tescili
# ---------------------------------------------------------------------------

class TestStaticConsumer:

    def test_core_js_defines_asm_events(self):
        src = (PROJECT_ROOT / "static" / "js" / "core.js").read_text(
            encoding="utf-8")
        assert "window.asmEvents" in src
        assert "EventSource" in src
        assert "/events" in src

    def test_events_route_registered(self, client):
        from app import create_app

        app = create_app(testing=True)
        rules = {r.rule for r in app.url_map.iter_rules()}
        assert "/events" in rules
