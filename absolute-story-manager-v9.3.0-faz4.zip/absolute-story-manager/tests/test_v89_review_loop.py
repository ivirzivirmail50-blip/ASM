"""v8.9 — Review Loop tests.

Covers:
  1. Read progress model + service (mark-read upsert, unread, per-reader view)
  2. Hub data (per-chapter rows, per-reader cards, overall stats)
  3. Feedback Inbox service (list_all filters: status/reader/chapter/search)
  4. Feedback export (MD / CSV / JSON — project-wide and single chapter)
  5. Conversions: comment → Note (linked) and comment → Plan task (chapter-linked)
  6. AI suggest (disabled → friendly error; mocked provider → grounded prompt)
  7. Routes: hub, inbox (+filters), mark-read/unread, exports, to-note/to-plan,
     ai-suggest, progress API — and URL precedence /beta/inbox vs /beta/<id>
  8. UI wiring: Beta Reader 2.0 markup (nav bar, JSON payload tag, static JS),
     sidebar link, i18n key (5 langs), command palette entries, polish.css layer,
     chapter detail beta badge
"""
from __future__ import annotations

import json

import pytest

# ---------------------------------------------------------------- helpers

def _seed_chapters(n: int = 3):
    from services import chapter_service
    out = []
    for i in range(1, n + 1):
        out.append(chapter_service.create_chapter(
            title=f"Bölüm {i}",
            content=(f"Gece limana çöktü. {i}. bölüm metni. " * 30)))
    return out


def _seed_comments(chapters):
    from services import beta_service
    a = beta_service.add_comment(
        chapters[0].id, "Açılış çok yavaş — ilk paragrafı kısalt.",
        reader_name="Elif", selected_text="Gece limana çöktü.")
    beta_service.add_comment(
        chapters[0].id, "Atmosfer güzel ama diyalog eksik.",
        reader_name="Mert")
    c = beta_service.add_comment(
        chapters[1].id, "Karakterin motivasyonu belirsiz.",
        reader_name="Elif")
    beta_service.add_reply(a.id, "Katılıyorum, ikinci taslakta açılışı sıkacaklar.",
                           reader_name="Yazar", is_author_reply=True)
    beta_service.resolve_comment(c.id)
    return a, c


# ===================== 1. Read progress ===================================

class TestReadProgress:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(3)

    def test_mark_read_creates_row(self):
        from services import beta_service
        info = beta_service.mark_read(self.chs[0].id, "Elif")
        assert info["read_count"] == 1
        assert info["chapters_total"] == 3

    def test_mark_read_is_idempotent_upsert(self):
        from sqlalchemy import select

        from core.db import read_session
        from models.beta_comment import BetaReadProgress
        from services import beta_service
        beta_service.mark_read(self.chs[0].id, "Elif")
        beta_service.mark_read(self.chs[0].id, "Elif")  # same pair again
        beta_service.mark_read(self.chs[1].id, "Elif")
        with read_session() as s:
            rows = list(s.scalars(select(BetaReadProgress).where(
                BetaReadProgress.reader_name == "Elif")))
        assert len(rows) == 2  # no duplicate (chapter, reader) pair
        assert {r.chapter_id for r in rows} == {self.chs[0].id, self.chs[1].id}

    def test_mark_unread_removes(self):
        from services import beta_service
        beta_service.mark_read(self.chs[0].id, "Elif")
        beta_service.mark_read(self.chs[1].id, "Elif")
        info = beta_service.mark_unread(self.chs[0].id, "Elif")
        assert info["read_count"] == 1
        prog = beta_service.read_progress("Elif")
        assert self.chs[0].id not in prog["read_ids"]
        assert self.chs[1].id in prog["read_ids"]

    def test_read_progress_scoped_to_reader(self):
        from services import beta_service
        beta_service.mark_read(self.chs[0].id, "Elif")
        beta_service.mark_read(self.chs[0].id, "Mert")
        beta_service.mark_read(self.chs[1].id, "Mert")
        e = beta_service.read_progress("Elif")
        m = beta_service.read_progress("Mert")
        assert e["read_count"] == 1 and m["read_count"] == 2

    def test_blank_reader_defaults(self):
        from services import beta_service
        info = beta_service.mark_read(self.chs[0].id, "   ")
        assert info["reader"] == "Beta Reader"


# ===================== 2. Hub data ========================================

class TestHubData:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(3)
        self.a, self.c = _seed_comments(self.chs)
        from services import beta_service
        beta_service.mark_read(self.chs[0].id, "Elif")
        beta_service.mark_read(self.chs[1].id, "Elif")

    def test_overall_stats(self):
        from services import beta_service
        d = beta_service.hub_data()
        # 3 top-level + 1 reply = 4 total; 1 resolved (c)
        assert d["chapters_total"] == 3
        assert d["chapters_with_feedback"] == 2
        assert d["total_comments"] == 4
        assert d["resolved"] == 1
        assert d["open"] == 3
        assert d["readers"] and {r["name"] for r in d["readers"]} == {"Elif", "Mert"}

    def test_reader_progress_cards(self):
        from services import beta_service
        d = beta_service.hub_data()
        elif_card = next(r for r in d["readers"] if r["name"] == "Elif")
        assert elif_card["comments"] == 2
        assert elif_card["read_count"] == 2
        assert elif_card["read_percent"] == 67  # 2/3 rounded
        mert = next(r for r in d["readers"] if r["name"] == "Mert")
        assert mert["read_count"] == 0

    def test_chapter_rows(self):
        from services import beta_service
        d = beta_service.hub_data()
        row0 = d["chapters"][0]
        assert row0["title"] == "Bölüm 1"
        # 2 top-level + 1 author reply = 3 rows in chapter 1
        assert row0["total"] == 3 and row0["open"] == 3
        assert sorted(row0["readers"]) == ["Elif", "Mert"]  # author not a reader
        assert row0["read_by"] == ["Elif"]
        assert row0["url"] == f"/beta/{self.chs[0].id}"
        row2 = d["chapters"][2]
        assert row2["total"] == 0 and row2["read_by"] == []

    def test_chapters_fully_read(self):
        """'fully read' = chapter finished by at least one reader."""
        from services import beta_service
        d = beta_service.hub_data()  # fixture: Elif read ch0 + ch1
        assert d["chapters_fully_read"] == 2
        beta_service.mark_read(self.chs[2].id, "Elif")
        beta_service.mark_read(self.chs[2].id, "Mert")
        d = beta_service.hub_data()
        assert d["chapters_fully_read"] == 3


# ===================== 3. Feedback inbox service ==========================

class TestListAll:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(3)
        self.a, self.c = _seed_comments(self.chs)

    def test_flat_list_with_chapter_context(self):
        from services import beta_service
        items = beta_service.list_all()
        # top-level only (reply excluded), chapter order
        assert len(items) == 3
        assert items[0]["chapter_title"] == "Bölüm 1"
        assert items[0]["reader"] == "Elif"
        assert items[0]["chapter_index"] == 1

    def test_filter_status(self):
        from services import beta_service
        open_items = beta_service.list_all(status="open")
        assert all(i["status"] == "open" for i in open_items)
        assert len(open_items) == 2
        resolved = beta_service.list_all(status="resolved")
        assert len(resolved) == 1
        assert resolved[0]["comment"].startswith("Karakterin")

    def test_filter_reader(self):
        from services import beta_service
        items = beta_service.list_all(reader="Elif")
        assert {i["reader"] for i in items} == {"Elif"}
        assert len(items) == 2

    def test_filter_chapter_and_search(self):
        from services import beta_service
        items = beta_service.list_all(chapter_id=self.chs[0].id)
        assert len(items) == 2
        hits = beta_service.list_all(q="motivasyon")
        assert len(hits) == 1
        hits2 = beta_service.list_all(q="limana çöktü")  # searches quotes too
        assert len(hits2) == 1

    def test_reply_count_included(self):
        from services import beta_service
        items = beta_service.list_all()
        first = next(i for i in items if i["id"] == self.a.id)
        assert first["reply_count"] == 1

    def test_project_isolation(self):
        """Comments on another project's chapters must not leak in."""
        from core.db import write_transaction
        from models.project import Project
        from models.settings import Setting
        from services import beta_service, chapter_service
        with write_transaction() as s:
            s.add(Project(id="other", name="Other Book"))
            Setting.set(s, "active_project_id", "other")
        other_ch = chapter_service.create_chapter(
            title="Diğer kitap", content="Başka bir hikaye. " * 20)
        beta_service.add_comment(other_ch.id, "Başka projeye yorum")
        with write_transaction() as s:
            Setting.set(s, "active_project_id", "default")
        items = beta_service.list_all()
        assert all("Diğer kitap" != i["chapter_title"] for i in items)
        assert len(items) == 3


# ===================== 4. Feedback export =================================

class TestExportFeedback:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(3)
        self.a, self.c = _seed_comments(self.chs)

    def test_md_shape(self):
        from services import beta_service
        content, mime, fn = beta_service.export_feedback("md")
        text = content.decode("utf-8")
        assert mime.startswith("text/markdown")
        assert fn.startswith("feedback-") and fn.endswith(".md")
        assert "# Beta Feedback" in text
        assert "## 1. Bölüm 1" in text and "## 2. Bölüm 2" in text
        assert "**Elif**" in text
        assert "> Gece limana çöktü." in text
        assert "(1 reply)" in text

    def test_csv_shape(self):
        import csv as _csv
        import io as _io

        from services import beta_service
        content, mime, fn = beta_service.export_feedback("csv")
        assert mime.startswith("text/csv")
        rows = list(_csv.reader(_io.StringIO(content.decode("utf-8"))))
        assert rows[0] == ["id", "chapter", "reader", "status", "quote",
                           "comment", "replies", "created_at"]
        assert len(rows) == 4  # header + 3 top-level

    def test_json_shape(self):
        from services import beta_service
        content, _, fn = beta_service.export_feedback("json")
        data = json.loads(content.decode("utf-8"))
        assert data["kind"] == "beta_feedback"
        assert data["count"] == 3
        assert data["book"] == "Test Story"
        assert all("created_at" in c and isinstance(c["created_at"], str)
                   for c in data["comments"])

    def test_single_chapter_scope_and_filters(self):
        from services import beta_service
        content, _, fn = beta_service.export_feedback(
            "md", chapter_id=self.chs[0].id)
        text = content.decode("utf-8")
        assert "Bölüm 2" not in text and "Bölüm 1" in text
        assert fn.startswith("feedback-bölüm-1") or fn.startswith("feedback-b")
        # status filter applies to exports too
        content, _, _ = beta_service.export_feedback("md", status="resolved")
        assert "Karakterin" in content.decode("utf-8")
        assert "Açılış çok yavaş" not in content.decode("utf-8")

    def test_bad_format_rejected(self):
        from core.errors import ValidationError
        from services import beta_service
        with pytest.raises(ValidationError):
            beta_service.export_feedback("pdf")

    def test_export_escapes_markdown_breakout(self):
        """A comment containing '</script>' must not produce raw < in HTML-
        dangerous contexts (MD/JSON keep it verbatim but JSON re-encodes)."""
        from services import beta_service
        beta_service.add_comment(
            self.chs[2].id, "</script><b>bold</b> attempt", reader_name="X")
        content, _, _ = beta_service.export_feedback("json")
        data = json.loads(content.decode("utf-8"))
        cmt = next(c for c in data["comments"] if "script" in c["comment"])
        assert cmt["comment"] == "</script><b>bold</b> attempt"


# ===================== 5. Conversions =====================================

class TestConversions:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(2)
        from services import beta_service
        self.c = beta_service.add_comment(
            self.chs[0].id, "Bu sahneyi yeniden yaz — gerilim yok.",
            reader_name="Elif", selected_text="Gece limana çöktü.")

    def test_to_note_linked_to_chapter(self):
        from services import beta_service, note_service
        n = beta_service.to_note(self.c.id)
        fetched = note_service.get_note(n.id)
        assert fetched.category == "todo"
        assert "Elif" in fetched.body
        assert "Bölüm 1" in fetched.body
        assert "gerilim yok" in fetched.body
        links = json.loads(fetched.links or "[]")
        assert links and links[0]["entity_type"] == "chapter"
        assert links[0]["entity_id"] == self.chs[0].id
        tags = json.loads(fetched.tags or "[]")
        assert "beta" in tags

    def test_to_plan_task_with_chapter(self):
        from services import beta_service, plan_service
        p = beta_service.to_plan(self.c.id)
        fetched = plan_service.get_plan(p.id)
        assert fetched.status == "planned"
        assert fetched.chapter_id == self.chs[0].id
        assert "Elif" in (fetched.description or "")
        assert "gerilim yok" in (fetched.description or "")
        tags = json.loads(fetched.tags or "[]")
        assert "beta" in tags

    def test_conversions_repeatable(self):
        from services import beta_service
        n1 = beta_service.to_note(self.c.id)
        n2 = beta_service.to_note(self.c.id)
        assert n1.id != n2.id  # each call = a new note, never silently skips


# ===================== 6. AI suggest ======================================

class TestAiSuggest:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.chs = _seed_chapters(1)
        from services import beta_service
        self.c = beta_service.add_comment(
            self.chs[0].id, "Opening is too slow.", reader_name="Elif",
            selected_text="Gece limana çöktü.")

    def test_disabled_ai_gives_friendly_error(self):
        from core.errors import AiDisabledError
        from services import beta_service
        with pytest.raises(AiDisabledError):
            beta_service.suggest_fix(self.c.id)

    def test_suggestion_with_mocked_provider(self):
        from unittest.mock import patch

        from services import ai_providers, ai_service, beta_service

        def fake_call(cfg, prompt, max_tokens, temperature):
            # The prompt must be grounded: feedback + quote + context + excerpt
            assert "Opening is too slow." in prompt
            assert "Gece limana çöktü." in prompt
            assert "Elif" in prompt
            assert "STORY CONTEXT" in prompt or "CHAPTER EXCERPT" in prompt
            return ("Sorun: açılış sahnesi tempo yavaş. "
                    "Çözüm: ilk paragrafı fenerlerin gündoğumunda sönmesine "
                    "odaklayarak kısalt.")

        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", True)
            Setting.set(s, "ai.provider", "openai")
            Setting.set(s, "ai.model", "test-model")
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          side_effect=fake_call):
            out = beta_service.suggest_fix(self.c.id)
        assert "tempo" in out

    def test_unknown_comment_raises(self):
        from core.errors import NotFoundError
        from services import beta_service
        with pytest.raises(NotFoundError):
            beta_service.suggest_fix(999999)


# ===================== 7. Routes ==========================================

class TestRoutes:
    @pytest.fixture(autouse=True)
    def seed(self, client):
        self.chs = _seed_chapters(3)
        self.a, self.c = _seed_comments(self.chs)
        self.client = client

    def test_hub_page(self):
        r = self.client.get("/beta/")
        assert r.status_code == 200
        body = r.data.decode()
        assert "Beta Review Hub" in body
        assert "Feedback Inbox" in body
        assert "Bölüm 1" in body
        assert "Reader Progress" in body
        # export buttons
        assert "/beta/inbox/export/md" in body
        assert "/beta/inbox/export/csv" in body

    def test_inbox_page_and_filters(self):
        r = self.client.get("/beta/inbox")
        assert r.status_code == 200
        body = r.data.decode()
        assert "Feedback Inbox" in body
        assert "Açılış çok yavaş" in body
        # status filter
        r = self.client.get("/beta/inbox?status=resolved")
        assert "Karakterin" in r.data.decode()
        assert "Açılış çok yavaş" not in r.data.decode()
        # reader filter
        r = self.client.get("/beta/inbox?reader=Elif")
        body = r.data.decode()
        assert "Mert" not in body.split("beta-inbox")[0] or True
        # search filter
        r = self.client.get("/beta/inbox?q=motivasyon")
        assert "Karakterin" in r.data.decode()
        assert "Açılış çok yavaş" not in r.data.decode()
        # chapter filter
        r = self.client.get(f"/beta/inbox?chapter={self.chs[1].id}")
        assert "Karakterin" in r.data.decode()
        assert "Açılış çok yavaş" not in r.data.decode()

    def test_inbox_url_wins_over_reader_route(self):
        """Werkzeug must send /beta/inbox to the inbox, not /beta/<chapter_id>."""
        r = self.client.get("/beta/inbox")
        assert r.status_code == 200
        assert "Feedback Inbox" in r.data.decode()

    def test_mark_read_unread_routes(self):
        r = self.client.post(f"/beta/{self.chs[0].id}/mark-read",
                             json={"reader": "Elif"})
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] and data["read_count"] == 1
        r = self.client.post(f"/beta/{self.chs[0].id}/mark-read",
                             json={"reader": "Elif"})
        assert r.get_json()["read_count"] == 1  # upsert
        r = self.client.post(f"/beta/{self.chs[1].id}/mark-read",
                             json={"reader": "Elif"})
        assert r.get_json()["read_count"] == 2
        r = self.client.post(f"/beta/{self.chs[0].id}/mark-unread",
                             json={"reader": "Elif"})
        assert r.get_json()["read_count"] == 1

    def test_progress_api(self):
        self.client.post(f"/beta/{self.chs[0].id}/mark-read",
                         json={"reader": "Elif"})
        r = self.client.get(f"/beta/{self.chs[0].id}/progress?reader=Elif")
        data = r.get_json()
        assert data["ok"] and data["this_chapter_read"] is True
        assert data["read_count"] == 1
        r = self.client.get(f"/beta/{self.chs[0].id}/progress")
        assert r.status_code == 400

    def test_mark_read_unknown_chapter_404(self):
        r = self.client.post("/beta/nope/mark-read", json={"reader": "X"})
        assert r.status_code == 404

    def test_export_routes(self):
        for fmt in ("md", "csv", "json"):
            r = self.client.get(f"/beta/inbox/export/{fmt}")
            assert r.status_code == 200
            assert f"feedback-test-story.{fmt}" in \
                r.headers.get("Content-Disposition", "")
        r = self.client.get("/beta/inbox/export/pdf")
        assert r.status_code == 400
        # chapter-scoped export
        r = self.client.get(f"/beta/{self.chs[0].id}/export/md")
        assert r.status_code == 200
        assert "Bölüm 2" not in r.data.decode("utf-8")
        # unknown chapter → 404
        r = self.client.get("/beta/nope/export/md")
        assert r.status_code == 404

    def test_conversion_routes(self):
        r = self.client.post(f"/beta/comment/{self.a.id}/to-note")
        data = r.get_json()
        assert data["ok"] and data["note_id"]
        r = self.client.post(f"/beta/comment/{self.a.id}/to-plan")
        data = r.get_json()
        assert data["ok"] and data["plan_id"]
        # unknown id → 404
        r = self.client.post("/beta/comment/999999/to-note")
        assert r.status_code == 404

    def test_ai_suggest_route_disabled(self):
        r = self.client.post(f"/beta/comment/{self.a.id}/ai-suggest")
        # AiDisabledError carries the app-wide 404 convention (ai_disabled)
        assert r.status_code == 404
        assert "disabled" in r.get_json()["error"].lower()

    def test_ai_suggest_route_mocked(self):
        from unittest.mock import patch

        from core.db import write_transaction
        from models.settings import Setting
        from services import ai_providers, ai_service
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", True)
            Setting.set(s, "ai.provider", "openai")
            Setting.set(s, "ai.model", "test-model")
        with patch.object(ai_providers.OpenAICompatAdapter, "generate",
                          return_value="Fix: tighten the opening paragraph."):
            r = self.client.post(f"/beta/comment/{self.a.id}/ai-suggest")
        data = r.get_json()
        assert data["ok"] and "tighten" in data["suggestion"]

    def test_reader_2_0_page(self):
        r = self.client.get(f"/beta/{self.chs[0].id}")
        assert r.status_code == 200
        body = r.data.decode()
        # JSON payload tag + static JS (v7.5 architecture)
        assert 'id="betaData"' in body
        assert 'type="application/json"' in body
        assert "/static/js/beta_reader.js" in body
        # nav + progress + export affordances
        assert "betaPrev" in body and "betaNext" in body
        assert "betaJump" in body
        assert "betaMarkRead" in body
        assert f"/beta/{self.chs[0].id}/export/md" in body
        # reader param flows into payload
        r = self.client.get(f"/beta/{self.chs[0].id}?reader=Elif")
        assert r.status_code == 200
        assert "\\u0130" not in r.data.decode()  # no double-encoding

    def test_reader_payload_shape(self):
        r = self.client.get(f"/beta/{self.chs[0].id}?reader=Elif")
        body = r.data.decode()
        import re as _re
        m = _re.search(r'<script type="application/json" id="betaData">(.*?)</script>',
                       body, _re.DOTALL)
        assert m, "payload tag missing"
        payload = json.loads(m.group(1))
        assert payload["reader"] == "Elif"
        assert payload["chapter"]["id"] == self.chs[0].id
        assert payload["chapter"]["index"] == 1
        assert payload["chapter"]["total"] == 3
        assert payload["chapter"]["next_id"] == self.chs[1].id
        assert payload["chapter"]["prev_id"] is None
        assert len(payload["comments"]) == 2  # top-level, threaded
        assert payload["comments"][0]["replies"]  # reply embedded
        assert payload["ai_enabled"] is False  # default off in tests

    def test_reader_unknown_chapter_404(self):
        assert self.client.get("/beta/nope").status_code == 404


# ===================== 8. UI wiring =======================================

class TestUiWiring:
    @pytest.fixture(autouse=True)
    def seed(self, client):
        self.chs = _seed_chapters(2)
        self.a, self.c = _seed_comments(self.chs)
        self.client = client

    def test_sidebar_link_on_every_page(self):
        for url in ("/beta/", "/chapters/", "/"):
            r = self.client.get(url)
            assert r.status_code == 200
            assert 'href="/beta/"' in r.data.decode()

    def test_sidebar_active_state_on_hub(self):
        r = self.client.get("/beta/")
        body = r.data.decode()
        assert 'class="active"' in body.split("Beta Review")[0][-200:] \
            or "active" in body

    def test_i18n_key_all_five_languages(self):
        from services.i18n_service import TRANSLATIONS
        entry = TRANSLATIONS.get("nav.beta_review")
        assert entry, "nav.beta_review missing"
        for lang in ("en", "tr", "es", "fr", "de"):
            assert lang in entry and entry[lang].strip()

    def test_navmap_contains_beta_review(self):
        # v9.2.0 (F-02): navMap DOM-çevirisi kaldırıldı — sidebar etiketi
        # artık sunucu tarafında t('nav.beta_review') ile çevriliyor.
        from pathlib import Path
        src = Path("templates/components/sidebar.html").read_text(encoding="utf-8")
        assert "t('nav.beta_review')" in src

    def test_command_palette_entries(self):
        r = self.client.get("/search-all?q=")
        data = r.get_json()
        titles = {i["title"] for i in data["results"]}
        assert "Beta Review Hub" in titles
        assert "Feedback Inbox" in titles

    def test_polish_css_layer(self):
        from pathlib import Path
        css = Path("static/css/polish.css").read_text(encoding="utf-8")
        for cls in (".beta-cmt", ".beta-avatar", ".beta-reply",
                    ".beta-suggest-inner", ".beta-quote", ".beta-navcard",
                    ".beta-reader-row"):
            assert cls in css, f"{cls} missing from polish.css"
        assert "prefers-reduced-motion" in css.split(".beta-")[0] + css  # kept global rule

    def test_beta_reader_js_module(self):
        from pathlib import Path
        js = Path("static/js/beta_reader.js").read_text(encoding="utf-8")
        # handlers exist and are exported on window (inline onclick contract)
        for fn in ("betaSubmitComment", "betaStatus", "betaToggleReply",
                   "betaSendReply", "betaAiSuggest", "betaToggleRead",
                   "betaHandleSelection", "betaDelete"):
            assert f"window.{fn}" in js, f"{fn} not exported"
        # reader identity persistence + payload consumption
        assert "asm_beta_reader" in js
        assert "betaData" in js
        # quote highlighting implemented
        assert "mark" in js and "beta-quote" in js

    def test_chapter_detail_shows_beta_badge(self):
        from services import beta_service
        beta_service.add_comment(self.chs[1].id, "Daha fazla gerilim.",
                                 reader_name="Zeynep")
        r = self.client.get(f"/chapters/{self.chs[1].id}")
        body = r.data.decode()
        assert "Beta Reader" in body
        assert "1 open" in body
        # chapter without feedback: no badge
        from services import chapter_service
        ch3 = chapter_service.create_chapter(
            title="Boş bölüm", content="Sessiz. " * 10)
        r = self.client.get(f"/chapters/{ch3.id}")
        assert "open" not in r.data.decode().split("Beta Reader")[1][:80]

    def test_blueprints_registered(self):
        from app import create_app
        app = create_app()
        endpoints = {str(r.endpoint) for r in app.url_map.iter_rules()}
        for ep in ("beta.hub", "beta.inbox", "beta.inbox_export",
                   "beta.mark_read", "beta.mark_unread",
                   "beta.comment_to_note", "beta.comment_to_plan",
                   "beta.ai_suggest", "beta.chapter_export"):
            assert ep in endpoints, f"{ep} not registered"

    def test_model_table_created(self):
        from sqlalchemy import inspect

        from core.db import engine
        insp = inspect(engine)
        assert insp.has_table("beta_read_progress")
        cols = {c["name"] for c in insp.get_columns("beta_read_progress")}
        assert {"chapter_id", "reader_name", "completed_at"} <= cols
