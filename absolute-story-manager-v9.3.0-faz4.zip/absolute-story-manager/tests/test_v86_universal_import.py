"""v8.6 — Universal Import tests.

Covers:
  1. Payload detection for every v8.5 export shape (envelopes, single sheets,
     bare arrays, full project transfer, garbage)
  2. Round-trip fidelity: export a collection → import it back → every field
     survives (world hierarchy/relations/metadata/map pin, character quotes,
     scene POV/chapter resolution, glossary forbidden variants, reference
     quotes/rating)
  3. Conflict strategies: skip / overwrite (with version snapshot) / duplicate
  4. ID remapping: imported copies get NEW ids, parents/relations remapped,
     external targets resolved by name, relation dedup (out+in = one row)
  5. Exclude: per-row checkboxes leave rows untouched
  6. Routes: /import/preview + /import/execute (form fields, error paths,
     result URLs) and Import Center UI wiring
  7. Full-project JSON delegates to the v7.5 transfer service
"""
from __future__ import annotations

import io
import json

import pytest

from core.errors import ValidationError

# ---------------------------------------------------------------- helpers

def _seed_world():
    """Parent location + child + species + a cross-type relation."""
    from services import world_service
    loc = world_service.create_entry(
        name="Boğaz Kıyısı", type_="location", description="Sisli bir liman.",
        content="Rıhtımda balıkçı tekneleri dizili.", notes="Kışın tenha.",
        category="Doğu", metadata={"region": "Marmara", "climate": "nemli"})
    child = world_service.create_entry(
        name="Fener", type_="location", parent_id=loc.id, description="Eski bir fener.")
    sp = world_service.create_entry(
        name="Suirler", type_="species", description="Gölge yaratıkları.",
        metadata={"habitat": "mağara", "lifespan": "300 yıl"})
    world_service.create_relation(from_id=loc.id, to_id=sp.id, rel_type="home_of",
                                  description="Suirler burada yaşar.")
    return loc, child, sp


def _seed_characters():
    from services import character_service
    c1 = character_service.create_character(
        name="Kerem", role="protagonist", psychology="İçine kapanık ama kararlı.",
        philosophy_quotes=["Kapılar açıkken geç."], aliases=["Kerem Ağa"],
        physical="Uzun boylu", background="Rıhtımda büyüdü", voice="Kısa cümleler.")
    c2 = character_service.create_character(name="Deniz", role="antagonist")
    return c1, c2


def _seed_glossary():
    from core.db import write_transaction
    from models.glossary import GlossaryEntry
    from services import glossary_service
    from services._common import dump_json, new_uuid
    with write_transaction() as s:
        g = GlossaryEntry(id=new_uuid(), term="Seur Kapıları", category="place",
                          definition="Kadim kapı ağı.",
                          alternates=dump_json(["Seur kapıları"]),
                          forbidden=dump_json(["Seurkapıları", "seur kapilari"]),
                          case_sensitive=1, notes="Büyük harf önemli.")
        s.add(g)
        s.flush()
        return g


def _seed_reference():
    from core.db import write_transaction
    from models.reference import Reference
    from services._common import dump_json, new_uuid
    with write_transaction() as s:
        r = Reference(id=new_uuid(), title="Osmanlı Mimarı", author="Ahmet K.",
                      source_type="book", publication_date="1998", publisher="YKY",
                      isbn_or_doi="975-363-222-9", read_status="read",
                      priority="high", rating=5,
                      quotes=dump_json([{"text": "Kubbe gökyüzünün yansımasıdır.",
                                         "page": 42}]),
                      tags=dump_json(["mimari", "tarih"]))
        s.add(r)
        s.flush()
        return r


def _seed_scene(chapter, pov):
    from core.db import write_transaction
    from models.scene import SceneCard
    from services._common import dump_json, new_uuid
    with write_transaction() as s:
        sc = SceneCard(id=new_uuid(), chapter_id=chapter.id, project_id=chapter.project_id,
                       title="Gece Varışı", summary="Kerem limana varır.",
                       full_text="Gece yarısı limana vardı.", pov_character_id=pov.id,
                       location="Rıhtım", time_of_day="night", mood="tense",
                       status="draft", word_count=5, tags=dump_json(["giriş"]))
        s.add(sc)
        s.flush()
        return sc


def _post(client, url, payload: bytes, filename="bundle.json", **form):
    data = {"file": (io.BytesIO(payload), filename)}
    data.update(form)
    return client.post(url, data=data, content_type="multipart/form-data")


def _export_json(export_fn, *args) -> bytes:
    from services import export_service
    content, _mime, _name = getattr(export_service, export_fn)(*args)
    return content


# ---------------------------------------------------------------- detection

class TestDetection:
    def test_characters_envelope(self):
        from services.import_service import detect_payload
        assert detect_payload({"collection": "characters", "count": 2,
                               "characters": [{"name": "A"}]}) == "characters"

    def test_world_envelope_any_type(self):
        from services.import_service import detect_payload
        assert detect_payload({"collection": "species", "entries": []}) == "world"
        assert detect_payload({"collection": "location", "entries": []}) == "world"

    def test_single_world_entry_sheet(self):
        from services.import_service import detect_payload
        sheet = {"id": "x", "name": "Fener", "type": "location", "parent_chain": [],
                 "relations_out": [], "map_pin": None}
        assert detect_payload(sheet) == "world"

    def test_single_character_sheet(self):
        from services.import_service import detect_payload
        assert detect_payload({"name": "Kerem", "role": "protagonist"}) == "characters"

    def test_scenes_glossary_references_envelopes(self):
        from services.import_service import detect_payload
        assert detect_payload({"collection": "scenes", "scenes": []}) == "scenes"
        assert detect_payload({"collection": "glossary", "entries": []}) == "glossary"
        assert detect_payload({"collection": "references", "references": []}) == "references"

    def test_bare_arrays(self):
        from services.import_service import detect_payload
        assert detect_payload([{"name": "A", "role": "supporting"}]) == "characters"
        assert detect_payload([{"term": "x"}]) == "glossary"
        assert detect_payload([{"title": "T", "author": "B", "source_type": "book"}]) == "references"
        assert detect_payload([{"name": "L", "type": "location", "content": "..."}]) == "world"
        assert detect_payload([{"title": "S", "pov": "Kerem", "mood": "tense"}]) == "scenes"

    def test_glossary_entries_key_without_collection(self):
        from services.import_service import detect_payload
        assert detect_payload({"entries": [{"term": "x"}]}) == "glossary"
        assert detect_payload({"entries": [{"name": "L", "type": "location"}]}) == "world"

    def test_full_project(self):
        from services.import_service import detect_payload
        assert detect_payload({"version": "asm-v7.5", "projects": [],
                               "chapters": []}) == "full_project"

    def test_garbage(self):
        from services.import_service import detect_payload
        assert detect_payload({"hello": "world"}) == "unknown"
        assert detect_payload("nope") == "unknown"
        assert detect_payload([42]) == "unknown"


# ---------------------------------------------------------------- preview

class TestPreview:
    def test_preview_world_rows(self):
        _seed_world()
        from services.import_service import preview_import
        raw = _export_json("export_world_collection", "location", "json")
        pv = preview_import(json.loads(raw))
        assert pv["kind"] == "world"
        assert pv["count"] == 2
        assert {r["name"] for r in pv["rows"]} == {"Boğaz Kıyısı", "Fener"}
        # both exist already (exported from this very project)
        assert all(r["status"] == "skip" for r in pv["rows"])
        fener = next(r for r in pv["rows"] if r["name"] == "Fener")
        assert fener["note"] == "parent: Boğaz Kıyısı"

    def test_preview_strategy_changes_status(self):
        _seed_world()
        from services.import_service import preview_import
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        pv = preview_import(raw, strategy="overwrite")
        assert all(r["status"] == "update" for r in pv["rows"])
        pv = preview_import(raw, strategy="duplicate")
        assert all(r["status"] == "copy" for r in pv["rows"])

    def test_preview_new_items(self):
        from services.import_service import preview_import
        pv = preview_import({"collection": "characters",
                             "characters": [{"name": "Yeni Simge"}]})
        assert pv["summary"] == {"new": 1, "existing": 0}
        assert pv["rows"][0]["status"] == "new"
        assert pv["rows"][0]["detail"] == "supporting"

    def test_preview_unknown_raises(self):
        from services.import_service import preview_import
        with pytest.raises(ValidationError):
            preview_import({"nonsense": True})


# ---------------------------------------------------------------- round-trip

class TestWorldRoundTrip:
    def test_full_fidelity_duplicate_strategy(self):
        loc, child, sp = _seed_world()
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        assert res["imported"] == 2 and res["failed"] == 0

        from sqlalchemy import select

        from core.db import read_session
        from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion
        with read_session() as s:
            locs = s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Boğaz Kıyısı")).all()
            assert len(locs) == 2
            copy = next(e for e in locs if e.id != loc.id)
            assert copy.description == "Sisli bir liman."
            assert copy.content == "Rıhtımda balıkçı tekneleri dizili."
            assert copy.notes == "Kışın tenha."
            assert copy.category == "Doğu"
            assert json.loads(copy.metadata_) == {"region": "Marmara", "climate": "nemli"}
            # child copy linked to the PARENT COPY (id remap!)
            children = s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Fener")).all()
            assert len(children) == 2
            child_copy = next(c for c in children if c.id != child.id)
            assert child_copy.parent_id == copy.id
            # relation resolved by NAME to the existing species
            rels = s.scalars(select(WorldEntryRelation).where(
                WorldEntryRelation.from_entry_id == copy.id)).all()
            assert len(rels) == 1
            assert rels[0].to_entry_id == sp.id
            assert rels[0].relation_type == "home_of"
            assert rels[0].description == "Suirler burada yaşar."
            # v1 import version exists
            vers = s.scalars(select(WorldEntryVersion).where(
                WorldEntryVersion.entry_id == copy.id)).all()
            assert any(v.source == "import" for v in vers)

    def test_relation_dedup_when_both_sides_in_payload(self):
        """A→B in A's relations_out AND in B's relations_in must import ONCE."""
        loc, child, sp = _seed_world()
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        from services.import_service import execute_import
        execute_import(raw, strategy="duplicate")
        from sqlalchemy import select

        from core.db import read_session
        from models.world import WorldEntry, WorldEntryRelation
        with read_session() as s:
            locs = s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Boğaz Kıyısı")).all()
            copies = [e for e in locs if e.id != loc.id]
            rels = s.scalars(select(WorldEntryRelation).where(
                WorldEntryRelation.from_entry_id == copies[0].id)).all()
            # home_of (to species) + contains? — Fener has relations_in from parent?
            # Only ONE relation per (from,to,type) regardless of out+in duplication
            keys = [(r.from_entry_id, r.to_entry_id, r.relation_type.lower()) for r in rels]
            assert len(keys) == len(set(keys))

    def test_single_entry_sheet_import(self):
        loc, child, sp = _seed_world()
        from services.export_service import export_world_entry
        from services.import_service import execute_import
        raw, _, _ = export_world_entry(child.id, "json")
        res = execute_import(json.loads(raw), strategy="duplicate")
        assert res["imported"] == 1
        note = res["results"][0]["note"]
        assert "parent linked: Boğaz Kıyısı" in note
        from sqlalchemy import select

        from core.db import read_session
        from models.world import WorldEntry
        with read_session() as s:
            feners = s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Fener")).all()
            assert len(feners) == 2
            copy = next(f for f in feners if f.id != child.id)
            # parent resolved by NAME to the existing parent
            assert copy.parent_id == loc.id

    def test_missing_parent_note(self):
        from services.import_service import execute_import
        sheet = {"id": "old1", "name": "Yetim Şehir", "type": "location",
                 "description": "Ebeveyni yok.",
                 "parent_chain": ["Olmayan Kıta"], "relations_out": [],
                 "relations_in": [], "children": [], "map_pin": None,
                 "metadata": {}, "category": None}
        res = execute_import(sheet, strategy="skip")
        assert res["imported"] == 1
        assert "not found" in res["results"][0]["note"]

    def test_cycle_safety(self):
        """A parent-cycle in a hand-crafted file must not hang the importer."""
        from services.import_service import execute_import
        payload = {"collection": "location", "entries": [
            {"id": "a", "name": "A", "type": "location", "parent_id": "b",
             "parent_chain": [], "relations_out": [], "relations_in": [],
             "map_pin": None, "metadata": {}},
            {"id": "b", "name": "B", "type": "location", "parent_id": "a",
             "parent_chain": [], "relations_out": [], "relations_in": [],
             "map_pin": None, "metadata": {}},
        ]}
        res = execute_import(payload, strategy="skip")
        assert res["imported"] == 2  # both land, cycle broken at root


class TestCharactersRoundTrip:
    def test_full_fidelity(self):
        c1, c2 = _seed_characters()
        raw = json.loads(_export_json("export_characters", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        assert res["imported"] == 2
        from sqlalchemy import select

        from core.db import read_session
        from models.character import Character
        with read_session() as s:
            kerems = s.scalars(select(Character).where(
                Character.name == "Kerem")).all()
            assert len(kerems) == 2
            copy = next(k for k in kerems if k.id != c1.id)
            assert copy.role == "protagonist"
            assert copy.psychology == "İçine kapanık ama kararlı."
            assert json.loads(copy.philosophy_quotes) == ["Kapılar açıkken geç."]
            assert json.loads(copy.aliases) == ["Kerem Ağa"]
            assert copy.physical == "Uzun boylu"
            assert copy.voice == "Kısa cümleler."

    def test_invalid_role_falls_back(self):
        from services.import_service import execute_import
        res = execute_import([{"name": "X", "role": "demigod"}], strategy="skip")
        assert res["imported"] == 1
        from sqlalchemy import select

        from core.db import read_session
        from models.character import Character
        with read_session() as s:
            x = s.scalars(select(Character).where(Character.name == "X")).first()
            assert x.role == "supporting"

    def test_single_sheet(self):
        from services.import_service import detect_payload, execute_import
        sheet = {"name": "Aylin", "role": "supporting", "age": "34"}
        assert detect_payload(sheet) == "characters"
        res = execute_import(sheet, strategy="skip")
        assert res["imported"] == 1


class TestScenesRoundTrip:
    def test_chapter_and_pov_resolution(self):
        from services import chapter_service
        c1, _ = _seed_characters()
        ch = chapter_service.create_chapter(title="Birinci Bölüm", content="Metin.")
        sc = _seed_scene(ch, c1)
        raw = json.loads(_export_json("export_scenes", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        assert res["imported"] == 1
        from sqlalchemy import select

        from core.db import read_session
        from models.scene import SceneCard
        with read_session() as s:
            cards = s.scalars(select(SceneCard).where(
                SceneCard.title == "Gece Varışı")).all()
            assert len(cards) == 2
            copy = next(x for x in cards if x.id != sc.id)
            assert copy.chapter_id == ch.id          # resolved by title
            assert copy.pov_character_id == c1.id    # resolved by name
            assert copy.location == "Rıhtım"
            assert copy.time_of_day == "night"
            assert copy.mood == "tense"
            assert copy.word_count == 5
            assert json.loads(copy.tags) == ["giriş"]
            assert copy.summary == "Kerem limana varır."

    def test_missing_chapter_becomes_standalone(self):
        from services.import_service import execute_import
        payload = {"collection": "scenes", "scenes": [{
            "title": "Sahne 1", "chapter": "Yok Bölüm", "pov": None,
            "location": None, "time_of_day": None, "mood": None,
            "status": "draft", "word_count": 3, "tags": [],
            "summary": None, "notes": None, "content": "bir iki üç"}]}
        res = execute_import(payload, strategy="skip")
        assert res["imported"] == 1
        assert "not found" in res["results"][0]["note"]
        from sqlalchemy import select

        from core.db import read_session
        from models.scene import SceneCard
        with read_session() as s:
            card = s.scalars(select(SceneCard).where(
                SceneCard.title == "Sahne 1")).first()
            assert card.chapter_id is None
            assert card.word_count == 3


class TestGlossaryReferencesRoundTrip:
    def test_glossary_fidelity(self):
        _seed_glossary()
        raw = json.loads(_export_json("export_glossary", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        # v9.3.0 (F-06): (project_id, term) is a UNIQUE natural key — a
        # literal duplicate row is no longer representable; the conflict is
        # registered as a skip with a note instead of failing the import.
        assert res["imported"] == 0
        from sqlalchemy import select

        from core.db import read_session
        from models.glossary import GlossaryEntry
        with read_session() as s:
            terms = s.scalars(select(GlossaryEntry).where(
                GlossaryEntry.term == "Seur Kapıları")).all()
            assert len(terms) == 1
            copy = terms[0]
            assert json.loads(copy.alternates) == ["Seur kapıları"]
            assert json.loads(copy.forbidden) == ["Seurkapıları", "seur kapilari"]
            assert copy.case_sensitive == 1
            assert copy.category == "place"

    def test_reference_fidelity(self):
        _seed_reference()
        raw = json.loads(_export_json("export_references", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        assert res["imported"] == 1
        from sqlalchemy import select

        from core.db import read_session
        from models.reference import Reference
        with read_session() as s:
            refs = s.scalars(select(Reference).where(
                Reference.title == "Osmanlı Mimarı")).all()
            assert len(refs) == 2
            copy = refs[-1]
            assert copy.author == "Ahmet K."
            assert copy.source_type == "book"
            assert copy.rating == 5
            assert copy.read_status == "read"
            quotes = json.loads(copy.quotes)
            assert quotes[0]["text"] == "Kubbe gökyüzünün yansımasıdır."
            assert quotes[0]["page"] == 42
            assert json.loads(copy.tags) == ["mimari", "tarih"]


# ---------------------------------------------------------------- strategies

class TestStrategies:
    def test_skip_leaves_existing_alone(self):
        _seed_world()
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="skip")
        assert res["skipped"] == 2 and res["imported"] == 0

    def test_overwrite_updates_and_snapshots(self):
        loc, child, sp = _seed_world()
        # import a modified copy of the SAME entry (same type+name)
        payload = {"collection": "location", "entries": [{
            "id": loc.id, "name": "Boğaz Kıyısı", "type": "location",
            "description": "GÜNCELLENMİŞ açıklama.", "content": "Yeni içerik.",
            "notes": "Yeni not.", "category": "Batı",
            "metadata": {"region": "Ege"}, "parent_chain": [], "children": [],
            "relations_out": [], "relations_in": [], "map_pin": None}]}
        from services.import_service import execute_import
        res = execute_import(payload, strategy="overwrite")
        assert res["updated"] == 1 and res["imported"] == 0
        from sqlalchemy import select

        from core.db import read_session
        from models.world import WorldEntry, WorldEntryVersion
        with read_session() as s:
            e = s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Boğaz Kıyısı")).first()
            assert e.description == "GÜNCELLENMİŞ açıklama."
            assert e.category == "Batı"
            assert json.loads(e.metadata_) == {"region": "Ege"}
            # pre-import snapshot kept
            vers = s.scalars(select(WorldEntryVersion).where(
                WorldEntryVersion.entry_id == e.id)).all()
            assert any(v.source == "import" for v in vers)
            snap = next(v for v in vers if v.source == "import")
            assert "Sisli bir liman." in snap.snapshot  # the OLD value

    def test_overwrite_characters(self):
        c1, _ = _seed_characters()
        from services.import_service import execute_import
        res = execute_import([{"name": "Kerem", "role": "protagonist",
                               "psychology": "Artık açık sözlü."}],
                             strategy="overwrite")
        assert res["updated"] == 1
        from sqlalchemy import select

        from core.db import read_session
        from models.character import Character
        with read_session() as s:
            k = s.scalars(select(Character).where(Character.name == "Kerem")).first()
            assert k.psychology == "Artık açık sözlü."

    def test_duplicate_creates_new_ids(self):
        loc, _, _ = _seed_world()
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate")
        copy_id = res["results"][0]["id"]
        assert copy_id != loc.id

    def test_exclude_skips_rows(self):
        _seed_world()
        raw = json.loads(_export_json("export_world_collection", "location", "json"))
        from services.import_service import execute_import
        res = execute_import(raw, strategy="duplicate", exclude={0})
        assert res["imported"] == 1  # only Fener (index 1)
        assert res["results"][0]["name"] == "Fener"

    def test_bad_strategy_rejected(self):
        from services.import_service import execute_import
        with pytest.raises(ValidationError):
            execute_import([{"name": "A", "role": "supporting"}], strategy="nuke")


# ---------------------------------------------------------------- routes

class TestRoutes:
    def test_preview_endpoint(self, client):
        client.get("/")  # init db
        _seed_world()
        raw = _export_json("export_world_collection", "location", "json")
        rv = _post(client, "/import/preview", raw, "locations.json")
        assert rv.status_code == 200
        d = rv.get_json()
        assert d["ok"] and d["kind"] == "world" and d["count"] == 2

    def test_execute_endpoint_with_urls(self, client):
        client.get("/")
        _seed_characters()
        raw = _export_json("export_characters", "json")
        rv = _post(client, "/import/execute", raw, "characters.json",
                   strategy="duplicate")
        assert rv.status_code == 200
        d = rv.get_json()
        assert d["ok"] and d["imported"] == 2
        for r in d["results"]:
            assert r["url"] and r["url"].startswith("/characters/")

    def test_execute_exclude_form(self, client):
        client.get("/")
        _seed_world()
        raw = _export_json("export_world_collection", "location", "json")
        rv = _post(client, "/import/execute", raw, "locations.json",
                   strategy="duplicate", exclude='[0]')
        d = rv.get_json()
        assert d["imported"] == 1

    def test_invalid_json_400(self, client):
        client.get("/")
        rv = _post(client, "/import/preview", b"{not json", "bad.json")
        assert rv.status_code == 400
        assert "JSON" in rv.get_json()["error"]

    def test_wrong_extension_400(self, client):
        client.get("/")
        rv = _post(client, "/import/preview", b"{}", "notes.txt")
        assert rv.status_code == 400

    def test_no_file_400(self, client):
        client.get("/")
        rv = client.post("/import/preview", data={})
        assert rv.status_code == 400

    def test_unknown_payload_400(self, client):
        client.get("/")
        rv = _post(client, "/import/preview", json.dumps({"x": 1}).encode(), "x.json")
        assert rv.status_code == 400
        assert "recognise" in rv.get_json()["error"] or "Could not" in rv.get_json()["error"]

    def test_page_wiring(self, client):
        client.get("/")
        rv = client.get("/chapters/import-center")
        html = rv.data.decode()
        assert "ASM Export Bundle" in html
        assert "/import/preview" in html
        assert "/import/execute" in html
        assert 'selectImportType(\'asm\'' in html


# ---------------------------------------------------------------- full project

class TestFullProjectDelegation:
    def test_roundtrip_through_import_service(self, client):
        client.get("/")
        _seed_world()
        _seed_characters()
        from services.project_transfer_service import export_all
        snapshot = export_all()
        # wipe world + characters, then re-import via the universal door
        from core.db import write_transaction
        from models.character import Character, CharacterGroupMember, CharacterRelationship
        from models.scene import SceneCard
        from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion
        with write_transaction() as s:
            # FK order: relations → versions → child entries → entries
            for r in s.query(WorldEntryRelation).all():
                s.delete(r)
            for v in s.query(WorldEntryVersion).all():
                s.delete(v)
            for e in s.query(WorldEntry).filter(WorldEntry.parent_id.isnot(None)).all():
                s.delete(e)
            for e in s.query(WorldEntry).all():
                s.delete(e)
            for sc in s.query(SceneCard).all():
                s.delete(sc)
            for m in s.query(CharacterGroupMember).all():
                s.delete(m)
            for r in s.query(CharacterRelationship).all():
                s.delete(r)
            for c in s.query(Character).all():
                s.delete(c)
        from services.import_service import detect_payload, execute_import
        assert detect_payload(snapshot) == "full_project"
        res = execute_import(snapshot, strategy="skip")
        assert res["kind"] == "full_project"
        assert res["imported"] > 0
        from sqlalchemy import select

        from core.db import read_session
        with read_session() as s:
            assert s.scalars(select(WorldEntry).where(
                WorldEntry.name == "Boğaz Kıyısı")).first() is not None
            assert s.scalars(select(Character).where(
                Character.name == "Kerem")).first() is not None


# ---------------------------------------------------------------- parsing

class TestParsing:
    def test_bom_tolerated(self):
        from services.import_service import parse_json_bytes
        raw = b"\xef\xbb\xbf" + json.dumps({"name": "A"}).encode()
        assert parse_json_bytes(raw) == {"name": "A"}

    def test_empty_rejected(self):
        from services.import_service import parse_json_bytes
        with pytest.raises(ValidationError):
            parse_json_bytes(b"")
