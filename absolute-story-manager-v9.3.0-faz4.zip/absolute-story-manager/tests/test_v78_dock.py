"""v7.8 regression tests — Unified Bottom-Right Dock (BR-Dock).

USER REPORT (v7.7 aftermath): "sol altta olan tuş çakışması durumunu düzeltmek
için onu sağ alta almışsın fakat durum daha kötü olmuş — sağ altta hem save
butonu hem ileri geri butonları hem de şimdi bu artı butonu gelmiş."

ROOT CAUSE (reproduced live with agent-browser geometry):
  v7.7 moved the Quick Capture FAB to the bottom-right — but the undo/redo
  toolbar was ALREADY fixed at right:1.5rem/bottom:1.5rem on EVERY page
  (base.html). The FAB (right:24px/bottom:24px) landed almost exactly on top
  of it. On builder pages the form-status pill (right:1rem/bottom:1rem) and
  on the reading page the chapter nav (bottom:1.5rem/right:1.5rem) joined
  the pile. Four independent widgets, one corner, zero coordination.

ARCHITECTURAL FIX — .br-dock:
  ONE fixed container (``#brDock``) owns the bottom-right corner. Every
  floating widget lives inside it as a flex-column child with a stable CSS
  ``order`` (10 page widgets → 20 status pill → 30 undo/redo → 40 AI fab →
  50 QC fab). Overlap is structurally impossible — there is exactly ONE
  fixed-positioned element at that corner.
"""
import json
import re


def _read(path):
    return open(path, encoding="utf-8").read()


# ----------------------------------------------------------- architecture


def test_v78_dock_container_in_base_template():
    """base.html ships the single #brDock container with an injectable block."""
    src = _read("templates/base.html")
    assert 'class="br-dock" id="brDock"' in src
    assert "{% block br_dock %}{% endblock %}" in src, (
        "pages must be able to inject widgets into the dock")


def test_v78_undo_toolbar_lives_inside_dock():
    """The undo/redo row is a child of the dock, not a sibling fixed element."""
    src = _read("templates/base.html")
    m = re.search(r'<div class="br-dock" id="brDock">(.*?)</div>\s*'
                  r'<!-- Quick Capture FAB', src, re.S)
    assert m, "dock div must wrap the undo toolbar"
    inner = m.group(1)
    assert 'class="undo-toolbar"' in inner
    assert 'id="undoBtn"' in inner and 'id="redoBtn"' in inner


def test_v78_dock_css_single_fixed_anchor():
    """main.css: the dock is the ONLY fixed bottom-right element."""
    css = _read("static/css/main.css")
    dm = re.search(r"\.br-dock \{[^}]*\}", css, re.S)
    assert dm, ".br-dock rule missing"
    block = dm.group(0)
    assert "position: fixed" in block
    assert re.search(r"right:\s*1\.5rem", block)
    assert re.search(r"bottom:\s*1\.5rem", block)
    assert "flex-direction: column" in block
    # Stable vertical ordering via CSS order — immune to JS append order
    assert re.search(r"\.br-dock > \.undo-toolbar \{ order: 30; \}", css)
    assert re.search(r"\.br-dock > \.ai-drawer-fab \{ order: 40; \}", css)
    assert re.search(r"\.br-dock > \.qc-fab \{ order: 50; \}", css)


def test_v78_undo_toolbar_no_longer_self_positions():
    """The undo toolbar must not carry its own fixed positioning anymore."""
    css = _read("static/css/main.css")
    m = re.search(r"\.undo-toolbar \{[^}]*\}", css, re.S)
    assert m
    assert "position: fixed" not in m.group(0), (
        ".undo-toolbar must be positioned by the dock, not by itself")


def test_v78_qc_fab_and_pill_are_dock_children():
    """polish.css: QC FAB + form status pill are dock children (no fixed)."""
    css = _read("static/css/polish.css")
    fab = re.search(r"\.qc-fab \{[^}]*\}", css, re.S).group(0)
    assert "position: fixed" not in fab
    pill = re.search(r"\.form-status-pill \{[^}]*\}", css, re.S).group(0)
    assert "position: fixed" not in pill
    assert re.search(r"\.form-status-pill \{\s*order: 20;", css)


def test_v78_ai_drawer_fab_is_dock_child():
    """The editor's AI opener is a dock child (order 40), not self-fixed."""
    css = _read("static/css/polish.css")
    fab = re.search(r"\.ai-drawer-fab \{[^}]*\}", css, re.S).group(0)
    assert "position: fixed" not in fab
    assert "bottom: 5.4rem" not in css or "5.4rem" not in fab, (
        "the manual offset hack must be gone")


def test_v78_js_appenders_target_dock():
    """quick_capture.js and form_progress.js append into #brDock."""
    qc = _read("static/js/quick_capture.js")
    assert 'document.getElementById("brDock")' in qc
    assert "(dock || document.body).appendChild(fab)" in qc
    fp = _read("static/js/form_progress.js")
    assert 'document.getElementById("brDock")' in fp
    assert "(dock || document.body).appendChild(pill)" in fp


def test_v78_reading_nav_in_dock_block():
    """Reading page chapter nav moved into the br_dock block."""
    src = _read("templates/reading.html")
    assert "{% block br_dock %}" in src
    assert 'id="btnPrevChapter"' in src and 'id="btnNextChapter"' in src
    # the old self-positioning inline style must be gone
    assert 'position: fixed; bottom: 1.5rem; right: 1.5rem' not in src


def test_v78_editor_ai_fab_in_dock_block():
    """Chapter editor's AI opener is injected via the br_dock block."""
    src = _read("templates/chapters/edit.html")
    assert "{% block br_dock %}" in src
    assert 'id="aiDrawerFab"' in src
    m = re.search(r"\{% block br_dock %\}(.*?)\{% endblock %\}", src, re.S)
    assert m and "aiDrawerFab" in m.group(1), (
        "AI FAB must be inside the br_dock block, not the content block")


def test_v78_dock_hidden_in_focus_mode():
    """The whole dock hides during the Focus Mode 2.0 full-screen takeover."""
    css = _read("static/css/main.css")
    assert ".focus-shell ~ .br-dock" in css or "body:has(.focus-shell) .br-dock" in css


# ----------------------------------------------------------- rendered pages


def test_v78_rendered_dashboard_has_dock(client):
    """Every rendered page contains exactly one dock holding the undo row."""
    rv = client.get("/")
    assert rv.status_code == 200
    html = rv.data.decode()
    assert 'id="brDock"' in html
    assert 'class="undo-toolbar"' in html
    # dock appears BEFORE the undo toolbar div in the markup (nesting)
    assert html.index('id="brDock"') < html.index('class="undo-toolbar"')


def test_v78_rendered_dock_contains_undo_buttons(client):
    from bs4 import BeautifulSoup
    rv = client.get("/chapters/")
    assert rv.status_code == 200
    soup = BeautifulSoup(rv.data.decode(), "html.parser")
    dock = soup.find(id="brDock")
    assert dock is not None
    undo = dock.find(id="undoBtn")
    redo = dock.find(id="redoBtn")
    assert undo is not None and redo is not None, (
        "undo/redo must live INSIDE the dock — the v7.7 collision came from "
        "the FAB landing on a free-floating undo toolbar")


def test_v78_rendered_reading_nav_inside_dock(client):
    """Reading page: prev/next chapter buttons are dock children."""
    from bs4 import BeautifulSoup
    rv = client.get("/reading/")
    assert rv.status_code == 200
    soup = BeautifulSoup(rv.data.decode(), "html.parser")
    dock = soup.find(id="brDock")
    assert dock is not None
    assert dock.find(id="btnPrevChapter") is not None
    assert dock.find(id="btnNextChapter") is not None
    # nothing inside the dock may self-position fixed
    for el in dock.find_all(style=True):
        assert "position: fixed" not in el.get("style", "")


def test_v78_no_stray_fixed_bottom_right_widgets(client):
    """Sanity: rendered dashboard has no fixed-positioned element outside
    the dock that anchors to the bottom-right corner."""
    from bs4 import BeautifulSoup
    rv = client.get("/")
    soup = BeautifulSoup(rv.data.decode(), "html.parser")
    stray = []
    for el in soup.find_all(style=True):
        style = el.get("style", "")
        if "position: fixed" in style or "position:fixed" in style:
            if ("right" in style and "bottom" in style):
                stray.append(el.get("id") or el.get("class"))
    assert not stray, f"stray fixed bottom-right elements: {stray}"
