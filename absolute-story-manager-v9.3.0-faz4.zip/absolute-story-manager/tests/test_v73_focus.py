"""Tests for v7.3 — Focus Mode 2.0 (Deep Writing Experience).

Covers:
  - Route /focus/ renders new template with typewriter, paragraph focus,
    ambient sound dropdown, daily goal ring, milestone toasts
  - Route /focus/api/today returns {words_today, daily_goal, percent, goal_met}
  - Template uses SVG sprite icons (no emoji chrome in top bar)
  - polish.css contains focus-* classes
  - Setting daily_word_goal drives the goal ring label
  - All ambient sound options present (rain/cafe/fire/library/off)
  - Focus Mode 2.0 CSS respects prefers-reduced-motion
"""
from __future__ import annotations

import pytest


@pytest.fixture
def app_with_v73():
    """Use the conftest app fixture (provided by conftest.py)."""
    from app import create_app
    app = create_app()
    yield app


@pytest.fixture
def client(app_with_v73):
    return app_with_v73.test_client()


# ---------------------------------------------------------------- route shape


def test_v73_focus_route_renders(client):
    r = client.get("/focus/")
    assert r.status_code == 200
    body = r.data.decode()
    assert "Focus Mode" in body
    # New shell + sections
    assert 'id="focusShell"' in body
    assert 'id="typewriterBtn"' in body
    assert 'id="paragraphFocusBtn"' in body
    assert 'id="ambientBtn"' in body
    assert 'id="ambientMenu"' in body
    assert 'id="goalRingFill"' in body
    assert 'id="goalRingLabel"' in body
    assert 'id="timerDisplay"' in body


def test_v73_focus_api_today_returns_goal_fields(client):
    r = client.get("/focus/api/today")
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    for key in ("words_today", "daily_goal", "percent", "goal_met"):
        assert key in j
    assert isinstance(j["words_today"], int)
    assert isinstance(j["daily_goal"], int)
    assert j["daily_goal"] > 0
    assert 0 <= j["percent"] <= 100
    assert isinstance(j["goal_met"], bool)


def test_v73_focus_api_today_uses_daily_goal_setting(client, app_with_v73):
    """Setting daily_word_goal drives the daily_goal field in /focus/api/today."""
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "daily_word_goal", "1234")
    # stats_service caches words_today with TTL — but daily_goal is read fresh
    r = client.get("/focus/api/today")
    j = r.get_json()
    assert j["daily_goal"] == 1234


def test_v73_focus_template_uses_svg_icons(client):
    """No emoji chrome in the top bar — all icons come from the sprite."""
    r = client.get("/focus/")
    body = r.data.decode()
    # These were the v6-era emoji in the previous focus mode template
    # ▶ ⏹ ☰ ← — none should appear in the new template
    for emoji in ("▶", "⏹", "☰", "← Exit"):
        assert emoji not in body, f"old emoji {emoji!r} still present"
    # Sprite references for new icons
    for icon_id in ("i-headphones", "i-type", "i-circle-dot",
                    "i-cloud-rain", "i-coffee", "i-flame-2", "i-library-2"):
        assert f'href="#{icon_id}"' in body, f"icon {icon_id} not in template"


def test_v73_focus_ambient_options_present(client):
    r = client.get("/focus/")
    body = r.data.decode()
    for sound in ("off", "rain", "cafe", "fire", "library"):
        assert f'data-sound="{sound}"' in body


def test_v73_focus_session_endpoints_still_work(client):
    """Pre-existing session start/end endpoints must continue to function."""
    r = client.post("/focus/api/session/start",
                    json={"session_type": "pomodoro", "target_minutes": 5})
    assert r.status_code == 200
    j = r.get_json()
    assert j["ok"] is True
    assert "id" in j

    r2 = client.post("/focus/api/session/end", json={"status": "completed"})
    assert r2.status_code == 200


def test_v73_focus_polish_css_layer(app_with_v73):
    """polish.css should have v7.3 focus-* classes."""
    from pathlib import Path
    css = (Path(app_with_v73.root_path) / "static" / "css" / "polish.css").read_text()
    for selector in (".focus-shell", ".focus-topbar", ".focus-timer",
                     ".focus-goal-ring", ".focus-editor-area",
                     ".focus-statusbar", ".focus-paragraph-overlay"):
        assert selector in css, f"selector {selector} missing"


def test_v73_focus_reduced_motion_rule(app_with_v73):
    from pathlib import Path
    css = (Path(app_with_v73.root_path) / "static" / "css" / "polish.css").read_text()
    assert "prefers-reduced-motion" in css
    # And the focus-shell block specifically calls it out
    idx = css.find(".focus-shell")
    assert idx >= 0


def test_v73_focus_start_id_param_picked_up(client):
    """?chapter= query param pre-selects a chapter."""
    from services.chapter_service import create_chapter
    ch = create_chapter(title="Focus Test Chapter", content="x")
    r = client.get(f"/focus/?chapter={ch.id}")
    body = r.data.decode()
    assert ch.id in body
    # The start_id is referenced in the script
    assert "startId" in body
