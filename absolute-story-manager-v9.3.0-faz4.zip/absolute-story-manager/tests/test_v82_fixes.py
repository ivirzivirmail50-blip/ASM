"""v8.2 regression tests — bug fixes + the A/B/C chat actions + Copilot 2.0.

Covers the four reported bugs and the new features:

1. Spell check 500 — the v7.7 Turkish branch returned a dict WITHOUT
   ``flagged_count``; ``check_all_chapters()`` then raised KeyError → HTTP
   500 for every Turkish writer. (Turkish chapter fixture reproduced it.)
2. Full import never applied the book name — project rows with existing IDs
   were skipped wholesale; v8.2 upserts book metadata from the file.
3. app.js toLowerCase crash — e.key can be undefined (IME/synthetic events).
4. Reading Mode ↑/↓ keys — only ←/→ were bound; also the "b" key toggled
   BOTH the sidebar and the bookmarks panel.
5. Button collisions (root fix) — dock z-index layer + Overlay Watchdog.
6. A/B/C chat actions + Copilot 2.0 story actions.
"""
from __future__ import annotations

import json

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _seed_turkish_chapter(title="Türkçe Bölüm", content=None):
    from core.db import write_transaction
    from models.chapter import Chapter
    from services._common import new_uuid, now_utc
    if content is None:
        content = ("İstanbul'un dar sokaklarında yürürken Ayşe'nin gözleri "
                   "parlıyordu. Çankırı'dan İzmir'e uzanan yolda ağaçtan "
                   "kuşlar uçtu. Şimşek taşı parladı.")
    with write_transaction() as s:
        ch = Chapter(id=new_uuid(), project_id="default", sort_order=1,
                     title=title, content=content, status="draft",
                     created_at=now_utc(), updated_at=now_utc())
        s.add(ch)
        return ch.id


def _seed_character(name="Ayşe Yılmazoğlu"):
    from core.db import write_transaction
    from models.character import Character
    from services._common import new_uuid
    with write_transaction() as s:
        c = Character(id=new_uuid(), project_id="default", name=name)
        s.add(c)
        return c.id


# ---------------------------------------------------------------------------
# 1 — Spell check: Turkish chapters must not 500
# ---------------------------------------------------------------------------

class TestSpellcheckTurkishFix:
    def test_turkish_result_has_flagged_count(self):
        from services import spellcheck_service as svc
        ch_id = _seed_turkish_chapter()
        result = svc.check_chapter(ch_id)
        assert "flagged_count" in result, "tr branch missing flagged_count (the 500)"
        assert isinstance(result["flagged_count"], int)

    def test_check_all_chapters_no_keyerror_on_turkish(self):
        from services import spellcheck_service as svc
        _seed_turkish_chapter()
        result = svc.check_all_chapters()  # raised KeyError before v8.2
        assert result["chapters_checked"] == 1
        assert "total_flagged" in result

    def test_spellcheck_page_200_with_turkish(self, client):
        _seed_turkish_chapter()
        rv = client.get("/spellcheck/")
        assert rv.status_code == 200
        assert b"Spell Check" in rv.data

    def test_spellcheck_api_200_with_turkish(self, client):
        _seed_turkish_chapter()
        rv = client.get("/spellcheck/api/check")
        assert rv.status_code == 200
        data = rv.get_json()
        assert data["ok"] is True

    def test_glossary_terms_are_checked_in_turkish(self):
        """v8.2: glossary terms belong to the near-miss set for tr chapters."""
        from core.db import write_transaction
        from models.glossary import GlossaryEntry
        from services import spellcheck_service as svc
        from services._common import new_uuid
        with write_transaction() as s:
            s.add(GlossaryEntry(id=new_uuid(), project_id="default",
                                term="Şimşektaşı", definition="x"))
        # "Şimşektaşz" is one edit away from the glossary term → flagged
        ch_id = _seed_turkish_chapter(
            content="Şimşektaşz parladı ve orman aydınlandı birden.")
        result = svc.check_chapter(ch_id)
        words = [f["word"] for f in result["flagged"]]
        assert any("imşek" in w for w in words), \
            "glossary near-miss not flagged for Turkish chapter"

    def test_english_chapters_unaffected(self):
        from services import spellcheck_service as svc
        ch_id = _seed_turkish_chapter(
            title="English", content="The quick brown fox jumps over the lazy dog.")
        result = svc.check_chapter(ch_id)
        assert "flagged_count" in result
        assert result.get("language") != "tr"


# ---------------------------------------------------------------------------
# 2 — Full import: the book name must come through
# ---------------------------------------------------------------------------

class TestImportBookName:
    def _payload(self, name="Kayıp Şehrin Sırrı"):
        return {
            "version": "asm-v7.5",
            "settings": {},
            "projects": [{
                "id": "default", "name": name, "subtitle": "Üçleme I",
                "genre": "fantastik", "target_words": 120000,
                "deadline": "2027-01-31", "color": "#8b5cf6",
                "created_at": "2025-01-01T00:00:00",
            }],
            "chapters": [],
        }

    def test_existing_project_name_updated(self):
        from core.db import read_session, write_transaction
        from models.project import Project
        from services import project_transfer_service as pts
        with write_transaction() as s:
            s.get(Project, "default").name = "Old Wrong Name"
        counts = pts.import_all(self._payload())
        with read_session() as s:
            proj = s.get(Project, "default")
            assert proj.name == "Kayıp Şehrin Sırrı"
            assert proj.genre == "fantastik"
            assert proj.target_words == 120000
        assert counts.get("projects_updated") == 1

    def test_reimport_idempotent(self):
        from services import project_transfer_service as pts
        pts.import_all(self._payload())
        counts = pts.import_all(self._payload())
        assert counts.get("projects", 0) == 0  # no duplicate row created

    def test_new_project_created_when_missing(self):
        from core.db import read_session
        from models.project import Project
        from services import project_transfer_service as pts
        payload = self._payload()
        payload["projects"][0]["id"] = "book-two"
        counts = pts.import_all(payload)
        with read_session() as s:
            assert s.get(Project, "book-two") is not None
        assert counts.get("projects") == 1

    def test_empty_values_do_not_blank_fields(self):
        from core.db import read_session, write_transaction
        from models.project import Project
        from services import project_transfer_service as pts
        with write_transaction() as s:
            p = s.get(Project, "default")
            p.genre = "kept-genre"
        payload = self._payload()
        payload["projects"][0]["genre"] = None
        pts.import_all(payload)
        with read_session() as s:
            assert s.get(Project, "default").genre == "kept-genre"

    def test_route_roundtrip(self, client):
        import io
        rv = client.post("/settings/import-json",
                         data={"file": (io.BytesIO(json.dumps(self._payload()).encode()),
                                       "book.json")},
                         content_type="multipart/form-data")
        assert rv.status_code == 200
        data = rv.get_json()
        assert data["ok"] is True
        from core.db import read_session
        from models.project import Project
        with read_session() as s:
            assert s.get(Project, "default").name == "Kayıp Şehrin Sırrı"


# ---------------------------------------------------------------------------
# 3 + 4 — Reading mode keys & app.js key guard (static analysis)
# ---------------------------------------------------------------------------

class TestKeyboardFixes:
    def test_appjs_no_unguarded_key_tolowercase(self):
        src = open("static/js/app.js", encoding="utf-8").read()
        assert "typeof e.key === \"string\"" in src, "e.key guard missing"
        # the raw pattern must only appear inside the explanatory comment
        for line in src.splitlines():
            if "e.key.toLowerCase()" in line:
                assert line.strip().startswith("//") or "every" in line, \
                    f"unguarded toLowerCase: {line.strip()[:80]}"

    def test_reading_mode_binds_up_down(self):
        src = open("static/js/reading_mode.js", encoding="utf-8").read()
        assert "'ArrowUp'" in src and "'ArrowDown'" in src
        assert "'PageUp'" in src and "'PageDown'" in src

    def test_reading_mode_marks_body_flag(self):
        src = open("static/js/reading_mode.js", encoding="utf-8").read()
        assert "data-reading-mode" in src

    def test_appjs_stands_down_in_reading_mode(self):
        src = open("static/js/app.js", encoding="utf-8").read()
        assert "data-reading-mode" in src, "global shortcuts must stand down"

    def test_reading_buttons_mention_up_down(self):
        src = open("templates/reading.html", encoding="utf-8").read()
        assert "(↑ or ←)" in src and "(↓ or →)" in src


# ---------------------------------------------------------------------------
# 5 — Button collision root fix
# ---------------------------------------------------------------------------

class TestCollisionRootFix:
    def test_dock_zindex_below_overlays(self):
        src = open("static/css/main.css", encoding="utf-8").read()
        assert "z-index: 45" in src, "dock must sit at z 45 (below overlays)"
        assert "z-index: 9950" not in src, "old dock z-index still present"

    def test_overlay_watchdog_css(self):
        src = open("static/css/main.css", encoding="utf-8").read()
        assert "body.asm-overlay-open .br-dock" in src

    def test_overlay_watchdog_js(self):
        src = open("static/js/app.js", encoding="utf-8").read()
        assert "_asmOverlayWatchdog" in src
        assert "asm-overlay-open" in src
        # animation-aware re-check
        assert "setTimeout(() => _check(), 350)" in src
        assert "setTimeout(() => _check(), 900)" in src

    def test_sw_version_bumped(self):
        src = open("static/js/sw.js", encoding="utf-8").read()
        # v9.1.0 (M-07): the SW cache version is now SYNCHRONIZED with
        # core.version.__version__ (test_asset_pipeline locks the sync).
        from core.version import __version__
        assert f'VERSION = "v{__version__}"' in src  # bumped with the app

    def test_settings_savebar_clears_dock(self):
        src = open("templates/settings.html", encoding="utf-8").read()
        assert "padding-right: 6.5rem" in src


# ---------------------------------------------------------------------------
# 6 — A / B / C chat actions
# ---------------------------------------------------------------------------

def _session_with_messages(char_id):
    from services import chat_service
    sess = chat_service.create_session(mode="character",
                                       character_ids=[char_id])
    chat_service.add_message(sess.id, role="user",
                             content="What do you fear most?")
    chat_service.add_message(sess.id, role="assistant",
                             content="I fear losing my sister. I hate boats.",
                             speaker_id=char_id, speaker_name="Ayşe Yılmazoğlu")
    return sess


class TestSceneDraft:
    def test_draft_generated_offline(self):
        from services import chat_actions_service as act
        cid = _seed_character()
        sess = _session_with_messages(cid)
        draft = act.scene_draft(sess.id)
        assert draft["title"]
        assert "fear" in draft["text"] or "sister" in draft["text"]

    def test_draft_saved_as_scene_card(self):
        from core.db import read_session
        from models.scene import SceneCard
        from services import chat_actions_service as act
        cid = _seed_character()
        sess = _session_with_messages(cid)
        draft = act.scene_draft(sess.id)
        result = act.save_scene_draft(sess.id, draft)
        with read_session() as s:
            card = s.get(SceneCard, result["scene_id"])
            assert card is not None
            assert card.status == "draft"
            assert "from-chat" in (card.tags or "")

    def test_empty_session_rejected(self):
        from services import chat_actions_service as act
        from services import chat_service
        cid = _seed_character()
        sess = chat_service.create_session(mode="character",
                                           character_ids=[cid])
        with pytest.raises(Exception):
            act.scene_draft(sess.id)

    def test_route_preview_and_save(self, client):
        cid = _seed_character()
        sess = _session_with_messages(cid)
        rv = client.post(f"/chat/api/sessions/{sess.id}/scene-draft",
                         json={})
        assert rv.status_code == 200
        draft = rv.get_json()["draft"]
        rv2 = client.post(f"/chat/api/sessions/{sess.id}/scene-draft/save",
                          json={"draft": draft})
        assert rv2.status_code == 200
        assert rv2.get_json()["ok"] is True

    def test_route_unknown_session(self, client):
        rv = client.post("/chat/api/sessions/nope/scene-draft", json={})
        assert rv.status_code == 400


class TestCharacterSync:
    def test_extract_offline_fallback_quotes(self):
        from services import chat_actions_service as act
        cid = _seed_character()
        sess = _session_with_messages(cid)
        ex = act.extract_character_updates(sess.id, cid)
        assert ex["character_id"] == cid
        assert any("boats" in q or "sister" in q for q in ex["quotes"])

    def test_apply_writes_card(self):
        from core.db import read_session
        from models.character import Character
        from services import chat_actions_service as act
        cid = _seed_character()
        act.apply_character_updates(cid, {
            "traits": ["Brave but contradictory"],
            "background_facts": ["Has a sister"],
        })
        with read_session() as s:
            ch = s.get(Character, cid)
            assert "Brave but contradictory" in (ch.psychology or "")
            assert "Has a sister" in (ch.background or "")

    def test_apply_empty_is_noop(self):
        from services import chat_actions_service as act
        cid = _seed_character()
        result = act.apply_character_updates(cid, {})
        assert result["updated"] == []

    def test_extract_rejects_outsider(self):
        from services import chat_actions_service as act
        cid = _seed_character()
        other = _seed_character("Başkası")
        sess = _session_with_messages(cid)
        with pytest.raises(Exception):
            act.extract_character_updates(sess.id, other)

    def test_routes(self, client):
        cid = _seed_character()
        sess = _session_with_messages(cid)
        rv = client.post(f"/chat/api/sessions/{sess.id}/sync-character",
                         json={"character_id": cid})
        assert rv.status_code == 200
        ex = rv.get_json()["extraction"]
        rv2 = client.post(f"/chat/api/characters/{cid}/sync-character/apply",
                          json={"updates": {"traits": ["X trait"]}})
        assert rv2.status_code == 200
        rv3 = client.post(f"/chat/api/sessions/{sess.id}/sync-character",
                          json={"character_id": ""})
        assert rv3.status_code == 400


class TestSuggestQuestions:
    def test_offline_fallback_questions(self):
        from services import chat_actions_service as act
        cid = _seed_character()
        sess = _session_with_messages(cid)
        result = act.suggest_questions(sess.id)
        assert len(result["questions"]) == 5

    def test_route(self, client):
        cid = _seed_character()
        sess = _session_with_messages(cid)
        rv = client.post(f"/chat/api/sessions/{sess.id}/suggest-questions",
                         json={})
        assert rv.status_code == 200
        assert len(rv.get_json()["questions"]) == 5


# ---------------------------------------------------------------------------
# 7 — Copilot 2.0
# ---------------------------------------------------------------------------

class TestCopilotStoryActions:
    def test_action_list(self, client):
        rv = client.get("/ai-copilot/api/story-actions")
        assert rv.status_code == 200
        actions = rv.get_json()["actions"]
        ids = {a["id"] for a in actions}
        assert {"plot_holes", "book_summary", "next_scene",
                "consistency", "twists", "world_gaps"} == ids

    def test_unknown_action_400(self, client):
        rv = client.post("/ai-copilot/api/story-action-stream",
                         json={"action": "nonsense"})
        assert rv.status_code == 400

    def test_page_renders_quick_actions(self, client):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", "true")
        rv = client.get("/ai-copilot/")
        assert rv.status_code == 200
        assert b"Quick Story Actions" in rv.data
        assert b"runStoryAction('plot_holes')" in rv.data
        assert b"Save as Note" in rv.data

    def test_stream_endpoint_emits_context_first(self, client):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", "true")
        rv = client.post("/ai-copilot/api/story-action-stream",
                         json={"action": "plot_holes"})
        assert rv.status_code == 200
        assert rv.mimetype == "text/event-stream"
        first = rv.get_data(as_text=True).splitlines()[0]
        assert '"type": "context"' in first

    def test_template_has_save_as_note(self):
        src = open("templates/ai_copilot/index.html", encoding="utf-8").read()
        assert "saveResultAsNote" in src
        assert "notes/api/new" in src


# ---------------------------------------------------------------------------
# 8 — UI wiring for the A/B/C buttons
# ---------------------------------------------------------------------------

class TestChatUIWiring:
    def _ai_on(self):
        from core.db import write_transaction
        from models.settings import Setting
        with write_transaction() as s:
            Setting.set(s, "ai.enabled", "true")

    def test_template_has_story_action_buttons(self, client):
        self._ai_on()
        cid = _seed_character()
        rv = client.get("/character-chat/")
        assert rv.status_code == 200
        assert b"CC.sceneDraft()" in rv.data
        assert b"CC.syncCharacter()" in rv.data
        assert b"CC.suggestQuestions()" in rv.data

    def test_template_has_modals(self, client):
        self._ai_on()
        _seed_character()
        rv = client.get("/character-chat/")
        assert b"ccDraftModal" in rv.data
        assert b"ccSyncModal" in rv.data

    def test_js_has_abc_functions(self):
        src = open("static/js/character_chat.js", encoding="utf-8").read()
        assert "sceneDraft" in src and "saveDraft" in src
        assert "syncCharacter" in src and "applySync" in src
        assert "suggestQuestions" in src and "useCoachQuestion" in src

    def test_css_for_story_actions(self):
        src = open("static/css/main.css", encoding="utf-8").read()
        assert ".cc-story-actions" in src
        assert ".story-action-btn" in src
