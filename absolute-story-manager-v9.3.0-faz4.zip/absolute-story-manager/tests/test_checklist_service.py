"""M-08 — checklist service coverage (34% → 80%+)."""
from __future__ import annotations

import pytest

from core.errors import ValidationError
from services import checklist_service as svc


@pytest.fixture()
def chapter_id():
    from services import chapter_service
    ch = chapter_service.create_chapter(title="Checklist Chapter",
                                        content="abc")
    return ch.id


class TestChecklistCrud:

    def test_get_seeds_defaults(self, chapter_id):
        items = svc.get_checklist(chapter_id)
        assert len(items) == len(svc.DEFAULT_CHECKLIST)
        cats = {i.category for i in items}
        assert {"plot", "character", "style", "grammar", "general"} <= cats
        assert all(not i.is_checked for i in items)

    def test_get_is_idempotent(self, chapter_id):
        first = svc.get_checklist(chapter_id)
        second = svc.get_checklist(chapter_id)
        assert len(first) == len(second)

    def test_add_item_and_validation(self, chapter_id):
        item = svc.add_item(chapter_id, "Yeni kontrol maddesi",
                            category="plot")
        assert item.id
        # add_item's order counter = current item count (seeding happens
        # only when get_checklist finds ZERO items, so it never runs here).
        assert item.sort_order == 0
        item2 = svc.add_item(chapter_id, "İkinci madde")
        assert item2.sort_order == 1
        with pytest.raises(ValidationError):
            svc.add_item(chapter_id, "")
        with pytest.raises(ValidationError):
            svc.add_item(chapter_id, "x" * 501)

    def test_toggle_item(self, chapter_id):
        item = svc.add_item(chapter_id, "toggle me")
        assert svc.toggle_item(item.id) is True
        assert svc.toggle_item(item.id) is False
        assert svc.toggle_item("nonexistent") is False

    def test_delete_item(self, chapter_id):
        item = svc.add_item(chapter_id, "delete me")
        svc.delete_item(item.id)
        remaining = svc.get_checklist(chapter_id)
        assert all(i.id != item.id for i in remaining)
        # deleting a ghost id must not raise
        svc.delete_item("nonexistent")


class TestChecklistProgress:

    def test_progress_zero(self, chapter_id):
        p = svc.get_progress(chapter_id)
        assert p["total"] == len(svc.DEFAULT_CHECKLIST)
        assert p["checked"] == 0
        assert p["pct"] == 0
        assert "plot" in p["by_category"]

    def test_progress_partial(self, chapter_id):
        items = svc.get_checklist(chapter_id)
        svc.toggle_item(items[0].id)
        svc.toggle_item(items[1].id)
        p = svc.get_progress(chapter_id)
        assert p["checked"] == 2
        assert p["pct"] == round(2 / p["total"] * 100)
        # Category roll-up counted.
        checked_cats = [
            c for c, d in p["by_category"].items() if d["checked"]
        ]
        assert checked_cats

    def test_progress_empty_chapter(self):
        # v9.3.0 (F-06): chapter_checklists.chapter_id is a hard FK — a ghost
        # chapter no longer auto-seeds; it reports an empty checklist.
        p = svc.get_progress("ghost-chapter")
        assert p["total"] == 0
        assert p["pct"] == 0
