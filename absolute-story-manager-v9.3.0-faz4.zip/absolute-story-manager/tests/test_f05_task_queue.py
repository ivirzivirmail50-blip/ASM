"""F-05 — dayanıklı görev kuyruğu testleri (v9.3.0).

Kilitlenen sözleşmeler:
  * enqueue → pending satır DB'de kalıcı
  * claim_next atomik: iki claim aynı görevi almaz
  * execute_one lifecycle: claim → progress → complete (+ result JSON)
  * fail path: executor hatası → status=failed + error metni
  * dayanıklılık: running'de takılan görev recover_stale_running ile
    pending'e döner (uygulama çöküşü simülasyonu)
  * purge_finished: eski done/failed satırları silinir, yenileri kalır
  * export entegrasyonu: async_export → execute_one → dosya + status done
  * status_dict: get_export_status API şekli korunur
  * rotalar: GET /tasks, GET /tasks/<id>, 404 zarfı
"""
from __future__ import annotations

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from services import task_queue_service as q  # noqa: E402

# ---------------------------------------------------------------------------
# Yaşam döngüsü
# ---------------------------------------------------------------------------

class TestLifecycle:

    def test_enqueue_creates_pending_row(self):
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        assert t.status == "pending"
        assert t.kind == "export"
        assert q.get_task(t.id) is not None

    def test_claim_is_atomic_and_fifo(self):
        t1 = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        t2 = q.enqueue("export", {"entity_type": "world_bible", "fmt": "md"})
        c1 = q.claim_next()
        c2 = q.claim_next()
        # FIFO: ilk giren önce alınır; iki claim farklı görevler
        assert {c1.id, c2.id} == {t1.id, t2.id}
        assert c1.id == t1.id
        # claim edilenler running
        assert q.get_task(c1.id).status == "running"
        assert q.get_task(c2.id).status == "running"
        # kuyruk boşaldı
        assert q.claim_next() is None

    def test_complete_and_fail_transitions(self):
        t = q.enqueue("export", {})
        q.claim_next()
        q.update_progress(t.id, 42, "Yarında")
        mid = q.get_task(t.id)
        assert mid.status == "running"
        assert mid.progress == 42
        q.complete(t.id, {"filename": "x.txt"})
        done = q.get_task(t.id)
        assert done.status == "done"
        assert done.progress == 100
        assert done.finished_at is not None

    def test_fail_records_error(self):
        t = q.enqueue("export", {})
        q.claim_next()
        q.fail(t.id, "ValueError: boom")
        row = q.get_task(t.id)
        assert row.status == "failed"
        assert "boom" in row.error

    def test_execute_one_dispatches_and_completes(self):
        import json as _json

        from services import export_service
        # küçük bir manuscript txt export'u — bölüm yoksa boş dosya da olur
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        assert q.execute_one() is True
        row = q.get_task(t.id)
        assert row.status == "done", row.error
        result = _json.loads(row.result)
        assert "filename" in result
        # export_service arayüzü aynı task_id'yi görür
        st = export_service.get_export_status(t.id)
        assert st["status"] == "done"
        assert st["progress"] == 100
        assert st["filename"] == result["filename"]

    def test_execute_one_unknown_kind_fails_cleanly(self):
        t = q.enqueue("space-laser", {})
        assert q.execute_one() is True  # koştu ama başarısız
        row = q.get_task(t.id)
        assert row.status == "failed"
        assert "Unknown task kind" in row.error

    def test_execute_one_empty_queue_returns_false(self):
        # kuyruğu tüket
        while q.claim_next() is not None:
            pass
        assert q.execute_one() is False


# ---------------------------------------------------------------------------
# Dayanıklılık
# ---------------------------------------------------------------------------

class TestDurability:

    def test_stale_running_recovered_to_pending(self):
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        q.claim_next()  # running — şimdi "çökelim"
        assert q.get_task(t.id).status == "running"

        recovered = q.recover_stale_running()
        assert recovered >= 1
        row = q.get_task(t.id)
        assert row.status == "pending"
        assert row.stage == "Requeued after restart"
        assert row.progress == 0
        # ve tekrar koşabilir
        assert q.execute_one() is True
        assert q.get_task(t.id).status == "done"

    def test_purge_removes_old_finished_keeps_recent(self):
        t_old = q.enqueue("export", {})
        q.claim_next()
        q.complete(t_old.id, {})
        t_new = q.enqueue("export", {})
        q.claim_next()
        q.complete(t_new.id, {})

        # eskiyi geçmişe it
        from sqlalchemy import update

        from core.db import new_bg_session
        from models.background_task import BackgroundTask
        old_time = datetime.now(timezone.utc) - timedelta(days=30)
        with new_bg_session() as s:
            s.execute(update(BackgroundTask)
                      .where(BackgroundTask.id == t_old.id)
                      .values(created_at=old_time))
            s.commit()

        removed = q.purge_finished(older_than_days=7, keep_rows=200)
        assert removed >= 1
        assert q.get_task(t_old.id) is None
        assert q.get_task(t_new.id) is not None

    def test_purge_respects_keep_rows_floor(self):
        # 4 GÜNCEL bitmiş görev, keep_rows=2 → yaş kuralı hiç silmez,
        # taban kuralı en eski 2'yi siler, en yeni 2 kalır.
        ids = []
        for _ in range(4):
            t = q.enqueue("export", {})
            q.claim_next()
            q.complete(t.id, {})
            ids.append(t.id)
        from sqlalchemy import update

        from core.db import new_bg_session
        from models.background_task import BackgroundTask
        base = datetime.now(timezone.utc)
        with new_bg_session() as s:
            for i, tid in enumerate(ids):
                s.execute(update(BackgroundTask)
                          .where(BackgroundTask.id == tid)
                          .values(created_at=base - timedelta(minutes=10 - i)))
            s.commit()
        q.purge_finished(older_than_days=7, keep_rows=2)
        assert q.get_task(ids[0]) is None     # en eski ikisi
        assert q.get_task(ids[1]) is None
        assert q.get_task(ids[2]) is not None
        assert q.get_task(ids[3]) is not None


# ---------------------------------------------------------------------------
# Rotalar
# ---------------------------------------------------------------------------

class TestTaskRoutes:

    def test_list_and_detail(self, client):
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        r = client.get("/tasks")
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] is True
        assert any(x["task_id"] == t.id for x in data["tasks"])

        r2 = client.get(f"/tasks/{t.id}")
        assert r2.status_code == 200
        assert r2.get_json()["task"]["status"] == "pending"

    def test_detail_404_envelope(self, client):
        from core.errors import NotFoundError
        r = client.get("/tasks/ghost-task")
        assert r.status_code == 404

    def test_export_async_flow_via_route(self, client):
        # rota → kuyruk → senkron koştur → durum done
        from services import export_service
        r = client.post("/export/start", json={
            "entity_type": "manuscript", "fmt": "txt"})
        if r.status_code == 200:
            tid = r.get_json()["task_id"]
            q.execute_one()
            st = export_service.get_export_status(tid)
            assert st["status"] == "done"
            content, mime, fname = export_service.get_export_file(tid)
            assert content  # dosya okundu


# ---------------------------------------------------------------------------
# Worker (thread)
# ---------------------------------------------------------------------------

class TestWorker:

    def test_start_worker_is_idempotent_and_recovers(self):
        # mevcut bir running görevi kurtarmalı + tek thread
        t = q.enqueue("export", {"entity_type": "manuscript", "fmt": "txt"})
        q.claim_next()
        q.start_worker()
        q.start_worker()
        import time
        deadline = time.time() + 10
        while time.time() < deadline:
            row = q.get_task(t.id)
            if row.status == "done":
                break
            time.sleep(0.05)
        assert q.get_task(t.id).status == "done"
        q.stop_worker()
