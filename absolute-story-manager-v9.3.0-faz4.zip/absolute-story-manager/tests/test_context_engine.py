"""Tests for the v6.0 Story Context Engine (RAG)."""
import pytest

from core.db import read_session, write_transaction
from models.character import CharacterRelationship
from services import (
    chapter_service,
    character_service,
    context_engine,
    glossary_service,
    world_service,
)
from services._common import new_uuid


@pytest.fixture
def story_data():
    """A small story database: 3 chapters, 3 characters, 2 world entries, 2 glossary terms."""
    ch1 = chapter_service.create_chapter(
        title="The Arrival",
        content="Elara stepped off the boat onto the pier of Stormhaven. The harbor city smelled of salt.",
        synopsis="Elara arrives in Stormhaven by boat.")
    ch2 = chapter_service.create_chapter(
        title="The Bargain",
        content="Kael the smuggler offered Elara passage to the Ember Wastes. She refused at first.",
        synopsis="Elara refuses Kael's offer, then accepts.")
    ch3 = chapter_service.create_chapter(
        title="The Wastes",
        content="The Ember Wastes stretched before them. Voss waited at the shrine.")
    c1 = character_service.create_character(
        name="Elara", role="protagonist", physical="tall, silver hair",
        psychology="stubborn, brave", background="exiled noble")
    c2 = character_service.create_character(
        name="Kael", role="supporting", physical="scarred face",
        psychology="cynical", background="smuggler")
    c3 = character_service.create_character(
        name="Voss", role="antagonist")
    w1 = world_service.create_entry(type_="location", name="Stormhaven",
                                    description="A harbor city on the northern coast.")
    w2 = world_service.create_entry(type_="location", name="Ember Wastes",
                                    description="A scorched desert with ancient shrines.")
    g1 = glossary_service.create_entry(term="Ashbound", definition="Mark of the old fire cult")
    g2 = glossary_service.create_entry(term="Silverfall", definition="Elara's family sword")
    # Relationship Elara ↔ Kael
    with write_transaction() as s:
        s.add(CharacterRelationship(
            id=new_uuid(), from_character_id=c1.id, to_character_id=c2.id,
            relationship_type="reluctant allies", is_bidirectional=True))
    return {"ch1": ch1, "ch2": ch2, "ch3": ch3,
            "c1": c1, "c2": c2, "c3": c3, "w1": w1, "w2": w2, "g1": g1, "g2": g2}


# --- Detection -------------------------------------------------------------

def test_detect_characters_by_name(story_data):
    from models.character import Character
    with read_session() as s:
        chars = list(s.query(Character).all())
    found = context_engine.detect_characters("Elara walked into the tavern.", chars)
    assert [c.name for c in found] == ["Elara"]


def test_detect_characters_ignores_partial_names(story_data):
    from models.character import Character
    with read_session() as s:
        chars = list(s.query(Character).all())
    # "Elarax" should NOT match Elara (word boundary)
    found = context_engine.detect_characters("Elarax is a different person.", chars)
    assert found == []


def test_detect_multiple_characters(story_data):
    from models.character import Character
    with read_session() as s:
        chars = list(s.query(Character).all())
    found = context_engine.detect_characters("Kael and Voss argued.", chars)
    names = {c.name for c in found}
    assert names == {"Kael", "Voss"}


def test_detect_world_entries(story_data):
    from models.world import WorldEntry
    with read_session() as s:
        entries = list(s.query(WorldEntry).all())
    found = context_engine.detect_world_entries("They sailed toward Stormhaven at dawn.", entries)
    assert [w.name for w in found] == ["Stormhaven"]


def test_detect_glossary_terms(story_data):
    from models.glossary import GlossaryEntry
    with read_session() as s:
        entries = list(s.query(GlossaryEntry).all())
    found = context_engine.detect_glossary("The Ashbound mark glowed on his palm.", entries)
    assert [g.term for g in found] == ["Ashbound"]


# --- Bundle building ---------------------------------------------------------

def test_build_context_assembles_everything(story_data):
    bundle = context_engine.build_context(
        "Elara and Kael crossed the Ember Wastes toward the shrine. The Ashbound mark burned.",
        chapter_id=story_data["ch3"].id,
    )
    names = {c["name"] for c in bundle.characters}
    assert "Elara" in names
    assert "Kael" in names
    world_names = {w["name"] for w in bundle.world}
    assert "Ember Wastes" in world_names
    terms = {g["term"] for g in bundle.glossary}
    assert "Ashbound" in terms
    # Plot memory: chapters before ch3 (The Arrival, The Bargain)
    titles = [p["title"] for p in bundle.plot]
    assert "The Arrival" in titles
    assert "The Bargain" in titles
    assert "The Wastes" not in titles  # never includes the anchor chapter itself
    # Relationship between detected characters
    assert any(r["from_name"] == "Elara" and r["to_name"] == "Kael"
               for r in bundle.relationships)


def test_build_context_respects_toggles(story_data):
    bundle = context_engine.build_context(
        "Elara entered Stormhaven.",
        chapter_id=story_data["ch3"].id,
        include={"characters": False, "relationships": False,
                 "world": True, "glossary": False, "plot": False},
    )
    assert bundle.characters == []
    assert bundle.plot == []
    assert bundle.world  # world still on


def test_render_is_nonempty_and_budgeted(story_data):
    bundle = context_engine.build_context(
        "Elara and Kael crossed the Ember Wastes. The Ashbound mark burned.",
        chapter_id=story_data["ch3"].id,
    )
    rendered = bundle.render()
    assert "CHARACTERS" in rendered
    assert "WORLD" in rendered
    assert "Elara" in rendered
    assert bundle.chars_used > 0
    assert bundle.chars_used <= context_engine.DEFAULT_BUDGET_CHARS


def test_build_prompt_wraps_context(story_data):
    prompt, bundle = context_engine.build_prompt(
        "Continue the story.",
        "Elara and Kael crossed the Ember Wastes.",
        chapter_id=story_data["ch3"].id,
    )
    assert "STORY CONTEXT" in prompt
    assert "TEXT TO WORK ON" in prompt
    assert "Elara" in prompt
    assert bundle.stats()["characters"] >= 2


def test_context_with_turkish_names():
    """Turkish İ/I normalization must not break name detection."""
    from models.character import Character
    from services._common import new_uuid

    def make(name):
        return Character(id=new_uuid(), name=name)

    chars = [make("İpek"), make("Deniz")]
    found = context_engine.detect_characters("İpek denize yürüdü.", chars)
    assert [c.name for c in found] == ["İpek"]
    # case-insensitive dotless/dotted
    found2 = context_engine.detect_characters("ipek DEniz konuştu", chars)
    assert {c.name for c in found2} == {"İpek", "Deniz"}
