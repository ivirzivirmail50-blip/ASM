"""S-09/S-10 — dev requirements split, lock file, ruff config, CI workflow."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestRequirementsSplit:
    def test_runtime_requirements_exclude_test_tools(self):
        """pytest/pytest-cov must NOT ship with production installs."""
        text = (ROOT / "requirements.txt").read_text()
        active = [ln.strip() for ln in text.splitlines()
                  if ln.strip() and not ln.strip().startswith("#")]
        for ln in active:
            assert not re.match(r"pytest", ln, re.I), f"test tool in prod: {ln}"

    def test_dev_requirements_include_test_tools(self):
        text = (ROOT / "requirements-dev.txt").read_text()
        assert "-r requirements.txt" in text
        assert re.search(r"^pytest>=", text, re.M)
        assert re.search(r"^pytest-cov>=", text, re.M)
        assert re.search(r"^ruff>=", text, re.M)

    def test_lock_file_pins_all_runtime_deps(self):
        """Every package in requirements.txt must have an exact pin."""
        reqs = (ROOT / "requirements.txt").read_text()
        lock = (ROOT / "requirements.lock").read_text()
        for ln in reqs.splitlines():
            ln = ln.strip()
            if not ln or ln.startswith("#"):
                continue
            pkg = re.split(r"[><=\[]", ln)[0].strip().lower()
            assert re.search(rf"^{pkg}==", lock, re.M | re.I), (
                f"{pkg} missing from requirements.lock"
            )

    def test_ruff_config_exists_and_is_minimal(self):
        text = (ROOT / "pyproject.toml").read_text()
        assert "[tool.ruff]" in text
        assert '"F821" not in' not in text  # F821 (undefined names) stays ON
        # The Phase-2 deferrals are documented, not silently dropped:
        assert '"F401"' in text  # listed in ignore with M-05 comment


class TestCIWorkflow:
    def test_workflow_exists(self):
        assert (ROOT / ".github" / "workflows" / "ci.yml").exists()

    def test_workflow_matrix_and_commands(self):
        text = (ROOT / ".github" / "workflows" / "ci.yml").read_text()
        assert "3.11" in text and "3.12" in text
        assert "requirements-dev.txt" in text
        assert "ruff check" in text
        assert "pytest" in text and "--cov" in text
        assert "PYTHONPATH" in text

    def test_workflow_triggers(self):
        text = (ROOT / ".github" / "workflows" / "ci.yml").read_text()
        assert "push:" in text
        assert "pull_request" in text


class TestRuffClean:
    def test_ruff_check_passes(self):
        """Acceptance criterion: `ruff check .` is clean (CI gate)."""
        import subprocess
        import sys
        result = subprocess.run(
            [sys.executable, "-m", "ruff", "check", "."],
            cwd=ROOT, capture_output=True, text=True, timeout=120,
        )
        assert result.returncode == 0, (
            f"ruff check failed:\n{result.stdout[-800:]}{result.stderr[-400:]}"
        )
