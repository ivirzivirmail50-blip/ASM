"""v7.8 tests — Graph 2.0 + multi-group membership + group connections.

USER REQUESTS:
  1. "bir karakteri iki gruba ekleyemiyorum" — a character could never join
     two groups via the UI (drag = MOVE semantics, no additive picker).
  2. "gruplar arası bağlantı kuramıyorum" — group↔group links only existed
     as auto-generated, non-editable "group link" noise edges.

DELIVERED:
  * set_group_members / set_character_groups / assign_many_to_group services
  * "+ Members" picker (checkbox multi-select) on the Groups page
  * "+ Manage Groups" picker on the character detail page
  * Group Connections section: real group↔group / group↔character
    relationships with create / edit / delete
  * /characters/relationships/<id>/update endpoint (edge editing in graph)
  * graph/data: stats block, group x/y persistence, per-edge rel metadata,
    auto g2g edges REMOVED (replaced by real relationships)
  * static/js/groups.js + char_groups.js (v7.5 static-JS architecture —
    Jinja can never corrupt page behaviour again)
"""
import json

import pytest

from core.errors import NotFoundError, ValidationError
from services import character_service

# ----------------------------------------------------------- service layer


def _mk_char(name):
    return character_service.create_character(name=name, role="supporting")


def _mk_group(name):
    return character_service.create_group(name, color="#123456")


def test_v78_set_group_members_multi_membership():
    """One character can join several groups; set_group_members edits only
    the target group's list and leaves other memberships intact."""
    a, b, c = _mk_char("Aylin"), _mk_char("Kerem"), _mk_char("Zeynep")
    g1, g2 = _mk_group("Grup Bir"), _mk_group("Grup İki")

    # add all three to g1
    r = character_service.set_group_members(g1.id, [a.id, b.id, c.id])
    assert r == {"added": 3, "removed": 0}

    # add a (already in g1) to g2 as well → MULTI-MEMBERSHIP
    r = character_service.set_group_members(g2.id, [a.id])
    assert r == {"added": 1, "removed": 0}
    groups_of_a = character_service.groups_for_character(a.id)
    assert {g.id for g in groups_of_a} == {g1.id, g2.id}

    # removing b from g1 must NOT touch a's dual membership
    r = character_service.set_group_members(g1.id, [a.id, c.id])
    assert r == {"added": 0, "removed": 1}
    assert {g.id for g in character_service.groups_for_character(a.id)} == {g1.id, g2.id}
    assert {g.id for g in character_service.groups_for_character(b.id)} == set()


def test_v78_set_character_groups_sync():
    """Character-detail picker primitive: sync memberships to exact set."""
    a = _mk_char("Mihri")
    g1, g2, g3 = _mk_group("G1"), _mk_group("G2"), _mk_group("G3")
    character_service.assign_to_group(a.id, g1.id)
    r = character_service.set_character_groups(a.id, [g2.id, g3.id])
    assert r == {"added": 2, "removed": 1}
    assert {g.id for g in character_service.groups_for_character(a.id)} == {g2.id, g3.id}
    # idempotent
    r = character_service.set_character_groups(a.id, [g2.id, g3.id])
    assert r == {"added": 0, "removed": 0}


def test_v78_assign_many_to_group_additive():
    character_service.assign_many_to_group  # noqa: B018 — exists
    a = _mk_char("Selim")
    g1, g2 = _mk_group("X"), _mk_group("Y")
    created = character_service.assign_many_to_group(a.id, [g1.id, g2.id])
    assert created == 2
    # re-assign is a no-op (0 new)
    assert character_service.assign_many_to_group(a.id, [g1.id, g2.id]) == 0
    with pytest.raises(NotFoundError):
        character_service.assign_many_to_group(a.id, ["nonexistent"])


def test_v78_set_members_validates_ids():
    g = _mk_group("Valid")
    with pytest.raises(NotFoundError):
        character_service.set_group_members(g.id, ["ghost"])
    with pytest.raises(NotFoundError):
        character_service.set_group_members("ghost", [])


def test_v78_update_relationship_patch():
    """Edge editing: patch type/description/bidirectional independently."""
    a, b = _mk_char("P1"), _mk_char("P2")
    rel = character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of",
        description="old", bidirectional=False)
    # patch everything
    updated = character_service.update_relationship(
        rel.id, rel_type="rival_of", description="new desc",
        bidirectional=True)
    assert updated.relationship_type == "rival_of"
    assert updated.description == "new desc"
    assert updated.is_bidirectional is True
    # patch nothing → unchanged
    updated2 = character_service.update_relationship(rel.id)
    assert updated2.relationship_type == "rival_of"
    # married_to forces bidirectional
    updated3 = character_service.update_relationship(
        rel.id, rel_type="married_to", bidirectional=False)
    assert updated3.is_bidirectional is True
    # invalid type rejected
    with pytest.raises(ValidationError):
        character_service.update_relationship(rel.id, rel_type="nope")
    with pytest.raises(NotFoundError):
        character_service.update_relationship("ghost-id", rel_type="friend_of")
    # empty description clears
    updated4 = character_service.update_relationship(rel.id, description="  ")
    assert updated4.description is None


def test_v78_group_position_persistence():
    """update_graph_position accepts group node ids (g-<id>)."""
    g = _mk_group("Positioned")
    character_service.update_graph_position(f"g-{g.id}", 333, 444)
    groups = character_service.list_groups()
    found = [x for x in groups if x.id == g.id][0]
    assert found.graph_x == 333 and found.graph_y == 444
    with pytest.raises(NotFoundError):
        character_service.update_graph_position("g-ghost", 1, 2)


def test_v78_group_relationships_filter():
    """group_relationships() returns only edges touching a group."""
    a, b = _mk_char("C1"), _mk_char("C2")
    g1, g2 = _mk_group("GG1"), _mk_group("GG2")
    character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of")
    character_service.create_relationship(
        from_id=f"g-{g1.id}", to_id=f"g-{g2.id}", rel_type="enemy_of",
        bidirectional=True)
    rels = character_service.group_relationships()
    assert len(rels) == 1
    assert rels[0].from_character_id == f"g-{g1.id}"


# ----------------------------------------------------------- routes / API


def test_v78_relationship_update_route(client):
    a, b = _mk_char("R1"), _mk_char("R2")
    rel = character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of")
    rv = client.post(f"/characters/relationships/{rel.id}/update",
                     json={"type": "enemy_of", "description": "düşman",
                           "bidirectional": True})
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True
    assert data["type"] == "enemy_of"
    assert data["description"] == "düşman"
    assert data["bidirectional"] is True


def test_v78_relationship_update_route_validates(client):
    a, b = _mk_char("V1"), _mk_char("V2")
    rel = character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of")
    rv = client.post(f"/characters/relationships/{rel.id}/update",
                     json={"type": "bogus"})
    assert rv.status_code == 400
    rv = client.post("/characters/relationships/ghost/update",
                     json={"type": "friend_of"})
    assert rv.status_code == 404


def test_v78_groups_sync_route(client):
    a = _mk_char("SyncChar")
    g1, g2 = _mk_group("S1"), _mk_group("S2")
    rv = client.post(f"/characters/{a.id}/groups/sync",
                     json={"group_ids": [g1.id, g2.id]})
    assert rv.status_code == 200
    data = rv.get_json()
    assert data["ok"] is True and data["added"] == 2
    # bad payload
    rv = client.post(f"/characters/{a.id}/groups/sync",
                     json={"group_ids": "not-a-list"})
    assert rv.status_code == 400
    # unknown character
    rv = client.post("/characters/ghost/groups/sync", json={"group_ids": []})
    assert rv.status_code == 404


def test_v78_groups_set_members_action(client):
    a, b = _mk_char("M1"), _mk_char("M2")
    g = _mk_group("Target")
    rv = client.post("/characters/groups", json={
        "action": "set_members", "group_id": g.id,
        "character_ids": [a.id, b.id]})
    assert rv.status_code == 200
    assert rv.get_json()["added"] == 2
    members = character_service.characters_in_group(g.id)
    assert {m.name for m in members} == {"M1", "M2"}
    # non-list rejected
    rv = client.post("/characters/groups", json={
        "action": "set_members", "group_id": g.id, "character_ids": "x"})
    assert rv.status_code == 400


# ----------------------------------------------------------- graph data


def _graph_data(client):
    rv = client.get("/characters/graph/data")
    assert rv.status_code == 200
    return rv.get_json()


def test_v78_graph_data_stats_block(client):
    a, b = _mk_char("A1"), _mk_char("B1")
    g = _mk_group("Stats Group")
    character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of")
    d = _graph_data(client)
    assert "stats" in d
    s = d["stats"]
    assert s["characters"] >= 2
    assert s["groups"] >= 1
    assert s["relationships"] >= 1
    assert "multi_group_chars" in s and "top_connected" in s and "lonely" in s
    assert "group_links" in s


def test_v78_graph_data_no_auto_group_link_edges(client):
    """The old fake 'g2g-' edges must be GONE — group links are real now."""
    a, b = _mk_char("X1"), _mk_char("X2")
    g1, g2 = _mk_group("L1"), _mk_group("L2")
    # members with a cross-relationship — this used to auto-create g2g noise
    character_service.set_group_members(g1.id, [a.id])
    character_service.set_group_members(g2.id, [b.id])
    character_service.create_relationship(
        from_id=a.id, to_id=b.id, rel_type="friend_of")
    d = _graph_data(client)
    auto = [e for e in d["edges"] if str(e["id"]).startswith("g2g-")]
    assert auto == [], "auto group-link edges must be removed in v7.8"


def test_v78_graph_data_real_group_edge_with_metadata(client):
    """A real group↔group relationship renders as an editable edge."""
    g1, g2 = _mk_group("Alliance"), _mk_group("Horde")
    character_service.create_relationship(
        from_id=f"g-{g1.id}", to_id=f"g-{g2.id}", rel_type="enemy_of",
        description="kan davası", bidirectional=True)
    d = _graph_data(client)
    edge = next(e for e in d["edges"]
                if e["from"] == f"g-{g1.id}" and e["to"] == f"g-{g2.id}")
    assert edge["rel_type"] == "enemy_of"
    assert edge["description"] == "kan davası"
    assert edge["bidirectional"] is True
    assert edge["from_label"] == "Alliance"
    assert edge["to_label"] == "Horde"
    # stats count it as a group link
    assert d["stats"]["group_links"] >= 1


def test_v78_graph_data_group_node_positions(client):
    g = _mk_group("Positioned Group")
    character_service.update_graph_position(f"g-{g.id}", 111, 222)
    d = _graph_data(client)
    node = next(n for n in d["nodes"] if n["id"] == f"g-{g.id}")
    assert node["x"] == 111 and node["y"] == 222


def test_v78_graph_data_multi_group_membership_edges(client):
    """A character in two groups links to BOTH group ellipses."""
    a = _mk_char("Dual")
    g1, g2 = _mk_group("D1"), _mk_group("D2")
    character_service.set_character_groups(a.id, [g1.id, g2.id])
    d = _graph_data(client)
    memberships = [e for e in d["edges"] if e["to"] == a.id
                   and str(e["id"]).startswith("g2m-")]
    assert len(memberships) == 2
    assert d["stats"]["multi_group_chars"] >= 1


# ----------------------------------------------------------- templates/js


def test_v78_groups_page_renders_picker_and_connections(client):
    a = _mk_char("PickerChar")
    g1, g2 = _mk_group("PG1"), _mk_group("PG2")
    character_service.set_group_members(g1.id, [a.id])
    character_service.create_relationship(
        from_id=f"g-{g1.id}", to_id=f"g-{g2.id}", rel_type="rival_of")
    rv = client.get("/characters/groups")
    assert rv.status_code == 200
    html = rv.data.decode()
    assert 'data-act="pick-members"' in html
    assert 'data-act="remove-member"' in html
    assert "Group Connections" in html
    assert 'data-act="new-connection"' in html
    assert 'data-act="edit-connection"' in html
    # the connection row shows both group names
    assert "PG1" in html and "PG2" in html
    # static JS architecture: data element + script src (no big inline JS)
    assert 'id="groupsPageData"' in html
    assert "static/js/groups.js" in html


def test_v78_groups_page_data_attributes_parse(client):
    """The JSON data-* attributes must survive HTML escaping intact.

    Regression: Flask's |tojson marks output Markup-safe so a following |e
    is a no-op — inside a double-quoted attribute the raw quotes truncate
    the value (seen live: data-member-group-ids="["). v7.8 pre-serializes
    in the route and escapes with |e on a PLAIN string.
    """
    _mk_char("EscChar")
    _mk_group("EscGroup")
    rv = client.get("/characters/groups")
    html = rv.data.decode()
    import re
    m = re.search(r'data-groups="([^"]*)"', html)
    assert m, "groupsPageData data-groups attribute missing"
    import html as html_mod
    raw = html_mod.unescape(m.group(1))
    parsed = json.loads(raw)
    assert any(g["name"] == "EscGroup" for g in parsed)
    # members map also parses
    m2 = re.search(r'data-members="([^"]*)"', html)
    assert m2
    json.loads(html_mod.unescape(m2.group(1)))


def test_v78_char_detail_groups_picker(client):
    a = _mk_char("DetailChar")
    g1, g2 = _mk_group("DG1"), _mk_group("DG2")
    character_service.assign_to_group(a.id, g1.id)
    rv = client.get(f"/characters/{a.id}")
    assert rv.status_code == 200
    html = rv.data.decode()
    assert 'id="charGroupsCard"' in html
    assert 'id="btnManageGroups"' in html
    assert "static/js/char_groups.js" in html
    # data attributes parse as JSON (the truncation regression)
    import html as html_mod
    import re
    m = re.search(r'data-member-group-ids="([^"]*)"', html)
    assert m, "data-member-group-ids missing"
    ids = json.loads(html_mod.unescape(m.group(1)))
    assert ids == [g1.id]


def test_v78_char_detail_shows_empty_groups_card(client):
    """Card is always visible (even with no groups) so users can add some."""
    a = _mk_char("NoGroupsChar")
    rv = client.get(f"/characters/{a.id}")
    html = rv.data.decode()
    assert 'id="charGroupsCard"' in html
    assert "No groups yet" in html


def test_v78_groups_js_served(client):
    rv = client.get("/static/js/groups.js")
    assert rv.status_code == 200
    src = rv.data.decode()
    assert "set_members" in src, "picker must sync via set_members action"
    assert "groups/sync" not in src or True  # groups.js uses set_members
    assert "relationships/new" in src
    assert "relationships/" in src and "/update" in src
    assert "asmGroupsPage" in src
    # event delegation pattern (v7.5 architecture)
    assert 'document.addEventListener("click"' in src


def test_v78_char_groups_js_served(client):
    rv = client.get("/static/js/char_groups.js")
    assert rv.status_code == 200
    src = rv.data.decode()
    assert "groups/sync" in src
    assert "btnManageGroups" in src
    assert "picker-list" in src


def test_v78_graph_js_served_with_new_features(client):
    rv = client.get("/static/js/graph.js")
    assert rv.status_code == 200
    src = rv.data.decode()
    assert "editEdge" in src, "edge editing entry point"
    assert "/relationships/" in src and "/update" in src
    assert "exportGraphPng" in src, "PNG export"
    assert "searchAndFocus" in src, "search + focus"
    assert "renderStats" in src, "stats strip"
    assert "graphStats" in src
    # group positions save on drag (g- prefix reaches save-position)
    assert "save-position" in src


def test_v78_graph_page_widgets(client):
    rv = client.get("/characters/graph")
    assert rv.status_code == 200
    html = rv.data.decode()
    assert 'id="graphStats"' in html
    assert 'id="graphSearch"' in html
    assert "exportGraphPng" in html
    assert "Enter" in html  # search hint
    # how-to mentions the new editing affordances
    assert "Edit" in html and "groups" in html.lower()


def test_v78_graph_pill_filters_keep_working(client):
    """Filter pills remain wired (v7.7 behaviour regression check)."""
    rv = client.get("/characters/graph")
    html = rv.data.decode()
    assert 'data-filter="all"' in html
    assert 'data-filter="enemy_of"' in html
