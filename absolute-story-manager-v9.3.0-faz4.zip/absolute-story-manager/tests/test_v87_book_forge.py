"""v8.7 — Book Forge tests.

Covers:
  1. Unicode-safe PDF font resolver (services.pdf_fonts)
  2. Print book PDF: trim sizes, mirrored layout, TOC page numbers,
     running headers, Turkish glyph fidelity, cover full-page
  3. Publication EPUB 3: mimetype/OPF/nav/chapters/CSS/cover/Turkish
  4. Publishing Preflight: every check family, score & grade
  5. Cover upload API: valid/invalid/magic-byte/size + remove
  6. Compile config: new keys, validation, language, book identity
     (active-book title fix), author override
  7. Turkish corruption fix regression across legacy PDF exports
  8. Routes + UI wiring on the Compile Wizard page
"""
from __future__ import annotations

import io
import json
import re
import zipfile

import pytest

from core.errors import ValidationError

# ---------------------------------------------------------------- helpers

def _png_bytes(color=(20, 40, 90), size=(400, 600)) -> bytes:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, format="PNG")
    return buf.getvalue()


def _seed_chapters(n=3, status="final", content=None):
    from core.db import read_session, write_transaction
    from models.chapter import Chapter
    with read_session() as s:
        from services._common import current_project_id
        pid = current_project_id(s)
    ids = []
    with write_transaction() as s:
        for i in range(1, n + 1):
            cid = f"v87ch{i}"
            s.add(Chapter(
                id=cid, project_id=pid, title=f"Test Chapter {i}",
                content=(content if content is not None else
                         ("Boğaz'ın sisli kıyısında bir fener yanıyordu. "
                          "Denizci bağırıyordu: ğışöçü ĞİŞÖÇÜ! "
                          "Sahne break sonrası metin devam ediyor. "
                          "Kıyı boyunca evler dizilmiş, pencerelerde ışık vardı.\n\n"
                          "İkinci paragraf ve sahnenin sonu.\n\n\n"
                          "Sahne break sonrası metin.\n\n" * 8)),
                sort_order=i, status=status))
            ids.append(cid)
    return ids


def _book_config(**overrides):
    from services import compile_service
    cfg = compile_service.get_config()
    cfg.update({
        "include_title_page": True, "include_copyright": True,
        "include_toc": True, "book_language": "en",
    })
    cfg.update(overrides)
    return cfg


def _compiled(cfg=None):
    from services import compile_service
    return compile_service.compile_manuscript(cfg or _book_config())


def _pdf_pages(data: bytes):
    from pypdf import PdfReader
    return PdfReader(io.BytesIO(data))


# ===================== 1. Font resolver ========================

class TestPdfFonts:
    def test_families_resolved(self):
        from services import pdf_fonts
        faces = pdf_fonts.ensure_fonts()
        for kind in ("serif", "sans", "mono"):
            assert kind in faces and len(faces[kind]) == 4
            assert faces[kind][0]

    def test_map_font_sends_builtins_to_safe_faces(self):
        from services import pdf_fonts
        assert pdf_fonts.map_font("Helvetica") == pdf_fonts.body_font("sans")
        assert pdf_fonts.map_font("Times-Roman") == pdf_fonts.body_font("serif")
        assert pdf_fonts.map_font("Courier") == pdf_fonts.font_faces("mono")[0]
        # unknown names pass through untouched
        assert pdf_fonts.map_font("ASM-Serif") == "ASM-Serif"

    def test_apply_to_stylesheet(self):
        from reportlab.lib.styles import getSampleStyleSheet

        from services import pdf_fonts
        ss = getSampleStyleSheet()
        pdf_fonts.apply_to_stylesheet(ss)
        names = {st.fontName for st in ss.byName.values()
                 if hasattr(st, "fontName")}
        assert "Helvetica" not in names

    def test_fallback_when_no_fonts_found(self, monkeypatch):
        from services import pdf_fonts
        monkeypatch.setattr(pdf_fonts, "_CANDIDATES", [])
        monkeypatch.setattr(pdf_fonts, "_MONO_CANDIDATES", [])
        pdf_fonts.reset_for_tests()
        faces = pdf_fonts.ensure_fonts()
        assert faces["serif"][0] == "Times-Roman"
        assert faces["sans"][0] == "Helvetica"
        assert faces["mono"][0] == "Courier"
        assert not pdf_fonts.using_embedded_fonts("serif")
        pdf_fonts.reset_for_tests()  # restore for later tests

    def test_idempotent(self):
        from services import pdf_fonts
        a = pdf_fonts.ensure_fonts()
        b = pdf_fonts.ensure_fonts()
        assert a == b


# ===================== 2. Print book PDF ========================

class TestBookPdf:
    @pytest.fixture(autouse=True)
    def seed(self):
        _seed_chapters(3)
        self.cfg = _book_config()

    def test_magic_and_pages(self):
        from services import compile_service
        data, mime, fname = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        assert data.startswith(b"%PDF-") and mime == "application/pdf"
        assert fname.endswith(".pdf")
        assert len(_pdf_pages(data).pages) >= 6

    def test_trim_sizes(self):
        from services import compile_service
        for name, (w, h) in {"6x9": (432, 648), "a5": (419.75, 595.27),
                             "letter": (612, 792)}.items():
            cfg = _book_config(pdf_page_size=name)
            data, _, _ = compile_service.render_compiled(_compiled(cfg), "pdf")
            box = [float(x) for x in _pdf_pages(data).pages[0].mediabox]
            assert abs(box[2] - w) < 1 and abs(box[3] - h) < 1, name

    def test_metadata_title_author(self):
        from services import compile_service
        data, _, _ = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        meta = _pdf_pages(data).metadata
        assert meta and meta.title == "Test Story"

    def test_toc_with_real_page_numbers(self):
        from services import compile_service
        data, _, _ = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        pages = _pdf_pages(data)
        toc_text = ""
        for p in pages.pages[:8]:
            t = p.extract_text() or ""
            if "Table of Contents" in t:
                toc_text = t
                break
        assert toc_text, "TOC page not found"
        # pypdf emits each entry's dots+number on its own line (drawn via
        # onDraw), so verify SEMANTICALLY: every chapter's REAL page number
        # appears on the TOC page, and vice versa.
        for i in (1, 2, 3):
            heading = f"Chapter {i} — Test Chapter {i}"
            assert heading in toc_text
            real = next(idx for idx, p in enumerate(pages.pages, start=1)
                        if idx > 3 and heading in (p.extract_text() or ""))
            assert str(real) in toc_text, f"TOC missing page {real} for ch {i}"
        # at least one page number proves real multiBuild output, not dummies
        assert re.search(r"\d", toc_text)

    def test_turkish_glyph_fidelity(self):
        from services import compile_service
        data, _, _ = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        # embedded TTF proof (WinAnsi built-ins can't carry these)
        assert b"FontFile2" in data
        text = "".join((p.extract_text() or "") for p in _pdf_pages(data).pages)
        assert "ğışöçü" in text and "ĞİŞÖÇÜ" in text
        assert "Boğaz'ın" in text

    def test_no_blank_pages_without_cover(self):
        from services import compile_service
        data, _, _ = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        for i, p in enumerate(_pdf_pages(data).pages, start=1):
            t = (p.extract_text() or "").strip()
            assert t, f"page {i} is completely blank"

    def test_cover_image_full_page(self, tmp_path, monkeypatch):
        from config import Config
        from services import compile_service
        monkeypatch.setattr(Config, "MEDIA_DIR", tmp_path)
        covers = tmp_path / "covers"
        covers.mkdir()
        (covers / "c.png").write_bytes(_png_bytes())
        cfg = _book_config(cover_image="/media/covers/c.png")
        data, _, _ = compile_service.render_compiled(_compiled(cfg), "pdf")
        first = _pdf_pages(data).pages[0]
        assert first.images, "cover page has no image"
        # the image must be drawn at REAL size: inspect the CTM preceding the
        # XObject Do operator — a degenerate matrix (all zeros) means the
        # flowable forgot to set self.width/self.height in wrap() and the
        # cover renders as a blank page.
        import re as _re
        stream = first.get_contents().get_data().decode("latin-1")
        m = _re.search(r"([\d.\- ]+)cm\s*/(\S+)\s+Do", stream)
        assert m, "no image draw operator in page 1 stream"
        nums = [float(x) for x in m.group(1).split()]
        assert abs(nums[0]) > 100 and abs(nums[3]) > 100, \
            f"cover image drawn at degenerate scale: {nums}"

    def test_scene_break_marker(self):
        from services import compile_service
        cfg = _book_config(scene_break_marker="* * *")
        data, _, _ = compile_service.render_compiled(_compiled(cfg), "pdf")
        text = "".join((p.extract_text() or "") for p in _pdf_pages(data).pages)
        assert "* * *" in text

    def test_language_turkish_labels(self):
        from services import compile_service
        cfg = _book_config(book_language="tr")
        data, _, _ = compile_service.render_compiled(_compiled(cfg), "pdf")
        text = "".join((p.extract_text() or "") for p in _pdf_pages(data).pages)
        assert "İçindekiler" in text
        assert "Bölüm 1" in text

    def test_pdf_outline_bookmarks(self):
        from services import compile_service
        data, _, _ = compile_service.render_compiled(_compiled(self.cfg), "pdf")
        r = _pdf_pages(data)
        titles = [o.get("/Title", "") for o in (r.outline or [])]
        assert any("Test Chapter 1" in t for t in titles)


# ===================== 3. Publication EPUB ========================

class TestBookEpub:
    @pytest.fixture(autouse=True)
    def seed(self):
        _seed_chapters(2)
        self.cfg = _book_config(include_dedication=True,
                                 dedication_text="Denizciler için")

    def _build(self, cfg=None):
        from services import compile_service
        return compile_service.render_compiled(_compiled(cfg or self.cfg), "epub")

    def _zip(self, data: bytes) -> zipfile.ZipFile:
        return zipfile.ZipFile(io.BytesIO(data))

    def test_valid_container(self):
        data, mime, fname = self._build()
        assert data[:4] == b"PK\x03\x04" and mime == "application/epub+zip"
        assert fname.endswith(".epub")
        zf = self._zip(data)
        infos = zf.infolist()
        assert infos[0].filename == "mimetype"
        assert infos[0].compress_type == zipfile.ZIP_STORED
        assert zf.read("mimetype") == b"application/epub+zip"

    def test_opf_metadata(self):
        zf = self._zip(self._build()[0])
        opf = [n for n in zf.namelist() if n.endswith(".opf")]
        assert opf
        data = zf.read(opf[0]).decode("utf-8")
        assert "<dc:title>Test Story</dc:title>" in data
        assert "<dc:language>en</dc:language>" in data
        assert "<dc:creator" in data and "Author</dc:creator>" in data
        assert "urn:uuid:" in data
        assert "<dc:date" in data

    def test_spine_order_cover_then_nav(self):
        zf = self._zip(self._build()[0])
        opf = [n for n in zf.namelist() if n.endswith(".opf")][0]
        data = zf.read(opf).decode("utf-8")
        spine = re.search(r"<spine[^>]*>(.*?)</spine>", data, re.S)
        assert spine
        idrefs = re.findall(r'idref="([^"]+)"', spine.group(1))
        assert idrefs[0] in ("cover", "cover-page"), idrefs
        assert "nav" in idrefs[:3]

    def test_chapters_and_toc_page(self):
        zf = self._zip(self._build()[0])
        names = zf.namelist()
        assert any(n.endswith("ch001.xhtml") for n in names)
        assert any(n.endswith("ch002.xhtml") for n in names)
        assert any(n.endswith("nav.xhtml") for n in names)
        assert any(n.endswith("contents.xhtml") for n in names)
        contents = zf.read([n for n in names if n.endswith("contents.xhtml")][0]).decode()
        assert "Test Chapter 1" in contents
        assert 'href="ch001.xhtml"' in contents

    def test_chapter_content_turkish_and_scene_break(self):
        zf = self._zip(self._build()[0])
        ch = zf.read([n for n in zf.namelist() if n.endswith("ch001.xhtml")][0]).decode()
        assert "ğışöçü" in ch
        assert "scene-break" in ch
        assert 'class="first"' in ch  # first paragraph unindented

    def test_css_embedded(self):
        zf = self._zip(self._build()[0])
        css = [n for n in zf.namelist() if n.endswith("book.css")]
        assert css
        assert "scene-break" in zf.read(css[0]).decode()

    def test_text_cover(self):
        zf = self._zip(self._build()[0])
        cover = zf.read([n for n in zf.namelist() if n.endswith("cover.xhtml")][0]).decode()
        assert "Test Story" in cover

    def test_image_cover(self, tmp_path, monkeypatch):
        from config import Config
        monkeypatch.setattr(Config, "MEDIA_DIR", tmp_path)
        covers = tmp_path / "covers"
        covers.mkdir()
        (covers / "c.png").write_bytes(_png_bytes())
        cfg = _book_config(cover_image="/media/covers/c.png")
        zf = self._zip(self._build(cfg)[0])
        assert any(n.endswith("cover.png") for n in zf.namelist())

    def test_dedication_page(self):
        zf = self._zip(self._build()[0])
        ded = [n for n in zf.namelist() if n.endswith("dedication.xhtml")]
        assert ded and "Denizciler için" in zf.read(ded[0]).decode()


# ===================== 4. Publishing Preflight ========================

class TestPreflight:
    @pytest.fixture(autouse=True)
    def seed(self):
        from core.db import read_session
        from services._common import current_project_id
        with read_session() as s:
            self.pid = current_project_id(s)

    def _report(self):
        from services import preflight_service
        return preflight_service.preflight_report()

    def _add_ch(self, cid, title, content, status="final"):
        from core.db import write_transaction
        from models.chapter import Chapter
        with write_transaction() as s:
            s.add(Chapter(id=cid, project_id=self.pid, title=title,
                          content=content, sort_order=99, status=status))

    def test_clean_book_scores_100(self):
        _seed_chapters(2, status="final")
        rep = self._report()
        # progress info issues allowed; no error/warn
        assert rep["issue_counts"]["error"] == 0
        assert rep["issue_counts"]["warn"] == 0
        assert rep["score"] >= 95 and rep["grade"] == "A"
        assert rep["ready"] is True

    def test_draft_status_warns(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf1", "Draft One", "word " * 300, status="draft")
        rep = self._report()
        cats = [i["category"] for i in rep["issues"]]
        assert "status" in cats
        assert rep["ready"] is False

    def test_empty_chapter_errors(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf2", "Empty One", "", status="final")
        rep = self._report()
        assert any(i["category"] == "empty" and i["severity"] == "error"
                   for i in rep["issues"])

    def test_leftover_markers_error(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf3", "TODO One", ("clean text. " * 100) + " TODO fix this. [placeholder]")
        rep = self._report()
        assert any(i["category"] == "markers" for i in rep["issues"])

    def test_tk_marker_not_turkish_word(self):
        # "tk" as editorial placeholder must match, but Turkish words
        # containing tk must not trigger a false positive
        _seed_chapters(1, status="final")
        self._add_ch("pf4", "TK One", "TK kontrol et.\n\n" + "katkı katlanmak satkılmak " * 30)
        rep = self._report()
        hits = [i for i in rep["issues"] if i["category"] == "markers"]
        assert hits and hits[0]["chapter_id"] == "pf4"

    def test_unbalanced_quotes_info(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf5", "Quote One", 'O "dedi ve gitti ' + "word " * 200)
        rep = self._report()
        assert any(i["category"] == "quotes" and i["severity"] == "info"
                   for i in rep["issues"])

    def test_odd_asterisks_info(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf6", "Star One", "one * two " * 151)
        rep = self._report()
        assert any(i["category"] == "emphasis" for i in rep["issues"])

    def test_long_paragraph_info(self):
        _seed_chapters(1, status="final")
        self._add_ch("pf7", "Wall One", "word " * 700)
        rep = self._report()
        assert any(i["category"] == "long_paras" for i in rep["issues"])

    def test_empty_book_error(self):
        rep = self._report()
        assert any(i["category"] == "empty_book" for i in rep["issues"])
        assert rep["score"] < 100

    def test_issue_has_chapter_link_fields(self):
        _seed_chapters(1, status="draft")
        rep = self._report()
        issue = [i for i in rep["issues"] if i["chapter_id"]][0]
        assert issue["chapter_id"] and issue["chapter_no"] == 1
        assert issue["chapter_title"] == "Test Chapter 1"

    def test_grade_mapping(self):
        from services import preflight_service as ps
        assert ps._finalize([], "x", 0, 0, 0)["grade"] == "A"
        assert ps._finalize([{"severity": "warn"}] * 4, "x", 0, 0, 0)["grade"] == "B"
        assert ps._finalize([{"severity": "error"}] * 3, "x", 0, 0, 0)["grade"] == "C"
        assert ps._finalize([{"severity": "error"}] * 4, "x", 0, 0, 0)["grade"] == "D"
        assert ps._finalize([{"severity": "error"}] * 9, "x", 0, 0, 0)["grade"] == "F"
        rep = ps._finalize([{"severity": "error"}] * 20, "x", 0, 0, 0)
        assert rep["score"] == 0  # floored


# ===================== 5. Cover API + routes ========================

class TestCoverAndRoutes:
    @pytest.fixture(autouse=True)
    def seed(self, monkeypatch, tmp_path):
        from config import Config
        monkeypatch.setattr(Config, "MEDIA_DIR", tmp_path)
        _seed_chapters(1)

    def test_compile_page_shows_forge_ui(self, client):
        r = client.get("/compile/")
        assert r.status_code == 200
        html = r.data.decode()
        assert "Book Identity" in html
        assert "Print Layout (PDF)" in html
        assert "downloadCompile('pdf')" in html
        assert "downloadCompile('epub')" in html
        assert "runPreflight()" in html
        assert "Trim size" in html

    def test_cover_upload_and_remove(self, client, tmp_path):
        from services import compile_service
        r = client.post("/compile/api/cover", data={
            "file": (io.BytesIO(_png_bytes()), "kapak.png"),
        }, content_type="multipart/form-data")
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] and data["has_cover"]
        cfg = compile_service.get_config()
        assert cfg["cover_image"].startswith("/media/covers/")
        assert (tmp_path / "covers").exists()

        r2 = client.post("/compile/api/cover/remove")
        assert r2.status_code == 200 and r2.get_json()["ok"]
        assert compile_service.get_config()["cover_image"] == ""

    def test_cover_upload_rejects_bad_extension(self, client):
        r = client.post("/compile/api/cover", data={
            "file": (io.BytesIO(b"plain text"), "notes.txt"),
        }, content_type="multipart/form-data")
        assert r.status_code == 400

    def test_cover_upload_rejects_magic_mismatch(self, client):
        r = client.post("/compile/api/cover", data={
            "file": (io.BytesIO(b"not a real png at all"), "fake.png"),
        }, content_type="multipart/form-data")
        assert r.status_code == 400

    def test_cover_upload_rejects_no_file(self, client):
        r = client.post("/compile/api/cover", data={})
        assert r.status_code == 400

    def test_preflight_api(self, client):
        r = client.get("/compile/api/preflight")
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] and "score" in data and "grade" in data
        assert "issues" in data and "issue_counts" in data

    def test_download_pdf_route(self, client):
        r = client.get("/compile/download?format=pdf")
        assert r.status_code == 200
        assert r.mimetype == "application/pdf"
        assert r.data.startswith(b"%PDF-")
        assert "attachment" in (r.headers.get("Content-Disposition") or "")

    def test_download_epub_route(self, client):
        r = client.get("/compile/download?format=epub")
        assert r.status_code == 200
        assert r.mimetype == "application/epub+zip"
        assert r.data[:4] == b"PK\x03\x04"
        assert "attachment" in (r.headers.get("Content-Disposition") or "")

    def test_download_invalid_format(self, client):
        r = client.get("/compile/download?format=mobi")
        assert r.status_code == 400
        assert r.get_json()["ok"] is False

    def test_legacy_formats_still_work(self, client):
        for fmt, sig in (("txt", b"Test Story"), ("md", b"# "),
                         ("html", b"<!DOCTYPE"), ("docx", b"PK\x03\x04")):
            r = client.get(f"/compile/download?format={fmt}")
            assert r.status_code == 200 and sig in r.data[:600], fmt

    def test_cover_path_security(self, tmp_path):
        import pathlib

        from config import Config
        from services import compile_service
        orig = Config.MEDIA_DIR
        try:
            Config.MEDIA_DIR = tmp_path
            # traversal attempt is refused
            cfg = _book_config(cover_image="/media/../app.py")
            assert compile_service.cover_media_path(cfg) is None
            cfg = _book_config(cover_image="/media/covers/nope.png")
            assert compile_service.cover_media_path(cfg) is None
        finally:
            Config.MEDIA_DIR = orig


# ===================== 6. Config & book identity ========================

class TestConfigAndIdentity:
    @pytest.fixture(autouse=True)
    def seed(self):
        _seed_chapters(1)

    def test_new_defaults_present(self):
        from services import compile_service
        cfg = compile_service.get_config()
        for key in ("author_name", "book_language", "cover_image",
                    "pdf_page_size", "pdf_font_size", "pdf_line_height",
                    "pdf_mirrored", "epub_justify"):
            assert key in cfg

    def test_save_config_roundtrip_and_validation(self):
        from services import compile_service
        cfg = compile_service.save_config(_book_config(
            pdf_page_size="a5", pdf_font_size=11, pdf_mirrored=False))
        assert cfg["pdf_page_size"] == "a5"
        assert cfg["pdf_mirrored"] is False
        with pytest.raises(ValidationError):
            compile_service.save_config({"pdf_page_size": "b6"})
        clamped = compile_service.save_config({"pdf_font_size": 99})
        assert clamped["pdf_font_size"] == 14.0

    def test_string_booleans_handled(self):
        from services import compile_service
        cfg = compile_service.save_config({"pdf_mirrored": "false",
                                           "epub_justify": "true"})
        assert cfg["pdf_mirrored"] is False and cfg["epub_justify"] is True

    def test_author_override(self):
        comp = _compiled(_book_config(author_name="Zeynep Karaca"))
        assert comp["author"] == "Zeynep Karaca"

    def test_author_falls_back_to_settings(self):
        comp = _compiled(_book_config(author_name=""))
        assert comp["author"] == "Author"  # default settings value

    def test_title_from_active_book(self):
        # create a second book, make it active, add a chapter there
        from core.db import write_transaction
        from models.chapter import Chapter
        from models.project import Project
        from models.settings import Setting
        with write_transaction() as s:
            s.add(Project(id="book87", name="İkinci Kitap"))
        with write_transaction() as s:
            s.add(Chapter(id="bkch", project_id="book87", title="Tek Bölüm",
                          content="Metin " * 50, sort_order=1, status="final"))
            Setting.set(s, "active_project_id", "book87")
        comp = _compiled(_book_config())
        assert comp["title"] == "İkinci Kitap"
        assert comp["chapter_count"] == 1

    def test_language_labels_turkish(self):
        comp = _compiled(_book_config(book_language="tr"))
        assert comp["language"] == "tr"
        headings = {s["heading"] for s in comp["sections"]}
        assert "İçindekiler" in headings
        ch = [s for s in comp["sections"] if s["type"] == "chapter"][0]
        assert ch["heading"].startswith("Bölüm 1")

    def test_language_defaults_to_ui_language(self):
        from services import i18n_service
        i18n_service.set_language("tr")
        try:
            comp = _compiled(_book_config(book_language=""))
            assert comp["language"] == "tr"
        finally:
            i18n_service.set_language("en")

    def test_preview_api_includes_pdf_epub_formats(self, client):
        r = client.get("/compile/api/preview")
        assert r.status_code == 200
        data = r.get_json()
        assert data["ok"] and data["chapter_count"] == 1

    def test_config_api_roundtrip(self, client):
        r = client.post("/compile/api/config", json={
            "pdf_page_size": "a4", "book_language": "tr", "format": "epub"})
        assert r.status_code == 200
        assert r.get_json()["config"]["pdf_page_size"] == "a4"


# ===================== 7. Turkish fix regression ========================

class TestTurkishPdfRegression:
    def test_character_sheet_turkish(self):
        from services import export_service
        data = {"name": "Şeyda Ğüler", "role": "main", "age": "",
                "gender": "", "background": "Boğaz'da büyüdü, ğışöçü test.",
                "avatar_color": "#6366f1"}
        pdf = export_service._character_sheet_pdf(data)
        assert b"FontFile2" in pdf
        text = "".join((p.extract_text() or "")
                       for p in _pdf_pages(pdf).pages)
        assert "Şeyda" in text and "Boğaz'da" in text

    def test_chapter_pdf_turkish(self):
        from services import export_service
        pdf = export_service._chapter_to_pdf(
            "Türkçe Başlık", "ğışöçü ĞİŞÖÇÜ içeren bölüm metni.")
        text = "".join((p.extract_text() or "")
                       for p in _pdf_pages(pdf).pages)
        assert "ğışöçü" in text

    def test_comparison_pdf_turkish(self):
        from routes.characters import _comparison_as_pdf
        class _Fake:
            pass
        c1, c2 = _Fake(), _Fake()
        c1.name, c1.role, c1.psychology = "Kıvanç Ğür", "main", "Sakin"
        c2.name, c2.role, c2.psychology = "Öykü Şen", "ally", "Neşeli"
        pdf = _comparison_as_pdf(c1, c2)
        text = "".join((p.extract_text() or "")
                       for p in _pdf_pages(pdf).pages)
        assert "Kıvanç" in text and "Öykü" in text
