"""v8.0 Mobile Writing Mode tests.

The headline bug these pin: the v2 sidebar rule
(body[data-ui-version="v2"] .sidebar { position: sticky }, specificity
0,2,1) silently beat main.css's mobile drawer rule (.sidebar { position:
fixed }, 0,1,0) — on phones the drawer NEVER hid and covered the whole
screen. The v8.0 fix re-asserts the drawer at v2 specificity.
"""
import re


def _read(path):
    return open(path, encoding="utf-8").read()


# ------------------------------------------------------------ the bug fix

def test_v2_mobile_drawer_override_exists():
    """ui-v2.css must re-assert position:fixed at v2 specificity."""
    css = _read("static/css/ui-v2.css")
    m = re.search(
        r'@media \(max-width: 768px\) \{.*?'
        r'body\[data-ui-version="v2"\] \.sidebar \{[^}]*position: fixed;[^}]*\}',
        css, re.S)
    assert m, "v2 mobile drawer override missing"


def test_v2_drawer_specificity_beats_sticky():
    """The override must come AFTER the sticky rule in source order (same
    specificity → later wins)."""
    css = _read("static/css/ui-v2.css")
    sticky_pos = css.find('body[data-ui-version="v2"] .sidebar {')
    override_pos = css.find('body[data-ui-version="v2"] .sidebar {\n    position: fixed')
    if override_pos == -1:
        # accept any ordering of properties inside the block
        blocks = [m.start() for m in re.finditer(
            r'body\[data-ui-version="v2"\] \.sidebar \{[^}]*position:\s*fixed', css)]
        override_pos = blocks[0] if blocks else -1
    assert sticky_pos != -1 and override_pos != -1
    assert override_pos > sticky_pos, "fixed override must follow the sticky rule"


def test_mobile_drawer_open_state_at_v2_specificity():
    css = _read("static/css/ui-v2.css")
    assert re.search(
        r'body\[data-ui-version="v2"\] \.app-shell\.mobile-nav-open \.sidebar \{\s*left: 0',
        css), "open state needs v2-scoped rule too"


def test_mobile_menu_button_shown_on_phones():
    css = _read("static/css/main.css")
    assert ".mobile-menu-btn { display: flex !important; }" in css


# ------------------------------------------------------- touch ergonomics

def test_touch_target_minimum_40px():
    css = _read("static/css/ui-v2.css")
    m = re.search(r"@media \(max-width: 768px\) \{(.*)$", css, re.S)
    assert m, "mobile block missing"
    block = m.group(1)
    assert re.search(r"\.mobile-menu-btn \{[^}]*min-width: 40px|"
                     r"\.mobile-menu-btn \{[^}]*width: 40px", block) or \
           re.search(r"\.mobile-menu-btn \{ width: 40px; height: 40px; \}", block), \
        "hamburger must be >= 40px on touch screens"


def test_tables_scroll_on_phones():
    css = _read("static/css/ui-v2.css")
    assert re.search(r"\.table \{[^}]*overflow-x: auto", css), \
        "tables must scroll horizontally instead of crushing"


def test_book_switcher_truncates_on_phones():
    css = _read("static/css/ui-v2.css")
    assert re.search(r"\.book-switcher-name \{[^}]*text-overflow: ellipsis", css)


def test_br_dock_adjusted_for_phones():
    css = _read("static/css/ui-v2.css")
    assert re.search(r"\.br-dock \{[^}]*right: 0\.5rem", css)


# ------------------------------------------------------------- templates

def test_viewport_meta_present():
    src = _read("templates/base.html")
    assert 'name="viewport"' in src
    assert "width=device-width" in src


def test_mobile_menu_button_in_topbar():
    src = _read("templates/base.html")
    assert 'class="mobile-menu-btn"' in src
    assert "toggleMobileNav" in src


def test_toggle_mobile_nav_implemented():
    js = _read("static/js/app.js")
    assert "function toggleMobileNav" in js
    assert "mobile-nav-open" in js
    assert "window.toggleMobileNav" in js


def test_content_bottom_padding_for_dock():
    """Main content must leave room for the BR-dock column so the FAB never
    covers the last line of text."""
    css = _read("static/css/main.css")
    assert re.search(r"\.content \{[^}]*padding: 1rem 0\.75rem 4rem", css)


def test_card_grid_stacks_on_phones():
    css = _read("static/css/main.css")
    assert re.search(r"\.card-grid\.cols-2,[^{]*\{[^}]*grid-template-columns: 1fr", css)
    # cols-5 (new in v8.0) must also stack
    assert "cols-5" in css


def test_emotion_svg_scrolls_on_phones():
    css = _read("static/css/polish.css")
    assert re.search(r"\.emotion-svg \{[^}]*min-width: 640px", css)


# ------------------------------------------------- viewport contract docs

def test_offline_page_mobile_friendly():
    src = _read("templates/offline.html")
    # extends base.html → inherits viewport meta + responsive shell
    assert '{% extends "base.html" %}' in src
    assert "card-grid" in src
