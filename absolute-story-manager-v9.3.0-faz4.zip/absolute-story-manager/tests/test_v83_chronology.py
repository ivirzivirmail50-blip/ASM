"""v8.3 tests — Story Chronology (visual manuscript timeline).

Complements plans.timeline (plan events on tracks) and timeline_check
(conflict audit): chronology maps the WRITTEN MANUSCRIPT onto story time
with plan events overlaid, gaps, out-of-order flags, and per-chapter
character presence.
"""
import json

import pytest


def _add_chapter(cid_seq, title, story_date=None, sort_order=0, content="Aylin yürüdü.", status="draft"):
    from core.db import write_transaction
    from models.chapter import Chapter
    with write_transaction() as s:
        ch = Chapter(id=cid_seq, project_id="default", title=title,
                     story_date=story_date, sort_order=sort_order,
                     content=content, word_count=len(content.split()),
                     status=status)
        s.add(ch)
    return cid_seq


def _add_plan(pid, title, story_date=None, event_type="plot_point", track="Main", chapter_id=None):
    from core.db import write_transaction
    from models.plan import Plan
    with write_transaction() as s:
        s.add(Plan(id=pid, project_id="default", title=title, story_date=story_date,
                   event_type=event_type, track=track, status="idea",
                   sort_order=0, chapter_id=chapter_id))


def _add_character(char_id, name, aliases_json="[]"):
    from core.db import write_transaction
    from models.character import Character
    with write_transaction() as s:
        s.add(Character(id=char_id, project_id="default", name=name,
                        aliases=aliases_json, role="main"))


# ------------------------------------------------------------- mode + layout

class TestChronologyModes:
    def test_date_mode(self, fresh_db):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        _add_chapter("c2", "İki", "2026-03-05", 2)
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["mode"] == "date"
        assert d["stats"]["dated_chapters"] == 2
        assert d["stats"]["coverage_pct"] == 100.0
        assert d["stats"]["story_days"] == 4
        assert d["stats"]["earliest"] == "2026-03-01"
        assert d["stats"]["latest"] == "2026-03-05"

    def test_day_mode_with_turkish_markers(self, fresh_db):
        _add_chapter("c1", "Bir", "Gün 1", 1)
        _add_chapter("c2", "İki", "Day 4", 2)
        _add_chapter("c3", "Üç", "Gün 9", 3)
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["mode"] == "day"
        ts = [c["t"] for c in d["chapters"]]
        assert ts == [1.0, 4.0, 9.0]

    def test_chapters_decide_mode_over_events(self, fresh_db):
        """Regression: real-dated plan events used to force date mode,
        leaving day-marker chapters off the axis entirely."""
        _add_chapter("c1", "Bir", "Gün 1", 1)
        _add_chapter("c2", "İki", "Gün 2", 2)
        _add_plan("p1", "Eski Olay", "2026-03-01")
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["mode"] == "day"
        assert all(c["t"] is not None for c in d["chapters"])

    def test_order_mode_fallback(self, fresh_db):
        _add_chapter("c1", "Bir", None, 1)
        _add_chapter("c2", "İki", "yaz başı belirsiz", 2)
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["mode"] == "order"
        assert d["stats"]["dated_chapters"] == 0
        assert len(d["undated"]) == 0  # order mode puts everything on the strip

    def test_empty_project(self, fresh_db):
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["ok"] is True
        assert d["mode"] == "order"
        assert d["stats"]["total_chapters"] == 0


# ------------------------------------------------------------- conflicts

class TestChronologyConflicts:
    def test_out_of_order_flag(self, fresh_db):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        _add_chapter("c2", "İki", "2026-03-20", 2)
        _add_chapter("c3", "Üç", "2026-03-05", 3)   # earlier date, later order
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert "c3" in d["oop_ids"]
        assert d["stats"]["oop_count"] == 1

    def test_gap_detection(self, fresh_db):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        _add_chapter("c2", "İki", "2026-06-01", 2)  # 92-day gap
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["stats"]["gap_count"] == 1
        g = d["gaps"][0]
        assert g["delta"] > 90
        assert g["from_title"] == "Bir"

    def test_no_false_gap_for_dense_story(self, fresh_db):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        _add_chapter("c2", "İki", "2026-03-03", 2)
        from services import chronology_service
        d = chronology_service.build_timeline()
        assert d["stats"]["gap_count"] == 0


# ------------------------------------------------------------- presence

class TestCharacterPresence:
    def test_presence_with_aliases(self, fresh_db):
        _add_character("ch1", "Aylin", '["Ayla"]')
        _add_character("ch2", "Kerem")
        _add_chapter("c1", "Bir", "2026-03-01", 1, content="Aylin sahile indi.")
        _add_chapter("c2", "İki", "2026-03-02", 2, content="Ayla ve Kerem buluştu. Ayla güldü.")
        from services import chronology_service
        d = chronology_service.build_timeline()
        by_id = {c["id"]: c for c in d["chapters"]}
        assert by_id["c1"]["characters"] == ["ch1"]
        assert sorted(by_id["c2"]["characters"]) == ["ch1", "ch2"]
        opts = {o["id"]: o["name"] for o in d["character_options"]}
        assert opts["ch1"] == "Aylin"

    def test_no_partial_name_match(self, fresh_db):
        _add_character("ch1", "Ali")
        _add_chapter("c1", "Bir", "2026-03-01", 1, content="Alinya geldi ve gitti.")
        from services import chronology_service
        d = chronology_service.build_timeline()
        # 'Alinya' must NOT count as 'Ali' (word-boundary matching)
        assert d["chapters"][0]["characters"] == []


# ------------------------------------------------------------- events

class TestPlanEvents:
    def test_events_overlay_and_linked_flag(self, fresh_db):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        _add_plan("p1", "Yazılmış Olay", "2026-03-01", chapter_id="c1")
        _add_plan("p2", "Planlanan Olay", "2026-03-08")
        from services import chronology_service
        d = chronology_service.build_timeline()
        by_id = {e["id"]: e for e in d["events"]}
        assert by_id["p1"]["linked"] is True
        assert by_id["p2"]["linked"] is False
        assert d["stats"]["events_total"] == 2
        assert d["stats"]["events_written"] == 1


# ------------------------------------------------------------- route + UI

class TestChronologyRoute:
    def test_page_renders_with_data_tag(self, client):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        r = client.get("/chronology/")
        assert r.status_code == 200
        html = r.get_data(as_text=True)
        assert 'id="chronoData"' in html
        assert "Story Chronology" in html
        assert "chronoZoomIn" in html
        assert "chronoCharChips" in html

    def test_json_tag_escapes_lt(self, client):
        """A title with '<' must not break out of the script data tag."""
        _add_chapter("c1", "Sır < Gerçek", "2026-03-01", 1)
        r = client.get("/chronology/")
        html = r.get_data(as_text=True)
        assert 'id="chronoData">{' in html
        assert "Sır < Gerçek" not in html.split('id="chronoData">')[1].split("</script>")[0]

    def test_empty_state(self, client):
        r = client.get("/chronology/")
        html = r.get_data(as_text=True)
        assert "No chapters yet" in html

    def test_api_endpoint(self, client):
        _add_chapter("c1", "Bir", "2026-03-01", 1)
        r = client.get("/chronology/api/timeline")
        assert r.status_code == 200
        assert r.get_json()["ok"] is True

    def test_sidebar_link(self, client):
        r = client.get("/chronology/")
        assert 'href="/chronology/"' in r.get_data(as_text=True)

    def test_command_palette_entry(self):
        js = open("static/js/command_palette.js", encoding="utf-8").read()
        assert '"/chronology/"' in js

    def test_i18n_key_five_languages(self):
        from services.i18n_service import TRANSLATIONS
        entry = TRANSLATIONS["nav.chronology"]
        assert set(entry.keys()) == {"en", "tr", "es", "fr", "de"}
        assert entry["tr"]

    def test_polish_css_chrono_layer(self):
        css = open("static/css/polish.css", encoding="utf-8").read()
        for cls in (".chrono-stage", ".chrono-chapter", ".chrono-event", ".chrono-gap"):
            assert cls in css

    def test_chronology_js_node_clean(self):
        import shutil
        import subprocess
        import tempfile
        node = shutil.which("node")
        if not node:
            pytest.skip("node unavailable")
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                         encoding="utf-8") as f:
            f.write(open("static/js/chronology.js", encoding="utf-8").read())
            tmp = f.name
        out = subprocess.run([node, "--check", tmp], capture_output=True)
        assert out.returncode == 0, out.stderr

    def test_guard_covers_chronology(self):
        guard = open("tests/test_inline_js_guard.py", encoding="utf-8").read()
        assert '"/chronology/"' in guard

    def test_blueprint_registered(self, app):
        rules = {str(r) for r in app.url_map.iter_rules()}
        assert "/chronology/" in rules
        assert "/chronology/api/timeline" in rules
