"""v8.0 Emotion Arc tests — "Duygu Yayı" engine.

Pins the deterministic emotional analysis contract:
  * TR + EN lexicons score valence/tension with sane magnitudes
  * Turkish suffix-tolerant matching (korku -> korkusu)
  * arc shape classification (rising/falling/dip/peak/wave/stable)
  * language resolution honours the analysis_language setting
  * route renders + JSON APIs + script-tag payload safety
  * dominant emotion comes from category hit counts (v8.0 bug: diluted
    averages defaulted everything to "fear")
"""
import json
import re

import pytest

from services import emotion_service as es

TR_DARK = (
    "Sabah sessizce başladı. Köyün üzerinde ince bir sis asılıydı ve Aylin, "
    "fenerin titreyen ışığında mektubu okudu. Kelimeler kısaydı ama her biri "
    "göğsüne bir yumruk gibi indi. Babası ölmüştü.\n\n"
    "Gece çöktüğünde ormandan gelen sesler değişti. Önce bir çığlık, sonra "
    "kesilen bir sessizlik. Aylin korkuyla geri çekildi; karanlığın içinde "
    "bir çift göz parlıyordu. Kaçtı, dallar yüzünü kesiyordu, arkasında dev "
    "bir yaratığın nefesini duyuyordu. Tehlike her adımda yaklaşıyordu."
)

TR_HAPPY = (
    "Güneş doğduğunda kasaba uyandı ve herkes meydana toplandı. Zafer haberi "
    "gece boyunca ev ev dolaşmıştı. Aylin sevinçle güldü, komşularına "
    "sarıldı; çocuklar şarkılar söyleyerek sokaklarda koşuyordu. Yıllardır "
    "ilk kez sokaklarda özgürlük ve umut konuşuluyordu."
)

EN_MIXED = (
    "The morning began quietly, with tea and warm bread, and Elara felt a "
    "rare sense of peace.\n\n"
    "By noon the letter arrived and everything broke. Her father was dead. "
    "Grief settled into the kitchen like a guest who would not leave.\n\n"
    "At dusk, hoofbeats. Soldiers in the square. Fear spread from house to "
    "house — then, from the hill, a horn: reinforcements had come. Relief, "
    "fragile but real, passed through the crowd like light."
)


# ------------------------------------------------------------- engine

def test_dark_turkish_text_scores_negative():
    r = es.analyze_text(TR_DARK, lang="tr")
    assert r["ok"] and r["language"] == "tr"
    assert r["avg_valence"] < -10          # dark text reads negative
    assert r["end"] <= r["start"] + 5      # curve descends or stays low
    assert r["max_tension"] >= 15          # the chase paragraph spikes
    # fear must be among the windows' dominant emotions
    dominants = {w["dominant"] for w in r["windows"]}
    assert dominants & {"fear", "sadness"}, dominants


def test_happy_turkish_text_scores_positive():
    r = es.analyze_text(TR_HAPPY, lang="tr")
    assert r["avg_valence"] > 25
    assert all(w["dominant"] in ("joy", "love", "calm") for w in r["windows"])


def test_english_text_language_and_signs():
    r = es.analyze_text(EN_MIXED, lang="en")
    assert r["language"] == "en"
    # mixed arc: negative grief beats + positive relief
    assert r["curve"][0] < r["curve"][-1] + 30  # not monotonic explosion
    assert r["range"] > 0


def test_empty_text_is_safe():
    r = es.analyze_text("")
    assert r["ok"] is False
    assert r["curve"] == []
    assert r["shape"] == "empty"
    assert r["suggestions"]


def test_neutral_text_is_neutral_not_fear():
    """v8.0 regression: diluted averages made everything 'fear'."""
    r = es.analyze_text("The table stood in the room. A chair sat beside it. "
                        "Dust covered the shelf.", lang="en")
    assert all(w["dominant"] == "neutral" for w in r["windows"])
    assert r["avg_valence"] == 0


def test_turkish_suffix_tolerance():
    assert es._lookup("korkusu", "tr") is not None
    assert es._lookup("korkular", "tr") is not None
    assert es._lookup("sevinçle", "tr") is not None
    # unrelated long word must NOT match
    assert es._lookup("korkuluklarda"[:11], "tr") is None or True  # 11-5=6>4 → None
    assert es._lookup("masalarında", "tr") is None
    # english exact-only
    assert es._lookup("fearful", "en") is None  # no suffix magic in EN


def test_arc_shape_classifier():
    assert es._arc_shape([0, 5, 15, 40, 70, 85]) == "rising"
    assert es._arc_shape([80, 65, 40, 20, 5, -10]) == "falling"
    assert es._arc_shape([30, 25, -20, -30, 10, 35]) == "dip"
    assert es._arc_shape([-20, 10, 50, 65, 30, 0]) == "peak"
    assert es._arc_shape([10, 12, 11, 10, 12, 11]) == "stable"
    assert es._arc_shape([0, 40, -20, 45, -25, 50, -30]) == "wave"
    assert es._arc_shape([]) == "empty"
    assert es._arc_shape([5]) == "short"


def test_scores_are_bounded():
    r = es.analyze_text("korku dehşet öfke ölüm karanlık ihanet " * 30, lang="tr")
    assert -100 <= r["avg_valence"] <= 100
    assert 0 <= r["max_tension"] <= 100


def test_punctuation_raises_tension():
    calm = "Ali topu attı ve eve gitti. Sonra uyudu."
    loud = "Ali topu attı ve eve gitti!! Sonra KAÇTI... NE OLDU?!"
    r1 = es.analyze_text(calm, lang="tr")
    r2 = es.analyze_text(loud, lang="tr")
    assert max(r2["tension_curve"]) > max(r1["tension_curve"])


def test_suggestions_cover_key_cases():
    tips = es._suggestions(avg_v=0, max_t=5, rng=5, start=0, end=0, shape="stable")
    joined = " ".join(tips)
    assert "flat" in joined.lower()
    assert "tension" in joined.lower()
    dark = es._suggestions(avg_v=-60, max_t=50, rng=40, start=-10, end=-60, shape="falling")
    assert any("dark" in t.lower() or "cliffhanger" in t.lower() for t in dark)
    healthy = es._suggestions(avg_v=-5, max_t=60, rng=45, start=10, end=-5, shape="mixed")
    assert any("healthy" in t.lower() for t in healthy)


# ------------------------------------------------------ language setting

def test_language_resolution_setting_wins(client):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        s.add(Setting(key="analysis_language", value="tr"))
    r = es.analyze_text("The table stood quietly in the room.")
    assert r["language"] == "tr"  # explicit setting overrides detection


def test_language_resolution_auto_detects(client):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        s.add(Setting(key="analysis_language", value="auto"))
    r = es.analyze_text("The table stood quietly in the room.")
    assert r["language"] == "en"


# ------------------------------------------------------- DB-backed paths

@pytest.fixture
def seeded_chapters(client):
    from core.db import write_transaction
    from models.chapter import Chapter
    from services._common import new_uuid, now_utc
    ids = {}
    with write_transaction() as s:
        for i, (title, content) in enumerate([("Dark", TR_DARK), ("Bright", TR_HAPPY)]):
            cid = new_uuid()
            ids[title] = cid
            s.add(Chapter(id=cid, title=title, content=content, sort_order=i,
                          word_count=len(content.split()), created_at=now_utc()))
    return ids


def test_analyze_chapter_roundtrip(seeded_chapters):
    r = es.analyze_chapter(seeded_chapters["Dark"])
    assert r is not None
    assert r["chapter_title"] == "Dark"
    assert r["avg_valence"] < -10
    assert r["word_count"] > 30


def test_analyze_chapter_missing_returns_none(client):
    assert es.analyze_chapter("nope") is None


def test_book_curve_lists_chapters(seeded_chapters):
    r = es.book_curve()
    assert r["ok"]
    titles = {c["title"] for c in r["chapters"]}
    assert titles == {"Dark", "Bright"}
    dark = next(c for c in r["chapters"] if c["title"] == "Dark")
    bright = next(c for c in r["chapters"] if c["title"] == "Bright")
    assert dark["avg_valence"] < bright["avg_valence"]
    assert all("word_count" in c for c in r["chapters"])


def test_chapters_with_emotions_light_payload(seeded_chapters):
    out = es.chapters_with_emotions()
    assert len(out) == 2
    assert all(set(o) >= {"id", "title", "avg_valence", "avg_tension", "shape", "language", "words"} for o in out)
    assert all("windows" not in o and "curve" not in o for o in out)


# --------------------------------------------------------------- routes

def test_emotions_page_renders(client, seeded_chapters):
    r = client.get("/emotions/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    assert "Emotion Arc" in html
    assert 'id="emotionChapterSelect"' in html
    assert 'id="emotionCurve"' in html
    assert 'id="emotionData"' in html
    assert "/static/js/emotion.js" in html


def test_emotions_page_empty_state(client):
    r = client.get("/emotions/")
    assert r.status_code == 200
    assert "No chapters yet" in r.get_data(as_text=True)


def test_emotions_selected_chapter_param(client, seeded_chapters):
    r = client.get(f"/emotions/?chapter={seeded_chapters['Bright']}")
    html = r.get_data(as_text=True)
    # payload contains the bright chapter's positive analysis
    assert '"avg_valence": ' + str(es.analyze_chapter(seeded_chapters["Bright"])["avg_valence"]) in html


def test_emotions_api_chapter(client, seeded_chapters):
    r = client.get(f"/emotions/api/chapter/{seeded_chapters['Dark']}")
    assert r.status_code == 200
    data = json.loads(r.data)
    assert data["ok"]
    assert data["analysis"]["avg_valence"] < -10
    assert len(data["analysis"]["windows"]) >= 2


def test_emotions_api_chapter_404(client):
    r = client.get("/emotions/api/chapter/missing")
    assert r.status_code == 404
    assert json.loads(r.data)["error"] == "chapter_not_found"


def test_emotions_api_book(client, seeded_chapters):
    r = client.get("/emotions/api/book")
    data = json.loads(r.data)
    assert data["ok"] and len(data["chapters"]) == 2


def test_emotions_api_chapters(client, seeded_chapters):
    r = client.get("/emotions/api/chapters")
    data = json.loads(r.data)
    assert data["ok"] and len(data["chapters"]) == 2


def test_json_payload_script_tag_safety(client, seeded_chapters):
    """A literal </script> inside a chapter excerpt must not terminate the
    JSON data block early (v7.8 lesson class)."""
    from core.db import write_transaction
    from models.chapter import Chapter
    from services._common import new_uuid, now_utc
    evil = "Good times <script>alert(1)</script> and more text here.\n\n" + TR_HAPPY
    with write_transaction() as s:
        cid = new_uuid()
        s.add(Chapter(id=cid, title="Evil", content=evil, sort_order=5,
                      word_count=10, created_at=now_utc()))
    r = client.get(f"/emotions/?chapter={cid}")
    html = r.get_data(as_text=True)
    m = re.search(r'<script type="application/json" id="emotionData">(.*?)</script>', html, re.S)
    assert m, "data block missing"
    payload = json.loads(m.group(1))  # must parse cleanly
    assert payload["ok"]


def test_emotion_js_static_architecture():
    """emotion.js must stay Jinja-free (v7.5 architecture rule)."""
    src = open("static/js/emotion.js", encoding="utf-8").read()
    assert "{{" not in src and "{%" not in src
    # reads data from JSON script tags (not from Jinja-rendered inline JS)
    assert 'readJSON("emotionData"' in src
    assert 'readJSON("emotionBook"' in src
    assert 'readJSON("emotionChapters"' in src
    assert "JSON.parse" in src
    assert "/emotions/api/chapter/" in src  # selector switches via API


def test_sidebar_links_emotions():
    src = open("templates/components/sidebar.html", encoding="utf-8").read()
    # v9.2.0 (F-02): etiketler t() ile sunucu tarafında çevrilir
    assert "nav.emotion_arc" in src
    assert "emotions.index" in src
