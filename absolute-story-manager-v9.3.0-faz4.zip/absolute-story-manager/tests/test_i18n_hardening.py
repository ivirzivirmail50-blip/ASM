"""S-05 + F-02 — i18n hardening: no duplicate keys + language caches.

Duplicate keys silently overwrite each other — in a Python dict literal
(S-05) AND in JSON (F-02: ``json.loads`` merges duplicate object keys
without any error). The scan below re-reads each translations/*.json as
RAW TEXT and asserts no key literal appears twice.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
I18N_DIR = ROOT / "translations"
SRC = ROOT / "services" / "i18n_service.py"


class TestNoDuplicateKeys:
    def test_translation_dict_has_no_duplicate_keys(self):
        """Duplicate anahtar taraması — JSON dosyaları ham metin olarak
        okunur (json.loads çakışmaları sessizce birleştirir)."""
        files = sorted(I18N_DIR.glob("*.json"))
        assert files, "translations/ directory not found"
        for path in files:
            text = path.read_text(encoding="utf-8")
            keys = re.findall(r'^\s*"([a-z0-9_.A-Z\-]+)"\s*:', text, re.M)
            seen, dupes = set(), []
            for k in keys:
                if k in seen:
                    dupes.append(k)
                seen.add(k)
            assert not dupes, f"{path.name}: duplicate keys {sorted(set(dupes))}"

    def test_all_keys_carry_english(self):
        """Every key must at least have an English fallback."""
        from services.i18n_service import TRANSLATIONS, _ensure_loaded
        _ensure_loaded()
        missing = [k for k, v in TRANSLATIONS.items() if "en" not in v]
        assert not missing, f"keys without English fallback: {missing}"

    def test_runtime_dict_matches_source(self):
        """Imported dict length == JSON key count (nothing shadowed)."""
        from services.i18n_service import TRANSLATIONS, _ensure_loaded
        _ensure_loaded()
        en = json.loads((I18N_DIR / "en.json").read_text(encoding="utf-8"))
        assert len(TRANSLATIONS) == len(en)
        assert set(TRANSLATIONS.keys()) == set(en.keys())

    def test_all_language_files_have_identical_key_sets(self):
        """F-02: parity — a new key must be added to EVERY language file
        (fallback hides the gap; parity makes it visible)."""
        files = {p.stem: json.loads(p.read_text(encoding="utf-8"))
                for p in I18N_DIR.glob("*.json")}
        assert set(files) == {"en", "tr", "es", "fr", "de"}
        base = set(files["en"])
        for lang, data in files.items():
            assert set(data) == base, (
                f"{lang}.json key set differs from en.json: "
                f"missing={sorted(base - set(data))} "
                f"extra={sorted(set(data) - base)}")


class TestLanguageCache:
    def setup_method(self):
        from services.i18n_service import invalidate_language_cache
        invalidate_language_cache()

    def teardown_method(self):
        from services.i18n_service import invalidate_language_cache
        invalidate_language_cache()

    def test_default_language_is_english(self, fresh_db):
        from services.i18n_service import get_current_language
        assert get_current_language() == "en"

    def test_set_language_updates_immediately(self, fresh_db):
        """Dil değişimi anında etkili (cache invalidate kabul kriteri)."""
        from services.i18n_service import get_current_language, set_language
        set_language("tr")
        assert get_current_language() == "tr"

    def test_unknown_language_falls_back_to_english(self, fresh_db):
        from services.i18n_service import get_current_language, set_language
        set_language("xx")
        assert get_current_language() == "en"

    def test_cache_avoids_repeated_db_reads(self, fresh_db, monkeypatch):
        """Second read must NOT open a new session (S-05 perf goal)."""
        import services.i18n_service as i18n
        calls = {"n": 0}
        real_read_session = i18n.read_session

        def counting_read_session(*args, **kwargs):
            calls["n"] += 1
            return real_read_session(*args, **kwargs)

        monkeypatch.setattr(i18n, "read_session", counting_read_session)
        i18n.invalidate_language_cache()
        assert i18n.get_current_language() == "en"
        assert i18n.get_current_language() == "en"
        assert i18n.get_current_language() == "en"
        assert calls["n"] == 1, "language must be read from DB only once"

    def test_translate_uses_cached_language(self, fresh_db):
        from services.i18n_service import set_language, translate
        set_language("tr")
        assert translate("action.save") == "Kaydet"
        assert translate("action.cancel") == "İptal"
        assert translate("nonexistent.key") == "nonexistent.key"
