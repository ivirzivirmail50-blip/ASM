"""v8.0 PWA tests — installable app, service worker, offline page.

v8.0 "Everywhere" pillar: ASM becomes a real installable application with
offline reading. These tests pin the contract:
  * manifest is valid JSON with icons/start_url/scope
  * /sw.js is served from ROOT scope (not /static/) with no-cache headers
  * the service worker precaches the shell + handles navigations + writes
  * every page links the manifest, theme-color and favicons
  * offline fallback page renders with the app shell
"""
import json
import re


def _read(path):
    return open(path, encoding="utf-8").read()


# ------------------------------------------------------------- manifest

def test_manifest_valid_json_and_fields(client):
    r = client.get("/manifest.webmanifest")
    assert r.status_code == 200
    assert "application/json" in r.content_type
    m = json.loads(r.data)
    assert m["name"] == "Absolute Story Manager"
    assert m["short_name"] == "ASM"
    assert m["start_url"] == "/dashboard"
    assert m["scope"] == "/"
    assert m["display"] == "standalone"
    assert m["background_color"].startswith("#")
    assert m["theme_color"].startswith("#")
    # three icon entries: 192 any, 512 any, 512 maskable
    icons = m["icons"]
    assert len(icons) == 3
    sizes = {i["sizes"] for i in icons}
    assert "192x192" in sizes and "512x512" in sizes
    assert any(i.get("purpose") == "maskable" for i in icons)
    assert all(i["type"] == "image/png" for i in icons)


def test_manifest_icons_exist_on_disk():
    import os
    base = "static/img/icons"
    for name in ("icon-192.png", "icon-512.png", "icon-maskable-512.png",
                 "apple-touch-icon.png", "favicon-32.png", "favicon-16.png"):
        p = os.path.join(base, name)
        assert os.path.exists(p), f"missing PWA icon {p}"
        assert os.path.getsize(p) > 300, f"{name} suspiciously small"


def test_manifest_icon_urls_serve(client):
    for url in ("/static/img/icons/icon-192.png",
                "/static/img/icons/icon-512.png",
                "/static/img/icons/icon-maskable-512.png"):
        r = client.get(url)
        assert r.status_code == 200, url
        assert r.content_type == "image/png"


# --------------------------------------------------------- service worker

def test_sw_served_from_root_scope(client):
    """SW MUST live at /sw.js — a /static/ location would scope it to
    /static/ and it could never control app pages."""
    r = client.get("/sw.js")
    assert r.status_code == 200
    assert "javascript" in r.content_type
    # freshness: an aggressively cached SW delays updates for up to 24h
    cc = (r.headers.get("Cache-Control") or "").lower()
    assert "no-cache" in cc or "no-store" in cc
    assert r.headers.get("Service-Worker-Allowed") == "/"


def test_sw_content_contract():
    src = _read("static/js/sw.js")
    # versioned caches + old-cache purge on activate
    assert "asm-shell-" in src and "asm-pages-" in src and "asm-assets-" in src
    assert "caches.keys" in src
    # offline fallback chain for navigations
    assert "/offline" in src
    assert "networkFirstPage" in src or "navigate" in src
    # friendly 503 JSON for blocked writes while offline
    assert "offlineWriteGuard" in src
    assert '"offline"' in src
    # update flow: page tells waiting worker to skip waiting
    assert "SKIP_WAITING" in src


def test_sw_js_is_valid_js():
    import shutil
    import subprocess
    import tempfile
    from pathlib import Path
    node = shutil.which("node")
    if not node:
        import pytest
        pytest.skip("node not available")
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(_read("static/js/sw.js"))
        path = f.name
    try:
        r = subprocess.run([node, "--check", path], capture_output=True, text=True, timeout=30)
        assert r.returncode == 0, r.stderr
    finally:
        Path(path).unlink(missing_ok=True)


def test_sw_precaches_shell_and_offline():
    src = _read("static/js/sw.js")
    assert "/static/css/main.css" in src
    assert "/static/css/polish.css" in src
    assert "/manifest.webmanifest" in src


# ------------------------------------------------------------ offline page

def test_offline_page_renders_with_shell(client):
    r = client.get("/offline")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    assert "offline" in html.lower()
    assert "app-shell" in html  # full shell (sidebar/topbar), not a bare page
    # auto-reload when connectivity returns
    assert '"online"' in html


# --------------------------------------------------------- base template

def test_base_template_pwa_head_links():
    src = _read("templates/base.html")
    assert 'rel="manifest"' in src
    assert 'name="theme-color"' in src
    assert "apple-touch-icon" in src
    assert "favicon-32.png" in src
    assert 'name="apple-mobile-web-app-capable"' in src


def test_every_page_gets_pwa_head(client):
    for url in ("/", "/chapters/", "/notes/", "/emotions/"):
        r = client.get(url)
        assert r.status_code == 200, url
        html = r.get_data(as_text=True)
        assert "manifest.webmanifest" in html, url
        assert "theme-color" in html, url


def test_offline_badge_in_topbar():
    src = _read("templates/base.html")
    assert 'id="offlineBadge"' in src
    assert "offline-badge" in src


def test_install_button_in_sidebar():
    src = _read("templates/components/sidebar.html")
    assert 'id="pwaInstallBtn"' in src
    assert "asmInstallApp" in src
    # hidden until beforeinstallprompt fires
    assert "display:none" in src


def test_appjs_registers_sw_and_watchers():
    src = _read("static/js/app.js")
    assert "serviceWorker" in src
    assert 'register("/sw.js")' in src
    # connectivity watch toggles the badge + toasts
    assert '"online"' in src and '"offline"' in src
    assert "offlineBadge" in src
    # update flow: waiting worker -> clickable toast -> SKIP_WAITING
    assert "beforeinstallprompt" in src
    assert "SKIP_WAITING" in src
    assert "updatefound" in src


def test_offline_badge_css_exists():
    src = _read("static/css/polish.css")
    assert ".offline-badge" in src
    assert "offline-badge[hidden]" in src
