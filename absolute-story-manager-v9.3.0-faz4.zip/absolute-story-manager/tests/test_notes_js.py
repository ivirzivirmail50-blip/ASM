"""v7.5 — Notes interaction architecture tests (the recurring "dead page" bug).

Root cause fixed in v7.5: a ~320-line inline <script> block in notes.html
contained Python slice syntax (``created_at[:10]``) inside a JS template
literal → SyntaxError → the WHOLE block failed to parse → every function was
undefined → no button on the page responded. This suite locks in the fix:

1. The template must NOT contain a large inline script (JS lives in
   static/js/notes.js where Jinja can never break it).
2. The static notes.js must parse cleanly and export its API on `window`.
3. The rendered page must be free of Python-isms in any inline script.
4. Every inline <script> on the rendered page must be valid JS (node --check).
"""
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent

TRICKY_NOTES = [
    # (title, body, category) — adversarial content that used to break things
    ('Alıntı "çift" içinde', "# Başlık\n\n**kalın** ve `kod` ve [link](https://x.com)", "idea"),
    ("Apostrof'lu Elara'nın", "Elara'nın kılıcı 'Ateş'ti — sorun değil.\n\n> alıntı", "question"),
    ("HTML <b>ve</b> emoji ✨", "<script>alert('x')</script> & “süslü” ✨🎉", "reference"),
    ("Tablo ve Türkçe", "| a | b |\n|---|---|\n| 1 | 2 |\n\nşğıöçü İstanbul", "todo"),
    ("Sadece başlık", "", "reminder"),
]


@pytest.fixture
def notes_client(client):
    from services import note_service as ns
    for title, body, cat in TRICKY_NOTES:
        ns.create_note(title=title, body=body, category=cat,
                       tags=["test", "türkçe"])
    return client


def _inline_scripts(html: str) -> list[str]:
    """Extract inline (no src=) <script> bodies from rendered HTML."""
    return re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", html, re.S)


def _node_check(js: str) -> tuple[bool, str]:
    """Syntax-check a JS snippet with node. Returns (ok, error)."""
    node = shutil.which("node")
    if not node:
        pytest.skip("node not available for JS syntax check")
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False,
                                     encoding="utf-8") as f:
        f.write(js)
        path = f.name
    try:
        r = subprocess.run([node, "--check", path], capture_output=True,
                           text=True, timeout=30)
        return r.returncode == 0, r.stderr
    finally:
        Path(path).unlink(missing_ok=True)


# ---- 1. Template architecture -------------------------------------------------

def test_notes_template_has_no_inline_logic_script():
    """The big JS block must live in static/js/notes.js, not in the template."""
    src = (PROJECT_ROOT / "templates" / "notes.html").read_text(encoding="utf-8")
    blocks = _inline_scripts(src)
    big = [b for b in blocks if len(b) > 500]
    assert not big, (
        "notes.html contains a large inline <script> — move it to "
        "static/js/notes.js (source-level fix for the dead-page bug)"
    )


def test_notes_template_references_static_js():
    src = (PROJECT_ROOT / "templates" / "notes.html").read_text(encoding="utf-8")
    assert "js/notes.js" in src


def test_static_notes_js_parses():
    js = (PROJECT_ROOT / "static" / "js" / "notes.js").read_text(encoding="utf-8")
    ok, err = _node_check(js)
    assert ok, f"static/js/notes.js has a syntax error: {err}"


def test_static_notes_js_exports_window_api():
    js = (PROJECT_ROOT / "static" / "js" / "notes.js").read_text(encoding="utf-8")
    for fn in ("openNewNoteModal", "openReadNoteModal", "exportAllNotes",
               "asmNotesReady"):
        assert f"window.{fn}" in js, f"notes.js must export window.{fn}"


def test_static_notes_js_uses_event_delegation():
    js = (PROJECT_ROOT / "static" / "js" / "notes.js").read_text(encoding="utf-8")
    assert "document.addEventListener(\"click\"" in js
    assert "closest(\"[data-action]\")" in js


def test_static_notes_js_has_no_python_slice_syntax():
    js = (PROJECT_ROOT / "static" / "js" / "notes.js").read_text(encoding="utf-8")
    # strip comments first — the header documents the old bug literally
    code_only = re.sub(r"/\*.*?\*/", "", js, flags=re.S)
    code_only = re.sub(r"//[^\n]*", "", code_only)
    assert not re.search(r"\w\[:\d+\]", code_only), "Python slice syntax found in JS"


# ---- 2. Rendered page ---------------------------------------------------------

def test_rendered_notes_page_all_inline_scripts_parse(notes_client):
    """THE regression guard: with tricky notes rendered, every inline script
    on the page must still be valid JavaScript."""
    r = notes_client.get("/notes/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    blocks = _inline_scripts(html)
    assert blocks, "expected at least one inline script (base.html)"
    for i, b in enumerate(blocks):
        ok, err = _node_check(b)
        assert ok, f"inline script #{i} failed to parse:\n{err}\n---\n{b[:400]}"


def test_rendered_notes_page_has_no_pythonisms(notes_client):
    r = notes_client.get("/notes/")
    html = r.get_data(as_text=True)
    for b in _inline_scripts(html):
        assert not re.search(r"\w\[:\d+\]", b), "Python slice leaked into JS"


def test_rendered_notes_page_includes_static_js(notes_client):
    r = notes_client.get("/notes/")
    assert b"js/notes.js" in r.data


def test_static_notes_js_is_served(app):
    with app.test_client() as c:
        r = c.get("/static/js/notes.js")
        assert r.status_code == 200
        assert b"asmNotesReady" in r.data


def test_note_cards_carry_data_attributes(notes_client):
    """Cards carry note data as JSON attribute — the only data channel
    between Jinja and notes.js."""
    r = notes_client.get("/notes/")
    html = r.get_data(as_text=True)
    assert html.count("data-note-data=") >= len(TRICKY_NOTES)
    # payload must be valid JSON (single-quoted attribute, Flask tojson)
    m = re.search(r"data-note-data='(.*?)'", html, re.S)
    assert m, "no data-note-data attribute found"
    payload = json.loads(m.group(1).replace("&#39;", "'"))
    assert "id" in payload and "title" in payload


def test_note_body_markdown_is_escaped_in_attribute(notes_client):
    """The pre-rendered markdown must be HTML-escaped inside the attribute —
    raw quotes would break the attribute and the whole card."""
    r = notes_client.get("/notes/")
    html = r.get_data(as_text=True)
    m = re.search(r'data-note-html="([^"]*)"', html)
    assert m, "no data-note-html attribute found"
    # Escaped entities must be present for tricky content
    assert "&lt;" in m.group(1) or "&amp;" in m.group(1) or m.group(1) == ""


# ---- 3. Global error net (never-silent failures) -------------------------------

def test_app_js_installs_global_error_net():
    js = (PROJECT_ROOT / "static" / "js" / "app.js").read_text(encoding="utf-8")
    assert "installGlobalErrorNet" in js
    assert 'window.addEventListener("error"' in js
    assert "unhandledrejection" in js


def test_app_js_parses():
    js = (PROJECT_ROOT / "static" / "js" / "app.js").read_text(encoding="utf-8")
    ok, err = _node_check(js)
    assert ok, f"app.js syntax error: {err}"


# ---- 4. Notes API still functional ---------------------------------------------

def test_note_crud_via_api(notes_client):
    r = notes_client.post("/notes/api/new", json={
        "title": "API notu", "body": "gövde", "category": "idea",
        "tags": ["api"], "pinned": False,
    })
    assert r.get_json()["ok"] is True
    nid = r.get_json()["id"]
    r = notes_client.post(f"/notes/api/{nid}/pin")
    assert r.get_json()["ok"] is True
    r = notes_client.post(f"/notes/api/{nid}/done")
    assert r.get_json()["ok"] is True
    r = notes_client.post(f"/notes/api/{nid}/delete")
    assert r.get_json()["ok"] is True
