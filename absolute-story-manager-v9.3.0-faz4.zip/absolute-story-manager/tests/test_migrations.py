"""M-01 — Alembic migration infrastructure tests (v9.1.0).

Covers the acceptance criteria from the plan:
  - empty DB: `alembic upgrade head` builds the schema without error
  - existing (filled) DB: stamped then upgraded, data intact, backup written
  - downgrade one step works and is reversible
  - init_db.py informs about the (new) Alembic-managed path
  - migration-built schema is equivalent to the create_all schema (golden)
"""
from __future__ import annotations

import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, inspect, text

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.migrations import (  # noqa: E402
    ALEMBIC_INI,
    EXPECTED_HEAD,
    get_current_revision,
    run_db_migrations,
)

# Tables owned by install_fts (raw SQL, outside Alembic by design).
# v9.3.0 (F-06): asm0003 reinstalls FTS during the migration itself, so the
# comparison must exclude the REAL FTS5 shadow set (the old constant listed
# notes_fts/glossary_terms_fts which never existed — harmless before asm0003
# because migrations never created FTS).
_FTS_TABLES = {
    "chapters_fts", "chapters_fts_data", "chapters_fts_idx",
    "chapters_fts_docsize", "chapters_fts_config",
    "characters_fts", "characters_fts_data", "characters_fts_idx",
    "characters_fts_docsize", "characters_fts_config",
    "world_fts", "world_fts_data", "world_fts_idx",
    "world_fts_docsize", "world_fts_config",
}
_COMPOSITE_INDEX = "ix_chapter_versions_ch_vnum"


def _new_file_engine(tmp_path: Path, name: str = "mig.db"):
    return create_engine(f"sqlite:///{tmp_path / name}", future=True)


def _table_names(eng) -> set[str]:
    return {
        t for t in inspect(eng).get_table_names()
        if t not in _FTS_TABLES and t != "alembic_version"
    }


def _index_names(eng, table: str) -> set[str]:
    return {ix["name"] for ix in inspect(eng).get_indexes(table)}


# ---------------------------------------------------------------------------
# Structural checks
# ---------------------------------------------------------------------------

def test_expected_head_matches_script_directory():
    """The EXPECTED_HEAD literal must equal the actual alembic head."""
    from alembic.script import ScriptDirectory

    script = ScriptDirectory(str(ALEMBIC_INI.parent / "alembic"))
    assert script.get_current_head() == EXPECTED_HEAD


def test_baseline_is_first_and_index_second():
    """asm0001 (baseline) has no parent; asm0002's parent is asm0001."""
    from alembic.script import ScriptDirectory

    script = ScriptDirectory(str(ALEMBIC_INI.parent / "alembic"))
    base = script.get_revision("asm0001")
    idx = script.get_revision("asm0002")
    assert base.down_revision is None
    assert idx.down_revision == "asm0001"


# ---------------------------------------------------------------------------
# Fresh database
# ---------------------------------------------------------------------------

def test_fresh_db_builds_full_schema(tmp_path):
    eng = _new_file_engine(tmp_path, "fresh.db")
    report = run_db_migrations(eng)

    assert report["action"] == "fresh"
    assert get_current_revision(eng) == EXPECTED_HEAD
    tables = _table_names(eng)
    # Spot-check the most important tables.
    for expected in ("projects", "chapters", "chapter_versions", "characters",
                     "world_entries", "settings", "notes", "glossary_entries"):
        assert expected in tables, f"missing table: {expected}"
    # The v8.4 composite index now arrives via migration asm0002.
    assert _COMPOSITE_INDEX in _index_names(eng, "chapter_versions")
    # Baseline must cover the service-registered models too.
    assert "chapter_checklists" in tables
    assert "snippets" in tables
    assert "background_tasks" in tables
    assert len(tables) == 41  # v9.3.0 (F-05): + background_tasks
    # v9.3.0 (F-06): hardening constraints are live on a fresh database.
    fks = sum(len(inspect(eng).get_foreign_keys(t)) for t in tables)
    uqs = sum(len(inspect(eng).get_unique_constraints(t)) for t in tables)
    cks = sum(len(inspect(eng).get_check_constraints(t)) for t in tables)
    assert fks >= 50, f"expected hard FK coverage, got {fks}"
    assert uqs >= 6, f"expected natural-key uniques, got {uqs}"
    assert cks >= 20, f"expected CHECK constraints, got {cks}"


def test_schema_equivalence_create_all_vs_migrations(tmp_path):
    """Golden equivalence: migration-built schema == create_all schema.

    v9.3.0 (F-06): the composite index is now declared in the models too, so
    create_all and the migration path produce byte-equivalent schemas — no
    intentional deltas remain.
    """
    from models import Base

    eng_ca = _new_file_engine(tmp_path, "createall.db")
    Base.metadata.create_all(eng_ca)

    eng_mig = _new_file_engine(tmp_path, "migrated.db")
    run_db_migrations(eng_mig)

    assert _table_names(eng_ca) == _table_names(eng_mig)

    for tbl in sorted(_table_names(eng_ca)):
        cols_ca = {
            c["name"]: (c["nullable"], str(c["type"]))
            for c in inspect(eng_ca).get_columns(tbl)
        }
        cols_mig = {
            c["name"]: (c["nullable"], str(c["type"]))
            for c in inspect(eng_mig).get_columns(tbl)
        }
        assert cols_ca == cols_mig, f"column mismatch on {tbl}"

    # Index delta: v9.3.0 — none. Perfect equivalence.
    for tbl in sorted(_table_names(eng_ca)):
        extra = _index_names(eng_mig, tbl) - _index_names(eng_ca, tbl)
        missing = _index_names(eng_ca, tbl) - _index_names(eng_mig, tbl)
        assert extra == set(), f"unexpected extra index on {tbl}: {extra}"
        assert missing == set(), f"missing index on {tbl}: {missing}"


# ---------------------------------------------------------------------------
# Legacy database adoption
# ---------------------------------------------------------------------------

def _build_legacy_db(tmp_path, name: str = "legacy.db", with_perf_index: bool = True):
    """Simulate a v9.0.x database: create_all + seed, no alembic_version."""
    from models import Base

    eng = _new_file_engine(tmp_path, name)
    Base.metadata.create_all(eng)
    if with_perf_index:
        from core.db import _ensure_performance_indexes
        _ensure_performance_indexes(eng)
    # Seed data the way v9.0.x would have.
    with eng.begin() as conn:
        conn.execute(text(
            "INSERT INTO projects (id, name, subtitle) "
            "VALUES ('legacy-1', 'Legacy Book', 'written on v9.0')"
        ))
        conn.execute(text(
            "INSERT INTO settings (key, value) VALUES ('theme', 'dark')"
        ))
    return eng


def test_legacy_db_is_stamped_and_upgraded(tmp_path):
    eng = _build_legacy_db(tmp_path)
    report = run_db_migrations(eng)

    assert report["action"] == "legacy-adopt"
    assert get_current_revision(eng) == EXPECTED_HEAD
    # Data survives adoption.
    with eng.connect() as conn:
        n_projects = conn.execute(text("SELECT COUNT(*) FROM projects")).scalar()
        theme = conn.execute(text(
            "SELECT value FROM settings WHERE key='theme'"
        )).scalar()
    assert n_projects >= 1
    assert theme == "dark"
    # A backup was written next to the DB.
    backup = report["backup"]
    assert backup is not None and Path(backup).exists()
    # The backup contains the pre-adoption state (version table absent,
    # data present).
    with sqlite3.connect(str(backup)) as con:
        rows = con.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        has_version = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE name='alembic_version'"
        ).fetchone()[0]
    assert rows >= 1
    assert has_version == 0


def test_legacy_db_with_wal_data_backup_is_complete(tmp_path):
    """Data sitting in the WAL file must land in the pre-alembic backup."""
    eng = _build_legacy_db(tmp_path, "wal.db")
    # Force WAL mode + a late write that stays in the WAL file.
    with eng.connect() as conn:
        conn.execute(text("PRAGMA journal_mode=WAL"))
        conn.execute(text(
            "INSERT INTO projects (id, name) VALUES ('wal-late', 'WAL Book')"
        ))
        conn.commit()
    report = run_db_migrations(eng)
    backup = report["backup"]
    assert backup is not None
    with sqlite3.connect(str(backup)) as con:
        names = {
            r[0] for r in con.execute("SELECT id FROM projects").fetchall()
        }
    assert "wal-late" in names


def test_legacy_db_missing_column_is_aligned(tmp_path):
    """A v8-style DB missing a newer column gets it back before stamping."""
    from models import Base

    eng = _new_file_engine(tmp_path, "oldcol.db")
    Base.metadata.create_all(eng)
    # Simulate old schema: drop a nullable, non-indexed column.
    with eng.begin() as conn:
        conn.execute(text("ALTER TABLE characters DROP COLUMN age"))
    before = {
        c["name"] for c in inspect(eng).get_columns("characters")
    }
    assert "age" not in before

    report = run_db_migrations(eng)
    assert report["action"] == "legacy-adopt"
    after = {
        c["name"] for c in inspect(eng).get_columns("characters")
    }
    assert "age" in after


def test_legacy_db_without_composite_index_gets_it(tmp_path):
    """v8.3-era DB (no runtime perf index) receives it via migration.

    v9.3.0: create_all now creates the composite (models declare it), so the
    v8.3 simulation must drop it explicitly after building the legacy DB.
    """
    eng = _build_legacy_db(tmp_path, "v83.db", with_perf_index=False)
    with eng.begin() as conn:
        conn.execute(text(
            "DROP INDEX IF EXISTS ix_chapter_versions_ch_vnum"))
    assert _COMPOSITE_INDEX not in _index_names(eng, "chapter_versions")

    run_db_migrations(eng)
    assert _COMPOSITE_INDEX in _index_names(eng, "chapter_versions")
    assert get_current_revision(eng) == EXPECTED_HEAD


# ---------------------------------------------------------------------------
# Downgrade / upgrade round trip
# ---------------------------------------------------------------------------

def test_downgrade_one_step_then_upgrade(tmp_path):
    from alembic.config import Config as AlembicConfig

    from alembic import command

    eng = _new_file_engine(tmp_path, "downgrade.db")
    run_db_migrations(eng)
    assert get_current_revision(eng) == "asm0005"

    cfg = AlembicConfig(str(ALEMBIC_INI))
    cfg.set_main_option("script_location", str(ALEMBIC_INI.parent / "alembic"))
    cfg.set_main_option("sqlalchemy.url", str(eng.url))
    cfg.attributes["configure_logger"] = False

    command.downgrade(cfg, "-1")
    assert get_current_revision(eng) == "asm0004"
    # v9.3.0 (F-10): downgrade drops the undo/redo stack column again.
    with eng.connect() as conn:
        cols = {r[1] for r in conn.execute(
            text("PRAGMA table_info(undo_operations)"))}
    assert "stack" not in cols
    # v9.3.0: the composite index outlives the downgrade — asm0002 owns it
    # and the relaxed rebuild recreates metadata indexes.
    assert _COMPOSITE_INDEX in _index_names(eng, "chapter_versions")
    # Data untouched by downgrade.
    with eng.connect() as conn:
        assert conn.execute(text("SELECT COUNT(*) FROM projects")).scalar() >= 0

    command.upgrade(cfg, "head")
    assert get_current_revision(eng) == EXPECTED_HEAD
    assert _COMPOSITE_INDEX in _index_names(eng, "chapter_versions")


# ---------------------------------------------------------------------------
# Fast path & init_db integration
# ---------------------------------------------------------------------------

def test_fast_path_is_noop_at_head(tmp_path):
    eng = _new_file_engine(tmp_path, "head.db")
    run_db_migrations(eng)

    report = run_db_migrations(eng)
    assert report == {
        "action": "noop", "from": EXPECTED_HEAD,
        "to": EXPECTED_HEAD, "backup": None,
    }


def test_init_db_on_fresh_engine_runs_migrations(tmp_path, monkeypatch):
    """init_db drives a pristine engine through the full migration flow."""
    import core.db

    eng = _new_file_engine(tmp_path, "initfresh.db")
    monkeypatch.setattr(core.db, "engine", eng)
    # Re-bind SessionLocal so seeding hits the new engine.
    from sqlalchemy.orm import scoped_session, sessionmaker
    factory = sessionmaker(bind=eng, expire_on_commit=False, future=True)
    monkeypatch.setattr(core.db, "SessionLocal", scoped_session(factory))
    monkeypatch.setattr(core.db, "session_factory", factory)

    report = core.db.init_db(seed_defaults=True)
    assert report["action"] == "fresh"
    assert get_current_revision(eng) == EXPECTED_HEAD
    # Seeding happened on the migrated schema.
    with eng.connect() as conn:
        n_settings = conn.execute(text("SELECT COUNT(*) FROM settings")).scalar()
        n_projects = conn.execute(text("SELECT COUNT(*) FROM projects")).scalar()
    assert n_settings > 0
    assert n_projects >= 1


def test_init_db_returns_noop_for_test_fixture_engine():
    """The conftest fixture DB is at head -> init_db is a fast no-op."""
    import core.db

    report = core.db.init_db(seed_defaults=False)
    assert report["action"] == "noop"


# ---------------------------------------------------------------------------
# CLI / script integration (mirrors the CI step)
# ---------------------------------------------------------------------------

def _run_cli(args, db_uri):
    import os
    env = dict(os.environ)
    env["ASM_DB_URI"] = db_uri
    return subprocess.run(
        [sys.executable, "-m", "alembic", "-c", str(ALEMBIC_INI), *args],
        cwd=str(PROJECT_ROOT), env=env, capture_output=True, text=True,
        timeout=120,
    )


def test_cli_upgrade_downgrade_upgrade_on_empty_db(tmp_path):
    db = tmp_path / "cli.db"
    uri = f"sqlite:///{db}"

    r1 = _run_cli(["upgrade", "head"], uri)
    assert r1.returncode == 0, r1.stderr
    with sqlite3.connect(str(db)) as con:
        assert con.execute("SELECT version_num FROM alembic_version"
                           ).fetchone()[0] == EXPECTED_HEAD

    r2 = _run_cli(["downgrade", "-1"], uri)
    assert r2.returncode == 0, r2.stderr
    with sqlite3.connect(str(db)) as con:
        assert con.execute("SELECT version_num FROM alembic_version"
                           ).fetchone()[0] == "asm0004"

    r3 = _run_cli(["upgrade", "head"], uri)
    assert r3.returncode == 0, r3.stderr
    with sqlite3.connect(str(db)) as con:
        assert con.execute("SELECT version_num FROM alembic_version"
                           ).fetchone()[0] == EXPECTED_HEAD


def test_init_db_script_reports_alembic_flow(tmp_path):
    import os

    db = tmp_path / "script.db"
    env = dict(os.environ)
    env["ASM_DB_URI"] = f"sqlite:///{db}"
    result = subprocess.run(
        [sys.executable, str(PROJECT_ROOT / "scripts" / "init_db.py")],
        cwd=str(PROJECT_ROOT), env=env, capture_output=True, text=True,
        timeout=120,
    )
    assert result.returncode == 0, result.stderr
    assert "Alembic" in result.stdout
    assert "migrations" in result.stdout.lower()
    # The script really migrated the target DB.
    with sqlite3.connect(str(db)) as con:
        rev = con.execute("SELECT version_num FROM alembic_version").fetchone()
    assert rev is not None and rev[0] == EXPECTED_HEAD
