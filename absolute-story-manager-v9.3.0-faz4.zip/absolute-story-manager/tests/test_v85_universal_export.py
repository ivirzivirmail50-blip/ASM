"""v8.5 — Universal Export tests.

Covers:
  1. Single world entry export (location/species/... in TXT/MD/PDF/DOCX/JSON)
     with metadata, hierarchy, relations and map pin fidelity
  2. World collection export filtered by type (+ search/category filters),
     correct plural labels, world-bible delegation for type=all (incl. new MD)
  3. Characters bulk export (TXT/MD/PDF/DOCX/JSON)
  4. Scene cards export (TXT/MD/CSV/JSON) with POV + chapter grouping
  5. Glossary export (TXT/MD/CSV/JSON) with forbidden variants
  6. References export (TXT/MD/CSV/JSON) with quotes + bibliography shape
  7. Routes: /export/collection/*, /export/collections, /world/<id>/export/*
  8. UI wiring: export menus on every page, Export Center Collections section
"""
from __future__ import annotations

import json

import pytest

from core.errors import NotFoundError

# ---------------------------------------------------------------- helpers

def _seed_world():
    """Two locations (parent/child) + a species + a relation between them."""
    from services import world_service
    loc = world_service.create_entry(
        name="Boğaz Kıyısı", type_="location", description="Sisli bir liman.",
        content="Rıhtımda balıkçı tekneleri dizili.", notes="Kışın tenha.",
        category="Doğu", metadata={"region": "Marmara", "climate": "nemli"})
    child = world_service.create_entry(
        name="Fener", type_="location", parent_id=loc.id, description="Eski bir fener.")
    sp = world_service.create_entry(
        name="Suirler", type_="species", description="Gölge yaratıkları.",
        metadata={"habitat": "mağara", "lifespan": "300 yıl"})
    world_service.create_relation(from_id=loc.id, to_id=sp.id, rel_type="home_of",
                                  description="Suirler burada yaşar.")
    return loc, child, sp


def _seed_characters():
    from services import character_service
    c1 = character_service.create_character(
        name="Kerem", role="protagonist", psychology="İçine kapanık ama kararlı.",
        philosophy_quotes=["Kapılar açıkken geç."])
    c2 = character_service.create_character(name="Deniz", role="antagonist")
    return c1, c2


# ===================== 1. Single world entry export ========================

class TestWorldEntryExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.loc, self.child, self.sp = _seed_world()

    def test_txt_has_sections_and_hierarchy(self):
        from services import export_service
        content, mime, fn = export_service.export_world_entry(self.child.id, "txt")
        text = content.decode("utf-8")
        assert "FENER" in text
        assert "HIERARCHY" in text
        assert "Boğaz Kıyısı" in text
        assert fn == "Fener.txt" and "text/plain" in mime

    def test_md_structure(self):
        from services import export_service
        content, _, fn = export_service.export_world_entry(self.loc.id, "md")
        text = content.decode("utf-8")
        assert "# Boğaz Kıyısı" in text
        assert "## Content" in text
        assert "## Metadata" in text
        assert "**Region:** Marmara" in text
        assert "## Children" in text and "Fener" in text
        assert fn == "Boğaz Kıyısı.md"

    def test_json_full_fidelity(self):
        from services import export_service
        content, _, _ = export_service.export_world_entry(self.loc.id, "json")
        d = json.loads(content)
        assert d["type"] == "location"
        assert d["metadata"]["region"] == "Marmara"
        assert d["children"] == ["Fener"]
        assert len(d["relations_out"]) == 1
        assert d["relations_out"][0]["target"] == "Suirler"
        assert d["relations_out"][0]["type"] == "home_of"
        # incoming on the species side
        content2, _, _ = export_service.export_world_entry(self.sp.id, "json")
        d2 = json.loads(content2)
        assert d2["relations_in"][0]["source"] == "Boğaz Kıyısı"

    def test_pdf_and_docx_bytes(self):
        from services import export_service
        pdf, _, f1 = export_service.export_world_entry(self.sp.id, "pdf")
        assert pdf.startswith(b"%PDF") and f1 == "Suirler.pdf"
        docx, mime, f2 = export_service.export_world_entry(self.sp.id, "docx")
        assert docx.startswith(b"PK") and f2 == "Suirler.docx"
        assert "wordprocessingml" in mime

    def test_map_pin_exported(self):
        from services import export_service, world_service
        e = world_service.create_entry(
            name="Kule", type_="location", map_pin_x=12.5, map_pin_y=40.1,
            map_pin_label="Ana kule")
        content, _, _ = export_service.export_world_entry(e.id, "json")
        d = json.loads(content)
        assert d["map_pin"]["x"] == 12.5
        assert d["map_pin"]["label"] == "Ana kule"
        txt, _, _ = export_service.export_world_entry(e.id, "txt")
        assert "MAP PIN" in txt.decode("utf-8")

    def test_turkish_survives_all_formats(self):
        from services import export_service
        for fmt in ("txt", "md", "json", "pdf", "docx"):
            content, _, _ = export_service.export_world_entry(self.loc.id, fmt)
            assert len(content) > 50, f"{fmt} suspiciously small"

    def test_unknown_format_raises(self):
        from services import export_service
        with pytest.raises(NotFoundError):
            export_service.export_world_entry(self.loc.id, "xyz")

    def test_unknown_entry_raises(self):
        from services import export_service
        with pytest.raises(NotFoundError):
            export_service.export_world_entry("nope", "txt")


# ===================== 2. World collection by type =========================

class TestWorldCollectionExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.loc, self.child, self.sp = _seed_world()

    def test_all_formats_location(self):
        from services import export_service
        for fmt, head in (("txt", b"LOCATIONS"), ("md", b"# Locations"),
                          ("pdf", b"%PDF"), ("docx", b"PK"), ("json", b'"collection"')):
            content, mime, fn = export_service.export_world_collection("location", fmt)
            assert head in content[:600], f"{fmt} missing header"
            assert fn.startswith("locations"), fn

    def test_plural_labels_correct(self):
        from services import export_service
        # species must NOT become "Speciess"
        _, _, fn = export_service.export_world_collection("species", "md")
        assert fn == "species.md"
        content, _, _ = export_service.export_world_collection("species", "md")
        assert b"# Species" in content and b"Speciess" not in content
        # technology → Technologies
        content, _, _ = export_service.export_world_collection("technology", "md")
        assert b"# Technologies" in content
        # magic_system → Magic Systems
        content, _, _ = export_service.export_world_collection("magic_system", "txt")
        assert b"MAGIC SYSTEMS" in content

    def test_search_filter(self):
        from services import export_service
        content, _, _ = export_service.export_world_collection("location", "txt",
                                                               search="fener")
        text = content.decode("utf-8")
        assert "FENER" in text
        assert "BOĞAZ KIYISI" not in text  # parent doesn't match search

    def test_category_filter(self):
        from services import export_service
        content, _, _ = export_service.export_world_collection(
            "location", "txt", category="Batı")
        assert "FENER" not in content.decode("utf-8")

    def test_type_all_delegates_to_world_bible(self):
        from services import export_service
        content, mime, fn = export_service.export_world_collection("all", "txt")
        assert fn == "world_bible.txt" and "text/plain" in mime
        assert "Boğaz Kıyısı" in content.decode("utf-8")

    def test_type_all_new_md_format(self):
        from services import export_service
        content, mime, fn = export_service.export_world_collection("all", "md")
        assert fn == "world_bible.md" and "text/markdown" in mime
        text = content.decode("utf-8")
        assert "# " in text and "Suirler" in text and "## Location" in text

    def test_metadata_included_in_collection(self):
        from services import export_service
        content, _, _ = export_service.export_world_collection("species", "md")
        text = content.decode("utf-8")
        assert "**Habitat:** mağara" in text
        assert "**Lifespan:** 300 yıl" in text

    def test_unknown_format_raises(self):
        from services import export_service
        with pytest.raises(NotFoundError):
            export_service.export_world_collection("location", "rtf")


# ===================== 3. Characters bulk export ===========================

class TestCharactersBulkExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.c1, self.c2 = _seed_characters()

    def test_all_formats(self):
        from services import export_service
        for fmt, head in (("txt", b"KEREM"), ("md", b"## Kerem"),
                          ("pdf", b"%PDF"), ("docx", b"PK"), ("json", b'"characters"')):
            content, mime, fn = export_service.export_characters(fmt)
            assert head in content[:900], f"{fmt} missing content"
            assert fn == f"characters.{fmt}"

    def test_json_count_and_fields(self):
        from services import export_service
        content, _, _ = export_service.export_characters("json")
        d = json.loads(content)
        assert d["count"] == 2
        names = {c["name"] for c in d["characters"]}
        assert names == {"Kerem", "Deniz"}
        kerem = next(c for c in d["characters"] if c["name"] == "Kerem")
        assert kerem["philosophy_quotes"] == ["Kapılar açıkken geç."]
        assert kerem["psychology"]

    def test_md_has_quotes_section(self):
        from services import export_service
        content, _, _ = export_service.export_characters("md")
        text = content.decode("utf-8")
        assert "### Notable Quotes" in text
        assert "Kapılar açıkken geç." in text


# ===================== 4. Scene cards export ===============================

class TestScenesExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        from services import chapter_service, scene_service
        self.ch = chapter_service.create_chapter(
            title="Bölüm Bir",
            content="Sahne bir metni burada.\n\n\nİkinci sahne metni.")
        self.cards = scene_service.extract_from_chapter(self.ch.id)

    def test_all_formats(self):
        from services import export_service
        for fmt, head in (("txt", b"SCENE"), ("md", b"# Scene"),
                          ("csv", b"title,chapter"), ("json", b'"scenes"')):
            content, mime, fn = export_service.export_scenes(fmt)
            assert head in content[:400], f"{fmt} missing header"
            assert fn == f"scenes.{fmt}"

    def test_grouped_by_chapter_name(self):
        from services import export_service
        content, _, _ = export_service.export_scenes("md")
        assert "Bölüm Bir" in content.decode("utf-8")

    def test_json_scene_count(self):
        from services import export_service
        content, _, _ = export_service.export_scenes("json")
        d = json.loads(content)
        assert d["count"] == len(self.cards)
        assert all(s["chapter"] == "Bölüm Bir" for s in d["scenes"])

    def test_csv_rows_parse(self):
        import csv as _csv
        import io as _io

        from services import export_service
        content, _, _ = export_service.export_scenes("csv")
        rows = list(_csv.reader(_io.StringIO(content.decode("utf-8"))))
        assert rows[0][0] == "title"
        assert len(rows) == len(self.cards) + 1  # header + scenes


# ===================== 5. Glossary export ==================================

class TestGlossaryExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        from services import glossary_service
        glossary_service.create_entry(
            term="Seur Kapıları", category="magic",
            definition="Ölümden sonra açılan kapılar.",
            alternates=["Seur kapıları"], forbidden=["Seur Kapilari"])
        glossary_service.create_entry(term="Kule", category="place",
                                      definition="Yüksek yapı.")

    def test_all_formats(self):
        from services import export_service
        for fmt, head in (("txt", b"GLOSSARY"), ("md", b"# Glossary"),
                          ("csv", b"term,category"), ("json", b'"glossary"')):
            content, mime, fn = export_service.export_glossary(fmt)
            assert head in content[:400], f"{fmt} missing header"
            assert fn == f"glossary.{fmt}"

    def test_forbidden_variants_in_output(self):
        from services import export_service
        txt, _, _ = export_service.export_glossary("txt")
        assert "FORBIDDEN: Seur Kapilari" in txt.decode("utf-8")
        md, _, _ = export_service.export_glossary("md")
        assert "Seur Kapilari" in md.decode("utf-8")

    def test_json_roundtrip(self):
        from services import export_service
        content, _, _ = export_service.export_glossary("json")
        d = json.loads(content)
        assert d["count"] == 2
        term = next(e for e in d["entries"] if e["term"] == "Seur Kapıları")
        assert term["alternates"] == ["Seur kapıları"]
        assert term["forbidden"] == ["Seur Kapilari"]


# ===================== 6. References export ================================

class TestReferencesExport:
    @pytest.fixture(autouse=True)
    def seed(self):
        from services import reference_service
        reference_service.create_reference(
            title="İstanbul'un Fenerleri", author="A. Yazar", source_type="book",
            url="https://example.com", rating=4, publication_date="2019",
            quotes=[{"text": "Fenerler şehrin hafızasıdır.", "page": "12"}],
            tags=["tarih", "şehir"])

    def test_all_formats(self):
        from services import export_service
        for fmt, head in (("txt", b"RESEARCH"), ("md", b"# Research"),
                          ("csv", b"title,author"), ("json", b'"references"')):
            content, mime, fn = export_service.export_references(fmt)
            assert head in content[:400], f"{fmt} missing header"
            assert fn == f"references.{fmt}"

    def test_quotes_and_rating_in_md(self):
        from services import export_service
        content, _, _ = export_service.export_references("md")
        text = content.decode("utf-8")
        assert "Fenerler şehrin hafızasıdır." in text
        assert "p. 12" in text
        assert "★★★★" in text

    def test_bibliography_line_shape(self):
        from services import export_service
        content, _, _ = export_service.export_references("txt")
        text = content.decode("utf-8")
        assert "İstanbul'un Fenerleri — A. Yazar (2019) [book]" in text


# ===================== 7. Routes ===========================================

class TestExportRoutes:
    @pytest.fixture(autouse=True)
    def seed(self):
        from services import chapter_service, glossary_service, reference_service, scene_service
        self.loc, self.child, self.sp = _seed_world()
        self.c1, self.c2 = _seed_characters()
        ch = chapter_service.create_chapter(
            title="Bölüm Bir", content="Sahne bir metni.\n\n\nİkinci sahne.")
        scene_service.extract_from_chapter(ch.id)
        glossary_service.create_entry(term="Seur Kapıları", category="magic",
                                      definition="Ölümden sonra açılan kapılar.")
        reference_service.create_reference(title="Fenerler", author="A. Yazar",
                                           source_type="book")

    def test_collection_routes_all_formats(self, client):
        checks = [
            "/export/collection/world/txt?type=location",
            "/export/collection/world/md?type=species",
            "/export/collection/world/pdf?type=location",
            "/export/collection/world/docx?type=species",
            "/export/collection/world/json?type=location",
            "/export/collection/world/md?type=all",
            "/export/collection/characters/txt",
            "/export/collection/characters/md",
            "/export/collection/characters/pdf",
            "/export/collection/characters/docx",
            "/export/collection/characters/json",
            "/export/collection/scenes/txt",
            "/export/collection/scenes/md",
            "/export/collection/scenes/csv",
            "/export/collection/scenes/json",
            "/export/collection/glossary/txt",
            "/export/collection/glossary/md",
            "/export/collection/glossary/csv",
            "/export/collection/glossary/json",
            "/export/collection/references/txt",
            "/export/collection/references/md",
            "/export/collection/references/csv",
            "/export/collection/references/json",
        ]
        for url in checks:
            r = client.get(url)
            assert r.status_code == 200, f"{url} → {r.status_code}"
            assert len(r.data) > 40, f"{url} too small"

    def test_world_collection_route_filters(self, client):
        r = client.get("/export/collection/world/txt?type=location&q=fener")
        assert r.status_code == 200
        assert b"FENER" in r.data
        # Parent must NOT appear as its own entry section (only in hierarchy context)
        assert b"BO\xc4\x9eAZ KIYISI\n==" not in r.data
        assert b"DESCRIPTION:\nSisli bir liman." not in r.data
        r = client.get("/export/collection/world/json?type=location&category=Bat%C4%B1")
        d = json.loads(r.data)
        assert d["count"] == 0

    def test_collections_api(self, client):
        r = client.get("/export/collections")
        assert r.status_code == 200
        d = json.loads(r.data)
        names = {c["name"] for c in d["collections"]}
        assert names == {"world", "characters", "scenes", "glossary", "references"}
        assert "location" in d["world_types"]
        assert "species" in d["world_types"]

    def test_single_entry_route_formats(self, client):
        for fmt in ("txt", "md", "pdf", "docx", "json"):
            r = client.get(f"/world/{self.loc.id}/export/{fmt}")
            assert r.status_code == 200, f"{fmt} → {r.status_code}"
            assert len(r.data) > 40

    def test_404s(self, client):
        assert client.get("/export/collection/aliens/txt").status_code == 404
        assert client.get("/export/collection/characters/xyz").status_code == 404
        assert client.get("/world/nope/export/txt").status_code == 404

    def test_attachment_headers(self, client):
        r = client.get("/export/collection/world/md?type=species")
        assert "attachment" in r.headers.get("Content-Disposition", "")
        assert "species.md" in r.headers.get("Content-Disposition", "")
        r = client.get(f"/world/{self.loc.id}/export/pdf")
        assert "attachment" in r.headers.get("Content-Disposition", "")
        assert "Bo" in r.headers.get("Content-Disposition", "")


# ===================== 8. UI wiring ========================================

class TestExportUIWiring:
    @pytest.fixture(autouse=True)
    def seed(self):
        self.loc, self.child, self.sp = _seed_world()
        self.c1, self.c2 = _seed_characters()

    def test_world_detail_has_export_menu(self, client):
        r = client.get(f"/world/{self.loc.id}")
        assert r.status_code == 200
        assert b"exportMenu" in r.data
        assert b"PDF Sheet" in r.data
        assert f"/world/{self.loc.id}/export/json".encode() in r.data

    def test_world_index_has_export_view(self, client):
        r = client.get("/world/?type=location")
        assert r.status_code == 200
        assert b"exportViewMenu" in r.data
        assert b"/export/collection/world/pdf?type=location" in r.data

    def test_world_index_export_carries_filters(self, client):
        r = client.get("/world/?type=location&q=fener&category=Do%C4%9Fu")
        assert b"q=fener" in r.data
        assert b"category=Do%C4%9Fu" in r.data

    def test_characters_list_has_export_all(self, client):
        r = client.get("/characters/")
        assert b"charExportMenu" in r.data
        assert b"/export/collection/characters/pdf" in r.data

    def test_scenes_page_has_export(self, client):
        r = client.get("/scenes/")
        assert b"sceneExportMenu" in r.data
        assert b"/export/collection/scenes/csv" in r.data

    def test_glossary_page_has_export(self, client):
        r = client.get("/glossary/")
        assert b"glossaryExportMenu" in r.data
        assert b"/export/collection/glossary/csv" in r.data

    def test_references_page_has_export(self, client):
        r = client.get("/references/")
        assert b"refExportMenu" in r.data
        assert b"/export/collection/references/md" in r.data

    def test_export_center_collections_section(self, client):
        r = client.get("/export/")
        assert r.status_code == 200
        assert b"Collections" in r.data
        assert b"setWorldType" in r.data
        # type chips for every world type
        assert b"wt-location" in r.data
        assert b"wt-species" in r.data
        assert b"wt-magic_system" in r.data
        # collection links
        assert b"/export/collection/characters/docx" in r.data
        assert b"/export/collection/scenes/csv" in r.data

    def test_export_center_world_bible_md_link(self, client):
        r = client.get("/export/")
        assert b"/export/collection/world/md?type=all" in r.data


# ===================== regression: old exports intact ======================

class TestOldExportsRegression:
    def test_character_sheet_still_works(self):
        from services import character_service, export_service
        c = character_service.create_character(name="Eski", role="minor")
        for fmt in ("txt", "pdf", "docx", "json"):
            content, _, fn = export_service.export_character_sheet(c.id, fmt)
            assert len(content) > 30 and fn.endswith(fmt)

    def test_world_bible_route_still_works(self, client):
        _seed_world()
        for fmt in ("txt", "pdf", "docx", "json"):
            r = client.get(f"/export/world-bible/{fmt}")
            assert r.status_code == 200, f"{fmt} → {r.status_code}"

    def test_manuscript_export_still_works(self, client):
        from services import chapter_service
        chapter_service.create_chapter(title="M1", content="İçerik.")
        r = client.get("/export/manuscript/txt")
        assert r.status_code == 200 and b"M1" in r.data
