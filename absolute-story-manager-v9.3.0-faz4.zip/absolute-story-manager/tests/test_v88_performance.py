"""v8.8 Performance Lab tests.

The measured answer to "does DB size hurt performance, what's the
threshold?" — pins the contract:

  * benchmark(): real query timing, warm-cache medians, verdicts vs
    thresholds, score/grade, trend delta vs stored previous run, write
    probe leaves nothing behind
  * report(): page/free-page fragmentation + VACUUM reclaim estimate,
    index coverage checklist (old DBs miss indexes — backfill restores),
    query-plan SCAN detection, FTS5 parity (external-content desync
    happens when triggers miss writes — rebuild restores), pragmas
  * actions: rebuild_fts, add_missing_indexes, integrity_check
  * auto-maintenance: due/not-due/disabled, interval setting, boot hook
  * routes: page renders the Performance Lab tab, API + actions wired
  * storage table-name regression: scene_cards / glossary_entries now
    appear in db_stats (v8.4 listed "scenes"/"glossary" — silently empty)
"""
from __future__ import annotations

import pytest
from sqlalchemy import text

from core.db import read_session, write_transaction
from models.settings import Setting
from services import perf_service

VERDICTS = {"fast", "ok", "slow", "critical", "skipped"}


def _set_setting(key: str, value) -> None:
    with write_transaction() as s:
        Setting.set(s, key, value)


def _get_setting(key: str, default=None):
    with read_session() as s:
        return Setting.get(s, key, default)


def _make_chapter(idx: int, words: int = 300) -> str:
    from services import chapter_service
    ch = chapter_service.create_chapter(
        title=f"Bölüm {idx}",
        content=("kelime " * words) + f"bölüm-{idx} fırtına",
    )
    return ch.id


def _engine():
    import core.db
    return core.db.engine


def _scalar(sql: str, params: dict | None = None):
    with _engine().connect() as conn:
        return conn.execute(text(sql), params or {}).scalar()


# ============================ 1. benchmark ================================

def test_benchmark_returns_measured_entries_with_verdicts():
    _make_chapter(1)
    _make_chapter(2)
    b = perf_service.benchmark()
    names = {e["name"] for e in b["entries"]}
    for expected in ("chapter_list", "chapter_read", "version_latest",
                     "world_by_type", "characters_list", "activity_recent",
                     "text_total", "fts_search", "like_search",
                     "write_txn"):
        assert expected in names, f"missing benchmark: {expected}"
    for e in b["entries"]:
        assert e["verdict"] in VERDICTS
        if e.get("ms") is not None:
            assert e["ms"] >= 0.0
    assert 0 <= b["score"]["score"] <= 100
    assert b["score"]["grade"] in "ABCDF"
    assert b["score"]["measured"] >= 1
    assert b["context"]["chapters"] == 2


def test_benchmark_on_empty_database_still_runs():
    b = perf_service.benchmark()
    assert b["score"]["measured"] >= 1  # write probe always measures
    fts = next(e for e in b["entries"] if e["name"] == "fts_search")
    assert fts["verdict"] == "skipped"  # no text to search — honest skip


def test_benchmark_second_run_shows_trend():
    _make_chapter(1)
    first = perf_service.benchmark()
    second = perf_service.benchmark()
    # every measured entry in run 2 must carry a delta vs run 1
    trended = [e for e in second["entries"] if e.get("trend") is not None]
    assert trended, "second run should carry trend deltas"
    for e in trended:
        assert e["trend"] in {"better", "worse", "same"}
        assert "delta_ms" in e
    # stored compact payload exists and matches
    stored = _get_setting("perf_last_benchmark")
    assert stored and stored["score"] == second["score"]["score"]
    assert stored["entries"]["chapter_list"] is not None


def test_write_probe_leaves_no_scratch_table():
    _make_chapter(1)
    result = perf_service._bench_write()
    assert result["ms"] is not None and result["ms"] >= 0
    # temp table lived inside a rolled-back transaction — nothing persists
    n = _scalar(
        "SELECT COUNT(*) FROM sqlite_temp_master WHERE name='_perf_scratch'")
    assert n == 0
    # and the persistent schema is untouched
    n2 = _scalar(
        "SELECT COUNT(*) FROM sqlite_master WHERE name LIKE '%perf_scratch%'")
    assert n2 == 0


def test_verdict_thresholds():
    assert perf_service._verdict(0.5, "lookup") == "fast"
    assert perf_service._verdict(10.0, "lookup") == "ok"
    assert perf_service._verdict(100.0, "lookup") == "slow"
    assert perf_service._verdict(500.0, "lookup") == "critical"
    assert perf_service._verdict(200.0, "scan") == "ok"      # scan scale
    assert perf_service._verdict(3.0, "write") == "fast"


# ============================ 2. report ===================================

def test_report_shape_and_pragmas():
    _make_chapter(1)
    r = perf_service.report()
    for key in ("pages", "pragmas", "index_coverage", "query_plans",
                "fts_health", "wal_mb", "auto_maintenance"):
        assert key in r, f"report missing {key}"
    assert r["pragmas"]["journal_mode"] == "wal"
    assert int(r["pragmas"]["foreign_keys"]) == 1
    assert r["pages"]["page_count"] > 0
    assert r["pages"]["page_size"] in (4096, 8192, 1024, 2048, 16384, 32768,
                                       65536)
    assert 0.0 <= r["pages"]["fragmentation_pct"] <= 100.0
    assert r["integrity"] is None  # deep=False by default


def test_report_deep_runs_quick_check():
    _make_chapter(1)
    r = perf_service.report(deep=True)
    assert r["integrity"]["ok"] is True
    assert r["integrity"]["verdict"] == "ok"
    assert r["integrity"]["result"].startswith("ok")


def test_index_coverage_detects_dropped_index_and_backfills():
    _make_chapter(1)
    # fresh DB has the composite index (conftest mirrors production init)
    r = perf_service.report()
    assert r["index_coverage"]["verdict"] == "ok"
    assert not r["index_coverage"]["missing"]
    # simulate an old database that never got it
    with _engine().begin() as conn:
        conn.execute(text("DROP INDEX ix_chapter_versions_ch_vnum"))
    r2 = perf_service.report()
    assert r2["index_coverage"]["verdict"] != "ok"
    missing_names = {m["name"] for m in r2["index_coverage"]["missing"]}
    assert "ix_chapter_versions_ch_vnum" in missing_names
    # backfill restores it
    result = perf_service.add_missing_indexes()
    assert any(c["name"] == "ix_chapter_versions_ch_vnum"
               for c in result["created"])
    r3 = perf_service.report()
    assert r3["index_coverage"]["verdict"] == "ok"
    # second call is a no-op
    result2 = perf_service.add_missing_indexes()
    assert result2["created"] == []


def test_index_coverage_accepts_prefix_equivalent():
    """A different-named index with the same leading columns counts."""
    _make_chapter(1)
    with _engine().begin() as conn:
        conn.execute(text("DROP INDEX ix_chapter_versions_ch_vnum"))
        conn.execute(text(
            "CREATE INDEX ix_alt_versions ON chapter_versions "
            "(chapter_id, version_number DESC)"))
    r = perf_service.report()
    missing_names = {m["name"] for m in r["index_coverage"]["missing"]}
    assert "ix_chapter_versions_ch_vnum" not in missing_names


def test_fts_parity_detects_desync_and_rebuild_restores():
    ch_id = _make_chapter(1, words=100)
    r = perf_service.report()
    assert r["fts_health"]["verdict"] == "ok"
    # simulate trigger bypass: remove the index entry without touching the
    # source row (exactly what a missed trigger write looks like)
    rowid, title, syn, content = None, None, None, None
    with _engine().connect() as conn:
        row = conn.execute(text(
            "SELECT rowid, title, synopsis, content FROM chapters "
            "WHERE id = :cid"), {"cid": ch_id}).one()
        rowid, title, syn, content = row
    with _engine().connect().execution_options(
            isolation_level="AUTOCOMMIT") as conn:
        conn.execute(text(
            "INSERT INTO chapters_fts(chapters_fts, rowid, title, synopsis, "
            "content) VALUES('delete', :rowid, :t, :s, :c)"),
            {"rowid": rowid, "t": title, "s": syn, "c": content})
    r2 = perf_service.report()
    chapters_row = next(x for x in r2["fts_health"]["rows"]
                        if x["source"] == "Chapters")
    assert chapters_row["verdict"] == "warn"
    assert chapters_row["index"] == chapters_row["rows"] - 1
    # rebuild restores parity from the source table
    result = perf_service.rebuild_fts()
    ch_result = next(x for x in result["results"]
                     if x["source"] == "Chapters")
    assert ch_result["fixed"] is True
    r3 = perf_service.report()
    assert r3["fts_health"]["verdict"] == "ok"
    # and FTS search works again
    hits = _scalar(
        "SELECT COUNT(*) FROM chapters_fts WHERE chapters_fts "
        "MATCH 'fırtına'")
    assert hits == 1


def test_query_plans_flag_scan_only_when_big():
    _make_chapter(1)
    qp = perf_service.report()["query_plans"]
    assert len(qp["plans"]) >= 8
    for p in qp["plans"]:
        assert p["plan"]  # every plan has detail text
    # small tables: scans are informational, never flagged
    assert qp["flagged"] == 0


def test_fragmentation_math_on_free_pages():
    """VACUUM reclaim estimate comes from real freelist pages."""
    _make_chapter(1)
    _make_chapter(2)
    # create free pages: write then delete
    from services import chapter_service
    ch3 = chapter_service.create_chapter(title="silinecek",
                                         content="geçici " * 500)
    chapter_service.delete_chapter(ch3.id)
    r = perf_service.report()
    p = r["pages"]
    assert p["freelist_count"] >= 1
    # freelist math is consistent with the pragma snapshot
    with _engine().connect() as conn:
        fl = conn.execute(text("PRAGMA freelist_count")).scalar()
        pc = conn.execute(text("PRAGMA page_count")).scalar()
    assert p["freelist_count"] == int(fl)
    assert p["page_count"] == int(pc)


# ============================ 3. actions + maintenance ====================

def test_integrity_check_action():
    r = perf_service.integrity_check()
    assert r["ok"] is True
    assert r["verdict"] == "ok"


def test_auto_maintenance_due_logic():
    from datetime import datetime, timedelta, timezone
    # fresh DB → no last run → due
    res = perf_service.run_auto_maintenance_if_due()
    assert res["ran"] is True
    assert "PRAGMA optimize" in res["actions"]
    # immediately again → not due (default 7 days)
    res2 = perf_service.run_auto_maintenance_if_due()
    assert res2["ran"] is False
    assert res2["reason"] == "not due yet"
    # recent timestamp → not due
    _set_setting("maintenance_last_run",
                 datetime.now(timezone.utc).isoformat())
    res3 = perf_service.run_auto_maintenance_if_due()
    assert res3["ran"] is False
    # stale timestamp → due again
    _set_setting("maintenance_last_run",
                 (datetime.now(timezone.utc) - timedelta(days=30)).isoformat())
    res4 = perf_service.run_auto_maintenance_if_due()
    assert res4["ran"] is True
    # disabled → never runs
    _set_setting("auto_maintenance_days", 0)
    _set_setting("maintenance_last_run",
                 (datetime.now(timezone.utc) - timedelta(days=30)).isoformat())
    res5 = perf_service.run_auto_maintenance_if_due()
    assert res5["ran"] is False
    assert res5["reason"] == "disabled"
    # force overrides
    res6 = perf_service.run_auto_maintenance_if_due(force=True)
    assert res6["ran"] is True


def test_auto_maintenance_setting_roundtrip():
    assert perf_service.auto_maintenance_days() == 7  # default ships on
    perf_service.set_auto_maintenance_days(14)
    assert perf_service.auto_maintenance_days() == 14
    st = perf_service.auto_maintenance_status()
    assert st["enabled"] is True and st["days"] == 14
    perf_service.set_auto_maintenance_days(0)   # clamp low
    st = perf_service.auto_maintenance_status()
    assert st["enabled"] is False
    perf_service.set_auto_maintenance_days(999)  # clamp high
    assert perf_service.auto_maintenance_days() == 365


def test_boot_maintenance_thread_spawns_and_finishes():
    import time as _t

    # stale last run → thread should run maintenance
    from datetime import datetime, timedelta, timezone
    _set_setting("maintenance_last_run",
                 (datetime.now(timezone.utc) - timedelta(days=30)).isoformat())
    perf_service.start_boot_maintenance()
    _t.sleep(1.0)
    last = _get_setting("maintenance_last_run")
    assert last is not None


def test_default_settings_ship_auto_maintenance():
    from models.settings import DEFAULT_SETTINGS
    assert DEFAULT_SETTINGS.get("auto_maintenance_days") == "7"


# ============================ 4. routes + UI ==============================

def test_storage_page_renders_performance_lab(client):
    _make_chapter(1)
    r = client.get("/storage/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    for probe in ("Performance Lab", "Run Benchmark", "File fragmentation",
                  "Index coverage", "Full-text index parity", "Query plans",
                  "Auto-maintenance", "When does database size actually hurt",
                  'data-panel="storage"', 'data-panel="perf"',
                  "runBenchmark", "perfAction", "saveAuto",
                  "perf-score-badge", "/storage/api/perf"):
        assert probe in html, f"page missing {probe}"


def test_storage_api_perf_shape(client):
    r = client.get("/storage/api/perf")
    assert r.status_code == 200
    data = r.get_json()
    assert data["ok"]
    rep = data["report"]
    for key in ("pages", "pragmas", "index_coverage", "query_plans",
                "fts_health", "auto_maintenance"):
        assert key in rep


def test_route_action_benchmark(client):
    _make_chapter(1)
    r = client.post("/storage/action", json={"action": "benchmark"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["ok"]
    assert "score" in data["result"]
    assert data["result"]["score"]["grade"] in "ABCDF"
    # stored → second page render shows it
    html = client.get("/storage/").get_data(as_text=True)
    assert "Last run" in html


def test_route_action_rebuild_fts_and_integrity(client):
    _make_chapter(1)
    r = client.post("/storage/action", json={"action": "rebuild_fts"})
    assert r.status_code == 200
    data = r.get_json()
    assert data["ok"] and "rebuilt" in data["message"]
    r2 = client.post("/storage/action", json={"action": "integrity_check"})
    data2 = r2.get_json()
    assert data2["ok"]
    assert data2["result"]["ok"] is True


def test_route_action_add_missing_indexes_and_save_auto(client):
    _make_chapter(1)
    client.get("/storage/")  # warm the app so init_db already ran
    with _engine().begin() as conn:
        conn.execute(text("DROP INDEX ix_chapter_versions_ch_vnum"))
    r = client.post("/storage/action", json={"action": "add_missing_indexes"})
    data = r.get_json()
    assert data["ok"]
    assert "Created 1 index" in data["message"]
    # save_auto round-trip through the route
    r2 = client.post("/storage/action", json={
        "action": "save_auto", "auto_maintenance_days": 21})
    data2 = r2.get_json()
    assert data2["ok"]
    assert data2["result"]["auto_maintenance_days"] == 21
    assert perf_service.auto_maintenance_days() == 21


def test_route_unknown_action_still_400(client):
    r = client.post("/storage/action", json={"action": "nope"})
    assert r.status_code == 400


def test_last_benchmark_view_merges_labels():
    _make_chapter(1)
    perf_service.benchmark()
    view = perf_service.last_benchmark_view()
    assert view is not None
    labels = {e["label"] for e in view["entries"]}
    assert any("Chapter list" in l for l in labels)
    assert view["score"] is not None


# ============================ 5. v8.8 storage regressions =================

def test_db_stats_reports_real_table_names():
    """v8.4 listed scenes/glossary/inspiration — wrong names, silently
    empty rows. v8.8 reports the real tables."""
    from models.scene import SceneCard
    from services import chapter_service, glossary_service, storage_service

    chapter_service.create_chapter(title="B", content="metin " * 50)
    with write_transaction() as s:
        s.add(SceneCard(id="sc1", title="Sahne", summary="bir sahne"))
    glossary_service.create_entry(term="Fırtına",
                                  definition="şiddetli rüzgâr",
                                  category="other")

    stats = storage_service.db_stats()
    reported = {t["table"]: t for t in stats["tables"] if t["rows"]}
    assert "scene_cards" in reported
    assert reported["scene_cards"]["rows"] == 1
    assert reported["scene_cards"]["measured"] is True
    assert "glossary_entries" in reported
    assert reported["glossary_entries"]["rows"] == 1


def test_db_stats_characters_text_columns_measured():
    from services import character_service, storage_service
    character_service.create_character(
        name="Elara",
        psychology="iç dünya metni " * 20,
        background="geçmiş hikâyesi " * 20,
    )
    stats = storage_service.db_stats()
    chars = next(t for t in stats["tables"] if t["table"] == "characters")
    assert chars["rows"] == 1
    assert chars["measured"] is True
    assert chars["text_bytes"] > 0
