"""S-07 — dead vendor weight removed; utility classes formalised.

The "tailwind.min.css" was the Tailwind Play CDN *JavaScript* shipped with a
.css extension (451 KB, zero rules could ever apply) and Alpine.js (44 KB)
was loaded on every page without a single x-data directive in any template.
These tests keep both from creeping back and verify every utility class used
by templates now has a real definition in the project CSS.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMPLATES = ROOT / "templates"
CSS_FILES = [ROOT / "static" / "css" / f for f in
             ("main.css", "polish.css", "ui-v2.css", "fa-icons.css",
              "vendor/vis-network/vis-network.min.css")]


def _all_css() -> str:
    return "\n".join(p.read_text(encoding="utf-8", errors="replace")
                     for p in CSS_FILES if p.exists())


class TestDeadVendorRemoved:
    def test_no_template_references_tailwind_or_alpine(self):
        """Checks actual src/href references, not explanatory comments."""
        offenders = []
        for t in TEMPLATES.rglob("*.html"):
            for m in re.findall(r'(?:src|href)="([^"]+)"',
                                t.read_text(encoding="utf-8",
                                            errors="replace")):
                if re.search(r"tailwind|alpine", m, re.I):
                    offenders.append(f"{t.name}: {m}")
        assert not offenders, f"templates still reference dead vendors: {offenders}"

    def test_vendor_dirs_deleted(self):
        assert not (ROOT / "static" / "vendor" / "tailwind").exists()
        assert not (ROOT / "static" / "vendor" / "alpine").exists()

    def test_manifest_has_no_dead_entries(self):
        manifest = (ROOT / "static" / "vendor" / "MANIFEST.txt").read_text()
        assert not re.search(r"tailwind|alpine", manifest, re.I)

    def test_fetch_vendor_no_longer_ships_them(self):
        text = (ROOT / "scripts" / "fetch_vendor.py").read_text()
        assert "cdn.tailwindcss.com" not in text
        assert "alpinejs" not in text

    def test_base_html_has_no_dead_links(self):
        """base.html must not link/script anything under vendor/tailwind|alpine."""
        text = (TEMPLATES / "base.html").read_text()
        for line in text.splitlines():
            if "vendor/" in line:
                assert "tailwind" not in line.lower()
                assert "alpine" not in line.lower()


class TestUtilityCoverage:
    """Every utility-flavoured class used in templates must be defined in
    the project's own CSS (the utilities Tailwind was supposed to provide)."""

    def test_used_utilities_are_defined(self):
        css = _all_css()
        used = set()
        for t in TEMPLATES.rglob("*.html"):
            for m in re.findall(r'class="([^"]+)"',
                                t.read_text(encoding="utf-8", errors="replace")):
                used.update(m.split())
        # Classes that look like Tailwind utilities (spacing/sizing/grid).
        tw_like = {c for c in used
                   if re.fullmatch(r"(flex|grid|hidden)[\w:-]*", c)
                   or re.fullmatch(r"(gap|mt|mb|ml|mr|p[trbl]?)-\d+", c)
                   or re.fullmatch(r"(grid-cols-\d|col-span-\d)", c)
                   or c in ("flex-1", "flex-wrap", "flex-col", "ml-auto",
                            "overflow-x-auto", "items-center",
                            "justify-between", "justify-end", "w-full",
                            "grow", "relative", "absolute", "rounded",
                            "rounded-lg", "rounded-full", "border",
                            "text-center", "text-sm", "text-xs", "text-lg",
                            "font-mono", "font-serif", "bg-elev-1",
                            "bg-elev-2", "btn-xs")}
        tw_like = {c for c in tw_like if ":" not in c or
                   re.search(re.escape(c).replace(r"\:", r"\\:"), css)}
        # For responsive variants check the escaped form exists in CSS.
        missing = []
        for c in sorted(tw_like):
            needle = c.replace(":", r"\:")
            if not re.search(r"\." + re.escape(needle) + r"[\s,{:]", css):
                missing.append(c)
        assert not missing, f"utilities used in templates but not defined: {missing}"

    def test_card_grid_cols6_defined(self):
        """cols-6 (story bible / series hub stat rows) must be styled."""
        css = _all_css()
        assert re.search(r"\.card-grid\.cols-6\s*\{", css)
