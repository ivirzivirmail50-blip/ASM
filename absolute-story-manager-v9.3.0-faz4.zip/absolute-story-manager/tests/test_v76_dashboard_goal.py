"""v7.6 regression tests — dashboard goal rendering robustness.

Live verification caught a real crash: when ``daily_word_goal`` is stored as a
STRING (e.g. "500" — JSON-encoded by Setting.set when given a str, or left by
an older version), the dashboard template did raw arithmetic:

    stats.words_today / settings.get('daily_word_goal', 500)
    → TypeError: unsupported operand type(s) for /: 'int' and 'str' → HTTP 500

The template now normalizes once ({% set daily_goal = ...|int or 500 %}) and
every consumer (ring label, session targets, weekly goal, ASM_DAILY_GOAL JS
global) uses the int. These tests pin that behaviour so the crash class can't
return.
"""
import pytest


@pytest.fixture
def client(app):  # conftest app (fresh_db)
    return app.test_client()


def _set_goal(value):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "daily_word_goal", value)


def _set_total_goal(value):
    from core.db import write_transaction
    from models.settings import Setting
    with write_transaction() as s:
        Setting.set(s, "total_word_goal", value)


# --------------------------------------------------------------- the crash


def test_v76_dashboard_survives_string_daily_goal(client):
    """The exact live-verification crash: string goal must not 500 the page."""
    _set_goal("500")
    r = client.get("/")
    assert r.status_code == 200, r.data[:500]
    assert b"Session Targets" in r.data


def test_v76_dashboard_survives_string_total_goal(client):
    """total_word_goal had the same raw-division pattern (Story Health card)."""
    _set_total_goal("80000")
    r = client.get("/")
    assert r.status_code == 200
    assert b"Story Health" in r.data


def test_v76_dashboard_goal_values_render(client):
    """Rendered page shows the normalized int goals, not Python str artifacts."""
    _set_goal("750")
    r = client.get("/")
    assert r.status_code == 200
    body = r.data.decode()
    assert "750" in body                      # goal label present
    assert "750750" not in body               # no string-repeat from "750" * 7
    assert "/ 5250 goal" in body              # weekly goal = 750 * 7 as int


def test_v76_dashboard_js_goal_global_is_int(client):
    """window.ASM_DAILY_GOAL must always be a bare number (int filter)."""
    _set_goal("500")
    body = client.get("/").data.decode()
    assert "window.ASM_DAILY_GOAL = 500;" in body
    assert 'window.ASM_DAILY_GOAL = "500"' not in body
    assert "window.ASM_DAILY_GOAL = None" not in body


# --------------------------------------------------------- defensive shape


def test_v76_dashboard_template_normalizes_goal():
    """Template source must contain the single normalization point."""
    src = open("templates/dashboard.html", encoding="utf-8").read()
    assert "|int or 500" in src                 # daily goal normalization
    assert "|int or 80000" in src               # total goal normalization
    # the fragile raw-division patterns must be gone
    assert "settings.get('daily_word_goal', 500) or 1" not in src
    assert "settings.get('daily_word_goal', 500) * 7" not in src
    assert "settings.get('total_word_goal', 80000) or 1" not in src


def test_v76_other_goal_readers_are_defensive():
    """Every Python reader of the setting still wraps in int() (belt+braces)."""
    import inspect

    import routes.focus_mode as fm
    import routes.outline as ol
    import services.insights_service as ins
    for mod in (fm, ol, ins):
        src = inspect.getsource(mod)
        assert 'Setting.get(s, "daily_word_goal"' not in src or "int(" in src, \
            f"{mod.__name__} reads daily_word_goal without int() cast"
