"""v9.0 — Series Bible tests.

Covers:
  1. SeriesLink model (table, unique constraint) + registration in ALL_MODELS
  2. Series overview (all books, per-book counts, totals)
  3. Series cast grouping (Turkish-aware name matching, shared detection,
     linked flag, per-book role chips)
  4. Series world grouping (type + name, shared detection)
  5. Link CRUD (create, duplicate → 409, self-book → 400, unknown → 404,
     unlink, links_for_entity with book names, candidate books)
  6. Continuity report (role drift, eye/hair attribute conflicts,
     world description drift, unlinked-same-name suggestions)
  7. Series Bible export (MD / JSON / PDF / DOCX shapes + fidelity)
  8. AI synopsis (disabled → 404 convention; mocked provider → grounded prompt)
  9. Routes (page, APIs, link/unlink, exports, unknown format 404)
 10. UI wiring (sidebar link, i18n 5 langs, navMap, polish.css layer,
     character + world detail Series menu/card, blueprint registered)
"""
from __future__ import annotations

import json

import pytest

# ---------------------------------------------------------------- helpers

def _new_book(client, name: str, **kw) -> dict:
    rv = client.post("/projects/new", json={"name": name, **kw})
    data = rv.get_json()
    assert data["ok"] is True, data
    return data


def _switch(client, project_id: str):
    rv = client.post(f"/projects/{project_id}/switch")
    assert rv.get_json()["ok"] is True


def _make_char(client, name: str, role: str = "protagonist",
               physical: str | None = None) -> dict:
    form = {"name": name, "role": role}
    if physical:
        form["physical"] = physical
    rv = client.post("/characters/new", data=form)
    data = rv.get_json()
    assert data and data["ok"] is True, rv.data[:300]
    return data


def _make_world(client, name: str, type_: str = "location",
                description: str = "") -> dict:
    rv = client.post("/world/new", data={
        "name": name, "type": type_, "description": description,
        "content": "", "notes": "", "category": "", "parent_id": "",
    })
    assert rv.status_code in (200, 302), rv.data[:300]
    # find the created entry by name
    from core.db import read_session
    from models.world import WorldEntry
    with read_session() as s:
        from sqlalchemy import select
        e = s.scalars(select(WorldEntry).where(
            WorldEntry.name == name).order_by(
            WorldEntry.created_at.desc())).first()
        assert e is not None
        return {"id": e.id, "name": e.name}


@pytest.fixture
def two_books(client):
    """default ('Test Story') + 'Kitap İki'. Leaves default active."""
    data = _new_book(client, "Kitap İki", genre="Fantasy", color="#f59e0b")
    _switch(client, "default")  # creation auto-switches; restore default
    return data


# ===================== 1. Model ============================================

class TestSeriesLinkModel:
    def test_table_and_columns(self):
        from models.series import SeriesLink
        cols = {c.name for c in SeriesLink.__table__.columns}
        assert {"id", "entity_type", "entity_id", "source_project_id",
                "target_project_id", "note", "created_at"} == cols

    def test_registered_in_all_models(self):
        import models
        assert models.series in models.ALL_MODELS
        from models import Base
        from models.series import SeriesLink
        assert "series_links" in Base.metadata.tables

    def test_unique_constraint(self):
        from models.series import SeriesLink
        uqs = [c.name for c in SeriesLink.__table__.constraints
               if c.__class__.__name__ == "UniqueConstraint"]
        assert "uq_series_link_target" in uqs


# ===================== 2. Overview =========================================

class TestSeriesOverview:
    def test_counts_books_and_totals(self, client, two_books):
        from services import series_service as svc
        # seed: 1 char + 1 chapter in default, 1 char in book two
        _make_char(client, "Elara")
        from services import chapter_service
        chapter_service.create_chapter(title="Bölüm 1", content="kelime " * 100)

        _switch(client, two_books["id"])
        _make_char(client, "Kael")

        ov = svc.series_overview()
        assert ov["totals"]["books"] == 2
        assert ov["totals"]["characters"] == 2
        by_name = {b["name"]: b for b in ov["books"]}
        assert by_name["Test Story"]["characters"] == 1
        assert by_name["Kitap İki"]["characters"] == 1
        assert by_name["Test Story"]["words"] > 0
        assert by_name["Test Story"]["is_active"] is False
        assert by_name["Kitap İki"]["is_active"] is True

    def test_active_book_sorted_first(self, two_books, client):
        from services import series_service as svc
        ov = svc.series_overview()
        assert ov["books"][0]["is_active"] is True


# ===================== 3. Cast grouping ====================================

class TestSeriesCast:
    def test_same_name_groups_across_books(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "Elara")
        _switch(client, two_books["id"])
        _make_char(client, "ELARA")  # case differs

        cast = svc.series_cast()
        elara = [g for g in cast["groups"] if g["key"] == "elara"]
        assert len(elara) == 1
        g = elara[0]
        assert g["books_count"] == 2
        assert len(g["entities"]) == 2
        assert {e["book_name"] for e in g["entities"]} == {"Test Story", "Kitap İki"}
        assert cast["shared_count"] == 1

    def test_turkish_dotted_i_groups(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "İsmet")
        _switch(client, two_books["id"])
        _make_char(client, "ismet")

        cast = svc.series_cast()
        keys = [g["key"] for g in cast["groups"]]
        # İ→i and i are the same person after Turkish-aware normalization
        assert keys.count("ismet") == 1

    def test_linked_flag_after_link(self, client, two_books):
        from services import series_service as svc
        c1 = _make_char(client, "Elara")
        _switch(client, two_books["id"])
        _make_char(client, "Elara")

        link = svc.link_entity("character", c1["id"], two_books["id"])
        cast = svc.series_cast()
        g = [x for x in cast["groups"] if x["key"] == "elara"][0]
        assert g["linked"] is True

    def test_link_without_local_copy_counts_shared(self, client, two_books):
        """Linking Elara into a book with NO local copy must still show
        her as a series character of 2 books (link = appears-in)."""
        from services import series_service as svc
        c1 = _make_char(client, "Elara")
        svc.link_entity("character", c1["id"], two_books["id"])

        cast = svc.series_cast()
        g = [x for x in cast["groups"] if x["key"] == "elara"][0]
        assert g["books_count"] == 2
        assert g["linked"] is True
        assert cast["shared_count"] == 1
        e = g["entities"][0]
        assert len(e["links"]) == 1
        assert e["links"][0]["book_name"] == "Kitap İki"

    def test_physical_attrs_extracted(self, client):
        from services import series_service as svc
        _make_char(client, "Elara", physical="She had green eyes and black hair.")
        cast = svc.series_cast()
        e = cast["groups"][0]["entities"][0]
        assert e["physical_attrs"] == {"eye": "green", "hair": "black"}

    def test_single_book_character_not_shared(self, client):
        from services import series_service as svc
        _make_char(client, "Solo")
        cast = svc.series_cast()
        assert cast["shared_count"] == 0
        assert all(g["books_count"] == 1 for g in cast["groups"])


# ===================== 4. World grouping ===================================

class TestSeriesWorld:
    def test_same_type_name_groups(self, client, two_books):
        from services import series_service as svc
        _make_world(client, "Fırtına Limanı", "location", "doğal liman")
        _switch(client, two_books["id"])
        _make_world(client, "Fırtına Limanı", "location", "doğal liman")

        world = svc.series_world()
        g = [x for x in world["groups"]
             if x["type"] == "location" and x["key"].endswith("fırtına limanı")]
        assert len(g) == 1
        assert g[0]["books_count"] == 2
        assert world["shared_count"] >= 1

    def test_same_name_different_type_not_grouped(self, client, two_books):
        from services import series_service as svc
        _make_world(client, "Aurelia", "location")
        _switch(client, two_books["id"])
        _make_world(client, "Aurelia", "faction")

        world = svc.series_world()
        matches = [g for g in world["groups"] if g["display"] == "Aurelia"]
        assert len(matches) == 2  # separate groups: different types

    def test_linked_world_flag(self, client, two_books):
        from services import series_service as svc
        w1 = _make_world(client, "Aurelia", "location")
        _switch(client, two_books["id"])
        _make_world(client, "Aurelia", "location")

        svc.link_entity("world", w1["id"], two_books["id"])
        world = svc.series_world()
        g = [x for x in world["groups"] if x["display"] == "Aurelia"][0]
        assert g["linked"] is True


# ===================== 5. Link CRUD ========================================

class TestLinkCrud:
    def _char_in_default(self, client):
        return _make_char(client, "Elara")

    def test_link_and_unlink(self, client, two_books):
        from services import series_service as svc
        c1 = self._char_in_default(client)
        link = svc.link_entity("character", c1["id"], two_books["id"],
                               note="Üç yıl sonra")
        assert link["entity_type"] == "character"
        assert link["source_project_id"] == "default"
        assert link["target_project_id"] == two_books["id"]
        assert link["note"] == "Üç yıl sonra"

        removed = svc.unlink(link["id"])
        assert removed["id"] == link["id"]
        assert svc.links_for_entity("character", c1["id"]) == []

    def test_duplicate_link_conflict(self, client, two_books):
        from core.errors import ConflictError
        from services import series_service as svc
        c1 = self._char_in_default(client)
        svc.link_entity("character", c1["id"], two_books["id"])
        with pytest.raises(ConflictError):
            svc.link_entity("character", c1["id"], two_books["id"])

    def test_link_to_own_book_rejected(self, client):
        from core.errors import ValidationError
        from services import series_service as svc
        c1 = self._char_in_default(client)
        with pytest.raises(ValidationError):
            svc.link_entity("character", c1["id"], "default")

    def test_link_unknown_entity_404(self, client, two_books):
        from core.errors import NotFoundError
        from services import series_service as svc
        with pytest.raises(NotFoundError):
            svc.link_entity("character", "nope", two_books["id"])

    def test_link_unknown_target_404(self, client):
        from core.errors import NotFoundError
        from services import series_service as svc
        c1 = self._char_in_default(client)
        with pytest.raises(NotFoundError):
            svc.link_entity("character", c1["id"], "ghost-book")

    def test_link_bad_entity_type(self, client, two_books):
        from core.errors import ValidationError
        from services import series_service as svc
        c1 = self._char_in_default(client)
        with pytest.raises(ValidationError):
            svc.link_entity("chapter", c1["id"], two_books["id"])

    def test_links_for_entity_carries_book_names(self, client, two_books):
        from services import series_service as svc
        c1 = self._char_in_default(client)
        svc.link_entity("character", c1["id"], two_books["id"])
        links = svc.links_for_entity("character", c1["id"])
        assert len(links) == 1
        assert links[0]["target_book_name"] == "Kitap İki"
        assert links[0]["target_book_color"] == "#f59e0b"

    def test_candidate_books_exclude_home_and_linked(self, client, two_books):
        from services import series_service as svc
        c1 = self._char_in_default(client)
        third = _new_book(client, "Kitap Üç")
        svc.link_entity("character", c1["id"], two_books["id"])
        targets = svc.link_target_books("character", c1["id"])
        ids = [t["id"] for t in targets]
        assert two_books["id"] not in ids
        assert third["id"] in ids
        assert "default" not in ids

    def test_series_links_all_names(self, client, two_books):
        from services import series_service as svc
        c1 = _make_char(client, "Elara")
        svc.link_entity("character", c1["id"], two_books["id"])
        rows = svc.series_links_all()
        assert len(rows) == 1
        assert rows[0]["entity_name"] == "Elara"
        assert rows[0]["source_book_name"] == "Test Story"
        assert rows[0]["target_book_name"] == "Kitap İki"

    def test_deleted_entity_named_gracefully(self, client, two_books):
        from services import series_service as svc
        c1 = _make_char(client, "Ghost")
        svc.link_entity("character", c1["id"], two_books["id"])
        rv = client.post(f"/characters/{c1['id']}/delete")
        assert rv.get_json()["ok"] is True
        rows = svc.series_links_all()
        assert len(rows) == 1
        assert rows[0]["entity_name"] == "(deleted character)"


# ===================== 6. Continuity report ================================

class TestContinuityReport:
    def test_role_drift_detected(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "Elara", role="protagonist")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", role="antagonist")

        rep = svc.continuity_report()
        drifts = [f for f in rep["findings"] if f["kind"] == "role_drift"]
        assert len(drifts) == 1
        assert "Elara" in drifts[0]["message"]
        assert set(drifts[0]["books"]) == {"Test Story", "Kitap İki"}
        assert drifts[0]["severity"] == "warn"

    def test_attribute_conflict_detected(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "Elara", physical="She had green eyes.")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", physical="Her blue eyes were cold.")

        rep = svc.continuity_report()
        conflicts = [f for f in rep["findings"]
                     if f["kind"] == "attribute_conflict"]
        assert len(conflicts) == 1
        assert "eye" in conflicts[0]["message"]
        assert "blue" in conflicts[0]["message"] and "green" in conflicts[0]["message"]

    def test_attribute_conflict_turkish(self, client, two_books):
        """Turkish physical descriptions must be detected too (v9.0 live
        validation caught the EN-only gap)."""
        from services import series_service as svc
        _make_char(client, "Elara", physical="Yeşil gözlü, siyah saçlı genç bir kadın.")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", physical="Mavi gözlü, kır saçlı olgun bir kâhin.")

        rep = svc.continuity_report()
        conflicts = [f for f in rep["findings"]
                     if f["kind"] == "attribute_conflict"]
        assert len(conflicts) == 1
        assert "eye" in conflicts[0]["message"]
        assert "blue" in conflicts[0]["message"] and "green" in conflicts[0]["message"]

    def test_cross_language_same_color_no_conflict(self, client, two_books):
        """"mavi gözlü" vs "blue eyes" is the SAME color — no false conflict."""
        from services import series_service as svc
        _make_char(client, "Elara", physical="Mavi gözlü bir kâhin.")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", physical="She had blue eyes.")

        rep = svc.continuity_report()
        assert not [f for f in rep["findings"]
                    if f["kind"] == "attribute_conflict"]

    def test_matching_attributes_no_conflict(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "Elara", physical="She had green eyes.")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", physical="green eyes, same as ever")

        rep = svc.continuity_report()
        assert not [f for f in rep["findings"]
                    if f["kind"] == "attribute_conflict"]

    def test_unlinked_same_name_suggestion(self, client, two_books):
        from services import series_service as svc
        c1 = _make_char(client, "Elara")
        _switch(client, two_books["id"])
        _make_char(client, "Elara")

        rep = svc.continuity_report()
        sugg = [f for f in rep["findings"]
                if f["kind"] == "unlinked_same_name"]
        assert len(sugg) == 1
        assert sugg[0]["entity_type"] == "character"
        assert c1["id"] in sugg[0]["entity_ids"]

    def test_linked_same_name_no_suggestion(self, client, two_books):
        from services import series_service as svc
        c1 = _make_char(client, "Elara")
        _switch(client, two_books["id"])
        _make_char(client, "Elara")
        svc.link_entity("character", c1["id"], two_books["id"])

        rep = svc.continuity_report()
        assert not [f for f in rep["findings"]
                    if f["kind"] == "unlinked_same_name"
                    and f["entity_type"] == "character"]

    def test_world_description_drift(self, client, two_books):
        from services import series_service as svc
        _make_world(client, "Aurelia", "location",
                    "Batı kıyısındaki en büyük liman kenti.")
        _switch(client, two_books["id"])
        _make_world(client, "Aurelia", "location",
                    "Kuzeydeki dağların eteğinde bir maden kasabası.")

        rep = svc.continuity_report()
        drifts = [f for f in rep["findings"]
                  if f["kind"] == "description_drift"]
        assert len(drifts) == 1
        assert "Aurelia" in drifts[0]["message"]
        assert drifts[0]["severity"] == "info"

    def test_world_similar_descriptions_no_drift(self, client, two_books):
        from services import series_service as svc
        _make_world(client, "Aurelia", "location",
                    "Batı kıyısındaki en büyük liman kenti.")
        _switch(client, two_books["id"])
        _make_world(client, "Aurelia", "location",
                    "Batı kıyısındaki en büyük liman kenti.")

        rep = svc.continuity_report()
        assert not [f for f in rep["findings"]
                    if f["kind"] == "description_drift"]

    def test_counts_summary(self, client, two_books):
        from services import series_service as svc
        _make_char(client, "Elara", role="protagonist")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", role="supporting")

        rep = svc.continuity_report()
        total = len(rep["findings"])
        assert rep["counts"]["total"] == total
        assert rep["counts"]["warn"] + rep["counts"]["info"] == total

    def test_clean_series_no_findings(self, client):
        from services import series_service as svc
        _make_char(client, "Solo")
        rep = svc.continuity_report()
        assert rep["findings"] == []
        assert rep["counts"] == {"warn": 0, "info": 0, "total": 0}


# ===================== 7. Export ===========================================

class TestSeriesExport:
    def _seed(self, client, two_books):
        _make_char(client, "Elara", physical="She had green eyes.")
        _make_world(client, "Aurelia", "location", "liman kenti")
        _switch(client, two_books["id"])
        _make_char(client, "Elara", role="antagonist",
                   physical="Her blue eyes were cold.")

    def test_markdown_shape(self, client, two_books):
        self._seed(client, two_books)
        from services import series_service as svc
        content, mime, name = svc.export_series_bible("md")
        text = content.decode("utf-8")
        assert name == "series_bible.md"
        assert mime == "text/markdown"
        assert text.startswith("# Series Bible")
        assert "## Books" in text
        assert "## Series Cast" in text
        assert "## Shared World" in text
        assert "## Continuity Findings" in text
        assert "**Elara**" in text
        assert "Test Story" in text and "Kitap İki" in text
        assert "(protagonist)" in text and "(antagonist)" in text

    def test_json_shape(self, client, two_books):
        self._seed(client, two_books)
        from services import series_service as svc
        content, mime, name = svc.export_series_bible("json")
        payload = json.loads(content)
        assert payload["kind"] == "asm-series-bible"
        assert payload["overview"]["totals"]["books"] == 2
        assert any(g["display"] == "Elara" for g in payload["cast"]["groups"])
        assert payload["continuity"]["counts"]["total"] > 0

    def test_pdf_magic_and_size(self, client, two_books):
        self._seed(client, two_books)
        from services import series_service as svc
        content, mime, name = svc.export_series_bible("pdf")
        assert content.startswith(b"%PDF")
        assert name == "series_bible.pdf"
        assert len(content) > 1000

    def test_docx_magic(self, client, two_books):
        self._seed(client, two_books)
        from services import series_service as svc
        content, mime, name = svc.export_series_bible("docx")
        assert content.startswith(b"PK")
        assert name == "series_bible.docx"

    def test_unknown_format_404(self, client):
        from core.errors import NotFoundError
        from services import series_service as svc
        with pytest.raises(NotFoundError):
            svc.export_series_bible("rtf")

    def test_pdf_turkish_glyphs(self, client, two_books):
        """Turkish text must survive the PDF roundtrip (v8.7 lesson)."""
        _make_char(client, "İsmet Şahoğlu")
        _make_world(client, "Fırtına Limanı", "location", "Boğaz'ın kuzeyi")
        from services import series_service as svc
        content, _, _ = svc.export_series_bible("pdf")
        # extract text via pdfminer if available
        try:
            import io

            from pdfminer.high_level import extract_text
            text = extract_text(io.BytesIO(content))
            assert "İsmet" in text or "Fırtına" in text
        except ImportError:
            pass  # pdfminer optional; magic + size checked elsewhere


# ===================== 8. AI synopsis ======================================

class TestAiSynopsis:
    def test_disabled_raises_404_convention(self, client):
        from core.errors import AiDisabledError
        from services import series_service as svc
        with pytest.raises(AiDisabledError):
            svc.ai_series_synopsis()

    def test_disabled_route_404(self, client):
        rv = client.post("/series/api/ai-synopsis")
        assert rv.status_code == 404

    def test_mocked_prompt_contains_books(self, client, two_books,
                                          monkeypatch):
        from services import ai_service
        from services import series_service as svc
        monkeypatch.setattr(ai_service, "is_enabled", lambda: True)
        captured = {}

        def fake_generate(prompt, **kw):
            captured["prompt"] = prompt
            return "Beş kitaplık destanın ilk adımı."

        monkeypatch.setattr(ai_service, "generate", fake_generate)
        text = svc.ai_series_synopsis()
        assert text == "Beş kitaplık destanın ilk adımı."
        assert "Test Story" in captured["prompt"]
        assert "Kitap İki" in captured["prompt"]
        assert "back-cover" in captured["prompt"]

    def test_route_with_mock(self, client, two_books, monkeypatch):
        from services import ai_service
        monkeypatch.setattr(ai_service, "is_enabled", lambda: True)
        monkeypatch.setattr(ai_service, "generate",
                            lambda p, **kw: "Seri özeti metni.")
        rv = client.post("/series/api/ai-synopsis")
        assert rv.status_code == 200
        assert rv.get_json()["synopsis"] == "Seri özeti metni."


# ===================== 9. Routes ===========================================

class TestSeriesRoutes:
    def test_page_renders(self, client, two_books):
        rv = client.get("/series/")
        assert rv.status_code == 200
        html = rv.data.decode()
        assert "Series Hub" in html
        assert "Kitap İki" in html
        assert "Cross-book continuity" in html

    def test_page_renders_single_book(self, client):
        rv = client.get("/series/")
        assert rv.status_code == 200
        assert "Series Hub" in rv.data.decode()

    def test_api_endpoints(self, client, two_books):
        for path in ("overview", "cast", "world", "continuity"):
            rv = client.get(f"/series/api/{path}")
            assert rv.status_code == 200
            assert rv.get_json()["ok"] is True

    def test_link_route_roundtrip(self, client, two_books):
        c1 = _make_char(client, "Elara")
        rv = client.post("/series/link", json={
            "entity_type": "character", "entity_id": c1["id"],
            "target_project_id": two_books["id"]})
        assert rv.status_code == 200
        link_id = rv.get_json()["link"]["id"]

        rv = client.get("/series/")
        assert "LINKED" in rv.data.decode()

        rv = client.delete(f"/series/link/{link_id}")
        assert rv.status_code == 200
        assert "LINKED" not in client.get("/series/").data.decode()

    def test_link_route_validation(self, client, two_books):
        rv = client.post("/series/link", json={"entity_type": "character"})
        assert rv.status_code == 400

        rv = client.post("/series/link", json={
            "entity_type": "character", "entity_id": "ghost",
            "target_project_id": two_books["id"]})
        assert rv.status_code == 404

    def test_export_routes(self, client, two_books):
        for fmt, magic in (("md", b"#"), ("json", b"{"),
                           ("pdf", b"%PDF"), ("docx", b"PK")):
            rv = client.get(f"/series/export/{fmt}")
            assert rv.status_code == 200
            assert rv.data.startswith(magic)
            assert "attachment" in rv.headers.get(
                "Content-Disposition", "")

    def test_export_unknown_format(self, client):
        rv = client.get("/series/export/rtf")
        assert rv.status_code == 404

    def test_unknown_link_delete_404(self, client):
        rv = client.delete("/series/link/nope")
        assert rv.status_code == 404

    def test_isolation_links_do_not_leak_into_lists(self, client, two_books):
        """Project isolation contract: linking Elara (default) into Kitap İki
        must NOT make her appear in Kitap İki's normal character list."""
        c1 = _make_char(client, "Elara")
        client.post("/series/link", json={
            "entity_type": "character", "entity_id": c1["id"],
            "target_project_id": two_books["id"]})
        _switch(client, two_books["id"])

        rv = client.get("/characters/")
        html = rv.data.decode()
        assert "Elara" not in html  # not leaked into the other book's list


# ===================== 10. UI wiring =======================================

class TestUiWiring:
    def test_sidebar_link(self, client):
        html = client.get("/series/").data.decode()
        assert 'href="/series/"' in html
        assert "<span>Series Hub</span>" in html

    def test_i18n_key_five_languages(self):
        from services.i18n_service import TRANSLATIONS
        key = "nav.series"
        for lang in ("en", "tr", "es", "fr", "de"):
            assert key in TRANSLATIONS, f"missing {key} for {lang}"
            assert TRANSLATIONS[key][lang]

    def test_navmap_contains_series(self, client):
        # v9.2.0 (F-02): navMap DOM-çevirisi kaldırıldı — sunucu tarafında
        # çevrilen sidebar etiketi artık HTML içinde doğrudan görünür.
        html = client.get("/series/").data.decode()
        assert "Series Hub" in html  # en UI: sunucu-render etiketi

    def test_polish_css_layer(self):
        css = open("static/css/polish.css", encoding="utf-8").read()
        assert ".series-tabs" in css
        assert ".series-chip" in css
        assert ".series-finding" in css
        assert ".series-book" in css

    def test_character_detail_series_menu(self, client):
        c1 = _make_char(client, "Elara")
        html = client.get(f"/characters/{c1['id']}").data.decode()
        assert "seriesMenu" in html
        assert "＋ Series ▾" in html
        assert "📚 Series" in html
        assert "seriesLinkEntity" in html

    def test_character_detail_shows_link(self, client, two_books):
        c1 = _make_char(client, "Elara")
        client.post("/series/link", json={
            "entity_type": "character", "entity_id": c1["id"],
            "target_project_id": two_books["id"]})
        html = client.get(f"/characters/{c1['id']}").data.decode()
        assert "appears in" in html
        assert "Kitap İki" in html

    def test_world_detail_series_menu(self, client):
        w1 = _make_world(client, "Aurelia", "location")
        html = client.get(f"/world/{w1['id']}").data.decode()
        assert "seriesMenu" in html
        assert "＋ Series ▾" in html
        assert "seriesLinkEntity" in html

    def test_world_detail_shows_link(self, client, two_books):
        w1 = _make_world(client, "Aurelia", "location")
        client.post("/series/link", json={
            "entity_type": "world", "entity_id": w1["id"],
            "target_project_id": two_books["id"]})
        html = client.get(f"/world/{w1['id']}").data.decode()
        assert "appears in <strong>Kitap İki</strong>" in html

    def test_blueprint_registered(self):
        from app import create_app
        app = create_app()
        assert "series" in app.blueprints

    def test_command_palette_sidebar_sync(self, client):
        """Palette reads sidebar DOM — Series Hub link must be present."""
        html = client.get("/series/").data.decode()
        assert "<span>Series Hub</span>" in html

    def test_ai_panel_hidden_when_disabled(self, client):
        html = client.get("/series/").data.decode()
        assert "AI Series Synopsis" not in html
