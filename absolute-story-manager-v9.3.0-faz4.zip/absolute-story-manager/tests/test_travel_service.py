"""M-08 — travel route service coverage (45% → 80%+).

v9.3.0 (F-06): travel_routes.character_id/project_id are hard FKs — tests
create real characters/projects instead of fictional ids.
"""
from __future__ import annotations

from services import travel_service as svc


def _mk_char(cid: str, project_id: str = "default") -> str:
    from core.db import write_transaction
    from models.character import Character
    with write_transaction() as s:
        s.add(Character(id=cid, project_id=project_id, name=f"Karakter {cid}"))
    return cid


def _mk_project(pid: str) -> None:
    from core.db import write_transaction
    from models.project import Project
    with write_transaction() as s:
        if s.get(Project, pid) is None:
            s.add(Project(id=pid, name=f"Kitap {pid}"))


class TestTravelRoutes:

    def test_create_and_list(self):
        _mk_char("char-1")
        r = svc.create_route(
            "char-1", "Ayşe'nin yolculuğu", color="#ff0000",
            waypoints=[{"lat": 41.0, "lng": 29.0, "label": "İstanbul"}],
        )
        assert r.id
        routes = svc.list_routes()
        assert any(x.id == r.id for x in routes)

    def test_create_defaults(self):
        _mk_char("char-2")
        r = svc.create_route("char-2", "Boş yol")
        assert r.color == "#6366f1"
        assert r.waypoints == "[]"  # dump_json([]) — empty list serialized

    def test_update_route(self):
        _mk_char("char-3")
        _mk_char("char-9")
        r = svc.create_route("char-3", "Eski ad")
        updated = svc.update_route(
            r.id, name="Yeni ad", color="#00ff00", character_id="char-9",
            waypoints=[{"lat": 1.0, "lng": 2.0}],
        )
        assert updated.name == "Yeni ad"
        assert updated.color == "#00ff00"
        assert updated.character_id == "char-9"
        assert "1.0" in updated.waypoints

    def test_update_unknown_returns_none(self):
        assert svc.update_route("ghost-route", name="x") is None

    def test_update_ignores_none_fields(self):
        _mk_char("char-4")
        r = svc.create_route("char-4", "Kalıcı ad")
        updated = svc.update_route(r.id, name=None, color=None)
        assert updated.name == "Kalıcı ad"

    def test_delete_route(self):
        _mk_char("char-5")
        r = svc.create_route("char-5", "Silinecek")
        svc.delete_route(r.id)
        assert all(x.id != r.id for x in svc.list_routes())
        # ghost delete must not raise
        svc.delete_route("ghost-route")

    def test_get_routes_json_roundtrip(self):
        _mk_char("char-6")
        svc.create_route(
            "char-6", "JSON yolu",
            waypoints=[{"lat": 3.0, "lng": 4.0, "label": "Nokta"}],
        )
        data = svc.get_routes_json()
        match = [d for d in data if d["name"] == "JSON yolu"]
        assert match
        assert match[0]["waypoints"][0]["label"] == "Nokta"
        assert match[0]["character_id"] == "char-6"

    def test_routes_are_project_scoped(self):
        from core.db import read_session, write_transaction
        from models.settings import Setting

        _mk_project("other-book")
        _mk_char("char-7", project_id="other-book")
        before = len(svc.list_routes())
        with write_transaction() as s:
            Setting.set(s, "active_project_id", "other-book")
        try:
            svc.create_route("char-7", "Diğer kitabın yolu")
            assert len(svc.list_routes()) == 1  # only the other book's route
        finally:
            with write_transaction() as s:
                Setting.set(s, "active_project_id", "default")
        assert len(svc.list_routes()) == before
