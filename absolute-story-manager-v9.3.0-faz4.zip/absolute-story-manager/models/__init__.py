"""SQLAlchemy ORM models for Absolute Story Manager."""
from __future__ import annotations

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base for all models."""


# Import all model modules so they register on Base.metadata.
from models import (  # noqa: E402,F401
    achievement,
    activity,
    ai_history,
    background_task,
    beta_comment,
    chapter,
    chapter_deps,
    char_location_pin,
    char_mood,
    character,
    chat,
    glossary,
    inspiration,
    journal,
    milestone,
    note,
    plan,
    project,
    reference,
    scene,
    series,
    session,
    settings,
    spellcheck,
    submission,
    travel_route,
    undo,
    voice,
    world,
)

# v9.1.0 (M-08): these two service modules DEFINE models (ChapterChecklist,
# Snippet). The import exists purely for the side effect of registering their
# tables on Base.metadata. It is cycle-tolerant: when one of these services is
# imported FIRST, this line runs while that module is still partial — the
# table still registers when the module finishes loading on its own.
try:  # noqa: E402
    from services.checklist_service import ChapterChecklist  # noqa: E402,F401
except ImportError:  # pragma: no cover - only hit mid-circular-import
    pass
try:  # noqa: E402
    from services.snippet_service import Snippet  # noqa: E402,F401
except ImportError:  # pragma: no cover - only hit mid-circular-import
    pass

ALL_MODELS = (project, settings, activity, chapter, character, plan, world, undo,
              travel_route, beta_comment, ai_history, inspiration, note, glossary,
              submission, voice, reference, scene, journal, achievement, spellcheck,
              session, chapter_deps, milestone, char_mood, char_location_pin, chat,
              series, background_task)
