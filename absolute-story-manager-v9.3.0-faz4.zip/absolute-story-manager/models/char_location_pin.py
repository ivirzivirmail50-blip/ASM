"""Character-Location pin model — where a character currently resides.

v7.6 Story Atlas: links a Character to a WorldEntry (location type) so the
atlas can pin characters onto the location tree.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text

from models import Base


class CharacterLocationPin(Base):
    __tablename__ = "character_location_pins"

    id = Column(String, primary_key=True)
    project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                        nullable=False, default="default", index=True)
    character_id = Column(String, ForeignKey("characters.id", ondelete="CASCADE"), index=True)
    location_id = Column(String, ForeignKey("world_entries.id", ondelete="CASCADE"), index=True)
    # kind: current_residence / origin / visiting / hiding / temporary
    kind = Column(String(40), default="current_residence", index=True)
    note = Column(Text)
    chapter_id = Column(String, ForeignKey("chapters.id", ondelete="CASCADE"), nullable=True)
    # Optional chapter-scoped pin (where character is *at* this chapter point in the timeline)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


PIN_KINDS = {
    "current_residence":  {"label": "Current residence",  "color": "#22c55e", "icon": "home"},
    "origin":             {"label": "Origin / hometown",   "color": "#3b82f6", "icon": "flag"},
    "visiting":           {"label": "Visiting",            "color": "#f59e0b", "icon": "compass"},
    "hiding":             {"label": "Hiding",              "color": "#ef4444", "icon": "eye-off"},
    "temporary":          {"label": "Temporary stay",      "color": "#a855f7", "icon": "clock"},
}
