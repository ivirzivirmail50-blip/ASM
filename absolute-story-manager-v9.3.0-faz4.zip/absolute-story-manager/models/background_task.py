"""BackgroundTask model — disk-backed durable job queue (F-05, v9.3.0).

Export/compile işleri artık bellek-içi cache'te değil bu tabloda yaşar:
uygulama kapansa bile görev durumu (pending/running/done/failed), ilerleme
ve sonuç diskte kalır; açılışta 'running'de takılı kalanlar tekrar kuyruğa
alınır (services/task_queue_service.recover_stale_running).

v9.3.0 (F-11): SQLAlchemy 2.0 Mapped tipi bildirimleri — strict mypy seti
bu modülü tam tiplerle denetler.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from models import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


class BackgroundTask(Base):
    """One durable background job (export / compile / ...)."""

    __tablename__ = "background_tasks"
    __table_args__ = (
        CheckConstraint("status IN ('pending', 'running', 'done', 'failed')",
                        name="ck_bgtask_status"),
        CheckConstraint("progress >= 0 AND progress <= 100",
                        name="ck_bgtask_progress_range"),
        Index("ix_bgtask_status_created", "status", "created_at"),
    )

    id: Mapped[str] = mapped_column(String, primary_key=True)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending", index=True)
    payload: Mapped[str | None] = mapped_column(Text)
    progress: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0)
    stage: Mapped[str | None] = mapped_column(String(200))
    result: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        nullable=False, default=_now, index=True)
    started_at: Mapped[datetime | None] = mapped_column()
    finished_at: Mapped[datetime | None] = mapped_column()
