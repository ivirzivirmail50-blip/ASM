"""Chapter + chapter_versions models."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    text,
)

from models import Base


class Chapter(Base):
    __tablename__ = "chapters"
    __table_args__ = (
        CheckConstraint("word_count >= 0", name="ck_chapters_wordcount_nonneg"),
        CheckConstraint("sort_order >= 0", name="ck_chapters_sort_nonneg"),
        CheckConstraint("story_day IS NULL OR story_day >= 1",
                        name="ck_chapters_storyday_pos"),
    )

    id = Column(String, primary_key=True)
    project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                        default="default", index=True)
    title = Column(String(500), nullable=False)
    content = Column(Text)
    synopsis = Column(Text)
    status = Column(String(20), default="draft", index=True)  # draft/revised/final
    word_count = Column(Integer, default=0)
    target_word_count = Column(Integer)
    sort_order = Column(Integer, default=0, index=True)
    character_ids = Column(Text)  # JSON array of all characters in this chapter
    tags = Column(Text)  # JSON array
    # Pro metadata (added for editor depth parity with Scrivener/Atticus)
    pov_character_id = Column(String, ForeignKey("characters.id", ondelete="SET NULL"), nullable=True, index=True)
    location = Column(String(500))  # primary setting of the chapter (free text or world entry name)
    story_day = Column(Integer)  # chronological day in the story (1-indexed)
    story_date = Column(String(50))  # in-story date string (e.g. "Day 14" or "Spring, Year 2")
    notes = Column(Text)  # author's private notes / scratchpad (separate from synopsis)
    custom_fields = Column(Text)  # JSON object for user-defined key/value pairs
    drafted_at = Column(DateTime)
    revised_at = Column(DateTime)
    finalized_at = Column(DateTime)
    raw_file_path = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))


class ChapterVersion(Base):
    __tablename__ = "chapter_versions"
    __table_args__ = (
        # v8.4 composite (asm0002 owns it for migrated DBs; declaring it here
        # too keeps create_all and the migration schema byte-equivalent).
        Index("ix_chapter_versions_ch_vnum", "chapter_id",
              text("version_number DESC")),
        CheckConstraint("is_pinned IN (0, 1)", name="ck_chver_pinned_bool"),
        CheckConstraint("version_number >= 1", name="ck_chver_vnum_pos"),
        CheckConstraint("word_count >= 0", name="ck_chver_wordcount_nonneg"),
    )

    id = Column(String, primary_key=True)
    chapter_id = Column(String, ForeignKey("chapters.id", ondelete="CASCADE"), index=True)
    version_number = Column(Integer)
    content = Column(Text)
    word_count = Column(Integer, default=0)
    source = Column(String(40))  # manual/reupload/status_change/split/merge
    uploaded_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    notes = Column(Text)
    label = Column(String(200))  # user-defined label, e.g. "Beta reader draft"
    is_pinned = Column(Boolean, default=False)  # pinned/starred version
