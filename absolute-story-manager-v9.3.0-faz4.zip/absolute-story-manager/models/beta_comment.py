"""Beta reader comment model — read-only annotations on chapters with threading."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)

from models import Base


class BetaComment(Base):
    """A comment left by a beta reader on a chapter. Supports threaded replies."""
    __tablename__ = "beta_comments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    chapter_id = Column(String, ForeignKey("chapters.id", ondelete="CASCADE"), index=True)
    reader_name = Column(String(100), default="Beta Reader")
    selected_text = Column(Text)  # The text the comment refers to
    comment = Column(Text, nullable=False)
    position = Column(Integer, default=0)  # Character offset in chapter
    status = Column(String(20), default="open")  # open / resolved
    # Threading: parent_id points to the comment this is replying to (null = top-level)
    parent_id = Column(Integer, ForeignKey("beta_comments.id", ondelete="CASCADE"), nullable=True, index=True)
    is_author_reply = Column(Boolean, default=False)  # True if the author (writer) replied
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class BetaReadProgress(Base):
    """v8.9 Review Loop — tracks which chapters a beta reader has finished.

    One row per (chapter, reader). Authors use this on the Beta Review Hub to
    see reader coverage: 'Elif has read 12 of 30 chapters'.
    """
    __tablename__ = "beta_read_progress"
    __table_args__ = (
        UniqueConstraint("chapter_id", "reader_name",
                         name="uq_beta_read_progress"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    chapter_id = Column(String, ForeignKey("chapters.id", ondelete="CASCADE"), nullable=False, index=True)
    reader_name = Column(String(100), nullable=False)
    completed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
