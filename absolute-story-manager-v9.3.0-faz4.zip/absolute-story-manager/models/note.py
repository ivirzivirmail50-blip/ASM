"""Note model — quick-capture items for the Notes & Ideas Inbox."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Boolean, CheckConstraint, Column, DateTime, ForeignKey, Integer, String, Text

from models import Base


class Note(Base):
    __tablename__ = "notes"
    __table_args__ = (
        CheckConstraint("pinned IN (0, 1)", name="ck_notes_pinned_bool"),
        CheckConstraint("done IN (0, 1)", name="ck_notes_done_bool"),
    )

    id = Column(String, primary_key=True)
    project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                        nullable=False, default="default", index=True)
    title = Column(String(500))
    body = Column(Text)
    category = Column(String(40), default="idea", index=True)
    tags = Column(Text)                       # JSON array
    pinned = Column(Boolean, default=False)
    done = Column(Boolean, default=False)           # for todos
    # Cross-reference links (JSON array of {entity_type, entity_id, entity_title})
    links = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))
