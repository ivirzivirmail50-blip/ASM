"""Series links — explicit cross-book entity references (v9.0).

A novelist with a multi-book workspace (v7.0) had books that were strict
islands: the same character re-created by hand in book 2, no way to say
"this is the SAME person". SeriesLink is the explicit, user-declared
bridge between books:

    character "Elara" (home: Book 1)  ──link──▶  appears in Book 2

Key design decisions:
  * The entity ALWAYS lives in (is edited in, belongs to) its home book.
    A link is a reference, not a copy — single source of truth.
  * Links are per (entity, target book): linking Elara into Book 2 and
    Book 3 are two rows. A unique constraint prevents double-linking.
  * Every service-layer query stays project-scoped (isolation tests keep
    passing); cross-book views live ONLY behind the Series Hub surface.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, String, Text, UniqueConstraint

from models import Base


class SeriesLink(Base):
    __tablename__ = "series_links"
    __table_args__ = (
        UniqueConstraint("entity_id", "target_project_id",
                         name="uq_series_link_target"),
    )

    id = Column(String, primary_key=True)
    # "character" | "world"
    entity_type = Column(String(20), nullable=False, index=True)
    # PK of the source entity (characters.id / world_entries.id)
    entity_id = Column(String, nullable=False, index=True)
    # Home book of the entity (where it is edited)
    source_project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                               nullable=False, index=True)
    # Book the entity is declared to appear in
    target_project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                               nullable=False, index=True)
    # Free-form per-book note, e.g. "Üç yıl sonra, Kâhin olmuş"
    note = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
