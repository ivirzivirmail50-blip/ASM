"""Settings (key/value with JSON-encoded values)."""
from __future__ import annotations

import json
import threading
from typing import Any

from sqlalchemy import Column, String, Text

from models import Base

# v9.1.0 (M-03) — module-level snapshot of the settings ROWS.
# Setting.get was a SELECT per call; every page render reads 10+ settings,
# so each request re-fetched the whole table many times. The snapshot is
# loaded once and invalidated on every write (Setting.set) and per-test
# (tests/conftest.py). Only DB ROWS are snapshotted — get()'s default
# semantics are preserved exactly (missing row -> caller default).
_snapshot: dict[str, Any] | None = None
_snapshot_lock = threading.Lock()


def invalidate_settings_snapshot() -> None:
    """Drop the cached settings snapshot; the next read reloads from DB."""
    global _snapshot
    with _snapshot_lock:
        _snapshot = None


def _snapshot_rows(session) -> dict[str, Any]:
    """Return (and cache) the parsed settings rows."""
    global _snapshot
    snap = _snapshot
    if snap is not None:
        return snap
    out: dict[str, Any] = {}
    for r in session.query(Setting).all():
        try:
            out[r.key] = json.loads(r.value) if r.value else r.value
        except (json.JSONDecodeError, TypeError):
            out[r.key] = r.value
    snap = out
    with _snapshot_lock:
        _snapshot = snap
    return snap

DEFAULT_SETTINGS: dict[str, str] = {
    "active_project_id": "default",
    "story_title": "My Story",
    "story_author": "Author",
    "story_genre": "",
    "story_description": "",
    "daily_word_goal": "500",
    "total_word_goal": "80000",
    # v7.0 — onboarding wizard flag
    "onboarded": "false",
    "manuscript_font": "Courier",
    "manuscript_font_size": "12",
    "manuscript_line_spacing": "2.0",
    "manuscript_margins": "1.0",
    "autosave_interval_seconds": "3",
    "version_snapshot_interval_minutes": "15",
    # v8.4 — storage management. version_history_limit: max chapter versions
    # kept per chapter (0 = unlimited; v1 originals + pinned always kept).
    # backup_retention_count: max backup zips kept (0 = unlimited).
    "version_history_limit": "25",
    "backup_retention_count": "14",
    "auto_backup_enabled": "true",
    "auto_backup_interval_hours": "6",
    # v9.0.1 (S-03) — media files (maps, avatars, music) are part of the
    # project: include data/media/ in ZIP backups by default.
    "backup_include_media": "true",
    # v8.8 — performance auto-maintenance: PRAGMA optimize + WAL checkpoint
    # on startup at most every N days (0 = disabled).
    "auto_maintenance_days": "7",
    "theme": "dark",
    "sidebar_collapsed": "false",
    "editor_font": "serif",
    "editor_font_size": "16",
    "chapter_viewer_font": "serif",
    "chapter_viewer_font_size": "16",
    "chapter_sort_default": "sort_order",
    "character_sort_default": "name",
    "default_chapter_status": "draft",
    "world_types": '["location","lore","faction","glossary"]',
    "ai.enabled": "false",
    "ai.provider": "ollama",
    "ai.api_base": "http://localhost:11434",
    "ai.api_key": "",
    "ai.model": "",
    "ai.timeout_seconds": "180",
    "ai.disclosure_accepted": "false",
    "chapters_per_page": "30",
    "world_per_page": "40",
    "search_results_per_module": "50",
}


class Setting(Base):
    __tablename__ = "settings"

    key = Column(String, primary_key=True)
    value = Column(Text)

    @classmethod
    def get(cls, session, key: str, default: Any = None) -> Any:
        # v9.1.0 (M-03): snapshot-served (invalidated by set / tests).
        snap = _snapshot_rows(session)
        val = snap.get(key)
        if val is None:
            return default
        return val

    @classmethod
    def set(cls, session, key: str, value: Any) -> None:
        v = json.dumps(value) if not isinstance(value, str) else json.dumps(value)
        row = session.query(cls).filter_by(key=key).first()
        if row is None:
            session.add(cls(key=key, value=v))
        else:
            row.value = v
        # v9.1.0 (M-03): every write drops the snapshot and the cached
        # template globals so theme/active-book changes apply immediately.
        invalidate_settings_snapshot()
        try:
            from core.cache import cache
            cache.invalidate("globals:")
        except Exception:  # noqa: BLE001 - cache is best-effort
            pass

    @classmethod
    def all_settings(cls, session) -> dict[str, Any]:
        snap = _snapshot_rows(session)
        out = dict(DEFAULT_SETTINGS)  # ensure defaults exist
        out.update(snap)
        return out
