"""Undo/redo operations — persistent in DB (command pattern).

Each operation records enough to reverse itself. Two stacks (v9.3.0, F-10):
``stack='u'`` (undoable) and ``stack='r'`` (redoable). A new destructive
action clears the redo stack (classic two-stack semantics).

Storage & growth (v9.3.0, F-10):
  * snapshots are zlib-compressed ("z1:" prefix, transparent fallback
    "j1:" for incompressible payloads),
  * MAX_UNDO rows AND MAX_UNDO_BYTES total budget — oldest entries are
    pruned beyond either cap.

Snapshots store enough entity data to recreate the row(s) on undo.
snapshot_row() (F-10) captures ANY single-row entity generically;
the hand-rolled rich snapshots stay for chapter/character/plan/world.
"""
from __future__ import annotations

import base64
import json
import logging
import zlib
from datetime import datetime, timezone
from typing import Any, Callable

from sqlalchemy import Column, DateTime, Integer, String, Text

from models import Base

log = logging.getLogger("asm.undo")

MAX_UNDO = 100
# v9.3.0 (F-10): undo tablosu büyüme denetimi — satır sayısına EK olarak
# toplam snapshot bayt bütçesi (varsayılan 16 MB).
MAX_UNDO_BYTES = 16 * 1024 * 1024


def _pack(snapshot: dict) -> str:
    """Snapshot'ı sıkıştırıp saklanabilir metin yap (z1/j1 önekli)."""
    raw = json.dumps(snapshot, ensure_ascii=False, default=str).encode("utf-8")
    try:
        comp = zlib.compress(raw, 6)
    except zlib.error:  # pragma: no cover
        comp = b""
    if comp and len(comp) < len(raw):
        return "z1:" + base64.b64encode(comp).decode("ascii")
    return "j1:" + raw.decode("utf-8", "replace")


def _unpack(stored: str | None) -> dict:
    """Paketi aç (eski düz-JSON kayıtları da okunur — geriye uyumluluk)."""
    if not stored:
        return {}
    if stored.startswith("z1:"):
        try:
            return json.loads(
                zlib.decompress(base64.b64decode(stored[3:])).decode("utf-8"))
        except (ValueError, zlib.error):
            log.warning("z1 snapshot açılamadı — boş sözlük.")
            return {}
    if stored.startswith("j1:"):
        try:
            return json.loads(stored[3:])
        except ValueError:
            return {}
    # v9.2 ve öncesi: düz JSON
    try:
        return json.loads(stored)
    except ValueError:
        return {}


class UndoOperation(Base):
    __tablename__ = "undo_operations"
    __table_args__ = (
        # v9.3.0 (F-10): iki yığın — u=undo, r=redo
        # (server_default: asm0003 rebuild'inin kolon kopyası 'u' doldurur)
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    operation = Column(String(80))  # delete_chapter / delete_character / delete_plan / delete_world_entry / reorder
    label = Column(String(200))     # human-readable label, e.g. "Delete chapter 'Chapter 1'"
    entity_type = Column(String(50))
    entity_id = Column(String(64))
    snapshot = Column(Text)         # packed JSON of the entity + related rows
    undo_action = Column(String(80))  # restore / restore_row / delete_again / delete_row_again
    stack = Column(String(1), nullable=False, server_default="u", index=True)  # u / r
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


def snapshot_chapter(ch) -> dict:
    """Capture a chapter + its versions for undo."""
    from core.db import read_session
    from models.chapter import ChapterVersion
    from services._common import load_json
    out = {
        "chapter": {
            "id": ch.id, "project_id": ch.project_id, "title": ch.title,
            "content": ch.content, "synopsis": ch.synopsis, "status": ch.status,
            "word_count": ch.word_count, "target_word_count": ch.target_word_count,
            "sort_order": ch.sort_order, "character_ids": ch.character_ids,
            "tags": ch.tags, "raw_file_path": ch.raw_file_path,
            "created_at": ch.created_at.isoformat() if ch.created_at else None,
            "updated_at": ch.updated_at.isoformat() if ch.updated_at else None,
        },
        "versions": [],
    }
    with read_session() as s:
        rows = s.query(ChapterVersion).filter_by(chapter_id=ch.id).all()
        for v in rows:
            out["versions"].append({
                "id": v.id, "chapter_id": v.chapter_id,
                "version_number": v.version_number, "content": v.content,
                "word_count": v.word_count, "source": v.source,
                "uploaded_at": v.uploaded_at.isoformat() if v.uploaded_at else None,
                "notes": v.notes,
            })
    return out


def snapshot_character(ch) -> dict:
    """Capture a character + groups + relationships + arcs for undo."""
    from core.db import read_session
    from models.character import CharacterArc, CharacterGroupMember, CharacterRelationship
    out = {
        "character": {
            "id": ch.id, "project_id": ch.project_id, "name": ch.name,
            "age": ch.age, "gender": ch.gender, "aliases": ch.aliases,
            "role": ch.role, "avatar_color": ch.avatar_color,
            "avatar_path": ch.avatar_path, "physical": ch.physical,
            "psychology": ch.psychology, "background": ch.background,
            "philosophy": ch.philosophy, "philosophy_quotes": ch.philosophy_quotes,
            "story_role": ch.story_role, "story_role_chapters": ch.story_role_chapters,
            "voice": ch.voice, "notes": ch.notes,
            "graph_x": ch.graph_x, "graph_y": ch.graph_y,
            "created_at": ch.created_at.isoformat() if ch.created_at else None,
            "updated_at": ch.updated_at.isoformat() if ch.updated_at else None,
        },
        "group_memberships": [],
        "relationships": [],
        "arcs": [],
    }
    with read_session() as s:
        for gm in s.query(CharacterGroupMember).filter_by(character_id=ch.id).all():
            out["group_memberships"].append({"id": gm.id, "group_id": gm.group_id})
        for r in s.query(CharacterRelationship).filter(
            (CharacterRelationship.from_character_id == ch.id)
            | (CharacterRelationship.to_character_id == ch.id)
        ).all():
            out["relationships"].append({
                "id": r.id, "from_character_id": r.from_character_id,
                "to_character_id": r.to_character_id,
                "relationship_type": r.relationship_type,
                "description": r.description, "is_bidirectional": r.is_bidirectional,
                "created_at": r.created_at.isoformat() if r.created_at else None,
            })
        for arc in s.query(CharacterArc).filter_by(character_id=ch.id).all():
            out["arcs"].append({
                "id": arc.id, "character_id": arc.character_id,
                "arc_name": arc.arc_name, "description": arc.description,
                "stages": arc.stages,
                "created_at": arc.created_at.isoformat() if arc.created_at else None,
            })
    return out


def snapshot_plan(p) -> dict:
    from core.db import read_session
    from models.plan import PlanSubtask
    out = {
        "plan": {
            "id": p.id, "project_id": p.project_id, "title": p.title,
            "description": p.description, "status": p.status, "column": p.column,
            "sort_order": p.sort_order, "chapter_id": p.chapter_id,
            "parent_id": p.parent_id, "depends_on_id": p.depends_on_id,
            "story_date": p.story_date, "event_type": p.event_type,
            "track": p.track, "characters_involved": p.characters_involved,
            "deadline": p.deadline.isoformat() if p.deadline else None,
            "effort_estimate": p.effort_estimate, "tags": p.tags,
            "created_at": p.created_at.isoformat() if p.created_at else None,
            "updated_at": p.updated_at.isoformat() if p.updated_at else None,
        },
        "subtasks": [],
    }
    with read_session() as s:
        for st in s.query(PlanSubtask).filter_by(plan_id=p.id).all():
            out["subtasks"].append({
                "id": st.id, "plan_id": st.plan_id, "title": st.title,
                "is_completed": st.is_completed, "sort_order": st.sort_order,
                "created_at": st.created_at.isoformat() if st.created_at else None,
            })
    return out


def snapshot_world_entry(e) -> dict:
    from core.db import read_session
    from models.world import WorldEntryRelation, WorldEntryVersion
    out = {
        "entry": {
            "id": e.id, "project_id": e.project_id, "type": e.type,
            "name": e.name, "category": e.category, "description": e.description,
            "content": e.content, "notes": e.notes, "metadata": e.metadata_,
            "parent_id": e.parent_id, "map_pin_x": e.map_pin_x,
            "map_pin_y": e.map_pin_y, "map_pin_label": e.map_pin_label,
            "map_image_path": e.map_image_path, "sort_order": e.sort_order,
            "created_at": e.created_at.isoformat() if e.created_at else None,
            "updated_at": e.updated_at.isoformat() if e.updated_at else None,
        },
        "versions": [],
        "relations": [],
    }
    with read_session() as s:
        for v in s.query(WorldEntryVersion).filter_by(entry_id=e.id).all():
            out["versions"].append({
                "id": v.id, "entry_id": v.entry_id,
                "version_number": v.version_number, "snapshot": v.snapshot,
                "source": v.source,
                "created_at": v.created_at.isoformat() if v.created_at else None,
                "notes": v.notes,
            })
        for r in s.query(WorldEntryRelation).filter(
            (WorldEntryRelation.from_entry_id == e.id)
            | (WorldEntryRelation.to_entry_id == e.id)
        ).all():
            out["relations"].append({
                "id": r.id, "from_entry_id": r.from_entry_id,
                "to_entry_id": r.to_entry_id,
                "relation_type": r.relation_type, "description": r.description,
            })
    return out


def _model_for_table(table: str):
    """Tablo adından ORM sınıfını bul (Base mapper kaydı üzerinden)."""
    for mapper in Base.registry.mappers:
        if mapper.class_.__tablename__ == table:
            return mapper.class_
    return None


def snapshot_row(obj) -> dict:
    """F-10: TEK satırlık herhangi bir varlığı generik yakala.

    Dönüş: {"table": <tablename>, "row": {kolon: değer}} — datetime'lar
    ISO metin, geri yüklemede ayrıştırılır.
    """
    row = {}
    for c in obj.__class__.__table__.columns:
        v = getattr(obj, c.name)
        if isinstance(v, (datetime,)):
            v = v.isoformat() if v else None
        row[c.name] = v
    return {"table": obj.__class__.__tablename__, "row": row}


def record_delete_row(obj, label: str | None = None) -> None:
    """F-10: tek satırlık bir varlığı generik undo ile silinir olarak kaydet.

    Silme öncesi (satır DB'den çekilmişken) çağrılır.
    """
    table = obj.__class__.__tablename__
    eid = str(getattr(obj, "id", ""))
    record_delete(
        entity_type=table, entity_id=eid,
        label=label or f"Delete {table} '{eid}'",
        snapshot=snapshot_row(obj), undo_action="restore_row")


def record_delete(entity_type: str, entity_id: str, label: str,
                  snapshot: dict, undo_action: str = "restore") -> None:
    """Record a delete operation for undo (called BEFORE the actual delete).

    v9.3.0 (F-10): yeni bir yıkıcı eylem, redo yığınını geçersiz kılar
    (iki yığın semantiği) ve büyüme denetimi satır + bayt bütçesiyle
    çalışır.
    """
    from core.db import write_transaction
    with write_transaction() as s:
        # Klasik iki yığın kuralı: yeni eylem → redo geçmişi çöpe
        s.query(UndoOperation).filter_by(stack="r").delete(
            synchronize_session=False)
        s.add(UndoOperation(
            operation=f"delete_{entity_type}",
            label=label,
            entity_type=entity_type,
            entity_id=entity_id,
            snapshot=_pack(snapshot),
            undo_action=undo_action,
            stack="u",
            created_at=datetime.now(timezone.utc),
        ))
        _prune_oversized(s)


def _prune_oversized(s) -> int:
    """F-10: büyüme denetimi — MAX_UNDO satır VE MAX_UNDO_BYTES bütçesi.

    En eski girişleri (her iki yığında) aşım bitene kadar siler.
    """
    deleted = 0
    rows = s.query(UndoOperation).order_by(UndoOperation.id.asc()).all()
    total_bytes = sum(len(op.snapshot or "") for op in rows)
    i = 0
    while (len(rows) - i > MAX_UNDO
           or (len(rows) - i > 1 and total_bytes > MAX_UNDO_BYTES)):
        # son kalan girişi asla yeme — kullanıcı en az bir undo ister
        op = rows[i]
        total_bytes -= len(op.snapshot or "")
        s.delete(op)
        i += 1
        deleted += 1
    return deleted


def list_recent(limit: int = 20) -> list[UndoOperation]:
    from core.db import read_session
    with read_session() as s:
        return list(s.query(UndoOperation).filter_by(stack="u").order_by(
            UndoOperation.id.desc()
        ).limit(limit).all())


def has_redo() -> bool:
    from core.db import read_session
    with read_session() as s:
        return s.query(UndoOperation.id).filter_by(stack="r").first() \
            is not None


def undo_last() -> dict[str, Any] | None:
    """Undo the most recent operation. Returns {ok, label} or None.

    v9.3.0 (F-10): u-yığınındaki en yeni girişi uygular, tersini r-yığınına
    iter — redo_last() onu geri alabilir.
    """
    from core.db import write_transaction
    with write_transaction() as s:
        last = (s.query(UndoOperation).filter_by(stack="u")
                .order_by(UndoOperation.id.desc()).first())
        if not last:
            return None
        snapshot = _unpack(last.snapshot)
        op_id, label = last.id, last.label
        entity_type, entity_id = last.entity_type, last.entity_id
        undo_action = last.undo_action

        if undo_action not in ("restore", "restore_row"):
            log.warning("undo_last: bilinmeyen eylem %s — yoksayıldı.",
                        undo_action)
            return None

        from sqlalchemy.exc import IntegrityError  # noqa: PLC0415 - lokal

        try:
            _restore_entity(s, entity_type, snapshot, undo_action)
            s.flush()
        except (_ConflictError, IntegrityError) as exc:
            s.rollback()
            return {"ok": False, "label": label, "action": "conflict",
                    "error": f"{type(exc).__name__}: {exc}"}
        # ters eylemi redo yığına taşı
        s.delete(last)
        s.add(UndoOperation(
            operation=last.operation, label=label,
            entity_type=entity_type, entity_id=entity_id,
            snapshot=last.snapshot,
            undo_action=("delete_again" if undo_action == "restore"
                         else "delete_row_again"),
            stack="r", created_at=datetime.now(timezone.utc),
        ))
        return {"ok": True, "label": label, "action": "restored",
                "can_redo": True}


class _ConflictError(Exception):
    """Undo geri yüklemesi bir kısıtı ihlal etti (ör. unique tarih)."""


def redo_last() -> dict[str, Any] | None:
    """Redo the most recent undo. Returns {ok, label} or None."""
    from core.db import write_transaction
    with write_transaction() as s:
        entry = (s.query(UndoOperation).filter_by(stack="r")
                 .order_by(UndoOperation.id.desc()).first())
        if not entry:
            return None
        snapshot = _unpack(entry.snapshot)
        label = entry.label
        try:
            _delete_again(s, entry.entity_type, snapshot)
        except _ConflictError as exc:
            return {"ok": False, "label": label,
                    "action": "conflict", "error": str(exc)}
        # geri alma girişini u yığınına geri it (undo yeniden çalışabilir)
        s.delete(entry)
        s.add(UndoOperation(
            operation=entry.operation, label=label,
            entity_type=entry.entity_type, entity_id=entry.entity_id,
            snapshot=entry.snapshot,
            undo_action=("restore" if entry.undo_action == "delete_again"
                         else "restore_row"),
            stack="u", created_at=datetime.now(timezone.utc),
        ))
        return {"ok": True, "label": label, "action": "redone",
                "can_undo": True}


def _delete_again(s, entity_type: str, snapshot: dict) -> None:
    """Redo: undo'nun geri yüklediği satırları (snapshot'tan) yeniden sil."""
    from models.chapter import Chapter, ChapterVersion
    from models.character import (
        Character,
        CharacterArc,
        CharacterGroupMember,
        CharacterRelationship,
    )
    from models.plan import Plan, PlanSubtask
    from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion

    if entity_type == "chapter":
        for v in snapshot.get("versions", []):
            obj = s.get(ChapterVersion, v["id"])
            if obj:
                s.delete(obj)
        obj = s.get(Chapter, snapshot["chapter"]["id"])
        if obj:
            s.delete(obj)
    elif entity_type == "character":
        for gm in snapshot.get("group_memberships", []):
            obj = s.get(CharacterGroupMember, gm["id"])
            if obj:
                s.delete(obj)
        for r in snapshot.get("relationships", []):
            obj = s.get(CharacterRelationship, r["id"])
            if obj:
                s.delete(obj)
        for arc in snapshot.get("arcs", []):
            obj = s.get(CharacterArc, arc["id"])
            if obj:
                s.delete(obj)
        obj = s.get(Character, snapshot["character"]["id"])
        if obj:
            s.delete(obj)
    elif entity_type == "plan":
        for st in snapshot.get("subtasks", []):
            obj = s.get(PlanSubtask, st["id"])
            if obj:
                s.delete(obj)
        obj = s.get(Plan, snapshot["plan"]["id"])
        if obj:
            s.delete(obj)
    elif entity_type == "world_entry":
        for v in snapshot.get("versions", []):
            obj = s.get(WorldEntryVersion, v["id"])
            if obj:
                s.delete(obj)
        for r in snapshot.get("relations", []):
            obj = s.get(WorldEntryRelation, r["id"])
            if obj:
                s.delete(obj)
        obj = s.get(WorldEntry, snapshot["entry"]["id"])
        if obj:
            s.delete(obj)
    else:  # restore_row snapshot'ları
        table = snapshot.get("table") or entity_type
        model = _model_for_table(table)
        if model is None:
            raise _ConflictError(f"Unknown table for redo: {table}")
        obj = s.get(model, snapshot["row"]["id"])
        if obj:
            s.delete(obj)


def _restore_entity(session, entity_type: str, snapshot: dict,
                    undo_action: str = "restore") -> None:
    """Restore an entity + its related rows from a snapshot.

    v9.3.0 (F-10): undo_action="restore_row" → generik tek-satır geri yükleme
    (snapshot_row ile yakalanan her tablo). Kısıt ihlali _ConflictError
    olarak yükselir (undo_last temiz bir hata dönsün diye).
    """
    from datetime import date as date_type
    from datetime import datetime

    from models.chapter import Chapter, ChapterVersion
    from models.character import (
        Character,
        CharacterArc,
        CharacterGroupMember,
        CharacterRelationship,
    )
    from models.plan import Plan, PlanSubtask
    from models.world import WorldEntry, WorldEntryRelation, WorldEntryVersion

    def _parse_dt(v):
        if not v:
            return None
        try:
            return datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None

    def _parse_date(v):
        if v is None:
            return None
        try:
            return date_type.fromisoformat(str(v)[:10])
        except (ValueError, TypeError):
            return None

    # ---- F-10: generik tek-satır geri yükleme ---------------------------
    if undo_action == "restore_row":
        from sqlalchemy import Date, DateTime
        from sqlalchemy.exc import IntegrityError

        table = snapshot.get("table") or entity_type
        model = _model_for_table(table)
        if model is None:
            raise _ConflictError(f"Unknown table for undo: {table}")
        row = snapshot.get("row") or {}
        if not row.get("id") or session.get(model, row["id"]) is None:
            kwargs = {}
            for col in model.__table__.columns:
                if col.name not in row:
                    continue
                v = row[col.name]
                if v is not None:
                    if isinstance(col.type, DateTime):
                        v = _parse_dt(v)
                    elif isinstance(col.type, Date):
                        v = _parse_date(v)
                kwargs[col.name] = v
            try:
                session.add(model(**kwargs))
                session.flush()
            except IntegrityError as exc:
                raise _ConflictError(
                    f"Cannot restore {table} — a conflicting row exists "
                    f"(unique key?): {exc.orig}") from exc
        return

    if entity_type == "chapter":
        c = snapshot["chapter"]
        existing = session.get(Chapter, c["id"])
        if not existing:
            ch = Chapter(
                id=c["id"], project_id=c["project_id"], title=c["title"],
                content=c["content"], synopsis=c["synopsis"], status=c["status"],
                word_count=c["word_count"], target_word_count=c["target_word_count"],
                sort_order=c["sort_order"], character_ids=c["character_ids"],
                tags=c["tags"], raw_file_path=c["raw_file_path"],
                created_at=_parse_dt(c["created_at"]) or datetime.now(timezone.utc),
                updated_at=_parse_dt(c["updated_at"]) or datetime.now(timezone.utc),
            )
            session.add(ch)
        # Restore versions
        for v in snapshot["versions"]:
            if not session.get(ChapterVersion, v["id"]):
                session.add(ChapterVersion(
                    id=v["id"], chapter_id=v["chapter_id"],
                    version_number=v["version_number"], content=v["content"],
                    word_count=v["word_count"], source=v["source"],
                    uploaded_at=_parse_dt(v["uploaded_at"]) or datetime.now(timezone.utc),
                    notes=v["notes"],
                ))
    elif entity_type == "character":
        c = snapshot["character"]
        existing = session.get(Character, c["id"])
        if not existing:
            ch = Character(
                id=c["id"], project_id=c["project_id"], name=c["name"],
                age=c["age"], gender=c["gender"], aliases=c["aliases"],
                role=c["role"], avatar_color=c["avatar_color"],
                avatar_path=c["avatar_path"], physical=c["physical"],
                psychology=c["psychology"], background=c["background"],
                philosophy=c["philosophy"], philosophy_quotes=c["philosophy_quotes"],
                story_role=c["story_role"], story_role_chapters=c["story_role_chapters"],
                voice=c["voice"], notes=c["notes"],
                graph_x=c["graph_x"], graph_y=c["graph_y"],
                created_at=_parse_dt(c["created_at"]) or datetime.now(timezone.utc),
                updated_at=_parse_dt(c["updated_at"]) or datetime.now(timezone.utc),
            )
            session.add(ch)
        for gm in snapshot["group_memberships"]:
            if not session.get(CharacterGroupMember, gm["id"]):
                session.add(CharacterGroupMember(
                    id=gm["id"], character_id=c["id"], group_id=gm["group_id"],
                ))
        for r in snapshot["relationships"]:
            if not session.get(CharacterRelationship, r["id"]):
                session.add(CharacterRelationship(
                    id=r["id"], from_character_id=r["from_character_id"],
                    to_character_id=r["to_character_id"],
                    relationship_type=r["relationship_type"],
                    description=r["description"],
                    is_bidirectional=r["is_bidirectional"],
                    created_at=_parse_dt(r["created_at"]) or datetime.now(timezone.utc),
                ))
        for arc in snapshot["arcs"]:
            if not session.get(CharacterArc, arc["id"]):
                session.add(CharacterArc(
                    id=arc["id"], character_id=arc["character_id"],
                    arc_name=arc["arc_name"], description=arc["description"],
                    stages=arc["stages"],
                    created_at=_parse_dt(arc["created_at"]) or datetime.now(timezone.utc),
                ))
    elif entity_type == "plan":
        p = snapshot["plan"]
        existing = session.get(Plan, p["id"])
        if not existing:
            from datetime import date as date_type
            deadline = None
            if p["deadline"]:
                try:
                    deadline = date_type.fromisoformat(p["deadline"])
                except (ValueError, TypeError):
                    pass
            session.add(Plan(
                id=p["id"], project_id=p["project_id"], title=p["title"],
                description=p["description"], status=p["status"], column=p["column"],
                sort_order=p["sort_order"], chapter_id=p["chapter_id"],
                parent_id=p["parent_id"], depends_on_id=p["depends_on_id"],
                story_date=p["story_date"], event_type=p["event_type"],
                track=p["track"], characters_involved=p["characters_involved"],
                deadline=deadline, effort_estimate=p["effort_estimate"],
                tags=p["tags"],
                created_at=_parse_dt(p["created_at"]) or datetime.now(timezone.utc),
                updated_at=_parse_dt(p["updated_at"]) or datetime.now(timezone.utc),
            ))
        for st in snapshot["subtasks"]:
            if not session.get(PlanSubtask, st["id"]):
                session.add(PlanSubtask(
                    id=st["id"], plan_id=st["plan_id"], title=st["title"],
                    is_completed=st["is_completed"], sort_order=st["sort_order"],
                    created_at=_parse_dt(st["created_at"]) or datetime.now(timezone.utc),
                ))
    elif entity_type == "world_entry":
        e = snapshot["entry"]
        existing = session.get(WorldEntry, e["id"])
        if not existing:
            session.add(WorldEntry(
                id=e["id"], project_id=e["project_id"], type=e["type"],
                name=e["name"], category=e["category"], description=e["description"],
                content=e["content"], notes=e["notes"], metadata_=e["metadata"],
                parent_id=e["parent_id"], map_pin_x=e["map_pin_x"],
                map_pin_y=e["map_pin_y"], map_pin_label=e["map_pin_label"],
                map_image_path=e["map_image_path"], sort_order=e["sort_order"],
                created_at=_parse_dt(e["created_at"]) or datetime.now(timezone.utc),
                updated_at=_parse_dt(e["updated_at"]) or datetime.now(timezone.utc),
            ))
        for v in snapshot["versions"]:
            if not session.get(WorldEntryVersion, v["id"]):
                session.add(WorldEntryVersion(
                    id=v["id"], entry_id=v["entry_id"],
                    version_number=v["version_number"], snapshot=v["snapshot"],
                    source=v["source"],
                    created_at=_parse_dt(v["created_at"]) or datetime.now(timezone.utc),
                    notes=v["notes"],
                ))
        for r in snapshot["relations"]:
            if not session.get(WorldEntryRelation, r["id"]):
                session.add(WorldEntryRelation(
                    id=r["id"], from_entry_id=r["from_entry_id"],
                    to_entry_id=r["to_entry_id"],
                    relation_type=r["relation_type"], description=r["description"],
                ))


# Need this import for the datetime usage in _restore_entity
