"""v8.1 — Persistent chat models.

ChatSession: a conversation (with one character, several characters, or the
plain writing assistant). ChatMessage: one turn inside a session.

Why tables: before v8.1 the character chat kept history in a JS variable that
was never even sent to the backend — the character forgot the previous
question, and a page refresh destroyed the whole conversation.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)

from models import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


class ChatSession(Base):
    """A persistent conversation.

    mode:
      - "character"  — the user interviews ONE character
      - "group"      — several characters in one room (director mode); the
                       user can either pick who answers or let the AI choose
      - "assistant"  — the general writing assistant (global AI Chat drawer)
    """
    __tablename__ = "chat_sessions"
    __table_args__ = (
        CheckConstraint("pinned IN (0, 1)", name="ck_chat_sessions_pinned_bool"),
        CheckConstraint("message_count >= 0", name="ck_chat_sessions_msgcount"),
        CheckConstraint("mode IN ('character', 'group', 'assistant')",
                        name="ck_chat_sessions_mode"),
    )

    id = Column(String, primary_key=True)
    project_id = Column(String, ForeignKey("projects.id", ondelete="CASCADE"),
                        nullable=False, default="default", index=True)
    mode = Column(String(20), default="character", index=True)  # character/group/assistant
    title = Column(String(300), default="")
    # Comma-separated character ids participating in the conversation.
    character_ids = Column(Text, default="")
    chapter_id = Column(String(64), ForeignKey("chapters.id", ondelete="SET NULL"))  # story-time anchor (may be NULL)
    # JSON: per-session overrides {"length": "normal", "temperature": 0.8,
    #                              "ctx_world": true, ...}
    settings = Column(Text, default="{}")
    pinned = Column(Boolean, default=False)
    message_count = Column(Integer, default=0)
    last_message_at = Column(DateTime, default=_now, index=True)
    created_at = Column(DateTime, default=_now)

    @property
    def participants(self) -> list[str]:
        return [p for p in (self.character_ids or "").split(",") if p]


class ChatMessage(Base):
    """One turn inside a ChatSession.

    role: "user" | "assistant" | "system"
    For group sessions, speaker_id/speaker_name record WHICH character spoke.
    context_stats: JSON blob of what the context engine fed this reply.
    """
    __tablename__ = "chat_messages"
    __table_args__ = (
        Index("ix_chat_messages_session_created", "session_id", "created_at"),
        CheckConstraint("role IN ('user', 'assistant', 'system')",
                        name="ck_chat_messages_role"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String, ForeignKey("chat_sessions.id", ondelete="CASCADE"),
                        nullable=False, index=True)
    role = Column(String(20), nullable=False)
    speaker_id = Column(String(64))   # character id when group mode
    speaker_name = Column(String(200))
    content = Column(Text, nullable=False, default="")
    context_stats = Column(Text)      # JSON: {"characters": 3, "world": 5, ...}
    # How the reply was produced (kept for the UI): temperature, tokens, mode
    meta = Column(Text)
    created_at = Column(DateTime, default=_now)
