/* ==========================================================================
   ASM v8.0 — Emotion Arc page (Duygu Yayı)
   Static JS (v7.5 architecture): all data flows in through JSON script tags
   and data-* attributes; Jinja never touches this file. Chapter switching
   goes through /emotions/api/* endpoints.
   ========================================================================== */
"use strict";

(function () {
  const dataEl = document.getElementById("emotionData");
  if (!dataEl) return; // not on this page

  function readJSON(id, fallback) {
    const node = document.getElementById(id);
    if (!node || !node.textContent.trim()) return fallback;
    try { return JSON.parse(node.textContent); }
    catch (e) { console.error("emotion: bad JSON in #" + id, e); return fallback; }
  }

  // Three separate payload tags (analysis / book / chapters) — the analysis
  // object itself lives in #emotionData, NOT wrapped under a key.
  const state = {
    analysis: readJSON("emotionData", null),
    book: readJSON("emotionBook", { ok: false, chapters: [] }),
    chapters: readJSON("emotionChapters", []),
  };

  // ---------------------------------------------------------------- helpers
  const NS = "http://www.w3.org/2000/svg";
  function el(tag, attrs) {
    const node = document.createElementNS(NS, tag);
    for (const k in attrs || {}) node.setAttribute(k, attrs[k]);
    return node;
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }
  const SHAPE_LABELS = {
    rising: "Rising ↗", falling: "Falling ↘", dip: "V-shape (dip & recover)",
    peak: "Peak (rise & fall)", wave: "Wave (many turns)",
    stable: "Stable", mixed: "Mixed", short: "Short", empty: "No content",
  };

  // ------------------------------------------------------------ main curve
  function drawCurve(analysis) {
    const holder = document.getElementById("emotionCurve");
    if (!holder) return;
    holder.innerHTML = "";
    const W = 860, H = 260, PAD_L = 36, PAD_R = 12, PAD_T = 14, PAD_B = 30;
    const curve = analysis.curve || [];
    const tension = analysis.tension_curve || [];

    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, class: "emotion-svg" });
    if (!curve.length) {
      const t = el("text", { x: W / 2, y: H / 2, "text-anchor": "middle",
        fill: "var(--text-mute, #888)", "font-size": "14" });
      t.textContent = "No paragraphs to analyze yet — write something first.";
      svg.appendChild(t);
      holder.appendChild(svg);
      return;
    }

    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const n = curve.length;
    const stepX = iw / Math.max(1, n - 1);
    const x = i => PAD_L + (n === 1 ? iw / 2 : i * stepX);
    const yV = v => PAD_T + ih / 2 - (v / 100) * (ih / 2 - 4); // valence -100..100
    const yT = t => PAD_T + ih - (t / 100) * (ih - 8);         // tension 0..100

    // grid + zero line
    for (const gv of [-100, -50, 0, 50, 100]) {
      svg.appendChild(el("line", { x1: PAD_L, x2: W - PAD_R, y1: yV(gv), y2: yV(gv),
        stroke: gv === 0 ? "var(--border, #333)" : "rgba(128,128,128,0.15)",
        "stroke-width": gv === 0 ? 1.2 : 1 }));
      const lbl = el("text", { x: 6, y: yV(gv) + 4, fill: "var(--text-mute, #888)", "font-size": "10" });
      lbl.textContent = String(gv);
      svg.appendChild(lbl);
    }

    // valence area (split by sign for green/red fill)
    let segStart = 0;
    function area(from, to) {
      if (to <= from) return;
      let d = `M ${x(from)} ${yV(0)}`;
      for (let i = from; i <= to; i++) d += ` L ${x(i)} ${yV(curve[i])}`;
      d += ` L ${x(to)} ${yV(0)} Z`;
      const positive = curve[from] >= 0;
      svg.appendChild(el("path", { d, fill: positive ? "rgba(52,199,89,0.22)" : "rgba(245,69,69,0.22)" }));
    }
    for (let i = 1; i < n; i++) {
      if ((curve[i] >= 0) !== (curve[i - 1] >= 0)) { area(segStart, i - 1); segStart = i; }
    }
    area(segStart, n - 1);

    // valence line
    let dv = `M ${x(0)} ${yV(curve[0])}`;
    for (let i = 1; i < n; i++) dv += ` L ${x(i)} ${yV(curve[i])}`;
    svg.appendChild(el("path", { d: dv, fill: "none", stroke: "#6366f1",
      "stroke-width": 2.4, "stroke-linejoin": "round", "stroke-linecap": "round" }));

    // tension line (dashed amber)
    let dt = `M ${x(0)} ${yT(tension[0] || 0)}`;
    for (let i = 1; i < n; i++) dt += ` L ${x(i)} ${yT(tension[i] || 0)}`;
    svg.appendChild(el("path", { d: dt, fill: "none", stroke: "#f59e0b",
      "stroke-width": 1.6, "stroke-dasharray": "5 4", opacity: 0.85 }));

    // markers on peak windows
    (analysis.peaks || []).slice(0, 3).forEach(p => {
      if (p.index == null || p.index >= n) return;
      svg.appendChild(el("circle", { cx: x(p.index), cy: yV(curve[p.index]), r: 5,
        fill: curve[p.index] >= 0 ? "#34c759" : "#f54545", stroke: "#0b1020", "stroke-width": 1.5 }));
    });

    // x labels
    for (let i = 0; i < n; i += Math.ceil(n / 12)) {
      const lbl = el("text", { x: x(i), y: H - 8, "text-anchor": "middle",
        fill: "var(--text-mute, #888)", "font-size": "10" });
      lbl.textContent = "¶" + (i + 1);
      svg.appendChild(lbl);
    }

    holder.appendChild(svg);
  }

  // ----------------------------------------------------------- book curve
  function drawBook(book) {
    const holder = document.getElementById("bookCurve");
    if (!holder) return;
    holder.innerHTML = "";
    const chapters = (book && book.chapters) || [];
    const W = 860, H = 150, PAD_L = 36, PAD_R = 12, PAD_T = 12, PAD_B = 26;
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, class: "emotion-svg" });
    if (chapters.length < 2) {
      const t = el("text", { x: W / 2, y: H / 2, "text-anchor": "middle",
        fill: "var(--text-mute, #888)", "font-size": "13" });
      t.textContent = "Book curve appears once at least two chapters have content.";
      svg.appendChild(t); holder.appendChild(svg); return;
    }
    const iw = W - PAD_L - PAD_R, ih = H - PAD_T - PAD_B;
    const n = chapters.length;
    const x = i => PAD_L + (iw / Math.max(1, n - 1)) * i;
    const yV = v => PAD_T + ih / 2 - (v / 100) * (ih / 2 - 3);

    svg.appendChild(el("line", { x1: PAD_L, x2: W - PAD_R, y1: yV(0), y2: yV(0),
      stroke: "var(--border, #333)", "stroke-width": 1 }));

    // bars: tension as translucent columns, valence as line
    chapters.forEach((c, i) => {
      const bh = (c.avg_tension / 100) * ih;
      svg.appendChild(el("rect", { x: x(i) - 7, y: PAD_T + ih - bh, width: 14, height: Math.max(0, bh),
        rx: 2, fill: "rgba(245,158,11,0.30)" }));
    });
    let d = `M ${x(0)} ${yV(chapters[0].avg_valence)}`;
    for (let i = 1; i < n; i++) d += ` L ${x(i)} ${yV(chapters[i].avg_valence)}`;
    svg.appendChild(el("path", { d, fill: "none", stroke: "#6366f1", "stroke-width": 2.2 }));
    chapters.forEach((c, i) => {
      svg.appendChild(el("circle", { cx: x(i), cy: yV(c.avg_valence), r: 3.5,
        fill: c.avg_valence >= 0 ? "#34c759" : "#f54545" }));
      const lbl = el("text", { x: x(i), y: H - 8, "text-anchor": "middle",
        fill: "var(--text-mute, #888)", "font-size": "9" });
      lbl.textContent = String(i + 1);
      svg.appendChild(lbl);
    });
    holder.appendChild(svg);
  }

  // ------------------------------------------------------------- panels
  function renderStats(a) {
    const valEl = document.getElementById("statAvgValence");
    if (valEl) {
      const v = a.avg_valence || 0;
      valEl.textContent = (v > 0 ? "+" : "") + v;
      valEl.style.color = v > 12 ? "var(--success, #34c759)"
        : v < -12 ? "var(--warning, #f54545)" : "var(--text, inherit)";
    }
    const tEl = document.getElementById("statAvgTension");
    if (tEl) tEl.textContent = (a.avg_tension || 0) + "/100";
    const sEl = document.getElementById("statShape");
    if (sEl) sEl.textContent = SHAPE_LABELS[a.shape] || a.shape || "—";
    const rEl = document.getElementById("statRange");
    if (rEl) rEl.textContent = (a.range || 0) + " pts";
    const langEl = document.getElementById("statLanguage");
    if (langEl) langEl.textContent = (a.language || "en").toUpperCase();
  }

  function renderPeaks(a) {
    const tbody = document.getElementById("peaksBody");
    if (!tbody) return;
    tbody.innerHTML = "";
    (a.peaks || []).forEach(p => {
      const tr = document.createElement("tr");
      const shift = p.shift > 0 ? "+" + p.shift : String(p.shift);
      tr.innerHTML = `<td>¶${p.paragraph}</td>` +
        `<td style="color:${p.valence >= 0 ? "var(--success)" : "var(--warning)"}">${p.valence > 0 ? "+" : ""}${p.valence}</td>` +
        `<td>${p.tension}</td><td>${shift}</td>` +
        `<td><span class="emotion-chip emotion-${esc(p.dominant)}">${esc(p.dominant)}</span></td>` +
        `<td class="text-mute" style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.excerpt)}">${esc(p.excerpt)}</td>`;
      tbody.appendChild(tr);
    });
    const empty = document.getElementById("peaksEmpty");
    if (empty) empty.style.display = (a.peaks || []).length ? "none" : "";
  }

  function renderSuggestions(a) {
    const box = document.getElementById("emotionSuggestions");
    if (!box) return;
    box.innerHTML = "";
    (a.suggestions || []).forEach(t => {
      const li = document.createElement("li");
      li.textContent = t;
      box.appendChild(li);
    });
  }

  function renderAll() {
    if (state.analysis) {
      drawCurve(state.analysis);
      renderStats(state.analysis);
      renderPeaks(state.analysis);
      renderSuggestions(state.analysis);
      const titleEl = document.getElementById("emotionChapterTitle");
      if (titleEl && state.analysis.chapter_title) titleEl.textContent = state.analysis.chapter_title;
    }
    drawBook(state.book);
  }

  // --------------------------------------------------------- selector
  const selector = document.getElementById("emotionChapterSelect");
  if (selector) {
    selector.addEventListener("change", async () => {
      const id = selector.value;
      if (!id) return;
      try {
        const r = await fetch("/emotions/api/chapter/" + encodeURIComponent(id));
        const data = await r.json();
        if (!data.ok) throw new Error(data.error || "bad response");
        state.analysis = data.analysis;
        renderAll();
        // keep URL shareable without a reload
        if (window.history && window.history.replaceState) {
          window.history.replaceState({}, "", "/emotions/?chapter=" + encodeURIComponent(id));
        }
      } catch (e) {
        if (window.showToast) showToast("Could not load that chapter's arc.", "error");
      }
    });
  }

  renderAll();
})();
