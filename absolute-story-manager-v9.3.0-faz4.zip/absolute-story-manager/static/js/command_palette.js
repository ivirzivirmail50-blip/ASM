/* ASM v6.0 — Command Palette (Ctrl+K / Cmd+K)
 * Quick access to every page + quick actions.
 * Reads the sidebar DOM so it auto-stays in sync with navigation.
 * v9.2.0 (F-02): labels resolve through window.ASM_T — the palette
 * speaks the interface language and SEARCH works on translated labels.
 * No external dependencies — vanilla JS.
 */
(function () {
  "use strict";

  let paletteEl = null;
  let inputEl = null;
  let listEl = null;
  let items = [];        // [{label, section, url, action}]
  let filtered = [];
  let activeIdx = 0;

  // v9.2.0 (F-02): translate through the server-rendered flat dict.
  const T = (key, fallback) =>
    (window.ASM_T && window.ASM_T[key]) || fallback;

  // ---- Quick actions (URLs are resolved lazily via window.ASM.urls) ----
  const QUICK_ACTIONS = [
    { i18n: "palette.new_chapter", fallback: "New Chapter", iconId: "file-text", url: "/chapters/new" },
    { i18n: "palette.new_character", fallback: "New Character", iconId: "users", url: "/characters/new" },
    { i18n: "palette.new_note", fallback: "New Note", iconId: "inbox", url: "/notes/" },
    { i18n: "palette.focus_mode", fallback: "Focus Mode", iconId: "target", url: "/focus/" },
    { i18n: "palette.emotion_arc", fallback: "Emotion Arc", iconId: "heart", url: "/emotions/" },
    { i18n: "palette.chronology", fallback: "Story Chronology", iconId: "calendar", url: "/chronology/" },
    { i18n: "palette.storage", fallback: "Storage & Health", iconId: "database", url: "/storage/" },
    { i18n: "palette.toggle_theme", fallback: "Toggle Theme", iconId: "palette", action: "toggleTheme" },
    { i18n: "palette.global_search", fallback: "Global Search", iconId: "search", url: "/search/" },
  ];

  function _svgFor(iconId) {
    return '<svg class="ic"><use href="#i-' + iconId + '"></use></svg>';
  }

  function buildItems() {
    items = [];
    const navSection = T("palette.section_navigate", "Navigate");
    const actionSection = T("palette.section_actions", "Actions");
    // 1. Sidebar links — auto-synced with navigation (already translated
    // server-side via t(), so palette search works on translated labels)
    document.querySelectorAll(".sidebar-nav a").forEach(a => {
      const labelSpan = a.querySelector("span:last-child");
      const label = (labelSpan ? labelSpan.textContent : a.textContent).trim();
      if (!label || !a.getAttribute("href") || a.getAttribute("href") === "#") return;
      let section = navSection;
      // v6.1: links live inside .nav-group; climb up to find the section label
      let sib = a.closest(".nav-group");
      while (sib) {
        const prev = sib.previousElementSibling;
        if (prev && prev.classList && prev.classList.contains("sidebar-section-label")) {
          section = (prev.querySelector("span") || prev).textContent.trim() || section;
          break;
        }
        sib = prev;
      }
      // v6.1: reuse the sidebar's SVG icon when present
      const svg = a.querySelector("svg.ic");
      items.push({
        label, section, iconEl: svg ? svg.outerHTML : null,
        url: a.getAttribute("href"),
      });
    });
    // 2. Quick actions (SVG icons from the sprite) — labels via ASM_T
    QUICK_ACTIONS.forEach(qa => items.push({
      label: T(qa.i18n, qa.fallback),
      section: actionSection,
      iconEl: _svgFor(qa.iconId),
      url: qa.url, action: qa.action,
    }));
    return items;
  }

  // ---- Fuzzy scoring: higher = better ----
  function score(query, label) {
    const q = query.toLowerCase();
    const l = label.toLowerCase();
    if (!q) return 1;
    const idx = l.indexOf(q);
    if (idx === 0) return 100;            // prefix match
    if (idx > 0) return 60 - Math.min(idx, 20);  // substring match
    // Subsequence match (all query chars in order)
    let qi = 0;
    for (let i = 0; i < l.length && qi < q.length; i++) {
      if (l[i] === q[qi]) qi++;
    }
    return qi === q.length ? 20 : -1;
  }

  function filterItems(query) {
    if (!query.trim()) {
      filtered = items.slice(0, 12);
      return;
    }
    const terms = query.trim().toLowerCase().split(/\s+/);
    filtered = items
      .map(it => {
        // Every term must match somewhere (label or section)
        let total = 0;
        for (const t of terms) {
          const s = Math.max(score(t, it.label), score(t, it.section) * 0.5);
          if (s < 0) { total = -1; break; }
          total += s;
        }
        return { it, s: total };
      })
      .filter(x => x.s >= 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, 12)
      .map(x => x.it);
  }

  function render() {
    listEl.innerHTML = "";
    filtered.forEach((it, i) => {
      const row = document.createElement("div");
      row.className = "cp-item" + (i === activeIdx ? " cp-active" : "");
      row.innerHTML =
        '<span class="cp-icon">' + (it.iconEl || (it.icon ? escapeHtml(it.icon) : "▸")) + "</span>" +
        '<span class="cp-label">' + escapeHtml(it.label) + "</span>" +
        '<span class="cp-section">' + escapeHtml(it.section) + "</span>";
      row.addEventListener("click", () => execute(it));
      row.addEventListener("mousemove", () => { if (activeIdx !== i) { activeIdx = i; render(); } });
      listEl.appendChild(row);
    });
    if (!filtered.length) {
      listEl.innerHTML = '<div class="cp-empty">' +
        escapeHtml(T("palette.empty", "No matches — try another word")) + "</div>";
    }
  }

  function execute(it) {
    close();
    if (!it) return;
    if (it.action === "toggleTheme") {
      // Reuse the app's built-in theme shortcut if present
      if (typeof window.toggleTheme === "function") { window.toggleTheme(); return; }
      const ev = new KeyboardEvent("keydown", { key: "t", bubbles: true });
      document.body.dispatchEvent(ev);
      return;
    }
    if (it.url) window.location.href = it.url;
  }

  function open() {
    if (!paletteEl) build();
    buildItems();
    inputEl.value = "";
    activeIdx = 0;
    filterItems("");
    render();
    paletteEl.style.display = "flex";
    requestAnimationFrame(() => inputEl.focus());
  }

  function close() {
    if (paletteEl) paletteEl.style.display = "none";
  }

  function build() {
    paletteEl = document.createElement("div");
    paletteEl.className = "asm-cp-backdrop";
    paletteEl.innerHTML =
      '<div class="asm-cp" role="dialog" aria-label="Command palette">' +
      '  <input class="asm-cp-input" placeholder="' +
      escapeHtml(T("palette.placeholder", "Type a page or action…")) +
      '" autocomplete="off" spellcheck="false">' +
      '  <div class="asm-cp-list"></div>' +
      '  <div class="cp-footer">ASM Command Palette</div>' +
      "</div>";
    document.body.appendChild(paletteEl);
    inputEl = paletteEl.querySelector(".asm-cp-input");
    listEl = paletteEl.querySelector(".asm-cp-list");

    inputEl.addEventListener("input", () => { activeIdx = 0; filterItems(inputEl.value); render(); });
    inputEl.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown") { e.preventDefault(); activeIdx = Math.min(activeIdx + 1, filtered.length - 1); render(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); activeIdx = Math.max(activeIdx - 1, 0); render(); }
      else if (e.key === "Enter") { e.preventDefault(); execute(filtered[activeIdx]); }
      else if (e.key === "Escape") { close(); }
    });
    paletteEl.addEventListener("mousedown", (e) => { if (e.target === paletteEl) close(); });
  }

  // ---- Global shortcut: Ctrl+K / Cmd+K ----
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
      e.preventDefault();
      if (paletteEl && paletteEl.style.display === "flex") close();
      else open();
    }
    if (e.key === "Escape" && paletteEl && paletteEl.style.display === "flex") close();
  });

  // Inject styles once
  const css = `
.asm-cp-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(2px);z-index:9999;align-items:flex-start;justify-content:center;padding-top:12vh}
.asm-cp{width:min(640px,92vw);background:var(--bg-elev-1,#222);border:1px solid var(--border,#444);border-radius:12px;box-shadow:0 18px 60px rgba(0,0,0,.5);overflow:hidden;font-family:inherit}
.asm-cp-input{width:100%;box-sizing:border-box;border:none;border-bottom:1px solid var(--border,#444);background:transparent;color:var(--text,#eee);padding:0.9rem 1rem;font-size:1rem;outline:none}
.asm-cp-list{max-height:340px;overflow-y:auto;padding:0.35rem}
.cp-item{display:flex;align-items:center;gap:0.65rem;padding:0.55rem 0.65rem;border-radius:8px;cursor:pointer;color:var(--text,#eee)}
.cp-item:hover,.cp-item.cp-active{background:var(--accent-soft,rgba(90,140,255,.15))}
.cp-icon{width:1.5rem;display:inline-flex;align-items:center;justify-content:center;opacity:.9}.cp-icon .ic{width:16px;height:16px}
.cp-label{flex:1;font-size:.95rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cp-section{font-size:.7rem;color:var(--text-dim,#999);background:var(--bg-elev-2,#333);padding:0.15rem 0.5rem;border-radius:999px;white-space:nowrap}
.cp-empty{padding:1.2rem;text-align:center;color:var(--text-dim,#999);font-size:.9rem}
.asm-cp-footer{padding:0.45rem 1rem;font-size:.7rem;color:var(--text-dim,#777);border-top:1px solid var(--border,#444)}
  `;
  const style = document.createElement("style");
  style.textContent = css;
  document.head.appendChild(style);

  // v9.1.0 (M-05): local escapeHtml removed — core.js (base.html) owns the
  // canonical global version; bare escapeHtml() calls resolve to it.

})();
