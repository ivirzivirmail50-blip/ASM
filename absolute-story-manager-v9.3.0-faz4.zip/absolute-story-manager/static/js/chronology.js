/* ASM v8.3 — Story Chronology renderer.
 * Static-JS architecture: data flows from the #chronoData JSON tag;
 * all user text is inserted via textContent (XSS-safe).
 */
(function () {
  "use strict";

  var data = null;
  var zoom = 1;
  var activeChars = {};   // charId -> true
  var layout = null;      // computed positions

  var CARD_W = 148, CARD_H = 116, CARD_GAP = 10;
  var PAD_L = 16, PAD_R = 24;
  var ROW_A = 30, ROW_B = 158;
  var AXIS_Y = 296;
  var EVENT_Y = 312;
  var GAP_Y = 336;
  var STAGE_H = 372;

  function $(id) { return document.getElementById(id); }

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  // ---------------------------------------------------------------- data
  function boot() {
    var tag = $("chronoData");
    if (!tag) return;
    try { data = JSON.parse(tag.textContent); }
    catch (e) { console.error("chronology data parse failed", e); return; }
    if (!data || !data.ok) return;

    buildCharChips();
    bindControls();
    render();
  }

  // ---------------------------------------------------------------- render
  function render() {
    var inner = $("chronoInner");
    if (!inner) return;
    inner.innerHTML = "";
    var stage = $("chronoStage");

    var chapters = data.chapters || [];
    var events = (data.events || []).filter(function (e) { return e.t !== null && e.t !== undefined; });
    var mode = data.mode || "order";
    var oop = {};
    (data.oop_ids || []).forEach(function (id) { oop[id] = true; });

    // ---- timeline values
    var tvals = chapters.filter(function (c) { return c.t !== null && c.t !== undefined; })
      .map(function (c) { return c.t; });
    if (mode === "order") {
      chapters.forEach(function (c, i) { c.t = i; });
      tvals = chapters.map(function (c, i) { return i; });
    }
    var tmin = tvals.length ? Math.min.apply(null, tvals) : 0;
    var tmax = tvals.length ? Math.max.apply(null, tvals) : 1;
    if (tmax === tmin) tmax = tmin + 1;

    var baseTrack = Math.max(stage.clientWidth - PAD_L - PAD_R, chapters.length * 100, 600);
    var track = baseTrack * zoom;
    var scale = track / (tmax - tmin);

    function xOf(t) { return PAD_L + (t - tmin) * scale; }

    // ---- place chapter cards (two rows, monotone overlap resolution)
    var rowEnd = [-Infinity, -Infinity];
    var placements = [];
    chapters.forEach(function (c) {
      if (c.t === null || c.t === undefined) return;
      var wantX = xOf(c.t);
      var row = rowEnd[0] <= rowEnd[1] ? 0 : 1;
      var x = Math.max(wantX, rowEnd[row] + CARD_GAP);
      rowEnd[row] = x + CARD_W;
      placements.push({ c: c, x: x, row: row });
    });

    // event pins: cluster-spaced around their x
    var eventPlacements = [];
    var lastX = -Infinity;
    events.sort(function (a, b) { return a.t - b.t; }).forEach(function (ev) {
      var x = Math.max(xOf(ev.t), lastX + 14);
      lastX = x;
      eventPlacements.push({ ev: ev, x: x });
    });

    var contentW = Math.max(
      track + PAD_L + PAD_R,
      Math.max(rowEnd[0], rowEnd[1]) + PAD_R,
      lastX + 40
    );
    inner.style.width = Math.max(contentW, stage.clientWidth) + "px";
    inner.style.height = STAGE_H + "px";

    // ---- axis
    var axis = el("div", "chrono-axis");
    axis.style.top = AXIS_Y + "px";
    inner.appendChild(axis);

    // ---- tick labels
    appendTicks(inner, mode, tmin, tmax, scale, chapters);

    // ---- gap ribbons
    (data.gaps || []).forEach(function (g) {
      var x1 = xOf(g.t1) + CARD_W / 2;
      var x2 = xOf(g.t2);
      if (x2 - x1 < 30) return;
      var gap = el("div", "chrono-gap");
      gap.style.left = x1 + "px";
      gap.style.width = (x2 - x1) + "px";
      gap.style.top = GAP_Y + "px";
      inner.appendChild(gap);
      var label = el("div", "chrono-gap-label",
        Math.round(g.delta) + (mode === "date" ? "-day gap" : " gap"));
      label.style.left = (x1 + (x2 - x1) / 2) + "px";
      label.style.top = (GAP_Y - 2) + "px";
      inner.appendChild(label);
    });

    // ---- chapter cards
    placements.forEach(function (p) {
      inner.appendChild(chapterCard(p.c, p.x, p.row === 0 ? ROW_A : ROW_B, oop[p.c.id]));
    });

    // ---- event pins
    eventPlacements.forEach(function (p) {
      var pin = el("div",
        "chrono-event " + (p.ev.linked ? "chrono-event-written chrono-event-linked" : "chrono-event-planned"));
      pin.style.left = p.x + "px";
      pin.style.top = EVENT_Y + "px";
      pin.setAttribute("data-ev", JSON.stringify({
        title: p.ev.title,
        date: p.ev.story_date_raw || "",
        track: p.ev.track || "",
        type: p.ev.event_type || "",
        linked: p.ev.linked
      }));
      pin.addEventListener("mouseenter", onPinEnter);
      pin.addEventListener("mouseleave", onPinLeave);
      pin.addEventListener("click", onPinClick);
      inner.appendChild(pin);
    });

    // ---- undated list
    renderUndated(mode);

    // ---- mode label
    var label = $("chronoModeLabel");
    if (label) {
      if (mode === "date") {
        label.textContent = "Date timeline" +
          (data.stats && data.stats.earliest ? " · " + data.stats.earliest + " → " + data.stats.latest : "");
      } else if (mode === "day") {
        label.textContent = "Day markers · Day " + Math.round(tmin) + " → Day " + Math.round(tmax);
      } else {
        label.textContent = "Reading order — no story dates yet";
      }
    }

    applyCharFilter();
  }

  function chapterCard(c, x, y, isOop) {
    var a = document.createElement("a");
    a.className = "chrono-chapter";
    a.href = "/chapters/" + c.id;
    a.style.left = x + "px";
    a.style.top = y + "px";
    a.setAttribute("data-chars", (c.characters || []).join(","));

    var num = el("div", "chrono-ch-num", "Ch. " + c.num + (c.story_date_raw ? " · " + c.story_date_raw : ""));
    a.appendChild(num);
    var title = el("div", "chrono-ch-title", c.title || "Untitled");
    a.appendChild(title);
    var meta = el("div", "chrono-ch-meta");
    var dot = el("span", "chrono-status-dot");
    dot.style.background = c.status_color || "var(--text-mute)";
    meta.appendChild(dot);
    meta.appendChild(document.createTextNode(
      (c.word_count || 0) + " w" + ((c.characters || []).length ? " · 👥 " + c.characters.length : "")));
    a.appendChild(meta);

    if (isOop) {
      var badge = el("div", "chrono-badge-oop", "!");
      badge.title = "Story date is earlier than the previous dated chapter — chronology and chapter order disagree.";
      a.appendChild(badge);
    }
    return a;
  }

  function appendTicks(inner, mode, tmin, tmax, scale, chapters) {
    var ticks = el("div");
    ticks.style.position = "absolute";
    ticks.style.left = "0"; ticks.style.right = "0";
    ticks.style.top = "0"; ticks.style.height = "18px";
    inner.appendChild(ticks);
    if (mode === "date") {
      // year ticks
      var startYear = Math.floor(tmin / 365.25) + 1;
      var spanYears = (tmax - tmin) / 365.25;
      var step = spanYears > 6 ? Math.ceil(spanYears / 8) : 1;
      for (var yr = startYear; yr <= Math.floor(tmax / 365.2425) + 1; yr += step) {
        if (yr < 1900 || yr > 2200) continue;
        var tick = el("div", "chrono-year", String(yr));
        var x = PAD_L + (yr * 365.2425 - tmin) * scale;
        if (x < PAD_L - 40 || x > parseInt(inner.style.width, 10)) continue;
        tick.style.left = x + "px";
        ticks.appendChild(tick);
      }
    } else if (mode === "day") {
      var step2 = Math.max(1, Math.ceil((tmax - tmin) / 12));
      for (var d = Math.ceil(tmin / step2) * step2; d <= tmax; d += step2) {
        var tick2 = el("div", "chrono-year", "Day " + d);
        tick2.style.left = (PAD_L + (d - tmin) * scale) + "px";
        ticks.appendChild(tick2);
      }
    }
  }

  function renderUndated(mode) {
    var wrap = $("chronoUndatedWrap");
    var list = $("chronoUndatedList");
    if (!wrap || !list) return;
    var undated = data.undated || [];
    if (mode === "order" || !undated.length) {
      wrap.classList.add("hidden");
      return;
    }
    wrap.classList.remove("hidden");
    $("chronoUndatedCount").textContent = String(undated.length);
    list.innerHTML = "";
    undated.forEach(function (u) {
      var chip = el("a", "badge no-dot", "Ch. " + u.num + " · " + (u.title || "Untitled"));
      chip.href = "/chapters/" + u.id;
      chip.style.fontSize = "0.68rem";
      chip.style.padding = "0.25rem 0.6rem";
      chip.style.color = "var(--accent-hover)";
      list.appendChild(chip);
    });
  }

  // ---------------------------------------------------------------- events
  var tooltip = null;
  function ensureTooltip() {
    if (!tooltip) {
      tooltip = el("div", "chrono-tooltip");
      document.body.appendChild(tooltip);
    }
    return tooltip;
  }

  function onPinEnter(ev) {
    var t = ensureTooltip();
    var d = {};
    try { d = JSON.parse(ev.target.getAttribute("data-ev")); } catch (e) { return; }
    t.textContent = "";
    var title = el("div", null, d.title || "Event");
    title.style.fontWeight = "600";
    t.appendChild(title);
    if (d.date) t.appendChild(el("div", null, "📅 " + d.date));
    if (d.track) t.appendChild(el("div", null, "Track: " + d.track));
    if (d.type) t.appendChild(el("div", null, "Type: " + d.type));
    t.appendChild(el("div", null, d.linked ? "✓ linked to a written chapter" : "planned — not written yet"));
    var r = ev.target.getBoundingClientRect();
    t.style.left = Math.min(window.innerWidth - 280, r.left) + "px";
    t.style.top = (r.bottom + 8) + "px";
    t.classList.add("chrono-tooltip-show");
  }
  function onPinLeave() {
    if (tooltip) tooltip.classList.remove("chrono-tooltip-show");
  }
  function onPinClick(ev) {
    var d = {};
    try { d = JSON.parse(ev.target.getAttribute("data-ev")); } catch (e) { return; }
    // no direct plan link in payload — events open the plans board
    window.location.href = "/plans/";
  }

  // ---------------------------------------------------------------- filter
  function buildCharChips() {
    var holder = $("chronoCharChips");
    if (!holder) return;
    var chars = data.character_options || [];
    if (!chars.length) return;
    var noChars = $("chronoNoChars");
    if (noChars) noChars.remove();
    chars.forEach(function (c) {
      var chip = el("button", "badge no-dot", c.name);
      chip.type = "button";
      chip.style.fontSize = "0.7rem";
      chip.style.padding = "0.28rem 0.7rem";
      chip.style.cursor = "pointer";
      chip.setAttribute("data-char-id", c.id);
      chip.addEventListener("click", function () {
        if (activeChars[c.id]) delete activeChars[c.id];
        else activeChars[c.id] = true;
        chip.style.background = activeChars[c.id] ? "var(--accent)" : "";
        chip.style.color = activeChars[c.id] ? "#fff" : "";
        applyCharFilter();
      });
      holder.appendChild(chip);
    });
  }

  function applyCharFilter() {
    var any = Object.keys(activeChars).length > 0;
    var cards = document.querySelectorAll(".chrono-chapter");
    Array.prototype.forEach.call(cards, function (card) {
      if (!any) { card.style.opacity = ""; return; }
      var chars = (card.getAttribute("data-chars") || "").split(",").filter(Boolean);
      var hit = chars.some(function (id) { return activeChars[id]; });
      card.style.opacity = hit ? "1" : "0.22";
    });
  }

  // ---------------------------------------------------------------- zoom
  function bindControls() {
    function setZoom(z) {
      zoom = Math.max(0.75, Math.min(10, z));
      var lbl = $("chronoZoomLabel");
      if (lbl) lbl.textContent = (Math.round(zoom * 100) / 100) + "×";
      render();
    }
    var zin = $("chronoZoomIn"), zout = $("chronoZoomOut"), zfit = $("chronoZoomFit");
    if (zin) zin.addEventListener("click", function () { setZoom(zoom * 1.5); });
    if (zout) zout.addEventListener("click", function () { setZoom(zoom / 1.5); });
    if (zfit) zfit.addEventListener("click", function () { setZoom(1); });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
