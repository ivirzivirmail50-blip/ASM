/* v7.3 — Floating Quick Capture (Deep Writing Experience)
 * Global Ctrl+Shift+N opens a floating composer anywhere in the app.
 * Type a single line/paragraph, pick a destination type, submit. Done.
 * Reuses the existing /quick-capture/api/capture endpoint.
 * SVG icons from the sprite (no emoji chrome).
 */
(function AsmQuickCapture() {
  if (window.__asmQuickCapture) return;
  window.__asmQuickCapture = true;

  const SPRITE = ` <svg class="ic" aria-hidden="true"><use href="#i-bulb"></use></svg> `;

  function icon(name) {
    return `<svg class="ic" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;
  }

  // Build composer once, keep it cached
  let _composer = null;
  function buildComposer() {
    if (_composer) return _composer;
    const el = document.createElement("div");
    el.className = "qc-shell";
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-modal", "true");
    el.setAttribute("aria-labelledby", "qcTitle");
    el.innerHTML = `
      <div class="qc-backdrop" data-act="close"></div>
      <div class="qc-modal">
        <div class="qc-header">
          <div class="qc-title" id="qcTitle">${icon("zap")} Quick Capture</div>
          <button class="qc-close" data-act="close" title="Close (Esc)">${icon("x")}</button>
        </div>
        <div class="qc-types" role="tablist">
          <button class="qc-type active" data-type="note" title="Save as a note">${icon("file-text")} Note</button>
          <button class="qc-type" data-type="chapter" title="Create a new chapter stub">${icon("book-open")} Chapter</button>
          <button class="qc-type" data-type="journal" title="Add to today's journal">${icon("calendar")} Journal</button>
          <button class="qc-type" data-type="snippet" title="Save as a reusable snippet">${icon("clipboard")} Snippet</button>
        </div>
        <div class="qc-body">
          <input type="text" class="qc-title-input" id="qcTitleInput" placeholder="Title (optional)" autocomplete="off">
          <textarea class="qc-body-input" id="qcBodyInput" placeholder="Type anything that crossed your mind — an idea, a line of dialogue, a note about a character…&#10;&#10;Ctrl+Enter to save."></textarea>
          <div class="qc-options">
            <label class="qc-opt" id="qcCategoryWrap">
              <span class="text-xs text-mute">Category</span>
              <select id="qcCategory" class="form-select qc-select">
                <option value="idea">Idea</option>
                <option value="character">Character</option>
                <option value="plot">Plot</option>
                <option value="world">World</option>
                <option value="dialogue">Dialogue</option>
                <option value="todo">To-do</option>
                <option value="research">Research</option>
              </select>
            </label>
            <label class="qc-opt" id="qcMoodWrap" style="display:none">
              <span class="text-xs text-mute">Mood</span>
              <select id="qcMood" class="form-select qc-select">
                <option value="ok">OK</option>
                <option value="great">Great</option>
                <option value="good">Good</option>
                <option value="struggling">Struggling</option>
                <option value="blocked">Blocked</option>
              </select>
            </label>
          </div>
        </div>
        <div class="qc-footer">
          <span class="qc-hint text-xs text-mute">Ctrl+Shift+N · Esc to close</span>
          <div class="qc-actions">
            <button class="btn" data-act="close">Cancel</button>
            <button class="btn btn-primary" data-act="save">${icon("send")} Save</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(el);
    _composer = el;

    // Wire up close on backdrop / cancel / Esc
    el.querySelectorAll('[data-act="close"]').forEach(b => b.addEventListener("click", close));
    el.querySelector(".qc-backdrop").addEventListener("click", close);
    el.querySelectorAll(".qc-type").forEach(btn => {
      btn.addEventListener("click", () => {
        el.querySelectorAll(".qc-type").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        // Show/hide contextual options
        const t = btn.dataset.type;
        el.querySelector("#qcCategoryWrap").style.display = (t === "note" || t === "chapter") ? "" : "none";
        el.querySelector("#qcMoodWrap").style.display = (t === "journal") ? "" : "none";
        // Focus the body if title is empty
        if (!el.querySelector("#qcTitleInput").value) el.querySelector("#qcBodyInput").focus();
      });
    });

    // Ctrl+Enter to save
    el.querySelector("#qcBodyInput").addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        e.preventDefault();
        save();
      }
    });
    el.querySelector("#qcTitleInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); el.querySelector("#qcBodyInput").focus(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); save(); }
    });

    el.querySelector('[data-act="save"]').addEventListener("click", save);
    return el;
  }

  function open() {
    const c = buildComposer();
    c.classList.add("open");
    document.body.classList.add("qc-lock");
    // Reset fields
    c.querySelector("#qcTitleInput").value = "";
    c.querySelector("#qcBodyInput").value = "";
    c.querySelector("#qcCategory").value = "idea";
    c.querySelector("#qcMood").value = "ok";
    // Reset type buttons
    c.querySelectorAll(".qc-type").forEach(b => b.classList.remove("active"));
    c.querySelector('.qc-type[data-type="note"]').classList.add("active");
    c.querySelector("#qcCategoryWrap").style.display = "";
    c.querySelector("#qcMoodWrap").style.display = "none";
    setTimeout(() => c.querySelector("#qcBodyInput").focus(), 50);
  }

  function close() {
    if (!_composer) return;
    _composer.classList.remove("open");
    document.body.classList.remove("qc-lock");
  }

  async function save() {
    if (!_composer) return;
    const c = _composer;
    const type = c.querySelector(".qc-type.active")?.dataset.type || "note";
    const title = c.querySelector("#qcTitleInput").value.trim();
    const body = c.querySelector("#qcBodyInput").value.trim();
    if (!title && !body) {
      showToast("Write something first", "warning", 1500);
      return;
    }
    const payload = { type, title, body };
    if (type === "note" || type === "chapter") {
      payload.category = c.querySelector("#qcCategory").value;
    }
    if (type === "journal") {
      payload.mood = c.querySelector("#qcMood").value;
    }
    const btn = c.querySelector('[data-act="save"]');
    btn.disabled = true;
    btn.innerHTML = `${icon("history")} Saving…`;
    try {
      const { data } = await asmFetch("/quick-capture/api/capture", { method: "POST", body: payload });
      btn.disabled = false;
      btn.innerHTML = `${icon("send")} Save`;
      if (data.ok) {
        const labels = { note: "Note saved", chapter: "Chapter created", journal: "Journal updated", snippet: "Snippet saved" };
        showToast(`${icon("check-circle")} ${labels[type] || "Saved"}`, "success", 2500);
        close();
        // Optional: navigate to the new entity
        // if (data.url) setTimeout(() => window.location.href = data.url, 600);
      } else {
        showToast(data.error || "Save failed", "error");
      }
    } catch (err) {
      btn.disabled = false;
      btn.innerHTML = `${icon("send")} Save`;
      showToast("Network error: " + err.message, "error");
    }
  }

  // Public API — other modules (app.js Ctrl+N, quick switch, header menu)
  // route here. Falls back to the legacy note-only modal if unavailable.
  window.asmQuickCapture = open;

  // Global hotkey: Ctrl+Shift+N (or Cmd+Shift+N on Mac)
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === "N" || e.key === "n")) {
      // Don't intercept when typing in a contenteditable / form input
      const t = e.target;
      const isTyping = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
      // Still allow it — just call preventDefault
      e.preventDefault();
      // If composer already open, close it (toggle)
      if (_composer && _composer.classList.contains("open")) close();
      else open();
    }
    if (e.key === "Escape" && _composer && _composer.classList.contains("open")) {
      e.preventDefault();
      close();
    }
  });

  // Add a small FAB in the bottom-right that opens the composer on click
  // (visible only when composer is closed). Single global capture entry
  // point — the old bottom-left .fab-capture was removed in v7.7 because it
  // overlapped the sidebar's last nav links and the footer stats.
  // v7.8: the FAB is appended into the unified bottom-right dock (#brDock)
  // so it can never overlap the undo toolbar / status pill / other widgets.
  function ensureFab() {
    if (document.getElementById("qcFab")) return;
    const fab = document.createElement("button");
    fab.id = "qcFab";
    fab.className = "qc-fab";
    fab.title = "Quick Capture (Ctrl+N or Ctrl+Shift+N)";
    fab.innerHTML = icon("plus");
    fab.setAttribute("aria-label", "Quick Capture");
    fab.addEventListener("click", open);
    const dock = document.getElementById("brDock");
    (dock || document.body).appendChild(fab);
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ensureFab);
  } else {
    ensureFab();
  }
})();
