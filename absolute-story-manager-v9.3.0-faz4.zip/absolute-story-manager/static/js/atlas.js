/**
 * Story Atlas — interactive nested tree + pin list + routes
 *
 * v7.6 feature. All data flows in via data-* attributes (NO inline Jinja
 * in JS blocks — this is the v7.5 root-architecture rule).
 */
(function () {
  'use strict';

  // ---- State ----
  var state = {
    tree: [],
    pins: [],
    routes: [],
    candidates: null,
    expandedNodes: new Set(),
  };

  // ---- Helpers ----
  function $(sel) { return document.querySelector(sel); }
  function $$(sel) { return Array.from(document.querySelectorAll(sel)); }
  function htmlEscape(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  // ---- Tree rendering ----
  function renderTree() {
    var el = $('#atlasTree');
    if (!el) return;
    try {
      state.tree = JSON.parse(el.getAttribute('data-tree') || '[]');
    } catch (e) {
      console.error('[atlas] tree data parse failed:', e);
      return;
    }
    if (!state.tree.length) {
      el.innerHTML = '<div class="atlas-empty">' +
        '<div class="text-mute text-sm">No locations yet.</div>' +
        '<a class="btn btn-sm btn-primary" href="/world/new?type=location">+ Create location</a>' +
        '</div>';
      return;
    }
    el.innerHTML = renderTreeNodes(state.tree, 0);
    bindTreeEvents();
  }

  function renderTreeNodes(nodes, depth) {
    var html = '';
    nodes.forEach(function (n) {
      var hasChildren = n.children && n.children.length > 0;
      var isExpanded = state.expandedNodes.has(n.id) || depth < 1; // expand top by default
      var pinCount = n.pins || 0;
      var subPinCount = n.subtree_pins || 0;
      html += '<div class="atlas-node" data-id="' + htmlEscape(n.id) + '" data-depth="' + depth + '">';
      html += '<div class="atlas-node-row" style="padding-left: ' + (depth * 18 + 8) + 'px">';
      // Expand toggle
      if (hasChildren) {
        html += '<button class="atlas-node-toggle" data-toggle="' + htmlEscape(n.id) + '" title="Expand/collapse">' +
          (isExpanded ? '▾' : '▸') + '</button>';
      } else {
        html += '<span class="atlas-node-toggle atlas-node-toggle-leaf"></span>';
      }
      // Color dot
      html += '<span class="atlas-node-dot" style="background: ' + htmlEscape(n.map_pin_color || '#6366f1') + '"></span>';
      // Name
      html += '<a class="atlas-node-name" href="/world/' + htmlEscape(n.id) + '">' + htmlEscape(n.name) + '</a>';
      // Category
      if (n.category) {
        html += '<span class="atlas-node-cat">' + htmlEscape(n.category) + '</span>';
      }
      // Pins badge
      if (pinCount > 0) {
        html += '<span class="atlas-node-pins" title="' + pinCount + ' character(s) pinned here">📍 ' + pinCount + '</span>';
      }
      // Subtree pins
      if (hasChildren && subPinCount > pinCount) {
        html += '<span class="atlas-node-subpins" title="' + subPinCount + ' total pins in subtree">↳ ' + subPinCount + '</span>';
      }
      // Map image indicator
      if (n.has_map_image) {
        html += '<span class="atlas-node-img" title="Has map image">🗺️</span>';
      }
      // Pin button
      html += '<button class="atlas-node-pinbtn btn btn-xs btn-ghost" data-pin="' + htmlEscape(n.id) + '" data-name="' + htmlEscape(n.name) + '" title="Pin character here">+ Pin</button>';
      html += '</div>';
      // Children
      if (hasChildren && isExpanded) {
        html += '<div class="atlas-children">' + renderTreeNodes(n.children, depth + 1) + '</div>';
      }
      html += '</div>';
    });
    return html;
  }

  function bindTreeEvents() {
    // Expand/collapse toggles
    $$('.atlas-node-toggle[data-toggle]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = btn.getAttribute('data-toggle');
        if (state.expandedNodes.has(id)) {
          state.expandedNodes.delete(id);
        } else {
          state.expandedNodes.add(id);
        }
        renderTree();
      });
    });
    // Pin buttons
    $$('.atlas-node-pinbtn').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var locId = btn.getAttribute('data-pin');
        var locName = btn.getAttribute('data-name');
        atlasOpenPinModal(locId, locName);
      });
    });
  }

  window.atlasExpandAll = function () {
    function walk(nodes) {
      nodes.forEach(function (n) {
        state.expandedNodes.add(n.id);
        if (n.children) walk(n.children);
      });
    }
    walk(state.tree);
    renderTree();
  };

  window.atlasCollapseAll = function () {
    state.expandedNodes = new Set();
    renderTree();
  };

  // ---- Pins list ----
  // v7.6 fix: renderPins() used to re-parse the server-rendered data-pins
  // attribute on EVERY call — so after a delete the in-memory filter was
  // silently overwritten with the stale page-load data and the removed pin
  // re-appeared. The attribute is now the single source of truth, kept in
  // sync with the server via refreshPins().
  function renderPins() {
    var el = $('#atlasPinsList');
    if (!el) return;
    try {
      state.pins = JSON.parse(el.getAttribute('data-pins') || '[]');
    } catch (e) {
      console.error('[atlas] pins data parse failed:', e);
      return;
    }
    if (!state.pins.length) {
      el.innerHTML = '<div class="atlas-empty">' +
        '<div class="text-mute text-sm">No character pins yet.</div>' +
        '<button class="btn btn-sm btn-primary" onclick="atlasOpenPinModal()">+ Pin Character</button>' +
        '</div>';
      return;
    }
    // Group by location
    var byLoc = {};
    state.pins.forEach(function (p) {
      var key = p.location.id;
      if (!byLoc[key]) byLoc[key] = {loc: p.location, items: []};
      byLoc[key].items.push(p);
    });
    var html = '';
    Object.keys(byLoc).forEach(function (key) {
      var g = byLoc[key];
      html += '<div class="atlas-pins-group">';
      html += '<div class="atlas-pins-group-head"><a href="/world/' + htmlEscape(g.loc.id) + '">' + htmlEscape(g.loc.name) + '</a></div>';
      g.items.forEach(function (p) {
        html += '<div class="atlas-pin-row">';
        html += '<span class="atlas-pin-char-dot" style="background: ' + htmlEscape(p.character.color) + '"></span>';
        html += '<a class="atlas-pin-char-name" href="/characters/' + htmlEscape(p.character_id) + '">' + htmlEscape(p.character.name) + '</a>';
        if (p.character.role) html += '<span class="atlas-pin-char-role">' + htmlEscape(p.character.role) + '</span>';
        html += '<span class="atlas-pin-kind" style="color: ' + htmlEscape(p.kind_color) + '">' + htmlEscape(p.kind_label) + '</span>';
        if (p.note) html += '<span class="atlas-pin-note">— ' + htmlEscape(p.note) + '</span>';
        html += '<button class="atlas-pin-delete" data-del="' + htmlEscape(p.id) + '" title="Remove pin">×</button>';
        html += '</div>';
      });
      html += '</div>';
    });
    el.innerHTML = html;
    // Bind delete
    $$('.atlas-pin-delete').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var pinId = btn.getAttribute('data-del');
        if (!confirm('Remove this pin?')) return;
        fetch('/atlas/api/pin/' + encodeURIComponent(pinId), {method: 'DELETE'})
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (data.ok) {
              refreshPins();       // server is the source of truth — re-fetch
              refreshTree();       // subtree pin counts changed too
              refreshStats();      // stats strip totals changed too
            } else {
              alert('Failed: ' + (data.error || 'unknown'));
            }
          });
      });
    });
  }

  // Fetch fresh pins from the server, sync the data-pins attribute (the
  // single source of truth) and re-render. No full page reload needed.
  function refreshPins() {
    fetch('/atlas/api/pins').then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok) return;
      var el = $('#atlasPinsList');
      if (el) el.setAttribute('data-pins', JSON.stringify(d.pins || []));
      renderPins();
    }).catch(function (err) {
      console.error('[atlas] refreshPins failed:', err);
    });
  }

  // Fetch fresh tree (with updated pin counts), sync data-tree, re-render.
  function refreshTree() {
    fetch('/atlas/api/tree').then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok) return;
      state.tree = d.roots;
      var treeEl = $('#atlasTree');
      if (treeEl) treeEl.setAttribute('data-tree', JSON.stringify(d.roots));
      renderTree();
    }).catch(function (err) {
      console.error('[atlas] refreshTree failed:', err);
    });
  }

  // Fetch the tree payload and update the stats strip in place.
  function refreshStats() {
    fetch('/atlas/api/tree').then(function (r) { return r.json(); }).then(function (d) {
      if (!d || !d.ok) return;
      var st = d.stats || {};
      var map = {
        '#atlasStatLocations': st.total_locations,
        '#atlasStatPinnedChars': st.pinned_characters,
        '#atlasStatPins': st.total_pins,
        '#atlasStatDepth': st.max_depth,
      };
      Object.keys(map).forEach(function (sel) {
        var el = document.querySelector(sel);
        if (el && map[sel] !== undefined && map[sel] !== null) el.textContent = String(map[sel]);
      });
    }).catch(function (err) {
      console.error('[atlas] refreshStats failed:', err);
    });
  }

  // ---- Routes list ----
  function renderRoutes() {
    var el = $('#atlasRoutesList');
    if (!el) return;
    try {
      state.routes = JSON.parse(el.getAttribute('data-routes') || '[]');
    } catch (e) {
      console.error('[atlas] routes data parse failed:', e);
      return;
    }
    if (!state.routes.length) {
      el.innerHTML = '<div class="atlas-empty">' +
        '<div class="text-mute text-sm">No travel routes yet.</div>' +
        '<a class="btn btn-sm btn-ghost" href="/world/map">Open map to draw a route →</a>' +
        '</div>';
      return;
    }
    var html = '';
    state.routes.forEach(function (r) {
      var wpCount = (r.waypoints || []).length;
      var chName = r.character_name || 'Character';
      html += '<div class="atlas-route-row">';
      html += '<span class="atlas-route-dot" style="background: ' + htmlEscape(r.color || '#6366f1') + '"></span>';
      html += '<span class="atlas-route-name">' + htmlEscape(r.name || 'Untitled route') + '</span>';
      if (r.character_name) html += '<span class="atlas-route-char">' + htmlEscape(chName) + '</span>';
      html += '<span class="atlas-route-wp" title="Waypoints">' + wpCount + ' stops</span>';
      html += '</div>';
    });
    el.innerHTML = html;
  }

  // ---- Pin modal ----
  window.atlasOpenPinModal = function (presetLocId, presetLocName) {
    var backdrop = $('#atlasPinBackdrop');
    var body = $('#atlasPinModalBody');
    if (!backdrop || !body) return;
    backdrop.hidden = false;
    document.body.style.overflow = 'hidden';

    if (!state.candidates) {
      body.innerHTML = '<div class="text-mute text-sm">Loading candidates…</div>';
      fetch('/atlas/api/candidates').then(function (r) { return r.json(); }).then(function (data) {
        if (data.ok) {
          state.candidates = data;
          renderPinModalBody(presetLocId, presetLocName);
        } else {
          body.innerHTML = '<div class="text-danger">Failed to load: ' + htmlEscape(data.error || 'unknown') + '</div>';
        }
      });
    } else {
      renderPinModalBody(presetLocId, presetLocName);
    }
  };

  function renderPinModalBody(presetLocId, presetLocName) {
    var body = $('#atlasPinModalBody');
    var cands = state.candidates;
    var html = '';
    if (!cands.characters.length) {
      html = '<div class="atlas-empty"><div class="text-mute text-sm">No characters. <a href="/characters/new">Create one</a>.</div></div>';
      body.innerHTML = html;
      return;
    }
    if (!cands.locations.length) {
      html = '<div class="atlas-empty"><div class="text-mute text-sm">No locations. <a href="/world/new?type=location">Create one</a>.</div></div>';
      body.innerHTML = html;
      return;
    }
    html = '<form id="atlasPinForm" class="atlas-pin-form" onsubmit="atlasSubmitPin(event)">';
    // Character
    html += '<label class="atlas-form-label">Character</label>';
    html += '<select name="character_id" class="form-select atlas-form-control" required>';
    cands.characters.forEach(function (c) {
      html += '<option value="' + htmlEscape(c.id) + '">' + htmlEscape(c.name) + (c.role ? ' (' + c.role + ')' : '') + '</option>';
    });
    html += '</select>';
    // Location
    html += '<label class="atlas-form-label">Location</label>';
    html += '<select name="location_id" class="form-select atlas-form-control" required>';
    cands.locations.forEach(function (l) {
      var sel = (presetLocId && l.id === presetLocId) ? ' selected' : '';
      html += '<option value="' + htmlEscape(l.id) + '"' + sel + '>' + htmlEscape(l.name) + (l.category ? ' · ' + htmlEscape(l.category) : '') + '</option>';
    });
    html += '</select>';
    if (presetLocName) {
      html += '<div class="text-xs text-mute" style="margin-top: -0.4rem">Pinning to: ' + htmlEscape(presetLocName) + '</div>';
    }
    // Kind
    html += '<label class="atlas-form-label">Kind</label>';
    html += '<select name="kind" class="form-select atlas-form-control">';
    cands.pin_kinds.forEach(function (k) {
      html += '<option value="' + htmlEscape(k.value) + '">' + htmlEscape(k.label) + '</option>';
    });
    html += '</select>';
    // Note
    html += '<label class="atlas-form-label">Note (optional)</label>';
    html += '<input type="text" name="note" class="form-input atlas-form-control" placeholder="e.g. hiding after the duel">';
    // Submit
    html += '<div class="atlas-pin-form-actions">';
    html += '<button type="button" class="btn btn-sm btn-ghost" onclick="atlasClosePinModal()">Cancel</button>';
    html += '<button type="submit" class="btn btn-sm btn-primary">Pin</button>';
    html += '</div>';
    html += '</form>';
    body.innerHTML = html;
  }

  window.atlasClosePinModal = function () {
    var backdrop = $('#atlasPinBackdrop');
    if (backdrop) backdrop.hidden = true;
    document.body.style.overflow = '';
  };

  window.atlasSubmitPin = function (e) {
    e.preventDefault();
    var form = e.target;
    var data = {
      character_id: form.character_id.value,
      location_id: form.location_id.value,
      kind: form.kind.value,
      note: form.note.value,
    };
    fetch('/atlas/api/pin', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data),
    }).then(function (r) { return r.json(); }).then(function (result) {
      if (result.ok) {
        // v7.6 fix: update in place — no full page reload. The pins list,
        // the tree counts and the stats strip all refresh from the server.
        atlasClosePinModal();
        refreshPins();
        refreshTree();
        refreshStats();
      } else {
        alert('Failed: ' + (result.error || 'unknown'));
      }
    });
  };

  // ---- Init ----
  function init() {
    renderTree();
    renderPins();
    renderRoutes();

    // ESC closes modal
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var backdrop = $('#atlasPinBackdrop');
        if (backdrop && !backdrop.hidden) atlasClosePinModal();
      }
    });
    // Click outside modal closes
    var backdrop = $('#atlasPinBackdrop');
    if (backdrop) {
      backdrop.addEventListener('click', function (e) {
        if (e.target === backdrop) atlasClosePinModal();
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
