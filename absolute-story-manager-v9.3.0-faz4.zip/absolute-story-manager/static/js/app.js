/* Absolute Story Manager — app.js
   CSRF, keyboard shortcuts, undo/redo, toasts, theme/sidebar toggle, helpers.
*/

// ---- CSRF helper ----
function getCsrfToken() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.content : "";
}

// ---- Fetch wrapper + HTML escape: single source in core.js (M-05, v9.1.0).
// app.js formerly redefined asmFetch and escapeHtml here — core.js (loaded
// first in base.html) now owns both. This file only CONSUMES them.

// ---- v6.2: SSE streaming helper with stop control ----
// Usage:
//   const stream = asmStream("/ai-copilot/api/suggest-stream", {body: {...}}, {
//     onContext(ctx) {}, onChunk(text) {}, onDone(fullText, ctx) {}, onError(msg) {}
//   });
//   stream.stop();  // aborts the request
async function asmStream(url, opts = {}, handlers = {}) {
  const controller = new AbortController();
  const h = handlers || {};
  const handle = { stop: () => controller.abort() };
  let full = "";
  let ctx = null;
  // Fire onStart IMMEDIATELY (before fetch) so the caller can wire up the
  // stop button while the request is still in flight.
  if (h.onStart) h.onStart(handle);
  try {
    const res = await fetch(url, {
      method: opts.method || "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCsrfToken(),
      },
      body: typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body || {}),
      signal: controller.signal,
    });
    if (!res.ok || !res.body) {
      let msg = "Stream failed (" + res.status + ")";
      try { const j = await res.json(); if (j.error) msg = j.error; } catch (e) {}
      if (h.onError) h.onError(msg);
      return handle;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      // SSE events are separated by a blank line
      const parts = buffer.split("\n\n");
      buffer = parts.pop() || "";
      for (const part of parts) {
        const line = part.startsWith("data: ") ? part.slice(6) : (part.startsWith("data:") ? part.slice(5) : null);
        if (line === null) continue;
        let ev;
        try { ev = JSON.parse(line); }
        catch (e) { continue; }
        if (ev.type === "context") {
          ctx = ev.context || null;
          if (h.onContext) h.onContext(ctx);
        } else if (ev.type === "chunk" && ev.text) {
          full += ev.text;
          if (h.onChunk) h.onChunk(ev.text, full);
        } else if (ev.type === "done") {
          if (h.onDone) h.onDone(full, ctx);
          if (ev.error && h.onError) h.onError(ev.error);
          return handle;
        } else if (ev.type === "error") {
          if (h.onError) h.onError(ev.message || "Stream error");
          if (h.onDone) h.onDone(full, ctx);
          return handle;
        }
      }
    }
    // Stream ended without explicit done
    if (h.onDone) h.onDone(full, ctx);
  } catch (err) {
    if (err.name === "AbortError") {
      if (h.onAbort) h.onAbort(full, ctx);
    } else if (h.onError) {
      h.onError(err.message || "Stream failed");
    }
  }
  return handle;
}

// ---- Form submission helper (sends FormData, not JSON) ----
// Use this for all form POSTs so request.form works on the backend.
async function submitForm(formEl, url) {
  const fd = new FormData(formEl);
  const res = await fetch(url || formEl.action, {
    method: "POST",
    headers: { "X-CSRFToken": getCsrfToken() },
    body: fd
  });
  let data;
  try { data = await res.json(); }
  catch { data = { ok: false, error: "Invalid response from server" }; }
  return data;
}

// ---- Toast system ----
function showToast(message, kind = "info", duration = 3000) {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const t = document.createElement("div");
  t.className = `toast ${kind}`;
  t.innerHTML = `<span>${_toastIcon(kind)}</span><span>${escapeHtml(message)}</span>`;
  container.appendChild(t);
  setTimeout(() => {
    t.classList.add("removing");
    setTimeout(() => t.remove(), 200);
  }, duration);
}

function _toastIcon(kind) {
  // v6.1: SVG icons from the page sprite (falls back to text glyphs)
  const ids = { success: "check-circle", error: "x", warning: "warning", info: "info" };
  const id = ids[kind] || "info";
  if (document.querySelector("#i-" + id)) {
    return `<svg class="ic"><use href="#i-${id}"></use></svg>`;
  }
  return { success: "✓", error: "✕", warning: "⚠", info: "ℹ" }[kind] || "ℹ";
}

// ---- Theme + sidebar toggle (persisted via /settings/save) ----
function toggleTheme() {
  const html = document.documentElement;
  const current = html.getAttribute("data-theme") || "dark";
  const next = current === "dark" ? "light" : "dark";
  html.setAttribute("data-theme", next);
  // Persist
  asmFetch("/settings/save", {
    method: "POST",
    body: { theme: next }
  }).then(({ data }) => {
    if (data.ok) showToast(`Theme: ${next}`, "info", 1500);
  });
}

function toggleSidebar() {
  const shell = document.getElementById("appShell");
  if (!shell) return;
  const collapsed = shell.getAttribute("data-sidebar-collapsed") === "true";
  const next = !collapsed;
  shell.setAttribute("data-sidebar-collapsed", next ? "true" : "false");
  asmFetch("/settings/save", {
    method: "POST",
    body: { sidebar_collapsed: next ? "true" : "false" }
  });
}

function toggleMobileNav() {
  const shell = document.getElementById("appShell");
  if (!shell) return;
  shell.classList.toggle("mobile-nav-open");
  // Close on click outside
  if (shell.classList.contains("mobile-nav-open")) {
    setTimeout(() => {
      document.addEventListener("click", function closeNav(e) {
        if (!e.target.closest(".sidebar") && !e.target.closest(".mobile-menu-btn")) {
          shell.classList.remove("mobile-nav-open");
          document.removeEventListener("click", closeNav);
        }
      });
    }, 100);
  }
}

// ---- Undo / Redo (command pattern, in-memory + DB-backed for deletes) ----
const _undoStack = [];
const _redoStack = [];
const MAX_UNDO = 100;

function pushUndo(label, undoFn, redoFn) {
  _undoStack.push({ label, undoFn, redoFn });
  if (_undoStack.length > MAX_UNDO) _undoStack.shift();
  _redoStack.length = 0;
  _updateUndoButtons();
}

function undo() {
  // First try DB-backed undo (persistent delete undo)
  asmFetch("/undo", { method: "POST", body: {} }).then(({ data }) => {
    if (data.ok) {
      showToast(`Undid: ${data.label}`, "success");
      setTimeout(() => location.reload(), 600);
    } else {
      // Fall back to in-memory undo
      const cmd = _undoStack.pop();
      if (!cmd) {
        showToast("Nothing to undo.", "info", 1500);
        return;
      }
      cmd.undoFn();
      _redoStack.push(cmd);
      _updateUndoButtons();
      showToast(`Undid: ${cmd.label}`, "info", 1500);
    }
  });
}

function redo() {
  const cmd = _redoStack.pop();
  if (!cmd) {
    showToast("Nothing to redo.", "info", 1500);
    return;
  }
  cmd.redoFn();
  _undoStack.push(cmd);
  _updateUndoButtons();
  showToast(`Redid: ${cmd.label}`, "info", 1500);
}

function _updateUndoButtons() {
  const undoBtn = document.getElementById("undoBtn");
  const redoBtn = document.getElementById("redoBtn");
  if (undoBtn) undoBtn.disabled = _undoStack.length === 0;
  if (redoBtn) redoBtn.disabled = _redoStack.length === 0;
}

// ---- Delete with undo toast (10-second window) ----
function showUndoToast(label, onUndo) {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const t = document.createElement("div");
  t.className = "toast warning";
  t.style.minWidth = "320px";
  t.innerHTML = `
    <span style="flex: 1">${escapeHtml(label)}. Undo?</span>
    <button class="btn btn-sm btn-primary" style="margin-left: 0.5rem">Undo</button>
  `;
  container.appendChild(t);
  let undone = false;
  const undoBtn = t.querySelector("button");
  undoBtn.onclick = () => {
    undone = true;
    t.classList.add("removing");
    setTimeout(() => t.remove(), 200);
    if (onUndo) onUndo();
  };
  // Auto-dismiss after 10 seconds
  setTimeout(() => {
    if (!undone) {
      t.classList.add("removing");
      setTimeout(() => t.remove(), 200);
    }
  }, 10000);
}

// ---- Keyboard shortcuts ----
document.addEventListener("keydown", (e) => {
  // v8.2 fix: `e.key` can be UNDEFINED on some synthetic/IME/old-Android
  // keyboard events — every `e.key.toLowerCase()` below then threw
  // "TypeError: Cannot read properties of undefined (reading 'toLowerCase')"
  // (reported at app.js:342) and killed the whole shortcuts listener.
  // Normalise ONCE here; the rest of the handler stays readable.
  const rawKey = typeof e.key === "string" ? e.key : "";
  const key = rawKey.length === 1 ? rawKey.toLowerCase() : rawKey;
  // Skip when typing in inputs/textareas (except for Ctrl+S / Ctrl+Z)
  const target = e.target;
  const isTyping = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable);

  // Ctrl+S — save (let editor handle it; otherwise prevent default)
  if ((e.ctrlKey || e.metaKey) && key === "s") {
    e.preventDefault();
    return;
  }
  // Ctrl+Z / Ctrl+Shift+Z
  if ((e.ctrlKey || e.metaKey) && key === "z") {
    if (e.shiftKey) { e.preventDefault(); redo(); }
    else if (!isTyping) { e.preventDefault(); undo(); }
    return;
  }
  // Ctrl+N — Quick Capture composer (v7.7: unified capture surface;
  // previously this dead-code branch raced a later handler that redirected
  // to /chapters/new, contradicting the shortcuts modal docs).
  // NOTE: Ctrl+Shift+N is owned by quick_capture.js (toggle behavior) —
  // do NOT bind it here, both are document-level listeners and would race.
  if ((e.ctrlKey || e.metaKey) && !e.shiftKey && key === "n") {
    e.preventDefault();
    _openCapture();
    return;
  }
  // "/" — focus search (if not typing)
  if (key === "/" && !isTyping) {
    e.preventDefault();
    const input = document.querySelector('input[name="q"]');
    if (input) input.focus();
    return;
  }
  // Ctrl+P / Cmd+P — Quick Switch
  if ((e.ctrlKey || e.metaKey) && key === "p") {
    e.preventDefault();
    openQuickSwitch();
    return;
  }
  // Escape — close modal / exit distraction-free
  if (key === "Escape") {
    const modal = document.querySelector(".modal-backdrop");
    if (modal) { modal.remove(); return; }
    if (document.body.classList.contains("distraction-free")) {
      document.body.classList.remove("distraction-free");
      return;
    }
  }
  // F11 — distraction-free
  if (key === "F11") {
    e.preventDefault();
    document.body.classList.toggle("distraction-free");
  }
  // Ctrl+E — toggle edit mode on detail pages
  if ((e.ctrlKey || e.metaKey) && key === "e") {
    e.preventDefault();
    const editLink = document.querySelector('a[href*="/edit"]');
    if (editLink) {
      window.location.href = editLink.href;
    }
  }
  // v8.2: Reading Mode owns b/t/g/?/arrows while it is open — without this
  // check pressing "b" toggled BOTH the app sidebar and the reading bookmarks
  // panel, and arrow keys fought the reader's chapter navigation.
  const readingMode = document.body && document.body.getAttribute("data-reading-mode") === "1";
  if (readingMode && !isTyping && !e.ctrlKey && !e.metaKey && !e.altKey) {
    const owned = ["b", "t", "g", "h", "f", "?", "/", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "PageUp", "PageDown"];
    if (owned.includes(key)) return;
  }
  // "?" — open keyboard shortcuts cheatsheet
  if (key === "?" && !isTyping) {
    e.preventDefault();
    openShortcutsModal();
    return;
  }
  // "t" — toggle theme (when not typing)
  if (key === "t" && !isTyping && !e.ctrlKey && !e.metaKey && !e.altKey) {
    e.preventDefault();
    toggleTheme();
    return;
  }
  // "b" — toggle sidebar (when not typing)
  if (key === "b" && !isTyping && !e.ctrlKey && !e.metaKey && !e.altKey) {
    e.preventDefault();
    toggleSidebar();
    return;
  }
  // "g" chord — navigation prefix (when not typing)
  if (key === "g" && !isTyping && !e.ctrlKey && !e.metaKey && !e.altKey) {
    e.preventDefault();
    _awaitChord();
    return;
  }
});

// ---- "g" chord navigation: press g, then a second key ----
function _awaitChord() {
  const hint = document.createElement("div");
  hint.id = "chordHint";
  hint.style.cssText = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:var(--bg-elev-2);border:1px solid var(--accent);padding:0.5rem 1rem;border-radius:6px;z-index:9999;font-size:0.9rem;box-shadow:0 4px 12px rgba(0,0,0,0.3)";
  hint.innerHTML = "Press <kbd>g</kbd> + key… <span style='color:var(--text-mute);font-size:0.8em'>d=dashboard c=chapters k=characters p=plans w=world s=search n=notes i=inspiration e=export x=settings h=hierarchy</span>";
  document.body.appendChild(hint);

  function cleanup() {
    hint.remove();
    document.removeEventListener("keydown", onChord, true);
  }
  function onChord(ev) {
    ev.preventDefault();
    ev.stopPropagation();
    cleanup();
    // v8.2: same undefined-key guard as the main shortcuts handler
    const k = typeof ev.key === "string" ? ev.key.toLowerCase() : "";
    const map = {
      d: "/dashboard/",     // dashboard
      c: "/chapters/",      // chapters
      k: "/characters/",    // characters
      p: "/plans/board",    // plans / kanban
      w: "/world/",         // world
      h: "/world/hierarchy",// v7.4 — location hierarchy tree
      s: "/search/",        // search
      n: "/notes/",         // notes
      i: "/inspiration/",   // inspiration
      t: "/plot-templates/",// plot structures
      e: "/export/",        // export
      x: "/settings/",      // settings
      "?": "/inspiration/", // also accepts ? for inspiration
    };
    if (map[k]) window.location.href = map[k];
  }
  document.addEventListener("keydown", onChord, true);
  // Auto-cancel after 1.5s
  setTimeout(() => { if (document.getElementById("chordHint")) cleanup(); }, 1500);
}

// ---- Keyboard shortcuts cheatsheet modal ----
function openShortcutsModal() {
  const groups = [
    {
      title: "Global",
      icon: "🌐",
      shortcuts: [
        { keys: "Ctrl/⌘ + K", desc: "Command Palette — jump anywhere (v6.0)" },
        { keys: "Ctrl/⌘ + P", desc: "Quick Switch (search + commands)" },
        { keys: "Ctrl/⌘ + N", desc: "Quick Capture composer — Note/Chapter/Journal/Snippet" },
        { keys: "Ctrl/⌘ + Shift + N", desc: "Quick Capture composer (same as Ctrl+N)" },
        { keys: "/",          desc: "Focus search box" },
        { keys: "?",          desc: "Open this shortcuts cheatsheet" },
        { keys: "Esc",        desc: "Close modal / exit distraction-free / exit Focus Mode 2.0" },
        { keys: "F11",        desc: "Toggle distraction-free mode" },
        { keys: "t",          desc: "Toggle dark/light theme" },
        { keys: "b",          desc: "Toggle sidebar collapse" },
      ],
    },
    {
      title: "Navigation (press g, then a letter)",
      icon: "🧭",
      shortcuts: [
        { keys: "g  d", desc: "Dashboard" },
        { keys: "g  c", desc: "Chapters" },
        { keys: "g  k", desc: "Characters" },
        { keys: "g  p", desc: "Plans / Kanban" },
        { keys: "g  w", desc: "World Library" },
        { keys: "g  s", desc: "Search" },
        { keys: "g  n", desc: "Notes & Ideas" },
        { keys: "g  i", desc: "Inspiration Hub" },
        { keys: "g  t", desc: "Theme Editor" },
        { keys: "g  e", desc: "Export Center" },
        { keys: "g  x", desc: "Settings" },
        { keys: "g  m", desc: "Milestones" },
        { keys: "g  g", desc: "Goals Calendar" },
        { keys: "g  a", desc: "Analytics" },
        { keys: "g  f", desc: "Focus Mode" },
        { keys: "g  r", desc: "Reading Mode" },
        { keys: "g  l", desc: "Story Lint" },
        { keys: "g  j", desc: "Sessions / Journal" },
      ],
    },
    {
      title: "Detail page shortcuts",
      icon: "📄",
      shortcuts: [
        { keys: "e",          desc: "Edit this item (chapter/character/world/plan)" },
        { keys: "b",          desc: "Back to list view" },
        { keys: "j / →",     desc: "Next chapter (chapter detail only)" },
        { keys: "k / ←",     desc: "Previous chapter (chapter detail only)" },
      ],
    },
    {
      title: "Notes & Hierarchy shortcuts (v7.4)",
      icon: "📖",
      shortcuts: [
        { keys: "←",         desc: "Previous note (in read modal)" },
        { keys: "→",         desc: "Next note (in read modal)" },
        { keys: "f",         desc: "Fullscreen note read modal" },
        { keys: "Esc",       desc: "Close note read modal" },
        { keys: "Drag",      desc: "Drag a hierarchy card onto another to reparent it" },
        { keys: "g  h",      desc: "Location Hierarchy tree" },
      ],
    },
    {
      title: "Editor shortcuts",
      icon: "✎",
      shortcuts: [
        { keys: "Alt + A",          desc: "AI Assistant drawer — insert streaming suggestions at the cursor (v6.3)" },
        { keys: "Ctrl/⌘ + S",       desc: "Save version snapshot" },
        { keys: "Ctrl/⌘ + F",       desc: "Find in chapter" },
        { keys: "Ctrl/⌘ + Shift + F", desc: "Find & Replace" },
        { keys: "Ctrl/⌘ + /",       desc: "Show editor shortcuts" },
        { keys: "Ctrl/⌘ + Enter",   desc: "Capture note (in editor)" },
      ],
    },
    {
      title: "Quick Switch commands (type > in Ctrl+P)",
      icon: "⚡",
      shortcuts: [
        { keys: "> new",    desc: "Create new items" },
        { keys: "> settings", desc: "Open settings" },
        { keys: "> theme",  desc: "Open theme editor" },
        { keys: "> note",   desc: "Quick capture note" },
        { keys: "> toggle", desc: "Toggle theme" },
      ],
    },
  ];
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal modal-lg">
      <div class="modal-header">
        <h3 class="modal-title">⌨ Keyboard Shortcuts</h3>
      </div>
      <div class="modal-body" style="max-height:70vh;overflow-y:auto">
        ${groups.map(g => `
          <div style="margin-bottom: 1.25rem">
            <div style="font-weight:600;margin-bottom:0.5rem;color:var(--accent)">${g.icon} ${g.title}</div>
            <table style="width:100%;border-collapse:collapse">
              ${g.shortcuts.map(s => `
                <tr>
                  <td style="padding:0.35rem 0;width:40%">
                    <kbd style="background:var(--bg-elev-3);border:1px solid var(--border);border-radius:4px;padding:2px 8px;font-family:monospace;font-size:0.85rem">${escapeHtml(s.keys)}</kbd>
                  </td>
                  <td style="padding:0.35rem 0;color:var(--text)">${escapeHtml(s.desc)}</td>
                </tr>
              `).join("")}
            </table>
          </div>
        `).join("")}
        <div style="margin-top:1rem;padding:0.75rem;background:var(--bg-elev-2);border-radius:6px;font-size:0.85rem;color:var(--text-mute)">
          Tip: most single-key shortcuts (like <kbd>t</kbd>, <kbd>b</kbd>, <kbd>?</kbd>) are disabled while you're typing in an input or textarea.
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" data-act="close">Close</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.querySelector('[data-act="close"]').onclick = () => backdrop.remove();
  backdrop.addEventListener("click", (ev) => { if (ev.target === backdrop) backdrop.remove(); });
}

// ---- Confirmation modal ----
function confirmDialog(message, opts = {}) {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <h3 class="modal-title">${escapeHtml(opts.title || "Confirm")}</h3>
        </div>
        <div class="modal-body">
          <p style="margin:0;color:var(--text)">${escapeHtml(message)}</p>
        </div>
        <div class="modal-footer">
          <button class="btn" data-act="cancel">Cancel</button>
          <button class="btn ${opts.danger ? 'btn-danger' : 'btn-primary'}" data-act="ok">${escapeHtml(opts.okLabel || "Confirm")}</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (ev) => {
      if (ev.target === backdrop) { backdrop.remove(); resolve(false); }
    });
    backdrop.querySelector('[data-act="cancel"]').onclick = () => { backdrop.remove(); resolve(false); };
    backdrop.querySelector('[data-act="ok"]').onclick = () => { backdrop.remove(); resolve(true); };
  });
}

// ---- Wire up undo/redo buttons ----
document.addEventListener("DOMContentLoaded", () => {
  const undoBtn = document.getElementById("undoBtn");
  const redoBtn = document.getElementById("redoBtn");
  if (undoBtn) undoBtn.addEventListener("click", undo);
  if (redoBtn) redoBtn.addEventListener("click", redo);
  _updateUndoButtons();
});

// ---- cycleStatus: click chapter status badge to cycle draft→revised→final ----
function cycleStatus(chapterId, currentStatus) {
  asmFetch(`/chapters/${chapterId}/cycle-status`, {
    method: "POST",
    body: {}
  }).then(({ data }) => {
    if (data.ok) {
      showToast(`Status → ${data.status}`, "success");
      setTimeout(() => location.reload(), 500);
    } else {
      showToast(data.error || "Failed", "error");
    }
  });
}

// ---- Export diff helper (client-side download) ----
function exportDiff(filename, content, format = "txt") {
  const blob = new Blob([content], { type: format === "html" ? "text/html" : "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ---- v7.5: Global error visibility net ---------------------------------------
// The recurring "page is dead, nothing responds" class of bug was ALWAYS a
// script error that failed silently (e.g. a Jinja/JS collision producing a
// SyntaxError in an inline block). From v7.5 on, no script error may ever be
// silent again: the user sees a visible toast with the file + line, which
// makes diagnosis immediate instead of "buttons just do nothing".
(function installGlobalErrorNet() {
  let lastToastAt = 0;
  function report(kind, msg) {
    const now = Date.now();
    if (now - lastToastAt < 2000) return;  // rate-limit error storms
    lastToastAt = now;
    try {
      if (typeof showToast === "function") {
        showToast(`UI error (${kind}): ${msg}. Some controls may not work — see console (F12).`, "error", 8000);
      }
    } catch (e) { /* toast itself broken — nothing more we can do */ }
    console.error(`[ASM ${kind}]`, msg);
  }
  window.addEventListener("error", function (e) {
    if (!e || !e.message) return;
    const src = e.filename ? e.filename.split("/").pop() : "page";
    report("script", `${e.message} (${src}:${e.lineno || "?"})`);
  });
  window.addEventListener("unhandledrejection", function (e) {
    const reason = e && e.reason;
    const msg = reason && reason.message ? reason.message : String(reason || "unknown");
    report("async", msg);
  });
})();

// ===========================================================================
// v8.0 — PWA: service worker lifecycle, install prompt, connectivity watch
// ===========================================================================
(function () {
  // ---- connectivity badge ----
  function syncBadge() {
    const badge = document.getElementById("offlineBadge");
    if (!badge) return;
    badge.hidden = navigator.onLine;
  }
  window.addEventListener("online", () => {
    syncBadge();
    showToast("Back online — saves enabled again", "success", 2500);
  });
  window.addEventListener("offline", () => {
    syncBadge();
    showToast("You are offline — reading from cache, saves paused", "warning", 4000);
  });
  syncBadge();

  // ---- install prompt ----
  let _installEvent = null;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    _installEvent = e;
    const btn = document.getElementById("pwaInstallBtn");
    if (btn) btn.style.display = "";
  });
  window.asmInstallApp = async function () {
    if (!_installEvent) return;
    _installEvent.prompt();
    const choice = await _installEvent.userChoice;
    if (choice && choice.outcome === "accepted") {
      showToast("Installing ASM… check your desktop / home screen", "success");
    }
    _installEvent = null;
    const btn = document.getElementById("pwaInstallBtn");
    if (btn) btn.style.display = "none";
  };
  window.addEventListener("appinstalled", () => {
    const btn = document.getElementById("pwaInstallBtn");
    if (btn) btn.style.display = "none";
    showToast("ASM installed — enjoy the app!", "success");
  });

  // ---- service worker registration + update flow ----
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", async () => {
      try {
        const reg = await navigator.serviceWorker.register("/sw.js");
        let reloadFlag = false;
        window.addEventListener("controllerchange", () => {
          if (reloadFlag) window.location.reload();
        });

        function offerUpdate(worker) {
          reloadFlag = true;
          const t = document.createElement("div");
          t.className = "toast info";
          t.style.cursor = "pointer";
          t.innerHTML = "<span>ℹ</span><span><b>New version available.</b> Click to update &amp; reload.</span>";
          t.onclick = () => {
            worker.postMessage({ type: "SKIP_WAITING" });
            t.remove();
          };
          const container = document.getElementById("toastContainer");
          if (container) {
            container.appendChild(t);
            setTimeout(() => t.classList.add("removing"), 15000);
            setTimeout(() => t.remove(), 15200);
          }
        }

        // already-waiting worker (update landed while tab was closed)
        if (reg.waiting && navigator.serviceWorker.controller) offerUpdate(reg.waiting);
        // new worker finished installing while this tab is open
        reg.addEventListener("updatefound", () => {
          const nw = reg.installing;
          if (!nw) return;
          nw.addEventListener("statechange", () => {
            if (nw.state === "installed" && navigator.serviceWorker.controller) offerUpdate(nw);
          });
        });
      } catch (err) {
        console.warn("SW registration failed:", err);
      }
    });
  }
})();

// ---- Expose globally ----
window.asmFetch = asmFetch;
window.submitForm = submitForm;
window.getCsrfToken = getCsrfToken;
window.showToast = showToast;
window.pushUndo = pushUndo;
window.undo = undo;
window.redo = redo;
window.toggleTheme = toggleTheme;
window.toggleSidebar = toggleSidebar;
window.toggleMobileNav = toggleMobileNav;
window.confirmDialog = confirmDialog;
window.cycleStatus = cycleStatus;
window.exportDiff = exportDiff;
window.escapeHtml = escapeHtml;
window.showUndoToast = showUndoToast;

// ---- Quick Switch (Ctrl+P) ----
let _qsSelected = -1;
let _qsResults = [];
const _QS_RECENT_KEY = "asm:qs-recent";
const _QS_RECENT_MAX = 8;

function _qsGetRecent() {
  try {
    return JSON.parse(localStorage.getItem(_QS_RECENT_KEY) || "[]");
  } catch (e) { return []; }
}

function _qsAddRecent(item) {
  if (!item || !item.url) return;
  let recent = _qsGetRecent();
  // Remove if already present (by url)
  recent = recent.filter(r => r.url !== item.url);
  // Add to front
  recent.unshift({ type: item.type, title: item.title, subtitle: item.subtitle || "", icon: item.icon || "▸", url: item.url, ts: Date.now() });
  // Cap to max
  recent = recent.slice(0, _QS_RECENT_MAX);
  try { localStorage.setItem(_QS_RECENT_KEY, JSON.stringify(recent)); } catch (e) {}
}

function openQuickSwitch() {
  const overlay = document.getElementById("quickSwitchOverlay");
  if (!overlay) return;
  overlay.style.display = "flex";
  const input = document.getElementById("quickSwitchInput");
  input.value = "";
  input.focus();
  _qsResults = [];
  _qsSelected = -1;
  // Show recent + nav items immediately on empty query
  _qsSearch("");
}

function closeQuickSwitch() {
  const overlay = document.getElementById("quickSwitchOverlay");
  if (overlay) overlay.style.display = "none";
}

async function _qsSearch(q) {
  // If query starts with `>` — show command palette (commands only)
  if (q.startsWith(">")) {
    const cmd = q.slice(1).trim().toLowerCase();
    const commands = [
      { type: "nav", title: "New Chapter", subtitle: "Create a new chapter", icon: "+", url: "/chapters/new", _cmd: true },
      { type: "nav", title: "New Character", subtitle: "Create a new character", icon: "+", url: "/characters/new", _cmd: true },
      { type: "nav", title: "New Plan Item", subtitle: "Create a new plan item", icon: "+", url: "/plans/new", _cmd: true },
      { type: "nav", title: "New World Entry", subtitle: "Create a new world entry", icon: "+", url: "/world/new", _cmd: true },
      { type: "nav", title: "Quick Note", subtitle: "Capture a note instantly (Ctrl+N)", icon: "⚡", url: "javascript:void(0)", action: "quickNote", _cmd: true },
      { type: "nav", title: "Toggle Theme", subtitle: "Switch dark/light", icon: "◐", url: "javascript:void(0)", action: "toggleTheme", _cmd: true },
      { type: "nav", title: "Settings", subtitle: "Open settings page", icon: "⚙", url: "/settings/", _cmd: true },
      { type: "nav", title: "Theme Editor", subtitle: "Customize colors and fonts", icon: "🎨", url: "/theme/", _cmd: true },
      { type: "nav", title: "AI Copilot", subtitle: "AI-powered writing suggestions", icon: "🤖", url: "/ai-copilot/", _cmd: true },
      { type: "nav", title: "Quick Capture Note", subtitle: "Open the note modal", icon: "📥", url: "javascript:void(0)", action: "quickNote", _cmd: true },
      { type: "nav", title: "Export Center", subtitle: "Export manuscript", icon: "↧", url: "/export/", _cmd: true },
      { type: "nav", title: "Story Lint", subtitle: "Run consistency checks", icon: "🔍", url: "/lint", _cmd: true },
      { type: "nav", title: "Sessions", subtitle: "View writing sessions", icon: "🍅", url: "/sessions/", _cmd: true },
      { type: "nav", title: "Goals Calendar", subtitle: "View writing goals", icon: "📅", url: "/goals/", _cmd: true },
    ];
    _qsResults = commands.filter(c => !cmd || c.title.toLowerCase().includes(cmd) || c.subtitle.toLowerCase().includes(cmd));
    _qsSelected = _qsResults.length > 0 ? 0 : -1;
    _qsRender();
    return;
  }
  // If empty query, show recent items + recently visited + nav items
  if (!q) {
    const recent = _qsGetRecent();
    const recentVisits = _getRecentVisits();
    // Fetch nav items from server (empty query returns them)
    const res = await fetch(`/search-all?q=`);
    const data = await res.json();
    const navItems = (data.results || []).filter(r => r.type === "nav");
    _qsResults = [];
    // Recent visits (most-recent first) — uses clock icon
    for (const v of recentVisits) {
      _qsResults.push({
        type: "visited",
        title: v.title,
        subtitle: v.path,
        icon: "🕒",
        url: v.path,
        _visited: true,
      });
    }
    if (recent.length) {
      for (const r of recent) {
        _qsResults.push({ ...r, type: r.type + "_recent", _recent: true, icon: "⏱" });
      }
    }
    _qsResults.push(...navItems);
    _qsSelected = _qsResults.length > 0 ? 0 : -1;
    _qsRender();
    return;
  }
  const res = await fetch(`/search-all?q=${encodeURIComponent(q)}`);
  const data = await res.json();
  let allResults = data.results || [];
  // Client-side fuzzy ranking: prefer items where the query appears as a subsequence
  // (matches "abc" → "a...b...c" anywhere in title) — ranks higher.
  if (q && allResults.length > 1) {
    const lowerQ = q.toLowerCase();
    allResults = allResults.map(r => {
      const titleLower = (r.title || "").toLowerCase();
      const subseqScore = _qsSubsequenceScore(lowerQ, titleLower);
      const containsScore = titleLower.includes(lowerQ) ? 100 : 0;
      r._score = subseqScore + containsScore;
      return r;
    }).sort((a, b) => (b._score || 0) - (a._score || 0));
  }
  _qsResults = allResults;
  _qsSelected = _qsResults.length > 0 ? 0 : -1;
  _qsRender();
}

function _qsSubsequenceScore(needle, haystack) {
  // Returns a score 0-100 based on how compactly `needle` appears as a subsequence in `haystack`.
  // Higher = better match (more compact, earlier in haystack).
  if (!needle) return 0;
  let ni = 0;
  let lastMatch = -2;
  let gapSum = 0;
  for (let hi = 0; hi < haystack.length && ni < needle.length; hi++) {
    if (haystack[hi] === needle[ni]) {
      if (lastMatch >= 0) gapSum += (hi - lastMatch - 1);
      lastMatch = hi;
      ni++;
    }
  }
  if (ni === needle.length) {
    // All chars matched as subsequence. Score: shorter gaps = higher score.
    return Math.max(0, 80 - gapSum);
  }
  return 0;
}

function _qsRender() {
  const container = document.getElementById("quickSwitchResults");
  if (!_qsResults.length) {
    container.innerHTML = '<div class="quickswitch-empty">No results found. Try a different search term.</div>';
    return;
  }
  // Group by type
  const groups = {};
  const groupOrder = ["Visited", "Recent", "chapter_recent", "character_recent", "plan_recent", "world_entry_recent", "Chapters", "Characters", "Plans", "World", "Navigation", "Other"];
  for (const r of _qsResults) {
    let label;
    if (r._visited) {
      label = "Visited";
    } else if (r._recent) {
      label = "Recent";
    } else {
      label = {chapter:"Chapters",character:"Characters",plan:"Plans",world_entry:"World",nav:"Navigation"}[r.type] || "Other";
    }
    (groups[label] = groups[label] || []).push(r);
  }
  // Sort groups: Recent first, then by groupOrder
  const sortedGroups = Object.entries(groups).sort((a, b) => {
    const ai = groupOrder.indexOf(a[0]);
    const bi = groupOrder.indexOf(b[0]);
    return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
  });
  let html = "";
  let idx = 0;
  for (const [label, items] of sortedGroups) {
    // Use "Commands" label if all items in this group are commands
    let groupLabel = label;
    if (items.length > 0 && items.every(i => i._cmd)) {
      groupLabel = "⚡ Commands";
    }
    html += `<div class="quickswitch-section-label">${escapeHtml(groupLabel)} <span class="qs-count">(${items.length})</span></div>`;
    for (const item of items) {
      const cls = idx === _qsSelected ? "quickswitch-item selected" : "quickswitch-item";
      const icon = item.icon || "▸";
      const cmdBadge = item._cmd ? '<span class="qs-cmd-badge" style="font-size: 0.6rem; padding: 0.1rem 0.4rem; background: var(--accent-soft); color: var(--accent-hover); border-radius: 4px; margin-left: 0.5rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em">cmd</span>' : '';
      // For command items, use a button instead of link (href="#" so it doesn't navigate)
      const tag = item._cmd ? 'a' : 'a';
      const href = item._cmd ? 'javascript:void(0)' : item.url;
      html += `<${tag} class="${cls}" data-idx="${idx}" href="${href}" onclick="_qsTrackClick(${idx})">
        <span class="qs-icon ${item._recent ? 'recent' : ''}">${icon}</span>
        <div class="qs-content">
          <div class="qs-title">${escapeHtml(item.title)}${cmdBadge}</div>
          <div class="qs-sub">${escapeHtml(item.subtitle || "")}</div>
        </div>
      </${tag}>`;
      idx++;
    }
  }
  container.innerHTML = html;
  // Scroll selected into view
  const sel = container.querySelector(".selected");
  if (sel) sel.scrollIntoView({ block: "nearest" });
}

function _qsTrackClick(idx) {
  if (idx >= 0 && _qsResults[idx]) {
    const item = _qsResults[idx];
    _qsAddRecent(item);
    _qsExecuteItem(item);
  }
}

// Quick Switch keyboard navigation
document.addEventListener("keydown", (e) => {
  const overlay = document.getElementById("quickSwitchOverlay");
  if (!overlay || overlay.style.display === "none") return;
  if (e.key === "Escape") { closeQuickSwitch(); e.preventDefault(); return; }
  if (e.key === "ArrowDown") {
    e.preventDefault();
    if (_qsResults.length) {
      _qsSelected = (_qsSelected + 1) % _qsResults.length;
      _qsRender();
    }
    return;
  }
  if (e.key === "ArrowUp") {
    e.preventDefault();
    if (_qsResults.length) {
      _qsSelected = (_qsSelected - 1 + _qsResults.length) % _qsResults.length;
      _qsRender();
    }
    return;
  }
  if (e.key === "Enter") {
    e.preventDefault();
    if (_qsSelected >= 0 && _qsResults[_qsSelected]) {
      const item = _qsResults[_qsSelected];
      _qsAddRecent(item);
      _qsExecuteItem(item);
    }
    return;
  }
});

// Execute an item — either navigate to URL or run an action (for commands)
function _qsExecuteItem(item) {
  if (!item) return;
  if (item.action === "quickNote") {
    closeQuickSwitch();
    setTimeout(() => (window.asmQuickCapture || openGlobalNoteCapture)(), 100);
    return;
  }
  if (item.action === "toggleTheme") {
    closeQuickSwitch();
    setTimeout(() => toggleTheme(), 100);
    return;
  }
  // Default: navigate
  if (item.url && item.url !== "javascript:void(0)") {
    window.location.href = item.url;
  } else {
    closeQuickSwitch();
  }
}

// Quick Switch input listener
document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("quickSwitchInput");
  if (!input) return;
  let debounce = null;
  input.addEventListener("input", () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => _qsSearch(input.value.trim()), 150);
  });
  // Click outside to close
  document.getElementById("quickSwitchOverlay")?.addEventListener("click", (e) => {
    if (e.target.id === "quickSwitchOverlay") closeQuickSwitch();
  });
  // Click outside to close Quick Add menu
  document.addEventListener("click", (e) => {
    const menu = document.getElementById("quickAddMenu");
    if (!menu || menu.classList.contains("hidden")) return;
    if (!e.target.closest("#quickAddMenu") && !e.target.closest(".relative")) {
      menu.classList.add("hidden");
    }
  });
});

window.openQuickSwitch = openQuickSwitch;
window.closeQuickSwitch = closeQuickSwitch;
window._qsTrackClick = _qsTrackClick;
window._qsExecuteItem = _qsExecuteItem;

// ---- Sidebar footer: Today's progress mini-widget ----
// Polls /goals/api/progress every 60s, updates the small progress bar + word count
async function _refreshSidebarTodayProgress() {
  const wordsEl = document.getElementById("sidebarTodayWords");
  const barEl = document.getElementById("sidebarTodayBar");
  if (!wordsEl || !barEl) return;
  try {
    const res = await fetch("/goals/api/progress");
    const data = await res.json();
    if (!data.ok) return;
    const today = data.today || {};
    const words = today.words || 0;
    const goal = today.goal || 0;
    const pct = Math.min(100, Math.round(today.pct || 0));
    wordsEl.textContent = goal > 0 ? `${words} / ${goal}` : `${words} words`;
    barEl.style.width = pct + "%";
    // Change color when goal met
    if (today.goal_met) {
      barEl.style.background = "var(--success)";
      wordsEl.style.color = "var(--success)";
    } else {
      barEl.style.background = "var(--accent)";
      wordsEl.style.color = "var(--accent-hover)";
    }
  } catch (e) { /* silent */ }
}
// Initial refresh + every 60s
document.addEventListener("DOMContentLoaded", () => {
  _refreshSidebarTodayProgress();
  setInterval(_refreshSidebarTodayProgress, 60000);
  // Track page visit for "Recently visited" feature
  _trackPageVisit();
  // Start vim-style g+key navigation listener
  _initVimNav();
});

// ---- Vim-style navigation (g then key) ----
let _vimPending = false;
let _vimTimeout = null;
function _initVimNav() {
  document.addEventListener("keydown", (e) => {
    const tag = (e.target.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || e.target.isContentEditable) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;

    if (!_vimPending) {
      if (e.key === "g") {
        _vimPending = true;
        clearTimeout(_vimTimeout);
        _vimTimeout = setTimeout(() => { _vimPending = false; }, 1000);
        e.preventDefault();
        return;
      }
    } else {
      _vimPending = false;
      clearTimeout(_vimTimeout);
      const map = {
        "d": "/",
        "c": "/chapters/",
        "k": "/characters/",
        "p": "/plans/",
        "w": "/world/",
        "s": "/search/",
        "n": "/notes/",
        "i": "/inspiration/",
        "t": "/theme/",
        "e": "/export/",
        "x": "/settings/",
        "m": "/milestones/",
        "g": "/goals/",
        "a": "/analytics/",
        "f": "/focus/",
        "r": "/reading/",
        "l": "/lint",
        "j": "/sessions/",
        "b": "/beta-reader",
      };
      if (map[e.key]) {
        e.preventDefault();
        window.location.href = map[e.key];
      }
    }
  });
}

// ---- Recently visited tracker ----
const _RECENT_VISITS_KEY = "asm:recent-visits";
const _RECENT_VISITS_MAX = 5;

function _trackPageVisit() {
  // Don't track search/API/static requests
  const path = window.location.pathname;
  if (path.startsWith("/static/") || path.startsWith("/search") ||
      path.includes("/api/") || path === "/") return;
  // Get page title
  const title = document.title.replace(" — ASM", "").trim() || path;
  let recent = [];
  try { recent = JSON.parse(localStorage.getItem(_RECENT_VISITS_KEY) || "[]"); } catch (e) {}
  // Remove if same path
  recent = recent.filter(r => r.path !== path);
  // Add to front
  recent.unshift({ path, title, ts: Date.now() });
  // Cap to 5
  recent = recent.slice(0, _RECENT_VISITS_MAX);
  try { localStorage.setItem(_RECENT_VISITS_KEY, JSON.stringify(recent)); } catch (e) {}
}

function _getRecentVisits() {
  try { return JSON.parse(localStorage.getItem(_RECENT_VISITS_KEY) || "[]"); }
  catch (e) { return []; }
}

// ---- Global Quick Capture (FAB + Ctrl+N) ----
function openGlobalNoteCapture() {
  // Build a modal that posts to /notes/api/new
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal" style="max-width: 500px">
      <div class="modal-header">
        <h3 class="modal-title">⚡ Quick Note</h3>
        <button class="btn btn-ghost btn-icon btn-sm" onclick="this.closest('.modal-backdrop').remove()">×</button>
      </div>
      <div class="modal-body">
        <div class="form-row">
          <label class="form-label text-xs text-mute">Category</label>
          <select id="qcCat" class="form-select">
            <option value="idea">💡 Idea</option>
            <option value="question">❓ Question</option>
            <option value="reminder">⏰ Reminder</option>
            <option value="reference">📚 Reference</option>
            <option value="scene_idea">🎬 Scene Idea</option>
            <option value="todo">✓ Todo</option>
          </select>
        </div>
        <div class="form-row">
          <input type="text" id="qcTitle" class="form-input" placeholder="Title (optional)…">
        </div>
        <div class="form-row">
          <textarea id="qcBody" class="form-textarea" rows="4" placeholder="Type your thought… (Ctrl+Enter to save)"></textarea>
        </div>
        <div class="form-row">
          <input type="text" id="qcTags" class="form-input" placeholder="Tags (comma-separated, optional)">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn" onclick="this.closest('.modal-backdrop').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="saveQuickNote(this)">💾 Save</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  setTimeout(() => document.getElementById("qcBody")?.focus(), 100);
  // Ctrl+Enter to save
  document.getElementById("qcBody").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      saveQuickNote(document.getElementById("qcBody"));
    }
  });
}
async function saveQuickNote(btn) {
  const backdrop = btn.closest(".modal-backdrop");
  const payload = {
    title: document.getElementById("qcTitle").value.trim(),
    body: document.getElementById("qcBody").value,
    category: document.getElementById("qcCat").value,
    tags: document.getElementById("qcTags").value.split(",").map(s => s.trim()).filter(Boolean),
    pinned: false,
    color: "#6366f1",
  };
  if (!payload.title && !payload.body) {
    showToast("Title or body required", "warning");
    return;
  }
  btn.textContent = "Saving…"; btn.disabled = true;
  try {
    const { data } = await asmFetch("/notes/api/new", { method: "POST", body: payload });
    if (data.ok) {
      showToast("⚡ Note captured!", "success");
      backdrop.remove();
    } else {
      showToast(data.error || "Save failed", "error");
      btn.textContent = "💾 Save"; btn.disabled = false;
    }
  } catch (err) {
    showToast("Save failed: " + err.message, "error");
    btn.textContent = "💾 Save"; btn.disabled = false;
  }
}
// _openCapture — single routing helper for Quick Capture.
// v7.7: the keydown binding lives in the main shortcuts handler at the top
// of this file (one source of truth); previously TWO document-level Ctrl+N
// listeners existed and the /chapters/new redirect silently won.
function _openCapture() {
  (window.asmQuickCapture || openGlobalNoteCapture)();
}
window.openGlobalNoteCapture = openGlobalNoteCapture;
window.saveQuickNote = saveQuickNote;

// ---- Global AI functions (available on every page when AI enabled) ----
async function aiConsistencyCheck() {
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal modal-lg">
      <div class="modal-header"><h3 class="modal-title">🔍 AI Consistency Check</h3></div>
      <div class="modal-body">
        <div id="ccStatus" class="text-sm text-dim">Scanning chapters against character/world DB…</div>
        <div id="ccResults" class="mt-3" style="max-height: 60vh; overflow-y: auto"></div>
      </div>
      <div class="modal-footer"><button class="btn" data-act="close">Close</button></div>
    </div>`;
  document.body.appendChild(backdrop);
  backdrop.querySelector('[data-act="close"]').onclick = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
  const { data } = await asmFetch("/ai/consistency-check", { method: "POST", body: {} });
  const status = document.getElementById("ccStatus");
  const results = document.getElementById("ccResults");
  if (data.ok) {
    status.textContent = `Found ${data.count} finding${data.count !== 1 ? 's' : ''}.`;
    if (data.findings && data.findings.length) {
      results.innerHTML = data.findings.map(f => `
        <div class="card mb-2" style="border-left: 3px solid ${f.severity === 'error' ? 'var(--danger)' : (f.severity === 'warning' ? 'var(--warning)' : 'var(--info)')}; padding: 0.6rem">
          <div class="flex items-center gap-2 mb-1">
            <span class="badge no-dot ${f.severity === 'error' ? 'danger' : (f.severity === 'warning' ? 'warning' : '')}">${f.severity}</span>
            <span class="badge no-dot" style="font-size: 0.6rem">${f.category}</span>
            ${f.chapter ? `<span class="text-mute text-xs">in "${escapeHtml(f.chapter)}"</span>` : ''}
          </div>
          <div class="text-sm" style="color: var(--text)">${escapeHtml(f.message)}</div>
        </div>`).join("");
    } else {
      results.innerHTML = '<div class="empty-state"><div class="empty-icon">✓</div><h3>No issues found</h3></div>';
    }
  } else {
    status.textContent = "Check failed: " + (data.error || "unknown error");
    status.style.color = "var(--danger)";
  }
}

async function aiNameGenerator() {
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal">
      <div class="modal-header"><h3 class="modal-title">🎲 AI Name Generator</h3></div>
      <div class="modal-body">
        <div class="card-grid cols-2 mb-3">
          <div class="form-row">
            <label class="form-label">Culture / Style</label>
            <select id="ngCulture" class="form-select">
              <option value="fantasy">Fantasy</option>
              <option value="medieval">Medieval European</option>
              <option value="norse">Norse</option>
              <option value="arabic">Arabic</option>
              <option value="japanese">Japanese</option>
              <option value="elvish">Elvish</option>
              <option value="dwarven">Dwarven</option>
              <option value="scifi">Sci-fi</option>
            </select>
          </div>
          <div class="form-row">
            <label class="form-label">Kind</label>
            <select id="ngKind" class="form-select">
              <option value="character">Character</option>
              <option value="location">Location</option>
              <option value="faction">Faction</option>
              <option value="artifact">Artifact</option>
            </select>
          </div>
        </div>
        <div id="ngResults" class="flex flex-col gap-2"></div>
      </div>
      <div class="modal-footer">
        <button class="btn" data-act="close">Close</button>
        <button class="btn btn-primary" data-act="gen">Generate</button>
      </div>
    </div>`;
  document.body.appendChild(backdrop);
  backdrop.querySelector('[data-act="close"]').onclick = () => backdrop.remove();
  backdrop.querySelector('[data-act="gen"]').onclick = async () => {
    const results = document.getElementById("ngResults");
    results.innerHTML = '<div class="text-mute text-sm">Generating…</div>';
    const { data } = await asmFetch("/ai/generate-name", {
      method: "POST",
      body: { culture: document.getElementById("ngCulture").value, kind: document.getElementById("ngKind").value }
    });
    if (data.ok && data.names && data.names.length) {
      results.innerHTML = data.names.map(n => `
        <div class="flex items-center gap-2" style="padding: 0.5rem; background: var(--bg-elev-2); border-radius: 6px">
          <span style="flex: 1; font-weight: 500">${escapeHtml(n)}</span>
          <button class="btn btn-ghost btn-sm" onclick="navigator.clipboard.writeText('${escapeHtml(n)}'); showToast('Copied.', 'success', 1200)">Copy</button>
        </div>`).join("");
    } else {
      results.innerHTML = `<div class="text-danger text-sm">${escapeHtml(data.error || 'Failed')}</div>`;
    }
  };
  backdrop.querySelector('[data-act="gen"]').click();
}

window.aiConsistencyCheck = aiConsistencyCheck;
window.aiNameGenerator = aiNameGenerator;

// ---- AI Loading Overlay with Cancel ----
let _aiAbortController = null;

function showAILoading(message, subMessage) {
  hideAILoading();
  _aiAbortController = new AbortController();
  const overlay = document.createElement("div");
  overlay.className = "ai-loading-overlay";
  overlay.id = "aiLoadingOverlay";
  overlay.innerHTML = `
    <div class="ai-loading-card">
      <div class="ai-loading-spinner"></div>
      <div class="ai-loading-text">${escapeHtml(message || "AI is thinking...")}</div>
      ${subMessage ? `<div class="ai-loading-sub">${escapeHtml(subMessage)}</div>` : ""}
      <button class="ai-loading-cancel" onclick="cancelAI()">✕ Cancel</button>
    </div>
  `;
  document.body.appendChild(overlay);
}

function hideAILoading() {
  const overlay = document.getElementById("aiLoadingOverlay");
  if (overlay) overlay.remove();
  _aiAbortController = null;
}

function cancelAI() {
  if (_aiAbortController) {
    _aiAbortController.abort();
    _aiAbortController = null;
  }
  hideAILoading();
  showToast("AI request cancelled.", "info", 1500);
}

function getAIAbortSignal() {
  return _aiAbortController ? _aiAbortController.signal : undefined;
}

// ---- AI Chat 2.0 — global assistant drawer (v8.1) ---------------------
// Replaces the old modal: now a slide-in drawer with REAL streaming, story
// context (RAG), persistent sessions and markdown-lite rendering — powered
// by the same /chat API as the character chat page.
let _aiChatSessionId = null;
let _aiChatStream = null;
let _aiChatStreaming = false;

function _aiChatMd(text) {
  let t = escapeHtml(text == null ? "" : text);
  t = t.replace(/`([^`\n]+)`/g, "<code class='cc-md-code'>$1</code>");
  t = t.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  t = t.replace(/~~([^~\n]+)~~/g, "<del>$1</del>");
  t = t.replace(/^###? (.+)$/gm, '<div class="cc-md-h">$1</div>');
  t = t.replace(/^[\s]*[•\-*] (.+)$/gm, '<div class="cc-md-li">• $1</div>');
  return t.replace(/\n/g, "<br>");
}

async function _aiChatApi(url, opts) {
  const res = await fetch(url, Object.assign({
    headers: { "Content-Type": "application/json", "X-CSRFToken": getCsrfToken() },
  }, opts || {}));
  let data;
  try { data = await res.json(); } catch { data = { ok: false, error: "Bad response" }; }
  if (!res.ok && data && data.error) throw new Error(data.error);
  return data;
}

async function _aiChatEnsureSession() {
  if (_aiChatSessionId) return _aiChatSessionId;
  const data = await _aiChatApi("/chat/api/sessions?mode=assistant");
  const latest = (data.sessions || [])[0];
  if (latest) { _aiChatSessionId = latest.id; return latest.id; }
  const created = await _aiChatApi("/chat/api/sessions", {
    method: "POST",
    body: JSON.stringify({ mode: "assistant", settings: { length: "normal", temperature: 0.7 } }),
  });
  _aiChatSessionId = created.session.id;
  return _aiChatSessionId;
}

function _aiChatBubble(role, content, name) {
  const who = name || (role === "user" ? "You" : "✨ Assistant");
  return `
    <div class="cc-msg ${role === "user" ? "user" : "char"} ai-chat-drawer-msg">
      ${role !== "user" ? `<span class="avatar avatar-sm cc-msg-avatar" style="background:var(--accent)">✨</span>` : ""}
      <div class="cc-msg-body">
        ${role !== "user" ? `<div class="cc-msg-name">${escapeHtml(who)}</div>` : ""}
        <div class="cc-msg-bubble cc-md">${_aiChatMd(content)}</div>
      </div>
      ${role === "user" ? `<span class="avatar avatar-sm cc-msg-avatar" style="background:var(--bg-elev-3)">YOU</span>` : ""}
    </div>`;
}

async function openAIChat() {
  // one drawer element, reused
  let drawer = document.getElementById("asmChatDrawer");
  if (!drawer) {
    drawer = document.createElement("div");
    drawer.id = "asmChatDrawer";
    drawer.className = "asm-chat-drawer";
    drawer.innerHTML = `
      <div class="asm-chat-drawer-head">
        <span class="asm-chat-drawer-title">✨ AI Assistant</span>
        <span class="text-mute text-xs" id="asmChatCtxHint">story-aware</span>
        <div class="grow"></div>
        <button class="btn btn-ghost btn-icon btn-sm" title="New conversation" onclick="aiChatNew()">＋</button>
        <button class="btn btn-ghost btn-icon btn-sm" title="Close" onclick="aiChatClose()">×</button>
      </div>
      <div class="asm-chat-drawer-ctxbar" id="asmChatCtxBar" style="display:none"></div>
      <div class="asm-chat-drawer-body" id="asmChatMessages"></div>
      <div class="asm-chat-drawer-suggest" id="asmChatSuggest"></div>
      <div class="asm-chat-drawer-inputrow">
        <textarea id="asmChatInput" rows="1"
          placeholder="Ask about plot, characters, style… (Enter to send)"></textarea>
        <button class="btn btn-primary" id="asmChatSendBtn" onclick="sendAIChatMessage()">Send</button>
        <button class="btn btn-danger" id="asmChatStopBtn" style="display:none" onclick="aiChatStop()">■</button>
      </div>`;
    document.body.appendChild(drawer);
    const input = drawer.querySelector("#asmChatInput");
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendAIChatMessage(); }
    });
    input.addEventListener("input", () => {
      input.style.height = "auto";
      input.style.height = Math.min(input.scrollHeight, 110) + "px";
    });
  }
  drawer.dataset.open = "true";
  // load the latest assistant conversation (memory across pages!)
  const box = drawer.querySelector("#asmChatMessages");
  box.innerHTML = '<div class="text-mute text-sm" style="text-align:center;padding:1.5rem">…</div>';
  try {
    const sid = await _aiChatEnsureSession();
    const data = await _aiChatApi(`/chat/api/sessions/${sid}`);
    const msgs = data.messages || [];
    _aiChatSessionId = sid;
    box.innerHTML = msgs.length
      ? msgs.map(m => _aiChatBubble(m.role, m.content, m.speaker_name)).join("")
      : `
        <div style="text-align:center;padding:1.6rem 1rem">
          <div style="font-size:2.2rem;opacity:.35">✨</div>
          <div class="text-mute" style="margin-top:0.4rem;font-size:0.85rem">
            Your story-aware co-writer. It knows your characters, world and chapters.</div>
        </div>`;
    const sugg = drawer.querySelector("#asmChatSuggest");
    sugg.innerHTML = msgs.length ? "" : `
      <button class="cc-chip" data-text="Give me a plot twist idea for my current story">💡 Plot twist</button>
      <button class="cc-chip" data-text="How can I deepen my protagonist's motivation?">🎭 Character</button>
      <button class="cc-chip" data-text="Suggest a vivid setting for a tense confrontation scene">⚔️ Setting</button>`;
    sugg.querySelectorAll(".cc-chip").forEach(b => b.onclick = () => {
      drawer.querySelector("#asmChatInput").value = b.dataset.text;
      sendAIChatMessage();
    });
    box.scrollTop = box.scrollHeight;
  } catch (e) {
    box.innerHTML = `<div class="text-mute text-sm" style="padding:1rem">Could not load history — ${escapeHtml(e.message)}</div>`;
  }
  setTimeout(() => drawer.querySelector("#asmChatInput")?.focus(), 150);
}

function aiChatClose() {
  const drawer = document.getElementById("asmChatDrawer");
  if (drawer) drawer.dataset.open = "false";
}

function aiChatStop() {
  if (_aiChatStream && _aiChatStream.stop) _aiChatStream.stop();
}

async function aiChatNew() {
  if (!confirm("Start a fresh conversation? (The old one stays in Character Chat → sessions)")) return;
  _aiChatSessionId = null;
  const drawer = document.getElementById("asmChatDrawer");
  if (!drawer) return;
  drawer.querySelector("#asmChatMessages").innerHTML = `
    <div style="text-align:center;padding:1.6rem 1rem">
      <div style="font-size:2.2rem;opacity:.35">✨</div>
      <div class="text-mute" style="margin-top:0.4rem;font-size:0.85rem">Fresh conversation started.</div>
    </div>`;
  await _aiChatEnsureSession();
}

async function sendAIChatMessage() {
  const drawer = document.getElementById("asmChatDrawer");
  const input = document.getElementById("asmChatInput");
  if (!drawer || !input || _aiChatStreaming) return;
  const message = input.value.trim();
  if (!message) return;
  input.value = "";
  input.style.height = "auto";
  const box = document.getElementById("asmChatMessages");
  const sugg = document.getElementById("asmChatSuggest");
  if (sugg) sugg.innerHTML = "";
  if (!box.querySelector(".cc-msg")) box.innerHTML = "";  // drop empty-state hero
  box.insertAdjacentHTML("beforeend", _aiChatBubble("user", message));
  box.scrollTop = box.scrollHeight;

  let sid;
  try { sid = await _aiChatEnsureSession(); }
  catch (e) {
    box.insertAdjacentHTML("beforeend",
      `<div class="ai-chat-msg assistant" style="color:var(--danger)">${escapeHtml(e.message)}</div>`);
    return;
  }

  // streaming bubble
  box.insertAdjacentHTML("beforeend", `
    <div class="cc-msg char" id="asmChatStreamMsg">
      <span class="avatar avatar-sm cc-msg-avatar" style="background:var(--accent)">✨</span>
      <div class="cc-msg-body">
        <div class="cc-msg-bubble cc-md" id="asmChatStreamBubble">
          <span class="cc-dots"><span></span><span></span><span></span></span>
        </div>
      </div>
    </div>`);
  box.scrollTop = box.scrollHeight;

  const sendBtn = document.getElementById("asmChatSendBtn");
  const stopBtn = document.getElementById("asmChatStopBtn");
  input.disabled = true; sendBtn.style.display = "none"; stopBtn.style.display = "";
  _aiChatStreaming = true;
  let full = "";

  asmStream(`/chat/api/sessions/${sid}/send`, { body: { message } }, {
    onStart(handle) { _aiChatStream = handle; },
    onContext(ctx) {
      const bar = document.getElementById("asmChatCtxBar");
      if (!ctx || !bar) return;
      const bits = [];
      if (ctx.characters) bits.push(`👤 ${ctx.characters}`);
      if (ctx.world) bits.push(`🌍 ${ctx.world}`);
      if (ctx.glossary) bits.push(`📖 ${ctx.glossary}`);
      if (ctx.plot) bits.push(`📚 ${ctx.plot}`);
      bar.innerHTML = "🧠 " + (bits.length ? bits.join(" · ") : "no story context yet");
      bar.style.display = "block";
    },
    onChunk(_c, all) {
      full = all;
      const bubble = document.getElementById("asmChatStreamBubble");
      if (bubble) bubble.innerHTML = _aiChatMd(full) + '<span class="cc-caret"></span>';
      box.scrollTop = box.scrollHeight;
    },
    onDone(finalText) {
      const t = (finalText || full || "").trim();
      const node = document.getElementById("asmChatStreamMsg");
      if (node) node.remove();
      if (t) {
        box.insertAdjacentHTML("beforeend", _aiChatBubble("assistant", t));
      } else {
        box.insertAdjacentHTML("beforeend",
          `<div class="ai-chat-msg assistant">(empty response — try again)</div>`);
      }
      _aiChatStream = null; _aiChatStreaming = false;
      input.disabled = false; sendBtn.style.display = ""; stopBtn.style.display = "none";
      box.scrollTop = box.scrollHeight; input.focus();
    },
    onAbort() {
      const node = document.getElementById("asmChatStreamMsg");
      if (node) node.remove();
      if (full.trim()) box.insertAdjacentHTML("beforeend", _aiChatBubble("assistant", full + " …"));
      _aiChatStream = null; _aiChatStreaming = false;
      input.disabled = false; sendBtn.style.display = ""; stopBtn.style.display = "none";
      box.scrollTop = box.scrollHeight; input.focus();
    },
    onError(msg) {
      const node = document.getElementById("asmChatStreamMsg");
      if (node) node.remove();
      box.insertAdjacentHTML("beforeend",
        `<div class="ai-chat-msg assistant" style="color:var(--danger)">⚠ ${escapeHtml(msg || "Failed")}</div>`);
      _aiChatStream = null; _aiChatStreaming = false;
      input.disabled = false; sendBtn.style.display = ""; stopBtn.style.display = "none";
      box.scrollTop = box.scrollHeight; input.focus();
    },
  });
}

window.openAIChat = openAIChat;
window.aiChatClose = aiChatClose;
window.aiChatNew = aiChatNew;
window.aiChatStop = aiChatStop;
window.sendAIChatMessage = sendAIChatMessage;
window.showAILoading = showAILoading;
window.hideAILoading = hideAILoading;
window.cancelAI = cancelAI;
window.getAIAbortSignal = getAIAbortSignal;

// ---- v8.2 Overlay Watchdog — the systemic end of button collisions -------
// History: floating buttons (+ FAB, undo ↶↷, reading ↑↓) kept colliding with
// overlays because every widget picked its own z-index. The dock now sits at
// z-index 45 (below every overlay layer), and this watchdog adds a second,
// future-proof line of defense: whenever ANY fixed overlay occupies the
// bottom-right corner region, body gets .asm-overlay-open and the dock is
// removed from the screen entirely (main.css):
//
//   body.asm-overlay-open .br-dock { display: none !important; }
//
// Detection is GENERIC — it scans direct <body> children (where every
// JS-created overlay lives) plus a short list of known in-content overlays.
// A future overlay that forgets the z-index rule is still caught as long as
// it is fixed-position and covers the corner. Transient widgets (toasts,
// graph hover popups, chord hints) are excluded by the size threshold.
(function _asmOverlayWatchdog() {
  window.__asmOverlayWatchdog = "v8.2.1";
  const KNOWN_OVERLAYS = [
    ".asm-chat-drawer",
    ".reading-bookmarks-panel",
    ".ai-drawer",
    ".asm-ai-drawer",
    ".modal-backdrop",
    ".qc-shell",
    ".quickswitch-overlay",
    ".asm-cp-backdrop",
    ".focus-shell",
  ];

  function _visible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;
    const r = el.getBoundingClientRect();
    return r.width > 10 && r.height > 10;
  }

  function _coversCorner(el) {
    // The dock zone: bottom-right corner box (right 200px × bottom 280px).
    // Proper rect-INTERSECTION test — an off-canvas drawer (translated out
    // to the right) must NOT count as covering the corner.
    const vw = window.innerWidth, vh = window.innerHeight;
    const r = el.getBoundingClientRect();
    // large overlay: tall panel/drawer/modal covering the corner …
    const tall = r.height >= vh * 0.5;
    // … or a wide bottom sheet that reaches into the corner
    const sheet = r.width >= vw * 0.5 && r.height >= vh * 0.25;
    if (!tall && !sheet) return false;
    // intersect with the corner box (vw-200, vh-280) → (vw, vh)
    return r.left < vw && r.top < vh && r.right >= vw - 200 && r.bottom >= vh - 280;
  }

  function _check() {
    let open = false;
    // 1) known overlay selectors (they may live anywhere in the DOM)
    for (const sel of KNOWN_OVERLAYS) {
      let el = null;
      try { el = document.querySelector(sel); } catch (e) { /* bad selector — skip */ }
      if (el && _visible(el) && _coversCorner(el)) { open = true; break; }
    }
    // 2) generic sweep of direct body children (JS-created overlays)
    if (!open) {
      for (const el of document.body.children) {
        if (el.id === "brDock" || el.classList.contains("br-dock")) continue;
        if (el.id === "toastContainer") continue; // transient, never hides the dock
        if (!_visible(el)) continue;
        const cs = getComputedStyle(el);
        if (cs.position !== "fixed") continue;
        if (_coversCorner(el)) { open = true; break; }
      }
    }
    document.body.classList.toggle("asm-overlay-open", open);
  }

  let _queued = false;
  function _schedule() {
    if (_queued) return;
    _queued = true;
    requestAnimationFrame(() => { _queued = false; _check(); });
    // v8.2 fix: overlays ANIMATE (slide/fade ~200-400ms). A single rAF check
    // runs mid-animation while the closing drawer still covers the corner —
    // the class then stuck ON forever because nothing re-checked after the
    // transition finished. Re-check after typical animation durations.
    setTimeout(() => _check(), 350);
    setTimeout(() => _check(), 900);
  }
  // exposed for live debugging / console forensics
  window.__asmOverlayCheck = _schedule;

  const start = () => {
    _check();
    const mo = new MutationObserver(_schedule);
    mo.observe(document.body, {
      subtree: true, childList: true,
      attributes: true, attributeFilter: ["class", "style", "hidden", "data-open"],
    });
    window.addEventListener("resize", _schedule);
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
