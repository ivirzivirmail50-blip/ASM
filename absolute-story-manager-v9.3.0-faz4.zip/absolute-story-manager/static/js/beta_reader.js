/* Beta Reader 2.0 (v8.9 "Review Loop")
 * -----------------------------------------------------------
 * Data payload arrives in a <script type="application/json" id="betaData">
 * tag (v7.5 static-JS architecture — no Jinja inside JS).
 *
 * Features:
 *  - prev/next chapter navigation + jump dropdown + position badge
 *  - reader identity (URL ?reader= param → localStorage persistence)
 *  - threaded comments rendered client-side, no reload on any action
 *  - selected-quote highlighting in the chapter body + scroll-to-quote
 *  - mark chapter as read / unread (per reader, feeds the Beta Hub)
 *  - optional AI fix suggestion per comment (author-side, when AI on)
 */
(function () {
  "use strict";

  let D = { chapter: {}, chapters: [], comments: [], reader: "",
            progress: {}, ai_enabled: false };
  try {
    const tag = document.getElementById("betaData");
    if (tag) D = JSON.parse(tag.textContent);
  } catch (e) { console.warn("betaData parse failed", e); }

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  // ---------------------------------------------------------------- identity
  function currentReader() {
    const el = $("readerName");
    return (el && el.value.trim()) || "Beta Reader";
  }

  function initIdentity() {
    const el = $("readerName");
    if (!el) return;
    if (D.reader) {
      el.value = D.reader;
      try { localStorage.setItem("asm_beta_reader", D.reader); } catch (e) {}
    } else {
      let saved = "";
      try { saved = localStorage.getItem("asm_beta_reader") || ""; } catch (e) {}
      if (saved) el.value = saved;
    }
    el.addEventListener("change", () => {
      try { localStorage.setItem("asm_beta_reader", currentReader()); } catch (e) {}
    });
  }

  // ---------------------------------------------------------------- nav bar
  function initNav() {
    const ch = D.chapter || {};
    const prev = $("betaPrev"), next = $("betaNext");
    if (prev) {
      if (ch.prev_id) { prev.href = withReader(`/beta/${ch.prev_id}`); }
      else { prev.classList.add("disabled"); prev.onclick = (e) => e.preventDefault(); }
    }
    if (next) {
      if (ch.next_id) { next.href = withReader(`/beta/${ch.next_id}`); }
      else { next.classList.add("disabled"); next.onclick = (e) => e.preventDefault(); }
    }
    const jump = $("betaJump");
    if (jump) {
      (D.chapters || []).forEach((c, i) => {
        const o = document.createElement("option");
        o.value = c.id;
        o.textContent = `${i + 1}. ${c.title}`;
        if (c.id === ch.id) o.selected = true;
        jump.appendChild(o);
      });
      jump.addEventListener("change", () => {
        if (jump.value && jump.value !== ch.id)
          window.location.href = withReader(`/beta/${jump.value}`);
      });
    }
    const pos = $("betaPosition");
    if (pos) pos.textContent = `Chapter ${ch.index || "?"} of ${ch.total || "?"}`;
  }

  function withReader(url) {
    const r = currentReader();
    if (r && r !== "Beta Reader")
      return `${url}${url.indexOf("?") >= 0 ? "&" : "?"}reader=${encodeURIComponent(r)}`;
    return url;
  }

  // ---------------------------------------------------------------- comments
  function commentCount(list) {
    let n = list.length;
    list.forEach((c) => { n += (c.replies || []).length; });
    return n;
  }

  function renderComments() {
    const wrap = $("commentList");
    if (!wrap) return;
    wrap.innerHTML = "";
    const list = D.comments || [];
    list.forEach((c) => wrap.appendChild(commentCard(c)));
    const countEl = $("betaCommentCount");
    if (countEl) countEl.textContent = String(commentCount(list));
    const openEl = $("betaOpenCount");
    if (openEl) {
      let openN = 0;
      list.forEach((c) => { if (c.status !== "resolved") openN += 1 + (c.replies || []).length; });
      openEl.textContent = String(openN);
    }
    if (!list.length) {
      const d = document.createElement("div");
      d.className = "text-mute text-sm";
      d.style.padding = "0.5rem";
      d.textContent = "No comments yet — select a passage and be the first.";
      wrap.appendChild(d);
    }
  }

  function commentCard(c) {
    const resolved = c.status === "resolved";
    const card = document.createElement("div");
    card.className = `beta-cmt ${resolved ? "beta-cmt-resolved" : ""}`;
    card.id = `c${c.id}`;
    const quote = c.selected_text
      ? `<div class="text-xs text-mute mb-1 beta-quote-line" style="font-style:italic">“${esc(c.selected_text.slice(0, 160))}${c.selected_text.length > 160 ? "…" : ""}”</div>`
      : "";
    const replies = (c.replies || []).map((r) => `
      <div class="beta-reply ${r.is_author_reply ? "beta-author-reply" : ""}">
        <div class="flex items-center gap-1 mb-1">
          <strong class="text-xs">${esc(r.reader_name)}</strong>
          ${r.is_author_reply && (r.reader_name || "").toLowerCase() !== "author"
            ? `<span class="badge no-dot accent" style="font-size:0.55rem">author</span>` : ""}
        </div>
        <div class="text-sm">${esc(r.comment)}</div>
      </div>`).join("");

    const aiBtn = D.ai_enabled
      ? `<button class="btn btn-ghost btn-sm beta-ai-btn" title="Ask the AI for a revision suggestion" onclick="betaAiSuggest(${c.id})">✦ AI fix</button>`
      : "";

    card.innerHTML = `
      <div class="flex items-center gap-2 mb-1 flex-wrap">
        <span class="beta-avatar" data-initial="${esc((c.reader_name || "B").slice(0, 1).toUpperCase())}">${esc((c.reader_name || "B").slice(0, 1).toUpperCase())}</span>
        <strong class="text-sm">${esc(c.reader_name)}</strong>
        <span class="badge no-dot ${resolved ? "success" : ""}" style="font-size:0.6rem">${esc(c.status)}</span>
      </div>
      ${quote}
      <div class="text-sm" style="color:var(--text)">${esc(c.comment)}</div>
      ${replies ? `<div class="flex flex-col gap-1 mt-1">${replies}</div>` : ""}
      <div class="flex flex-wrap gap-1 mt-1 beta-cmt-actions">
        ${resolved
          ? `<button class="btn btn-ghost btn-sm" onclick="betaStatus(${c.id}, 'reopen')">↺ Reopen</button>`
          : `<button class="btn btn-ghost btn-sm" onclick="betaStatus(${c.id}, 'resolve')">✓ Resolve</button>`}
        <button class="btn btn-ghost btn-sm" onclick="betaToggleReply(${c.id})">↩ Reply</button>
        ${aiBtn}
        <button class="btn btn-ghost btn-sm text-danger" onclick="betaDelete(${c.id})" title="Delete comment and replies">🗑</button>
      </div>
      <div class="beta-reply-form hidden" id="reply-${c.id}">
        <textarea class="form-textarea" rows="2" id="replytext-${c.id}" placeholder="Reply as the author…"></textarea>
        <button class="btn btn-primary btn-sm mt-1" onclick="betaSendReply(${c.id})">Send reply</button>
      </div>
      <div class="beta-suggest hidden" id="suggest-${c.id}"></div>`;
    return card;
  }

  // ------------------------------------------------------------- selection
  function betaHandleSelection() {
    const selection = String(window.getSelection()).trim();
    if (selection.length > 2) {
      const el = $("selectedText");
      if (el) el.value = selection;
      const c = $("commentText");
      if (c) c.focus();
    }
  }

  async function betaSubmitComment() {
    const comment = ($("commentText") || {}).value || "";
    if (!comment.trim()) { showToast("Type a comment first.", "warning"); return; }
    const body = {
      comment: comment.trim(),
      reader_name: currentReader(),
      selected_text: ($("selectedText") || {}).value || "",
    };
    const { data } = await asmFetch(`/beta/${D.chapter.id}/comment`, {
      method: "POST", body,
    });
    if (data.ok) {
      try { localStorage.setItem("asm_beta_reader", currentReader()); } catch (e) {}
      showToast("Comment added.", "success");
      $("commentText").value = "";
      $("selectedText").value = "";
      await refreshComments();
    } else showToast(data.error || "Failed", "error");
  }

  async function refreshComments() {
    const { data } = await asmFetch(`/beta/${D.chapter.id}/threaded`, { method: "GET" });
    if (data.ok) {
      D.comments = data.comments || [];
      renderComments();
      highlightQuotes();
      refreshReadState();
    }
  }

  // ------------------------------------------------------- status / delete
  async function betaStatus(id, action) {
    const { data } = await asmFetch(`/beta/comment/${id}/${action}`, { method: "POST" });
    if (data.ok) {
      showToast(action === "resolve" ? "Resolved." : "Reopened.",
                action === "resolve" ? "success" : "warning");
      await refreshComments();
    } else showToast(data.error || "Failed", "error");
  }

  async function betaDelete(id) {
    const ok = await confirmDialog("Delete this comment (and its replies)?",
                                   { danger: true, okLabel: "Delete" });
    if (!ok) return;
    const { data } = await asmFetch(`/beta/comment/${id}/delete`, { method: "POST" });
    if (data.ok) { showToast("Deleted.", "success"); await refreshComments(); }
  }

  // ----------------------------------------------------------------- reply
  function betaToggleReply(id) {
    const f = $(`reply-${id}`);
    if (f) { f.classList.toggle("hidden"); if (!f.classList.contains("hidden")) $(`replytext-${id}`)?.focus(); }
  }

  async function betaSendReply(id) {
    const ta = $(`replytext-${id}`);
    const text = ta ? ta.value.trim() : "";
    if (!text) { showToast("Type a reply first.", "warning"); return; }
    const { data } = await asmFetch(`/beta/comment/${id}/reply`, {
      method: "POST",
      body: { comment: text, reader_name: "Author", is_author_reply: true },
    });
    if (data.ok) { showToast("Reply sent.", "success"); await refreshComments(); }
    else showToast(data.error || "Failed", "error");
  }

  // ------------------------------------------------------------ AI suggest
  async function betaAiSuggest(id) {
    const panel = $(`suggest-${id}`);
    if (!panel) return;
    if (panel.dataset.loaded) { panel.classList.toggle("hidden"); return; }
    panel.classList.remove("hidden");
    panel.innerHTML = `<div class="beta-suggest-inner text-sm text-dim">✦ Asking the AI…</div>`;
    const { data } = await asmFetch(`/beta/comment/${id}/ai-suggest`, { method: "POST" });
    if (data.ok) {
      panel.dataset.loaded = "1";
      panel.innerHTML = `
        <div class="beta-suggest-inner">${esc(data.suggestion || "").replace(/\n/g, "<br>")}</div>
        <div class="flex gap-1 mt-2">
          <button class="btn btn-ghost btn-sm" onclick="betaCopySuggest(${id})">Copy</button>
        </div>`;
      panel.dataset.raw = data.suggestion || "";
    } else {
      panel.innerHTML = `<div class="beta-suggest-inner text-sm" style="color:var(--danger)">${esc(data.error || "AI request failed")}</div>`;
    }
  }

  function betaCopySuggest(id) {
    const panel = $(`suggest-${id}`);
    if (panel && panel.dataset.raw) {
      navigator.clipboard?.writeText(panel.dataset.raw)
        .then(() => showToast("Suggestion copied.", "success"))
        .catch(() => showToast("Copy failed.", "error"));
    }
  }

  // ---------------------------------------------------------- read progress
  async function betaToggleRead() {
    const reader = currentReader();
    const isRead = (D.progress.read_ids || []).includes(D.chapter.id);
    const action = isRead ? "mark-unread" : "mark-read";
    const { data } = await asmFetch(`/beta/${D.chapter.id}/${action}`, {
      method: "POST", body: { reader },
    });
    if (data.ok) {
      // refresh progress state
      const p = await asmFetch(`/beta/${D.chapter.id}/progress?reader=${encodeURIComponent(reader)}`, { method: "GET" });
      if (p.data.ok) D.progress = { reader, read_ids: p.data.read_ids,
                                    read_count: p.data.read_count,
                                    chapters_total: p.data.chapters_total };
      refreshReadState();
      showToast(isRead ? "Marked as unread." : `Marked as read (${D.progress.read_count}/${D.progress.chapters_total}).`, "success");
      // keep the URL reader param in sync for prev/next links
      try { const u = new URL(window.location.href);
            u.searchParams.set("reader", reader);
            window.history.replaceState({}, "", u); } catch (e) {}
      D.reader = reader;
    } else showToast(data.error || "Failed", "error");
  }

  function refreshReadState() {
    const badge = $("betaProgressBadge");
    const btn = $("betaMarkRead");
    const isRead = (D.progress.read_ids || []).includes(D.chapter.id);
    const total = D.progress.chapters_total || D.chapter.total || 0;
    const done = D.progress.read_count || 0;
    if (badge) badge.textContent = `📖 ${done}/${total} chapters read`;
    if (btn) {
      btn.textContent = isRead ? "✓ Read — undo" : "✓ Mark as read";
      btn.classList.toggle("btn-primary", !isRead);
      btn.classList.toggle("btn-ghost", isRead);
    }
  }

  // --------------------------------------------------------- highlight pass
  function highlightQuotes() {
    const root = $("chapterContent");
    if (!root) return;
    root.querySelectorAll("mark.beta-quote").forEach((m) => {
      const parent = m.parentNode;
      parent.replaceChild(document.createTextNode(m.textContent), m);
      parent.normalize();
    });
    (D.comments || []).forEach((c) => {
      const q = (c.selected_text || "").trim();
      if (!q || q.length < 4) return;
      if (findFirst(root, q, `qc${c.id}`)) return;
    });
  }

  function findFirst(root, needle, markId) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const idx = node.textContent.indexOf(needle);
      if (idx >= 0) {
        const range = document.createRange();
        range.setStart(node, idx);
        range.setEnd(node, idx + needle.length);
        const mark = document.createElement("mark");
        mark.className = "beta-quote";
        mark.id = markId;
        try {
          range.surroundContents(mark);
        } catch (e) { return false; }
        return true;
      }
    }
    return false;
  }

  // ------------------------------------------------------------------- init
  initIdentity();
  initNav();
  renderComments();
  highlightQuotes();
  refreshReadState();

  // Expose handlers (inline onclick contract)
  window.betaHandleSelection = betaHandleSelection;
  window.betaSubmitComment = betaSubmitComment;
  window.betaStatus = betaStatus;
  window.betaDelete = betaDelete;
  window.betaToggleReply = betaToggleReply;
  window.betaSendReply = betaSendReply;
  window.betaAiSuggest = betaAiSuggest;
  window.betaCopySuggest = betaCopySuggest;
  window.betaToggleRead = betaToggleRead;
})();
