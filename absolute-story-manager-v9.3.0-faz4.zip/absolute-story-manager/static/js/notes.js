/* Absolute Story Manager — notes.js (v7.5)
   ============================================================================
   SOURCE-LEVEL FIX for the recurring "notes page is dead" bug.

   ROOT CAUSE (v7.4): the notes page used a ~320-line INLINE <script> block
   inside a Jinja template. One line contained Python slice syntax
   (`n.created_at[:10]`) copied from a Jinja expression into a JS template
   literal → SyntaxError → the ENTIRE block failed to parse → every function
   (openNewNoteModal, exportAllNotes, togglePin, ...) was undefined → no
   button on the page did anything. Earlier variants of the same class of
   bug (Jinja macro output breaking JS strings) hit other pages too.

   ARCHITECTURE FIX (this file):
   1. ALL notes-page JS lives in this STATIC file — Jinja never touches it,
      so Jinja/JS string collisions are structurally impossible here.
   2. Data flows in through data-* attributes only (data-note-data JSON,
      data-note-html pre-rendered markdown), never through injected code.
   3. Event DELEGATION: one document-level listener handles all current and
      future note cards. A failure while parsing one card cannot unwire the
      rest of the page.
   4. Per-note parsing is wrapped in try/catch — one malformed card renders
      inert instead of killing the grid.
   5. Every public handler is exported on `window` explicitly so the inline
      onclick attributes resolve even if load order changes.
   ============================================================================ */

(function () {
  "use strict";

  // ---- helpers (self-contained; app.js may load after this file) -----------

  function esc(v) {
    if (v === null || v === undefined) return "";
    return String(v)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function safeNoteData(card) {
    try {
      return JSON.parse(card.dataset.noteData || "{}") || {};
    } catch (e) {
      console.warn("notes.js: malformed note payload on card", card, e);
      return {};
    }
  }

  function datePart(iso) {
    // JS-safe replacement for the old Python slice `created_at[:10]`
    if (!iso || typeof iso !== "string") return "";
    return iso.slice(0, 10);
  }

  function allCards() {
    return Array.prototype.slice.call(document.querySelectorAll(".note-card"));
  }

  function cardByNoteId(id) {
    return document.querySelector('.note-card[data-note-id="' + String(id).replace(/"/g, '\\"') + '"]');
  }

  function reloadSoon(ms) {
    setTimeout(function () { window.location.reload(); }, ms || 500);
  }

  // ---- API calls -----------------------------------------------------------

  async function api(url, body) {
    if (typeof asmFetch !== "function") {
      throw new Error("asmFetch unavailable (app.js failed to load?)");
    }
    const opts = { method: "POST" };
    if (body !== undefined) opts.body = body;
    const { data } = await asmFetch(url, opts);
    return data || { ok: false, error: "Invalid response" };
  }

  // ---- Read modal (v7.4 behaviour, rebuilt on delegation-friendly grounds) -

  function closeReadModals() {
    document.querySelectorAll(".modal-backdrop.read-note-backdrop").forEach(function (b) {
      b.remove();
    });
  }

  function openReadNoteModal(idx) {
    const cards = allCards();
    const card = cards[idx];
    if (!card) return;
    const n = safeNoteData(card);
    const bodyHtml = (card.dataset.noteHtml || "").trim() ||
      '<em class="text-mute">(empty body)</em>';
    const tags = Array.isArray(n.tags) ? n.tags : [];
    const links = Array.isArray(n.links) ? n.links : [];

    const tagsHtml = tags.length
      ? '<div class="flex gap-1 flex-wrap mt-2">' +
        tags.map(function (t) { return '<span class="badge">#' + esc(t) + "</span>"; }).join("") +
        "</div>"
      : "";
    const linksHtml = links.length
      ? '<div class="mt-3 pt-2" style="border-top:1px solid var(--border)">' +
        '<div class="text-xs text-mute uppercase mb-1" style="letter-spacing:0.06em">Linked to</div>' +
        '<div class="flex flex-col gap-1">' +
        links.map(function (l) {
          return '<a class="text-xs" style="color:var(--accent);text-decoration:none;word-break:break-word;" href="' +
            esc(l.url || "#") + '">🔗 ' + esc(l.entity_type) + ": " + esc(l.entity_title) + "</a>";
        }).join("") +
        "</div></div>"
      : "";

    const hasPrev = idx > 0;
    const hasNext = idx < cards.length - 1;
    const prevBtn = hasPrev
      ? '<button class="btn btn-sm btn-ghost" data-act="prev" title="Previous note (←)">← Prev</button>'
      : '<button class="btn btn-sm btn-ghost" disabled style="opacity:0.4" title="No previous note">← Prev</button>';
    const nextBtn = hasNext
      ? '<button class="btn btn-sm btn-ghost" data-act="next" title="Next note (→)">Next →</button>'
      : '<button class="btn btn-sm btn-ghost" disabled style="opacity:0.4" title="No next note">Next →</button>';
    const counter = '<span class="text-xs text-mute" style="font-variant-numeric:tabular-nums">' +
      (idx + 1) + " / " + cards.length + "</span>";

    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop read-note-backdrop";
    backdrop.innerHTML =
      '<div class="modal read-note-modal" style="max-width:720px;border-left:4px solid ' +
        esc(n.color || "#6366f1") + '">' +
      '<div class="modal-header" style="display:flex;align-items:flex-start;gap:0.6rem;flex-wrap:wrap">' +
        '<span style="font-size:1.6rem;line-height:1">' + esc(n.icon || "💡") + "</span>" +
        '<div class="grow" style="min-width:0;flex:1">' +
          '<h3 class="modal-title" style="margin:0">' + esc(n.title || "Untitled note") + "</h3>" +
          '<div class="text-xs text-mute">' + esc(n.category_label || n.category || "") +
            (n.created_at ? " · " + esc(datePart(n.created_at)) : "") +
            (n.pinned ? " · 📌 pinned" : "") + (n.done ? " · ✓ done" : "") + "</div>" +
        "</div>" + prevBtn + counter + nextBtn +
        '<button class="btn btn-sm" data-act="edit" title="Edit note">✎ Edit</button>' +
        '<button class="btn btn-sm btn-ghost" data-act="fullscreen" title="Fullscreen (f)">⛶</button>' +
        '<button class="btn btn-ghost btn-icon btn-sm" data-act="close" title="Close (Esc)">✕</button>' +
      "</div>" +
      '<div class="modal-body" style="max-height:60vh;overflow-y:auto">' +
        '<div class="chapter-content prose" style="font-size:1rem;line-height:1.7;color:var(--text)">' +
          bodyHtml + "</div>" + tagsHtml + linksHtml +
      "</div>" +
      '<div class="modal-footer" style="display:flex;justify-content:space-between;align-items:center;gap:0.5rem">' +
        '<div class="text-xs text-mute">← → to navigate · f for fullscreen · Esc to close</div>' +
        '<div style="display:flex;gap:0.4rem">' +
          '<button class="btn" data-act="pin" title="' + (n.pinned ? "Unpin" : "Pin") + '">' +
            (n.pinned ? "Unpin" : "Pin") + "</button>" +
          '<button class="btn" data-act="done" title="' + (n.done ? "Mark active" : "Mark done") + '">' +
            (n.done ? "Undo done" : "Done") + "</button>" +
          '<button class="btn btn-primary" data-act="close">Close</button>' +
        "</div>" +
      "</div>" +
    "</div>";

    document.body.appendChild(backdrop);
    document.body.style.overflow = "hidden";

    const close = function () {
      backdrop.remove();
      document.body.style.overflow = "";
    };
    const goPrev = function () { if (hasPrev) { close(); openReadNoteModal(idx - 1); } };
    const goNext = function () { if (hasNext) { close(); openReadNoteModal(idx + 1); } };
    const toggleFullscreen = function () {
      const m = backdrop.querySelector(".read-note-modal");
      const mb = backdrop.querySelector(".modal-body");
      if (m.classList.contains("fullscreen")) {
        m.classList.remove("fullscreen");
        m.style.maxWidth = "720px";
        if (mb) mb.style.maxHeight = "60vh";
      } else {
        m.classList.add("fullscreen");
        m.style.maxWidth = "95vw";
        if (mb) mb.style.maxHeight = "80vh";
      }
    };

    backdrop.addEventListener("mousedown", function (e) { if (e.target === backdrop) close(); });
    const q = function (sel) { return backdrop.querySelector(sel); };
    q("[data-act=close]").onclick = close;
    q("[data-act=edit]").onclick = function () { close(); openNewNoteModal(n); };
    q("[data-act=fullscreen]").onclick = toggleFullscreen;
    if (hasPrev) q("[data-act=prev]").onclick = goPrev;
    if (hasNext) q("[data-act=next]").onclick = goNext;
    q("[data-act=pin]").onclick = async function () { await togglePin(n.id); close(); };
    q("[data-act=done]").onclick = async function () { await toggleDone(n.id); close(); };

    document.addEventListener("keydown", function esc(e) {
      if (e.key === "Escape") { close(); document.removeEventListener("keydown", esc); }
      else if (e.key === "ArrowLeft" && hasPrev) { goPrev(); document.removeEventListener("keydown", esc); }
      else if (e.key === "ArrowRight" && hasNext) { goNext(); document.removeEventListener("keydown", esc); }
      else if ((e.key === "f" || e.key === "F") &&
               e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
        toggleFullscreen();
      }
    });
  }

  // ---- New / Edit modal -----------------------------------------------------

  const NOTE_COLORS = ["#6366f1", "#ec4899", "#22c55e", "#f59e0b", "#ef4444", "#14b8a6", "#6b7299"];
  const NOTE_CATEGORIES = [
    ["idea", "💡 Idea"], ["question", "❓ Question"], ["reminder", "⏰ Reminder"],
    ["reference", "📚 Reference"], ["scene_idea", "🎬 Scene Idea"], ["todo", "✓ Todo"],
  ];

  function openNewNoteModal(initial) {
    initial = initial || {};
    // Close any previous edit backdrop (multiple opens should never stack)
    document.querySelectorAll(".modal-backdrop.note-edit-backdrop").forEach(function (b) { b.remove(); });

    const catOpts = NOTE_CATEGORIES.map(function (c) {
      return '<option value="' + c[0] + '"' +
        (initial.category === c[0] ? " selected" : "") + ">" + c[1] + "</option>";
    }).join("");
    const colorSwatches = NOTE_COLORS.map(function (c) {
      const active = (!initial.color && c === "#6366f1") || initial.color === c;
      return '<label style="cursor:pointer;padding:0.2rem;border-radius:6px">' +
        '<input type="radio" name="note_color" value="' + c + '" style="display:none"' +
        (active ? " checked" : "") + ">" +
        '<span style="display:inline-block;width:22px;height:22px;background:' + c +
        ';border-radius:6px;border:2px solid ' + (active ? "var(--text)" : "transparent") + '"></span></label>';
    }).join("");

    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop note-edit-backdrop";
    backdrop.innerHTML =
      '<div class="modal modal-lg">' +
        '<div class="modal-header"><h3 class="modal-title">' +
          (initial.id ? "Edit Note" : "Quick Note") + "</h3></div>" +
        '<div class="modal-body">' +
          '<div class="form-row"><label class="form-label">Category</label>' +
            '<select id="noteCat" class="form-select">' + catOpts + "</select></div>" +
          '<div class="form-row"><label class="form-label">Title (optional)</label>' +
            '<input type="text" id="noteTitle" class="form-input" value="' + esc(initial.title || "") +
            '" placeholder="A short headline…"></div>' +
          '<div class="form-row"><label class="form-label">Body</label>' +
            '<textarea id="noteBody" class="form-textarea" rows="6" placeholder="The note itself…">' +
            esc(initial.body || "") + "</textarea></div>" +
          '<div class="form-row"><label class="form-label">Tags (comma-separated)</label>' +
            '<input type="text" id="noteTags" class="form-input" value="' +
            esc((initial.tags || []).join(", ")) +
            '" placeholder="research, chapter-3, character:elara"></div>' +
          '<div class="form-row"><label class="form-label">Color</label>' +
            '<div class="flex gap-1 items-center" id="noteColorPicker">' + colorSwatches + "</div></div>" +
          '<div class="form-row"><label class="flex items-center gap-1 text-sm">' +
            '<input type="checkbox" id="notePinned"' + (initial.pinned ? " checked" : "") +
            "> Pin to top</label></div>" +
        "</div>" +
        '<div class="modal-footer">' +
          '<button class="btn" data-act="cancel">Cancel</button>' +
          '<button class="btn btn-primary" data-act="ok">Save</button>' +
        "</div>" +
      "</div>";

    document.body.appendChild(backdrop);
    document.body.style.overflow = "hidden";
    const close = function () { backdrop.remove(); document.body.style.overflow = ""; };
    backdrop.querySelector('[data-act="cancel"]').onclick = close;
    backdrop.addEventListener("mousedown", function (e) { if (e.target === backdrop) close(); });

    backdrop.querySelector('[data-act="ok"]').onclick = async function () {
      const payload = {
        title: document.getElementById("noteTitle").value.trim(),
        body: document.getElementById("noteBody").value,
        category: document.getElementById("noteCat").value,
        tags: document.getElementById("noteTags").value.split(",").map(function (s) { return s.trim(); }).filter(Boolean),
        pinned: document.getElementById("notePinned").checked,
        color: (document.querySelector('input[name="note_color"]:checked') || {}).value || "#6366f1",
      };
      if (!payload.title && !payload.body) {
        if (typeof showToast === "function") showToast("Title or body required", "warning");
        return;
      }
      const url = initial.id ? "/notes/api/" + initial.id : "/notes/api/new";
      try {
        const data = await api(url, payload);
        close();
        if (data.ok) {
          if (typeof showToast === "function") showToast("Saved!", "success");
          reloadSoon(500);
        } else {
          if (typeof showToast === "function") showToast(data.error || "Failed", "error");
        }
      } catch (err) {
        if (typeof showToast === "function") showToast("Save failed: " + err.message, "error");
      }
    };

    document.querySelectorAll('input[name="note_color"]').forEach(function (r) {
      r.addEventListener("change", function () {
        document.querySelectorAll("#noteColorPicker label span").forEach(function (span) {
          span.style.borderColor = "transparent";
        });
        const s = this.parentElement && this.parentElement.querySelector("span");
        if (s) s.style.borderColor = "var(--text)";
      });
    });
    setTimeout(function () {
      const t = document.getElementById("noteTitle");
      if (t && !t.value) t.focus();
    }, 50);
  }

  // ---- card actions ---------------------------------------------------------

  async function togglePin(id) {
    const data = await api("/notes/api/" + id + "/pin");
    if (data.ok) {
      if (typeof showToast === "function") showToast(data.pinned ? "Pinned" : "Unpinned", "success");
      reloadSoon(500);
    } else if (typeof showToast === "function") showToast(data.error || "Failed", "error");
  }

  async function toggleDone(id) {
    const data = await api("/notes/api/" + id + "/done");
    if (data.ok) {
      if (typeof showToast === "function") showToast(data.done ? "Marked done" : "Marked active", "success");
      reloadSoon(500);
    } else if (typeof showToast === "function") showToast(data.error || "Failed", "error");
  }

  async function deleteNote(id) {
    const ok = await confirmDialog("Delete this note?", { danger: true, okLabel: "Delete" });
    if (!ok) return;
    const data = await api("/notes/api/" + id + "/delete");
    if (data.ok) {
      if (typeof showToast === "function") showToast("Deleted", "success");
      reloadSoon(500);
    } else if (typeof showToast === "function") showToast(data.error || "Failed", "error");
  }

  // ---- export all notes as markdown ------------------------------------------

  function exportAllNotes() {
    const cards = document.querySelectorAll(".note-card");
    if (!cards.length) {
      if (typeof showToast === "function") showToast("No notes to export", "warning");
      return;
    }
    let md = "# Notes Export — " + new Date().toLocaleDateString() + "\n\n";
    let failed = 0;
    cards.forEach(function (card) {
      try {
        const d = safeNoteData(card);
        md += "## " + (d.icon || "📝") + " " + (d.title || "Untitled") + "\n\n";
        md += "**Category:** " + (d.category_label || d.category || "—") + "\n";
        md += "**Created:** " + (d.created_at ? datePart(d.created_at) : "—") + "\n";
        if (d.tags && d.tags.length) md += "**Tags:** " + d.tags.map(function (t) { return "#" + t; }).join(" ") + "\n";
        md += "\n" + (d.body || "") + "\n\n---\n\n";
      } catch (e) { failed += 1; }
    });
    const blob = new Blob([String(md)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "notes_export_" + new Date().toISOString().slice(0, 10) + ".md";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    if (typeof showToast === "function") {
      showToast("Exported " + (cards.length - failed) + " notes as Markdown", "success");
    }
  }

  // ---- delegated wiring (single source of truth for clicks) ------------------

  function findCard(el) {
    return el ? el.closest(".note-card") : null;
  }

  document.addEventListener("click", function (e) {
    // 1) action buttons inside note cards
    const btn = e.target.closest("[data-action]");
    if (btn && btn.dataset.action) {
      const card = findCard(btn);
      if (!card) return;
      e.preventDefault();
      e.stopPropagation();
      const action = btn.dataset.action;
      const noteId = btn.dataset.noteId || (card.dataset && card.dataset.noteId) || "";
      const idx = parseInt(card.dataset.noteIndex || "0", 10) || 0;
      if (action === "read") { openReadNoteModal(idx); return; }
      if (action === "pin") { togglePin(noteId).catch(console.error); return; }
      if (action === "done") { toggleDone(noteId).catch(console.error); return; }
      if (action === "edit") { openNewNoteModal(safeNoteData(card)); return; }
      if (action === "delete") { deleteNote(noteId).catch(console.error); return; }
      return;
    }
    // 2) click on note body → read modal
    const body = e.target.closest(".note-card .note-body");
    if (body) {
      const card = findCard(body);
      if (!card) return;
      e.preventDefault();
      openReadNoteModal(parseInt(card.dataset.noteIndex || "0", 10) || 0);
    }
  });

  // ---- public API ------------------------------------------------------------

  window.openNewNoteModal = openNewNoteModal;
  window.openReadNoteModal = openReadNoteModal;
  window.exportAllNotes = exportAllNotes;
  window.editNote = function (note) { openNewNoteModal(note); };
  window.togglePin = togglePin;
  window.toggleDone = toggleDone;
  window.deleteNote = deleteNote;
  window.asmNotesReady = true;
})();
