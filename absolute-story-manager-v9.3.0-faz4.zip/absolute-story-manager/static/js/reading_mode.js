/**
 * Reading Mode — full static-Javascript architecture (v7.6 root-rewrite)
 *
 * Replaces the previous 200+ line inline <script> with a static module. v7.5
 * architecture rule: NO inline Jinja/JS collisions. All data flows in via
 * /reading/api/chapters JSON endpoint, all preferences via localStorage.
 *
 * v7.6 adds:
 * - Bookmarks (Ctrl+D / Cmd+D) per chapter — saved to localStorage
 * - Highlights (text selection → color toolbar) — saved to localStorage
 * - Reading-time tracking (per-chapter + per-session via IntersectionObserver)
 * - Bookmarks/highlights/reading-time slide-out panel
 *
 * Sidebar SVG icons referenced via <use href="#i-...">
 */
(function () {
  'use strict';

  // ---- State ----
  var state = {
    chapters: [],
    currentChapterIdx: 0,
    bookmarks: {},          // {chapterId: {ts, note, scrollPct}}
    highlights: [],         // [{chapterId, text, color, ts, snippet}]
    chapterTimeMs: {},     // {chapterId: ms}
    currentChapterStartTs: null,
    sessionStartTs: Date.now(),
    sessionActiveMs: 0,
    observer: null,
    timeTrackerInterval: null,
  };

  var BOOKS_KEY = 'asm:reading:bookmarks';
  var HIGHLIGHTS_KEY = 'asm:reading:highlights';
  var TIMES_KEY = 'asm:reading:chapter_times';
  var PREFS_KEY = 'asm:reading:prefs';
  var RESUME_KEY = 'asm:reading:chapterIdx';

  // ---- Helpers ----
  function $(s) { return document.querySelector(s); }
  function $$(s) { return Array.from(document.querySelectorAll(s)); }
  // v9.1.0 (M-05): local escapeHtml/escapeAttr removed — core.js owns the
  // canonical escapeHtml (global). escapeAttr simply aliases it.
  function escapeAttr(s) { return escapeHtml(s); }
  function fmtDuration(ms) {
    var s = Math.floor(ms / 1000);
    var m = Math.floor(s / 60);
    s = s % 60;
    if (m >= 60) {
      var h = Math.floor(m / 60); m = m % 60;
      return h + 'h ' + m + 'm';
    }
    return m + 'm ' + s + 's';
  }

  // ---- Persistence ----
  function loadBookmarks() {
    try { state.bookmarks = JSON.parse(localStorage.getItem(BOOKS_KEY) || '{}') || {}; }
    catch (e) { state.bookmarks = {}; }
  }
  function saveBookmarks() { localStorage.setItem(BOOKS_KEY, JSON.stringify(state.bookmarks)); }
  function loadHighlights() {
    try { state.highlights = JSON.parse(localStorage.getItem(HIGHLIGHTS_KEY) || '[]') || []; }
    catch (e) { state.highlights = []; }
  }
  function saveHighlights() { localStorage.setItem(HIGHLIGHTS_KEY, JSON.stringify(state.highlights)); }
  function loadTimes() {
    try { state.chapterTimeMs = JSON.parse(localStorage.getItem(TIMES_KEY) || '{}') || {}; }
    catch (e) { state.chapterTimeMs = {}; }
  }
  function saveTimes() { localStorage.setItem(TIMES_KEY, JSON.stringify(state.chapterTimeMs)); }

  // ---- API fetch helper ----
  // v9.1.0 (M-05): local asmFetch removed — core.js (loaded first via
  // base.html) owns the canonical version. The call site below was migrated
  // from the legacy {ok, status, data} contract to core's {res, data}.

  // ---- Load chapters ----
  function loadChapters() {
    asmFetch('/reading/api/chapters', { method: 'GET' }).then(function (resp) {
      if (!resp.res.ok || !resp.data || !resp.data.ok || !resp.data.chapters.length) {
        $('#readerContent').innerHTML =
          '<div class="empty-state" style="padding: 4rem 1rem; text-align: center">' +
          '<div class="text-3xl mb-2">📖</div>' +
          '<div class="text-mute">No chapters to read yet.</div>' +
          '<a href="/chapters/new" class="btn btn-primary mt-3">+ New Chapter</a>' +
          '</div>';
        return;
      }
      state.chapters = resp.data.chapters;
      loadPrefs();
      loadBookmarks();
      loadHighlights();
      loadTimes();
      renderChapters();
      restoreHighlights();
      var savedIdx = parseInt(localStorage.getItem(RESUME_KEY) || '0', 10);
      if (savedIdx > 0 && savedIdx < state.chapters.length) {
        setTimeout(function () { jumpToChapter(state.chapters[savedIdx].id); }, 200);
      }
      var totalWords = state.chapters.reduce(function (s, c) { return s + (c.word_count || 0); }, 0);
      var mins = Math.round(totalWords / 250);
      $('#readingStats').textContent = state.chapters.length + ' chapters · ~' + mins + ' min read';
      updateBookmarkCount();
      renderBookmarksPanel();
      renderReadingTimePanel();
      startTimeTracker();
    }).catch(function (err) {
      console.error('[reading] load failed:', err);
      $('#readerContent').innerHTML = '<div class="empty-state text-danger">Failed to load chapters.</div>';
    });
  }

  // ---- Render ----
  function renderChapters() {
    var hideTitles = $('#hideTitles').checked;
    var hideMeta = $('#hideMeta').checked;
    var html = state.chapters.map(function (c, i) {
      var isBookmarked = state.bookmarks[c.id];
      var chapterTime = state.chapterTimeMs[c.id] || 0;
      var body = '';
      body += '<div class="reader-chapter" data-idx="' + i + '" data-id="' + escapeAttr(c.id) +
              '" style="margin-bottom: 4rem; scroll-margin-top: 120px">';
      if (!hideTitles) {
        body += '<div class="reader-chapter-head" style="display: flex; align-items: center; gap: 0.5rem; margin: 2rem 0 1rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border)">';
        body += '<h2 style="flex: 1; font-size: 1.6em; font-weight: 700; color: var(--text); margin: 0">' +
                escapeHtml(c.title) + '</h2>';
        body += '<button class="btn btn-xs btn-ghost bm-toggle" data-bm="' + escapeAttr(c.id) +
                '" title="Bookmark chapter (Ctrl+D)">';
        body += '<svg class="ic" style="width:14px;height:14px' +
                (isBookmarked ? '; color: var(--accent)' : '') + '"><use href="#i-bookmark"></use></svg>';
        body += '</button>';
        body += '</div>';
      } else {
        body += '<div style="height: 2rem"></div>';
      }
      if (!hideMeta) {
        body += '<div class="text-xs text-mute" style="margin-bottom: 1.5rem">' +
                'Chapter ' + (i + 1) + ' of ' + state.chapters.length +
                ' · ' + (c.word_count || 0) + ' words · ~' +
                Math.round((c.word_count || 0) / 250) + ' min';
        if (chapterTime > 0) body += ' · <span title="Time on this chapter">⏱ ' + fmtDuration(chapterTime) + '</span>';
        if (c.tags && c.tags.length) {
          body += ' · ' + c.tags.map(function (t) { return '#' + escapeHtml(t); }).join(' ');
        }
        body += '</div>';
      }
      // Body: render content. For highlight support, wrap each paragraph in a span.
      var content = (c.content || '(empty chapter)');
      // Convert to paragraphs — split on double newline
      var paras = content.split(/\n\s*\n/);
      var prose = paras.map(function (p, pi) {
        // Escape + preserve single newlines as <br>
        var escaped = escapeHtml(p).replace(/\n/g, '<br>');
        return '<p class="reader-paragraph" data-para="' + pi + '" style="margin: 0 0 1em 0; white-space: pre-wrap; word-wrap: break-word">' + escaped + '</p>';
      }).join('');
      body += '<div class="chapter-prose">' + prose + '</div>';
      body += '</div>';
      return body;
    }).join('');
    $('#readerContent').innerHTML = html;
    attachChapterObserver();
    bindBookmarkToggles();
  }

  function attachChapterObserver() {
    if (state.observer) state.observer.disconnect();
    state.observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var idx = parseInt(entry.target.dataset.idx, 10);
          if (!isNaN(idx)) {
            // Track time on previous chapter
            if (state.currentChapterIdx !== idx && state.currentChapterStartTs) {
              var elapsed = Date.now() - state.currentChapterStartTs;
              var chId = state.chapters[state.currentChapterIdx].id;
              state.chapterTimeMs[chId] = (state.chapterTimeMs[chId] || 0) + elapsed;
              saveTimes();
              renderReadingTimePanel();
            }
            state.currentChapterIdx = idx;
            state.currentChapterStartTs = Date.now();
            localStorage.setItem(RESUME_KEY, String(idx));
            updateProgressBar();
            var jump = $('#chapterJump');
            if (jump) jump.value = state.chapters[idx].id;
          }
        }
      });
    }, { rootMargin: '-100px 0px -60% 0px', threshold: 0 });
    $$('.reader-chapter').forEach(function (el) { state.observer.observe(el); });
  }

  function updateProgressBar() {
    var scrollTop = window.scrollY;
    var docHeight = document.body.scrollHeight - window.innerHeight;
    var pct = docHeight > 0 ? Math.min(100, (scrollTop / docHeight) * 100) : 0;
    $('#progressBar').style.width = pct + '%';
  }

  function jumpToChapter(chId) {
    var el = document.querySelector('.reader-chapter[data-id="' + CSS.escape(chId) + '"]');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function scrollToPrevChapter() {
    if (state.currentChapterIdx > 0) jumpToChapter(state.chapters[state.currentChapterIdx - 1].id);
  }
  function scrollToNextChapter() {
    if (state.currentChapterIdx < state.chapters.length - 1) jumpToChapter(state.chapters[state.currentChapterIdx + 1].id);
  }
  function toggleFullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
  }
  function toggleControls() {
    var c = $('#readingControls');
    c.style.display = c.style.display === 'none' ? 'flex' : 'none';
  }

  // ---- Preferences ----
  function saveReadingPrefs() {
    var prefs = {
      fontFamily: $('#fontFamily').value,
      fontSize: $('#fontSize').value,
      lineHeight: $('#lineHeight').value,
      maxWidth: $('#maxWidth').value,
      readTheme: $('#readTheme').value,
      hideTitles: $('#hideTitles').checked,
      hideMeta: $('#hideMeta').checked,
    };
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    applyPrefs(prefs);
  }
  function loadPrefs() {
    var raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return;
    var p;
    try { p = JSON.parse(raw); } catch (e) { return; }
    if (p.fontFamily) $('#fontFamily').value = p.fontFamily;
    if (p.fontSize) $('#fontSize').value = p.fontSize;
    if (p.lineHeight) $('#lineHeight').value = p.lineHeight;
    if (p.maxWidth) $('#maxWidth').value = p.maxWidth;
    if (p.readTheme) $('#readTheme').value = p.readTheme;
    if (p.hideTitles != null) $('#hideTitles').checked = p.hideTitles;
    if (p.hideMeta != null) $('#hideMeta').checked = p.hideMeta;
    applyPrefs(p);
  }
  function applyPrefs(p) {
    var reader = $('#readerContent');
    if (p.fontFamily) reader.style.fontFamily = p.fontFamily;
    if (p.fontSize) {
      reader.style.fontSize = p.fontSize + 'px';
      $('#fontSizeLabel').textContent = p.fontSize + 'px';
    }
    if (p.lineHeight) {
      var lh = (parseInt(p.lineHeight, 10) / 100).toFixed(1);
      reader.style.lineHeight = lh;
      $('#lineHeightLabel').textContent = lh;
    }
    if (p.maxWidth) reader.style.maxWidth = p.maxWidth + 'px';
    applyTheme();
  }
  function applyTheme() {
    var theme = $('#readTheme').value;
    var reader = $('#readerContent');
    var viewport = $('#readerViewport');
    reader.style.removeProperty('background');
    reader.style.removeProperty('color');
    viewport.style.removeProperty('background');
    if (theme === 'paper') { viewport.style.background = '#ffffff'; reader.style.color = '#1a1a1a'; }
    else if (theme === 'sepia') { viewport.style.background = '#f4ecd8'; reader.style.color = '#3a2f1a'; }
    else if (theme === 'dark') { viewport.style.background = '#1a1a1a'; reader.style.color = '#e0e0e0'; }
    else if (theme === 'night') { viewport.style.background = '#000000'; reader.style.color = '#808080'; }
  }
  function updateFontSize() {
    var v = $('#fontSize').value;
    $('#readerContent').style.fontSize = v + 'px';
    $('#fontSizeLabel').textContent = v + 'px';
  }
  function updateLineHeight() {
    var v = parseInt($('#lineHeight').value, 10) / 100;
    $('#readerContent').style.lineHeight = v.toFixed(1);
    $('#lineHeightLabel').textContent = v.toFixed(1);
  }
  function updateMaxWidth() {
    var v = $('#maxWidth').value;
    $('#readerContent').style.maxWidth = v + 'px';
  }

  // ---- Bookmarks ----
  function toggleBookmark(chId) {
    if (state.bookmarks[chId]) {
      delete state.bookmarks[chId];
    } else {
      var scrollPct = (window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight) * 100).toFixed(1);
      state.bookmarks[chId] = { ts: Date.now(), scrollPct: parseFloat(scrollPct) };
    }
    saveBookmarks();
    renderChapters();
    updateBookmarkCount();
    renderBookmarksPanel();
  }
  function updateBookmarkCount() {
    var n = Object.keys(state.bookmarks).length;
    $('#bookmarkCount').textContent = n;
    $('#bmCount').textContent = n;
  }
  function bindBookmarkToggles() {
    $$('.bm-toggle').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        toggleBookmark(btn.getAttribute('data-bm'));
      });
    });
  }

  // ---- Highlights ----
  function getSelectionInfo() {
    var sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    var range = sel.getRangeAt(0);
    // Find chapter container
    var node = range.commonAncestorContainer;
    while (node && node.nodeType !== 1) node = node.parentNode;
    while (node && !node.classList.contains('reader-chapter')) node = node.parentElement;
    if (!node) return null;
    var chapterId = node.getAttribute('data-id');
    var text = sel.toString();
    if (!text || text.length < 2) return null;
    return { chapterId: chapterId, text: text, range: range, chapterNode: node };
  }
  function showHighlightToolbar() {
    var info = getSelectionInfo();
    var toolbar = $('#highlightToolbar');
    if (!info) { toolbar.hidden = true; return; }
    var rect = info.range.getBoundingClientRect();
    toolbar.style.top = (window.scrollY + rect.top - 50) + 'px';
    toolbar.style.left = (window.scrollX + Math.max(20, rect.left + (rect.width / 2) - 100)) + 'px';
    toolbar.hidden = false;
  }
  function hideHighlightToolbar() { $('#highlightToolbar').hidden = true; }

  function applyHighlightToSelection(color) {
    var info = getSelectionInfo();
    if (!info) return;
    if (!color) {
      // Remove — find existing highlight containing this range and remove
      state.highlights = state.highlights.filter(function (h) {
        return !(h.chapterId === info.chapterId && h.text === info.text);
      });
      saveHighlights();
      restoreHighlights();
      hideHighlightToolbar();
      window.getSelection().removeAllRanges();
      renderBookmarksPanel();
      return;
    }
    // Wrap selection in a <mark> with the color
    try {
      var mark = document.createElement('mark');
      mark.className = 'reader-highlight';
      mark.style.background = color;
      mark.style.padding = '0 2px';
      mark.style.borderRadius = '2px';
      mark.setAttribute('data-hl-text', info.text);
      mark.setAttribute('data-hl-color', color);
      info.range.surroundContents(mark);
    } catch (e) {
      // surroundContents fails if selection crosses element boundaries; fall back to insert
      console.warn('[reading] highlight failed for cross-element selection:', e);
    }
    // Save highlight
    state.highlights.push({
      chapterId: info.chapterId,
      text: info.text,
      color: color,
      ts: Date.now(),
      chapterTitle: (state.chapters.find(function (c) { return c.id === info.chapterId; }) || {}).title || 'Unknown',
    });
    saveHighlights();
    hideHighlightToolbar();
    window.getSelection().removeAllRanges();
    renderBookmarksPanel();
  }
  function restoreHighlights() {
    if (!state.highlights.length) return;
    // For each highlight, find the text in the chapter and wrap
    state.highlights.forEach(function (h) {
      var chapterEl = document.querySelector('.reader-chapter[data-id="' + CSS.escape(h.chapterId) + '"]');
      if (!chapterEl) return;
      // Find text in chapter
      var walker = document.createTreeWalker(chapterEl, NodeFilter.SHOW_TEXT, null);
      var node;
      while ((node = walker.nextNode())) {
        var idx = node.nodeValue.indexOf(h.text);
        if (idx === -1) continue;
        // Already inside a highlight? skip
        if (node.parentElement && node.parentElement.classList.contains('reader-highlight')) continue;
        // Split and wrap
        var range = document.createRange();
        range.setStart(node, idx);
        range.setEnd(node, idx + h.text.length);
        try {
          var mark = document.createElement('mark');
          mark.className = 'reader-highlight';
          mark.style.background = h.color;
          mark.style.padding = '0 2px';
          mark.style.borderRadius = '2px';
          mark.setAttribute('data-hl-text', h.text);
          mark.setAttribute('data-hl-color', h.color);
          range.surroundContents(mark);
        } catch (e) {
          // Cross-element selection — skip
        }
        break; // Only first occurrence
      }
    });
  }

  // ---- Bookmarks/Highlights panel ----
  function renderBookmarksPanel() {
    // Bookmarks pane
    var bmPane = $('#rbpBookmarks');
    var bmList = Object.keys(state.bookmarks).map(function (id) {
      var b = state.bookmarks[id];
      var ch = state.chapters.find(function (c) { return c.id === id; });
      return { id: id, title: ch ? ch.title : 'Unknown', ts: b.ts, scrollPct: b.scrollPct };
    }).sort(function (a, b) { return b.ts - a.ts; });
    if (!bmList.length) {
      bmPane.innerHTML = '<div class="text-mute text-sm">No bookmarks yet. Press Ctrl+D (or Cmd+D) to bookmark a chapter.</div>';
    } else {
      bmPane.innerHTML = bmList.map(function (b) {
        var d = new Date(b.ts);
        return '<div class="rbp-item" onclick="window.readingJumpToChapter(\'' + b.id + '\')">' +
          '<div class="rbp-item-title">' + escapeHtml(b.title) + '</div>' +
          '<div class="rbp-item-meta">📖 ' + d.toLocaleString() + ' · ' + b.scrollPct + '%</div>' +
          '<button class="rbp-item-del" data-bm-del="' + escapeAttr(b.id) + '" title="Remove">×</button>' +
          '</div>';
      }).join('');
      $$('.rbp-item-del').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          toggleBookmark(btn.getAttribute('data-bm-del'));
        });
      });
    }
    // Highlights pane
    var hlPane = $('#rbpHighlights');
    $('#hlCount').textContent = state.highlights.length;
    if (!state.highlights.length) {
      hlPane.innerHTML = '<div class="text-mute text-sm">No highlights yet. Select text, then click a color.</div>';
    } else {
      hlPane.innerHTML = state.highlights.slice().reverse().map(function (h, i) {
        var d = new Date(h.ts);
        return '<div class="rbp-item">' +
          '<span class="rbp-hl-swatch" style="background: ' + h.color + '"></span>' +
          '<div class="rbp-item-content">' +
          '<div class="rbp-item-snippet">"' + escapeHtml(h.text.length > 80 ? h.text.slice(0, 80) + '…' : h.text) + '"</div>' +
          '<div class="rbp-item-meta">📍 ' + escapeHtml(h.chapterTitle) + ' · ' + d.toLocaleString() + '</div>' +
          '</div>' +
          '<button class="rbp-item-del" data-hl-del="' + i + '" title="Remove">×</button>' +
          '</div>';
      }).join('');
      $$('.rbp-item-del[data-hl-del]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var idx = parseInt(btn.getAttribute('data-hl-del'), 10);
          // Map idx back to original (we reversed)
          var realIdx = state.highlights.length - 1 - idx;
          state.highlights.splice(realIdx, 1);
          saveHighlights();
          renderChapters();
          restoreHighlights();
          renderBookmarksPanel();
        });
      });
    }
  }

  // ---- Reading-time tracking ----
  function startTimeTracker() {
    state.currentChapterStartTs = Date.now();
    if (state.timeTrackerInterval) clearInterval(state.timeTrackerInterval);
    // Update every 5s
    state.timeTrackerInterval = setInterval(function () {
      state.sessionActiveMs += 5000;
      renderReadingTimePanel();
    }, 5000);
    // Pause on blur, resume on focus
    window.addEventListener('blur', function () {
      if (state.currentChapterStartTs) {
        var elapsed = Date.now() - state.currentChapterStartTs;
        var chId = state.chapters[state.currentChapterIdx].id;
        state.chapterTimeMs[chId] = (state.chapterTimeMs[chId] || 0) + elapsed;
        saveTimes();
        state.currentChapterStartTs = null;
      }
    });
    window.addEventListener('focus', function () {
      if (!state.currentChapterStartTs) state.currentChapterStartTs = Date.now();
    });
    // Save on unload
    window.addEventListener('beforeunload', function () {
      if (state.currentChapterStartTs) {
        var elapsed = Date.now() - state.currentChapterStartTs;
        var chId = state.chapters[state.currentChapterIdx].id;
        state.chapterTimeMs[chId] = (state.chapterTimeMs[chId] || 0) + elapsed;
        saveTimes();
      }
    });
  }

  function renderReadingTimePanel() {
    var pane = $('#rbpReadingTime');
    if (!pane) return;
    var totalMs = 0;
    state.chapters.forEach(function (c) { totalMs += state.chapterTimeMs[c.id] || 0; });
    var sessionMs = state.sessionActiveMs + (state.currentChapterStartTs ? Date.now() - state.currentChapterStartTs : 0);
    var html = '<div class="rbp-stats">' +
      '<div class="rbp-stat"><strong>' + fmtDuration(totalMs) + '</strong><div class="rbp-stat-label">Total reading time</div></div>' +
      '<div class="rbp-stat"><strong>' + fmtDuration(sessionMs) + '</strong><div class="rbp-stat-label">This session</div></div>' +
      '</div>' +
      '<div class="rbp-section-label">Per chapter</div>' +
      '<div class="rbp-chapter-times">';
    state.chapters.forEach(function (c, i) {
      var t = state.chapterTimeMs[c.id] || 0;
      var isCurrent = i === state.currentChapterIdx;
      html += '<div class="rbp-chapter-row' + (isCurrent ? ' current' : '') + '">' +
        '<span class="rbp-chapter-num">' + (i + 1) + '</span>' +
        '<span class="rbp-chapter-title">' + escapeHtml(c.title) + '</span>' +
        '<span class="rbp-chapter-time">' + (t > 0 ? fmtDuration(t) : '—') + '</span>' +
        '</div>';
    });
    html += '</div>';
    pane.innerHTML = html;
  }

  // ---- Bookmarks panel toggle ----
  function toggleBookmarksPanel() {
    var p = $('#bookmarksPanel');
    p.hidden = !p.hidden;
    if (!p.hidden) {
      renderBookmarksPanel();
      renderReadingTimePanel();
    }
  }

  // ---- Window-level API ----
  window.readingJumpToChapter = jumpToChapter;

  // ---- Bind events ----
  function bindEvents() {
    $('#fontFamily').addEventListener('change', saveReadingPrefs);
    $('#fontSize').addEventListener('input', function () { updateFontSize(); saveReadingPrefs(); });
    $('#lineHeight').addEventListener('input', function () { updateLineHeight(); saveReadingPrefs(); });
    $('#maxWidth').addEventListener('change', function () { updateMaxWidth(); saveReadingPrefs(); });
    $('#readTheme').addEventListener('change', function () { applyTheme(); saveReadingPrefs(); });
    $('#hideTitles').addEventListener('change', function () { saveReadingPrefs(); renderChapters(); });
    $('#hideMeta').addEventListener('change', function () { saveReadingPrefs(); renderChapters(); });
    $('#btnFullscreen').addEventListener('click', toggleFullscreen);
    $('#btnToggleControls').addEventListener('click', toggleControls);
    $('#btnPrevChapter').addEventListener('click', scrollToPrevChapter);
    $('#btnNextChapter').addEventListener('click', scrollToNextChapter);
    $('#chapterJump').addEventListener('change', function () { jumpToChapter(this.value); });
    $('#btnBookmarks').addEventListener('click', toggleBookmarksPanel);
    $('#btnCloseBookmarks').addEventListener('click', toggleBookmarksPanel);

    // Highlight toolbar buttons
    $$('#highlightToolbar .hl-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyHighlightToSelection(btn.getAttribute('data-color'));
      });
    });

    // Selection — show highlight toolbar
    document.addEventListener('selectionchange', function () {
      var sel = window.getSelection();
      if (sel && !sel.isCollapsed && sel.toString().length >= 2) {
        // Verify selection is inside readerContent
        var node = sel.anchorNode;
        while (node && node !== document.body) {
          if (node.id === 'readerContent') { showHighlightToolbar(); return; }
          node = node.parentNode;
        }
      }
      hideHighlightToolbar();
    });

    // Keyboard nav
    // v8.2: ↑/↓ now jump chapters too (they match the on-screen ↑/↓ buttons —
    // users expected them and only ←/→ worked). PageUp/PageDown are aliases.
    // Body flag tells app.js to stand down for keys reading mode owns
    // (b/t/g//) so "b" no longer opens BOTH the sidebar and the bookmarks
    // panel at once.
    document.body.setAttribute('data-reading-mode', '1');
    document.addEventListener('keydown', function (e) {
      var tag = e.target.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        if (state.chapters.length) toggleBookmark(state.chapters[state.currentChapterIdx].id);
      } else if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'h' || e.key === 'H')) {
        e.preventDefault();
        applyHighlightToSelection('#fde68a'); // default yellow
      } else if (e.key === 'ArrowLeft' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault(); scrollToPrevChapter();
      } else if (e.key === 'ArrowRight' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault(); scrollToNextChapter();
      } else if (e.key === 'ArrowUp' && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault(); scrollToPrevChapter();
      } else if (e.key === 'ArrowDown' && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault(); scrollToNextChapter();
      } else if ((e.key === 'PageUp' || e.key === 'PageDown') && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (e.key === 'PageUp') scrollToPrevChapter(); else scrollToNextChapter();
      } else if (e.key === 'f' || e.key === 'F') {
        e.preventDefault(); toggleFullscreen();
      } else if (e.key === 'h' || e.key === 'H') {
        e.preventDefault(); toggleControls();
      } else if (e.key === 'b' || e.key === 'B') {
        // Only if not in form
        e.preventDefault(); toggleBookmarksPanel();
      }
    });

    // Scroll progress
    window.addEventListener('scroll', updateProgressBar, { passive: true });
  }

  // ---- Init ----
  function init() {
    bindEvents();
    loadChapters();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
