/* chapter_editor.js — v9.1.0 (M-06)
 *
 * Migrated from the 878-line inline <script> in templates/chapters/edit.html
 * (the v7.5 architecture rule: templates carry NO executable JS — data flows
 * in via the #editor-data JSON block below, following the reading_mode.js
 * pattern). Behavior is unchanged; only the four Jinja interpolations were
 * replaced by ED.* reads.
 *
 * Data contract (from the template's #editor-data block):
 *   ED.chapterId         string   chapter id
 *   ED.aiEnabled         boolean  settings ai.enabled
 *   ED.autosaveInterval  number   settings autosave_interval_seconds
 *   ED.targetWordCount   number   chapter.target_word_count
 */
"use strict";

const ED = JSON.parse(
  document.getElementById("editor-data").textContent
);

let easyMDE;

document.addEventListener("DOMContentLoaded", () => {
  // Build toolbar — include AI Assist button only when AI is enabled
  const aiEnabled = ED.aiEnabled;
  // Custom "find" toolbar button — invokes CodeMirror's built-in search addon
  const findAction = {
    name: "find-in-chapter",
    action: (editor) => {
      const cm = editor.codemirror;
      if (cm && typeof cm.execCommand === "function") {
        cm.execCommand("find");
      } else {
        showToast("Find not available — press Ctrl+F", "info", 2000);
      }
    },
    className: "fa fa-search",
    title: "Find in this chapter (Ctrl+F)",
  };
  const replaceAction = {
    name: "replace-in-chapter",
    action: (editor) => {
      const cm = editor.codemirror;
      if (cm && typeof cm.execCommand === "function") {
        cm.execCommand("replace");
      } else {
        showToast("Replace not available — press Ctrl+Shift+F", "info", 2000);
      }
    },
    className: "fa fa-exchange",
    title: "Find & Replace in this chapter (Ctrl+Shift+F)",
  };
  // Shortcuts help overlay button
  const shortcutsAction = {
    name: "shortcuts-help",
    action: () => showShortcutsHelp(),
    className: "fa fa-question-circle",
    title: "Keyboard shortcuts (Ctrl+/)",
  };
  let toolbar = ["bold", "italic", "heading", "|", "quote", "unordered-list", "ordered-list",
                 "|", "link", "image", "code", "table", "|", findAction, replaceAction, "|",
                 "preview", "side-by-side", "fullscreen", "|", shortcutsAction, "guide"];
  // AI toolbar items — EasyMDE-shaped {name, action, className, title}.
  // F-03: shared by BOTH engines (EasyMDE consumes them as custom
  // actions; CodeMirror 6 renders them as toolbar buttons).
  let aiToolbarItems = [];
  if (aiEnabled) {
    aiToolbarItems = [
               {
                 name: "ai-continue",
                 action: async (editor) => {
                   const tail = editor.value().slice(-1500);
                   if (!tail.trim()) { showToast("Write something first.", "warning"); return; }
                   showAILoading("AI is writing...", "Continue (basic — no context)");
                   try {
                     const { data } = await asmFetch("/ai/continue", {
                       method: "POST", body: { text: tail, max_tokens: 400 }
                     });
                     hideAILoading();
                     if (data.ok) {
                       editor.value(editor.value() + "\n\n" + data.response);
                       showToast("Continuation inserted.", "success");
                       markDirty();
                       // Auto-save after AI insertion
                       
                     } else {
                       showToast(data.error || "AI failed", "error");
                     }
                   } catch (err) {
                     hideAILoading();
                     showToast("Cancelled or failed: " + err.message, "error");
                   }
                 },
                 className: "ai-btn-continue",
                 title: "✨ Continue (basic — no context)",
               },
               {
                 name: "ai-continue-context",
                 action: async (editor) => {
                   const tail = editor.value().slice(-1500);
                   if (!tail.trim()) { showToast("Write something first.", "warning"); return; }
                   showAILoading("AI is writing with context...", "Characters + world + plot");
                   try {
                     const { data } = await asmFetch("/ai/continue-context", {
                       method: "POST",
                       body: { text: tail, chapter_id: ED.chapterId, max_tokens: 500 }
                     });
                     hideAILoading();
                     if (data.ok) {
                       editor.value(editor.value() + "\n\n" + data.response);
                       const ctx = data.context || {};
                       showToast(`Inserted (${ctx.characters} chars, ${ctx.world} world, ${ctx.summaries} summaries)`, "success", 4000);
                       markDirty();
                       
                     } else {
                       showToast(data.error || "AI failed", "error");
                     }
                   } catch (err) {
                     hideAILoading();
                     showToast("Cancelled or failed: " + err.message, "error");
                   }
                 },
                 className: "ai-btn-context",
                 title: "✨ Continue with Context (characters + world + plot)",
               },
               {
                 name: "ai-summarize",
                 action: async (editor) => {
                   const text = editor.value();
                   if (!text.trim()) { showToast("Nothing to summarize.", "warning"); return; }
                   showAILoading("AI is summarizing...", "Generating synopsis");
                   try {
                     const { data } = await asmFetch("/ai/summarize", {
                       method: "POST", body: { text }
                     });
                     hideAILoading();
                     if (data.ok) {
                       const syn = document.querySelector("textarea[name='synopsis']");
                       if (syn) { syn.value = data.response; showToast("Synopsis filled.", "success"); }
                     } else { showToast(data.error || "AI failed", "error"); }
                   } catch (err) { hideAILoading(); showToast("Failed: " + err.message, "error"); }
                 },
                 className: "ai-btn-summarize",
                 title: "✨ Summarize (fill synopsis)",
               },
               {
                 name: "ai-tags",
                 action: async (editor) => {
                   const text = editor.value();
                   if (!text.trim()) { showToast("Nothing to tag.", "warning"); return; }
                   showAILoading("AI is suggesting tags...", "Analyzing content");
                   try {
                     const { data } = await asmFetch("/ai/suggest-tags", {
                       method: "POST", body: { text }
                     });
                     hideAILoading();
                     if (data.ok && data.tags && data.tags.length) {
                       const tagInput = document.querySelector("input[name='tags']");
                       if (tagInput) {
                         const existing = tagInput.value.split(",").map(s => s.trim()).filter(Boolean);
                         const merged = Array.from(new Set([...existing, ...data.tags])).join(", ");
                         tagInput.value = merged;
                         showToast(`Tags added: ${data.tags.join(", ")}`, "success", 3000);
                       }
                     } else { showToast(data.error || "AI failed", "error"); }
                   } catch (err) { hideAILoading(); showToast("Failed: " + err.message, "error"); }
                 },
                 className: "ai-btn-tags",
                 title: "✨ Suggest tags",
               },
    ];
    toolbar = ["bold", "italic", "heading", "|", "quote", "unordered-list", "ordered-list",
               "|", "link", "image", "code", "table", "|", findAction, replaceAction, "|",
               ...aiToolbarItems, "|",
               "preview", "side-by-side", "fullscreen", "|", shortcutsAction, "guide"];
  }

  // ---- F-03 (v9.2.0): engine dispatch --------------------------------
  // editor.engine setting: "codemirror" (default) or "easymde" (rollback
  // flag — the two engines live side by side for an easy escape hatch).
  // AsmCM6Editor returns an EasyMDE-compatible object, so everything below
  // (change listener, autosave, sprint, AI flows) is engine-agnostic.
  const useCM6 = ED.editorEngine !== "easymde" &&
                 window.ASMCM && window.AsmCM6Editor;
  if (useCM6) {
    easyMDE = window.AsmCM6Editor.create({
      textarea: document.getElementById("editor"),
      aiEnabled: aiEnabled,
      aiActions: aiToolbarItems,
      actions: { shortcuts: () => showShortcutsHelp() },
    });
  } else {
    easyMDE = new EasyMDE({
    element: document.getElementById("editor"),
    autofocus: true,
    spellChecker: true,
    status: ["lines", "words", "cursor"],
    toolbar: toolbar,
    renderingConfig: { singleLineBreaks: false },
    minHeight: "400px",
    tabSize: 4,
    indentWithTabs: false,
    unorderedListStyle: "-",
  });
  }

  // Render scene splitter
  setTimeout(renderSceneSplitter, 500);

  // Track changes — NOTE: there is NO element with id="wordCount"; the live counter is "liveWordCount".
  // The previous version bound `wc` to a non-existent element and threw on every keystroke, aborting
  // the change handler before markDirty() ran, which silently broke autosave.
  let dirty = false;
  let saveTimer = null;
  let lastSavedAt = null; // Date object of last successful autosave
  const status = document.getElementById("saveStatus");

  function markDirty() {
    dirty = true;
    status.textContent = "Editing…";
    status.className = "badge warning no-dot";
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(autosave, ED.autosaveInterval * 1000);
  }

  function formatTimeAgo(dateObj) {
    if (!dateObj) return "";
    const secs = Math.floor((Date.now() - dateObj.getTime()) / 1000);
    if (secs < 5) return "just now";
    if (secs < 60) return `${secs}s ago`;
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  }

  async function autosave() {
    if (!dirty) return;
    const content = easyMDE.value();
    status.textContent = "Saving…";
    status.className = "badge info no-dot";
    try {
      const { data } = await asmFetch(`/chapters/${ED.chapterId}/autosave`, {
        method: "POST",
        body: { content }
      });
      if (data.ok) {
        dirty = false;
        lastSavedAt = new Date();
        status.textContent = `Saved · ${data.word_count} words`;
        status.className = "badge success no-dot";
        // Live word counter (the only legitimate target)
        const liveEl = document.getElementById("liveWordCount");
        if (liveEl) liveEl.textContent = data.word_count;
        // If diff preview is visible, refresh it now that there's a new "latest" base
        if (_diffEnabled) _refreshDiffPreview();
      } else {
        status.textContent = "Save failed";
        status.className = "badge danger no-dot";
      }
    } catch (err) {
      status.textContent = "Save failed (offline?)";
      status.className = "badge danger no-dot";
    }
  }

  // Tick the "saved Xs ago" label every 5s
  setInterval(() => {
    if (lastSavedAt && !dirty) {
      status.textContent = `Saved ${formatTimeAgo(lastSavedAt)} · ${document.getElementById("liveWordCount").textContent} words`;
    }
  }, 5000);

  easyMDE.codemirror.on("change", () => {
    const v = easyMDE.value();
    const count = v.trim().split(/\s+/).filter(Boolean).length;
    // Live word counter — the one element that actually exists
    const liveEl = document.getElementById("liveWordCount");
    if (liveEl) liveEl.textContent = count;
    // Update progress bar
    const fill = document.getElementById("wcFill");
    if (fill) {
      const target = ED.targetWordCount;
      if (target > 0) fill.style.width = Math.min(100, (count / target * 100)) + "%";
    }
    // Sprint word count
    if (_sprintActive) {
      const swc = document.getElementById("sprintWordCount");
      if (swc) swc.textContent = count - _sprintStartWords;
      _updateSprintWpm();
    }
    // Diff preview (if enabled)
    if (_diffEnabled) _refreshDiffPreview();
    renderSceneSplitter();
    markDirty();
  });

  // Ctrl+S → save version snapshot; Ctrl+/ → shortcuts help
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "s") {
      e.preventDefault();
      saveChapter();
    } else if ((e.ctrlKey || e.metaKey) && e.key === "/") {
      // Some browsers intercept Ctrl+/ for devtools; try anyway
      e.preventDefault();
      showShortcutsHelp();
    }
  });

  // Load saved composition mode settings (persists across sessions)
  loadCompSettings();

  // Poll the daily-goal progress API every 60s (and once at startup)
  async function refreshTodayProgress() {
    try {
      const res = await fetch("/goals/api/progress");
      const data = await res.json();
      if (!data.ok) return;
      const today = data.today || {};
      const words = today.words || 0;
      const goal = today.goal || 0;
      const pct = today.pct || 0;
      const goalMet = today.goal_met;
      const wordsEl = document.getElementById("todayWords");
      const goalEl = document.getElementById("todayGoal");
      if (wordsEl) {
        wordsEl.textContent = `${words} word${words === 1 ? "" : "s"}`;
        wordsEl.className = goalMet ? "" : "text-mute";
        if (goalMet) wordsEl.style.color = "var(--success)";
        else wordsEl.style.color = "";
      }
      if (goalEl) {
        goalEl.textContent = goal > 0 ? ` / ${goal} · ${Math.round(pct)}%` : "";
      }
    } catch (e) { /* silent */ }
  }
  refreshTodayProgress();
  setInterval(refreshTodayProgress, 60000);
});

// ---- Sprint Timer ----
// Now backed by the WritingSession DB row via /focus/api/session/* endpoints.
// The sprint started in the editor will appear in sessions.html, contribute
// to the goals calendar, and survive a page reload.
let _sprintActive = false;
let _sprintPaused = false;
let _sprintStartWords = 0;
let _sprintStartTime = 0;
let _sprintRemaining = 25 * 60; // 25 minutes in seconds
let _sprintInterval = null;
let _sprintSessionId = null;
let _sprintHeartbeat = null;

async function toggleSprint() {
  if (!_sprintActive) {
    // Start sprint — create a WritingSession row in the DB
    _sprintActive = true;
    _sprintPaused = false;
    _sprintStartWords = easyMDE.value().trim().split(/\s+/).filter(Boolean).length;
    _sprintStartTime = Date.now();
    _sprintRemaining = 25 * 60;
    document.getElementById("sprintBar").classList.remove("hidden");
    document.getElementById("sprintBtn").textContent = "⏸ Pause Sprint";
    try {
      const { data } = await asmFetch("/focus/api/session/start", {
        method: "POST",
        body: {
          session_type: "sprint",
          target_minutes: 25,
          chapter_id: ED.chapterId,
        }
      });
      if (data.ok) {
        _sprintSessionId = data.id;
        showToast("Sprint started — counting toward today's goal.", "info", 3000);
      } else {
        showToast(`Sprint started (DB sync failed: ${data.error || 'unknown'})`, "warning", 3000);
      }
    } catch (err) {
      showToast(`Sprint started (network error: ${err.message})`, "warning", 3000);
    }
    _sprintInterval = setInterval(() => {
      if (!_sprintPaused) {
        _sprintRemaining--;
        _updateSprintDisplay();
        if (_sprintRemaining <= 0) {
          stopSprint(true);
        }
      }
    }, 1000);
    // Heartbeat every 30s so the DB row tracks elapsed time even if browser crashes
    _sprintHeartbeat = setInterval(() => {
      if (!_sprintActive || _sprintPaused) return;
      // No-op fetch; the server updates elapsed time on end_session.
      // If we wanted to track partial progress we'd POST to a heartbeat endpoint.
    }, 30000);
  } else if (_sprintPaused) {
    // Resume
    _sprintPaused = false;
    document.getElementById("sprintBtn").textContent = "⏸ Pause Sprint";
  } else {
    // Pause
    _sprintPaused = true;
    document.getElementById("sprintBtn").textContent = "▶ Resume Sprint";
  }
}

function _updateSprintDisplay() {
  const m = Math.floor(_sprintRemaining / 60);
  const s = _sprintRemaining % 60;
  document.getElementById("sprintTimer").textContent =
    `${m.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`;
}

function _updateSprintWpm() {
  if (!_sprintActive || _sprintPaused) return;
  const elapsedMin = (Date.now() - _sprintStartTime) / 60000;
  if (elapsedMin > 0.1) {
    const words = parseInt(document.getElementById("sprintWordCount").textContent) || 0;
    const wpm = Math.round(words / elapsedMin);
    document.getElementById("sprintWpm").textContent = wpm;
  }
}

async function stopSprint(completed) {
  const finalWords = parseInt(document.getElementById("sprintWordCount").textContent) || 0;
  _sprintActive = false;
  _sprintPaused = false;
  if (_sprintInterval) { clearInterval(_sprintInterval); _sprintInterval = null; }
  if (_sprintHeartbeat) { clearInterval(_sprintHeartbeat); _sprintHeartbeat = null; }
  document.getElementById("sprintBar").classList.add("hidden");
  document.getElementById("sprintBtn").textContent = "⏱ Sprint";
  // End the WritingSession row in the DB
  if (_sprintSessionId) {
    try {
      const { data } = await asmFetch("/focus/api/session/end", {
        method: "POST",
        body: { status: completed ? "completed" : "stopped" }
      });
      _sprintSessionId = null;
      if (data.ok) {
        const realWords = data.words_written ?? finalWords;
        if (completed) {
          showToast(`Sprint complete! ${realWords} words saved to your session log.`, "success", 5000);
        } else {
          showToast(`Sprint stopped. ${realWords} words recorded.`, "info", 2000);
        }
        // Refresh today's progress badge since sprint added words
        if (typeof refreshTodayProgress === "function") refreshTodayProgress();
      } else {
        showToast("Sprint ended (DB sync failed).", "warning", 2000);
      }
    } catch (err) {
      _sprintSessionId = null;
      showToast(`Sprint ended (network error: ${err.message})`, "warning", 2000);
    }
  } else {
    if (completed) {
      showToast(`Sprint complete! You wrote ${finalWords} words.`, "success", 5000);
    } else {
      showToast("Sprint stopped.", "info", 1500);
    }
  }
}

// If user navigates away mid-sprint, gracefully end the session
window.addEventListener("beforeunload", () => {
  if (_sprintActive && _sprintSessionId) {
    // Send a fire-and-forget end request via sendBeacon
    const payload = JSON.stringify({ status: "abandoned" });
    try {
      navigator.sendBeacon(
        "/focus/api/session/end",
        new Blob([payload], { type: "application/json" })
      );
    } catch (e) { /* silent */ }
  }
});

// ---- Version Diff Live Preview ----
// Now fetches the *actual latest version* from the server (was previously comparing
// current-vs-current and always reporting "no changes").
let _diffEnabled = false;
let _diffDebounce = null;

async function toggleDiffPreview() {
  _diffEnabled = document.getElementById("diffToggle").checked;
  const container = document.getElementById("diffPreviewContainer");
  if (_diffEnabled) {
    container.classList.remove("hidden");
    container.innerHTML = '<div class="text-mute text-sm" style="padding:0.5rem">Loading diff…</div>';
    await _refreshDiffPreview();
  } else {
    container.classList.add("hidden");
    container.innerHTML = "";
  }
}

async function _refreshDiffPreview() {
  if (!_diffEnabled) return;
  const container = document.getElementById("diffPreviewContainer");
  // Debounce: don't refetch on every keystroke
  if (_diffDebounce) clearTimeout(_diffDebounce);
  _diffDebounce = setTimeout(async () => {
    try {
      const res = await fetch(`/chapters/${ED.chapterId}/diff-vs-latest`);
      const data = await res.json();
      if (!data.ok) {
        container.innerHTML = '<div class="text-mute text-sm" style="padding:0.5rem">Failed to load diff.</div>';
        return;
      }
      if (!data.has_version || (!data.added && !data.removed)) {
        container.innerHTML = '<div class="text-mute text-sm" style="padding:0.5rem">No changes since the last saved version.</div>';
        return;
      }
      let header = `<div class="text-xs text-mute mb-1">+${data.added} added · −${data.removed} since v${data.version_number}`;
      if (data.saved_at) {
        const ago = new Date(data.saved_at).toLocaleString();
        header += ` · saved ${ago}`;
      }
      header += `</div>`;
      container.innerHTML = header
        + '<div class="diff-view" style="font-size:0.78rem;max-height:300px;overflow-y:auto">'
        + data.diff_html
        + '</div>';
    } catch (err) {
      container.innerHTML = '<div class="text-mute text-sm" style="padding:0.5rem">Diff fetch failed: ' + escapeHtml(err.message) + '</div>';
    }
  }, 400);
}

async function saveChapter() {
  const form = document.getElementById("chapterForm");
  const fd = new FormData(form);
  fd.set("content", easyMDE.value());
  const status = document.getElementById("saveStatus");
  status.textContent = "Saving version…";
  status.className = "badge info no-dot";
  const res = await fetch(`/chapters/${ED.chapterId}/edit`, {
    method: "POST",
    headers: { "X-CSRFToken": getCsrfToken() },
    body: fd
  });
  let data;
  try { data = await res.json(); }
  catch { data = { ok: false, error: "Invalid response" }; }
  if (data.ok) {
    showToast("Version saved.", "success");
    setTimeout(() => window.location.href = data.url, 500);
  } else {
    showToast(data.error || "Save failed", "error");
    status.textContent = "Save failed";
    status.className = "badge danger no-dot";
  }
}

function toggleDistractionFree() {
  toggleComposition();
}

function toggleComposition() {
  document.body.classList.toggle("composition-mode");
  const settings = document.getElementById("compSettings");
  if (document.body.classList.contains("composition-mode")) {
    settings.classList.remove("hidden");
    showToast("Focus mode on. Customize background, font, width below.", "info", 3000);
    applyCompStyle();
  } else {
    settings.classList.add("hidden");
  }
}

// ---- Typewriter mode (vertical cursor centering) ----
let _typewriterOn = false;
let _typewriterCursorHandler = null;

function toggleTypewriter() {
  _typewriterOn = document.getElementById("compTypewriter").checked;
  if (_typewriterOn && easyMDE && easyMDE.codemirror) {
    const cm = easyMDE.codemirror;
    if (!_typewriterCursorHandler) {
      _typewriterCursorHandler = () => {
        if (!_typewriterOn) return;
        const info = cm.getScrollInfo();
        const cursor = cm.cursorCoords(true, "local");
        const target = cursor.top - info.clientHeight / 2 + (cursor.bottom - cursor.top) / 2;
        cm.scrollTo(null, Math.max(0, target));
      };
    }
    cm.on("cursorActivity", _typewriterCursorHandler);
    _typewriterCursorHandler(); // center now
    showToast("Typewriter mode on — cursor will stay centered.", "info", 2000);
  } else if (!_typewriterOn && _typewriterCursorHandler && easyMDE && easyMDE.codemirror) {
    easyMDE.codemirror.off("cursorActivity", _typewriterCursorHandler);
  }
  saveCompSettings();
}

function applyCompStyle() {
  if (!document.body.classList.contains("composition-mode")) return;
  const bg = document.getElementById("compBg").value;
  const fontSize = document.getElementById("compFont").value;
  const width = document.getElementById("compWidth").value;
  const lineHeight = document.getElementById("compLineHeight").value;
  document.getElementById("compFontVal").textContent = fontSize + "px";
  document.getElementById("compLHVal").textContent = lineHeight;
  const content = document.querySelector(".content");
  if (content) {
    content.style.maxWidth = width + "px";
    content.style.background = bg;
    content.style.minHeight = "100vh";
  }
  const cm = document.querySelector(".CodeMirror");
  if (cm) {
    cm.style.fontSize = fontSize + "px";
    cm.style.lineHeight = lineHeight;
  }
  // Save to localStorage
  saveCompSettings();
}

function saveCompSettings() {
  const cfg = {
    bg: document.getElementById("compBg").value,
    font: document.getElementById("compFont").value,
    width: document.getElementById("compWidth").value,
    lineHeight: document.getElementById("compLineHeight").value,
    typewriter: document.getElementById("compTypewriter").checked,
  };
  try { localStorage.setItem("asm:comp-settings", JSON.stringify(cfg)); } catch (e) {}
}

function loadCompSettings() {
  let cfg = null;
  try { cfg = JSON.parse(localStorage.getItem("asm:comp-settings") || "null"); } catch (e) {}
  if (!cfg) {
    // First-time defaults: respect the user's current theme color
    const rootBg = getComputedStyle(document.documentElement).getPropertyValue("--bg-elev-1").trim() || "#131a30";
    cfg = { bg: rootBg, font: "18", width: "760", lineHeight: "1.7", typewriter: false };
  }
  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  setVal("compBg", cfg.bg);
  setVal("compFont", cfg.font);
  setVal("compWidth", cfg.width);
  setVal("compLineHeight", cfg.lineHeight);
  const tw = document.getElementById("compTypewriter");
  if (tw) tw.checked = !!cfg.typewriter;
}

// ---- Scene/Beat splitter ----
function renderSceneSplitter() {
  const content = easyMDE ? easyMDE.value() : "";
  const scenes = content.split(/\n\n\n+/);
  const container = document.getElementById("sceneSplitter");
  if (scenes.length <= 1) {
    container.innerHTML = "";
    return;
  }
  let html = '<div class="text-xs text-mute mb-1">Scenes in this chapter:</div>';
  scenes.forEach((scene, i) => {
    const wc = scene.trim().split(/\s+/).filter(Boolean).length;
    const preview = scene.trim().substring(0, 60).replace(/\n/g, " ");
    html += `<div class="scene-marker">
      <span class="scene-num">Scene ${i+1}</span>
      <span>${escapeHtml(preview)}${preview.length >= 60 ? "…" : ""}</span>
      <span class="text-mute" style="margin-left:auto">${wc}w</span>
    </div>`;
  });
  container.innerHTML = html;
}

// ---- Keyboard shortcuts help overlay ----
function showShortcutsHelp() {
  let overlay = document.getElementById("shortcutsOverlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "shortcutsOverlay";
    overlay.style.cssText = [
      "position: fixed", "top: 0", "left: 0", "right: 0", "bottom: 0",
      "background: rgba(0,0,0,0.6)", "z-index: 9999",
      "display: flex", "align-items: center", "justify-content: center",
    ].join("; ");
    overlay.innerHTML = `
      <div style="background: var(--bg-elev-1); border: 1px solid var(--border);
                  border-radius: 12px; padding: 2rem; max-width: 560px; width: 90%;
                  max-height: 80vh; overflow-y: auto; box-shadow: var(--shadow-lg)">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem">
          <h2 style="margin: 0; font-size: 1.1rem">⌨️ Keyboard Shortcuts</h2>
          <button class="btn btn-ghost btn-icon btn-sm" onclick="document.getElementById('shortcutsOverlay').remove()">×</button>
        </div>
        <table style="width: 100%; font-size: 0.85rem">
          <tbody>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Save version snapshot</td><td><kbd>Ctrl</kbd>+<kbd>S</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Find in this chapter</td><td><kbd>Ctrl</kbd>+<kbd>F</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Find & Replace</td><td><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>F</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Find next</td><td><kbd>Ctrl</kbd>+<kbd>G</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Find previous</td><td><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>G</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Toggle focus mode</td><td><kbd>F11</kbd> or button</td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Bold</td><td><kbd>Ctrl</kbd>+<kbd>B</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Italic</td><td><kbd>Ctrl</kbd>+<kbd>I</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Heading</td><td><kbd>Ctrl</kbd>+<kbd>H</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Insert link</td><td><kbd>Ctrl</kbd>+<kbd>K</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Inline code</td><td><kbd>Ctrl</kbd>+<kbd>\`</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Blockquote</td><td><kbd>Ctrl</kbd>+<kbd>Q</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Undo</td><td><kbd>Ctrl</kbd>+<kbd>Z</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Redo</td><td><kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>Z</kbd></td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Toggle fullscreen</td><td><kbd>F11</kbd> (in editor)</td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Insert scene break</td><td>Type <code>***</code> on its own line</td></tr>
            <tr><td style="padding: 0.3rem 0; color: var(--text-dim)">Show this help</td><td><kbd>Ctrl</kbd>+<kbd>/</kbd></td></tr>
          </tbody>
        </table>
        <div style="margin-top: 1rem; font-size: 0.75rem; color: var(--text-mute)">
          On macOS, use <kbd>⌘</kbd> instead of <kbd>Ctrl</kbd>.
        </div>
      </div>`;
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) overlay.remove();
    });
    document.body.appendChild(overlay);
  } else {
    overlay.remove();
  }
}

// =========================================================================
// v6.3 — In-editor AI Assistant drawer (streaming, chapter-aware)
// =========================================================================
let _aiStream = null;      // active stream handle
let _aiResult = "";        // latest completed suggestion
let _aiHadSelection = false;

function toggleAIDrawer(open) {
  const drawer = document.getElementById("aiDrawer");
  if (!drawer) return;
  drawer.dataset.open = open ? "true" : "false";
}

async function aiDrawerAction(action) {
  const drawer = document.getElementById("aiDrawer");
  if (!drawer || !easyMDE) return;
  const cm = easyMDE.codemirror;
  if (_aiStream) _aiStream.stop();

  // What text does the AI work on?
  let text = cm.getSelection();
  _aiHadSelection = !!text;
  if (!text) {
    if (action === "continue") {
      // Tail of everything BEFORE the cursor — natural continuation point.
      // If the cursor sits at the very start (autofocus), fall back to the
      // tail of the whole document so Continue always has something to work on.
      const cur = cm.getCursor();
      const before = cm.getRange({ line: 0, ch: 0 }, cur);
      text = before.slice(-600) || cm.getValue().slice(-600);
    } else {
      text = cm.getValue();
    }
  }
  if (!text.trim()) { showToast("Nothing to work with — write or select some text first.", "warning"); return; }

  const body = {
    text, action,
    chapter_id: ED.chapterId,
    ctx_characters: document.getElementById("aiCtxChars").checked,
    ctx_relationships: document.getElementById("aiCtxRel").checked,
    ctx_world: document.getElementById("aiCtxWorld").checked,
    ctx_glossary: document.getElementById("aiCtxGloss").checked,
    ctx_plot: document.getElementById("aiCtxPlot").checked,
    max_tokens: 320,
  };

  const out = document.getElementById("aiSuggestion");
  const setBtn = (id, on) => { const b = document.getElementById(id); if (b) b.disabled = !on; };
  setBtn("aiInsertBtn", false); setBtn("aiReplaceBtn", false); setBtn("aiCopyBtn", false);
  document.getElementById("aiStopBtn").style.display = "inline-flex";
  out.style.whiteSpace = "pre-wrap";
  out.style.fontFamily = "'Noto Serif', Georgia, serif";
  out.style.lineHeight = "1.7";
  out.style.color = "var(--text)";
  out.textContent = "";

  const actionNames = { continue: "Continue", expand: "Expand", shorter: "Shorten", dialogue: "Dialogue" };

  await asmStream("/ai-copilot/api/suggest-stream", { body }, {
    onStart(handle) { _aiStream = handle; },
    onContext(ctx) {
      const el = document.getElementById("aiCtxStats");
      if (!ctx) { el.textContent = ""; return; }
      const bits = [];
      if (ctx.characters) bits.push(`👤${ctx.characters}`);
      if (ctx.world) bits.push(`🌍${ctx.world}`);
      if (ctx.glossary) bits.push(`📖${ctx.glossary}`);
      if (ctx.plot) bits.push(`📚${ctx.plot}`);
      el.textContent = bits.length ? "knows: " + bits.join(" ") : "";
    },
    onChunk(_c, fullText) {
      _aiResult = fullText;
      out.textContent = fullText;
      const caret = document.createElement("span");
      caret.className = "cp-caret";
      out.appendChild(caret);
    },
    onDone(fullText) {
      _aiResult = (fullText || _aiResult).trim();
      out.textContent = _aiResult || "(empty response)";
      document.getElementById("aiStopBtn").style.display = "none";
      setBtn("aiInsertBtn", !!_aiResult);
      // Replace-selection only makes sense when the user had selected text
      setBtn("aiReplaceBtn", !!_aiResult && _aiHadSelection);
      setBtn("aiCopyBtn", !!_aiResult);
      _aiStream = null;
    },
    onAbort() {
      _aiResult = (_aiResult || "").trim();
      out.textContent = _aiResult + "\n\n(stopped)";
      document.getElementById("aiStopBtn").style.display = "none";
      setBtn("aiInsertBtn", !!_aiResult);
      setBtn("aiReplaceBtn", !!_aiResult && _aiHadSelection);
      setBtn("aiCopyBtn", !!_aiResult);
      _aiStream = null;
    },
    onError(msg) {
      out.innerHTML = `<div style="color: var(--danger); padding: 0.75rem; border: 1px solid var(--danger); border-radius: 8px; background: var(--danger-soft)">⚠ ${escapeHtml(msg || "AI failed")}</div>`;
      document.getElementById("aiStopBtn").style.display = "none";
      _aiStream = null;
    },
  });
  // (label for screen readers / debugging)
  drawer.dataset.lastAction = actionNames[action] || action;
}

function aiInsertAtCursor() {
  if (!_aiResult || !easyMDE) return;
  const cm = easyMDE.codemirror;
  cm.focus();
  cm.replaceSelection("\n\n" + _aiResult + "\n\n", "around");
  markDirty();
  showToast("Inserted at cursor.", "success", 1800);
}

function aiReplaceSelection() {
  if (!_aiResult || !easyMDE) return;
  const cm = easyMDE.codemirror;
  if (!cm.somethingSelected()) { showToast("No selection to replace.", "warning"); return; }
  cm.replaceSelection(_aiResult, "around");
  markDirty();
  showToast("Selection replaced.", "success", 1800);
}

function aiCopyResult() {
  if (!_aiResult) return;
  navigator.clipboard.writeText(_aiResult);
  showToast("Copied!", "success", 1500);
}

function aiStopStream() {
  if (_aiStream) { _aiStream.stop(); showToast("Stream stopped", "info", 1500); }
}

// Alt+A opens/closes the drawer (when AI is enabled)
document.addEventListener("keydown", (e) => {
  if (e.altKey && (e.key === "a" || e.key === "A")) {
    if (!document.getElementById("aiDrawer")) return;
    e.preventDefault();
    const open = document.getElementById("aiDrawer").dataset.open === "true";
    toggleAIDrawer(!open);
  }
});

// =========================================================================
// v7.2 — Inline AI auto-fill buttons (synopsis + tags)
// =========================================================================
async function aiFillSynopsis() {
  if (!easyMDE) return;
  const text = easyMDE.value();
  if (!text.trim()) { showToast("Write some content first.", "warning"); return; }
  const btn = document.getElementById("aiFillSynopsis");
  if (btn) { btn.disabled = true; btn.innerHTML = "⟳ Working…"; }
  try {
    showAILoading("AI is summarizing the chapter…", "Writing synopsis");
    const { data } = await asmFetch("/ai/summarize", { method: "POST", body: { text } });
    hideAILoading();
    if (data.ok && data.response) {
      const syn = document.querySelector("textarea[name='synopsis']");
      if (syn) { syn.value = data.response; markDirty(); showToast("Synopsis filled by AI.", "success"); }
    } else { showToast(data.error || "AI failed", "error"); }
  } catch (err) { hideAILoading(); showToast("Failed: " + err.message, "error"); }
  finally { if (btn) { btn.disabled = false; btn.textContent = "✦ AI"; } }
}
async function aiFillTags() {
  if (!easyMDE) return;
  const text = easyMDE.value();
  if (!text.trim()) { showToast("Write some content first.", "warning"); return; }
  const btn = document.getElementById("aiFillTags");
  if (btn) { btn.disabled = true; btn.innerHTML = "⟳ Working…"; }
  try {
    showAILoading("AI is suggesting tags…", "Analyzing content");
    const { data } = await asmFetch("/ai/suggest-tags", { method: "POST", body: { text } });
    hideAILoading();
    if (data.ok && data.tags && data.tags.length) {
      const tagInput = document.querySelector("input[name='tags']");
      if (tagInput) {
        const existing = tagInput.value.split(",").map(s => s.trim()).filter(Boolean);
        const merged = Array.from(new Set([...existing, ...data.tags])).join(", ");
        tagInput.value = merged;
        showToast(`Tags added: ${data.tags.join(", ")}`, "success");
      }
    } else { showToast(data.error || "AI failed", "error"); }
  } catch (err) { hideAILoading(); showToast("Failed: " + err.message, "error"); }
  finally { if (btn) { btn.disabled = false; btn.textContent = "✦ Suggest tags"; } }
}
// v7.2 — wire the AI auto-fill buttons directly (DOMContentLoaded has already
// fired by the time this inline script runs).
(function wireAIFillButtons() {
  const synBtn = document.getElementById("aiFillSynopsis");
  if (synBtn) synBtn.addEventListener("click", aiFillSynopsis);
  const tagBtn = document.getElementById("aiFillTags");
  if (tagBtn) tagBtn.addEventListener("click", aiFillTags);
})();
