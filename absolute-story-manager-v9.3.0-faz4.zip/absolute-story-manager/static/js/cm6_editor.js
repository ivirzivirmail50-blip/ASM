/* cm6_editor.js — CodeMirror 6 engine for the chapter editor. F-03 (v9.2.0).
 *
 * Provides window.AsmCM6Editor.create() returning an EasyMDE-compatible
 * object so chapter_editor.js (the SINGLE integration point since M-06)
 * stays engine-agnostic:
 *
 *   .value()            -> string        (get)
 *   .value(text)        -> void          (set, replaces whole doc)
 *   .codemirror.execCommand("find"|"replace")
 *   .codemirror.on("change", cb)
 *   .togglePreview() / .toggleSideBySide() / .toggleFullScreen()
 *
 * Toolbar parity with the EasyMDE setup: bold, italic, heading, quote,
 * unordered-list, ordered-list, link, image, code, table, find, replace,
 * preview, side-by-side, fullscreen, shortcuts, guide + (when AI enabled)
 * ai-continue, ai-dialogue, ai-summarize, ai-tags.
 *
 * Preview is server-rendered via POST /chapters/preview-md (single markdown
 * pipeline — md_to_html — same as compile/reading mode), not a JS renderer:
 * offline-first, no extra vendor.
 */
"use strict";

window.AsmCM6Editor = (function () {

  function create(opts) {
    const textarea = opts.textarea;
    const initial = textarea.value || "";
    const host = document.createElement("div");
    host.className = "cm6-wrap";
    textarea.parentNode.insertBefore(host, textarea);
    textarea.style.display = "none"; // keep for form fallback

    // ---- DOM: toolbar / editor / statusbar / preview ----
    const toolbar = document.createElement("div");
    toolbar.className = "cm6-toolbar";
    host.appendChild(toolbar);

    const bodyRow = document.createElement("div");
    bodyRow.className = "cm6-body";
    host.appendChild(bodyRow);

    const editorMount = document.createElement("div");
    editorMount.className = "cm6-mount";
    bodyRow.appendChild(editorMount);

    const preview = document.createElement("div");
    preview.className = "cm6-preview markdown-body hidden";
    bodyRow.appendChild(preview);

    const statusbar = document.createElement("div");
    statusbar.className = "cm6-statusbar";
    host.appendChild(statusbar);
    statusbar.innerHTML =
      '<span class="cm6-stat" data-stat="lines">0 lines</span>' +
      '<span class="cm6-stat" data-stat="words">0 words</span>' +
      '<span class="cm6-stat" data-stat="cursor">Ln 1, Col 1</span>';

    // ---- editor instance ----
    const ed = window.ASMCM.createMarkdownEditor({
      parent: editorMount,
      doc: initial,
      spellcheck: true,
      tabSize: 4,
    });
    const view = ed.view;

    // ---- easyMDE-compatible face ----
    const changeListeners = [];
    const api = {
      value(text) {
        if (text === undefined) return ed.getValue();
        ed.setValue(text);
        return undefined;
      },
      focus() { ed.focus(); },
      toTextArea() { ed.destroy(); host.remove(); textarea.style.display = ""; },
      togglePreview() { _toggleMode("preview"); },
      toggleSideBySide() { _toggleMode("side"); },
      toggleFullScreen() { host.classList.toggle("cm6-fullscreen"); },
      isPreviewActive() { return !preview.classList.contains("hidden"); },
      isSideBySideActive() {
        return bodyRow.classList.contains("cm6-side-by-side");
      },
      codemirror: {
        execCommand(cmd) {
          if (cmd === "find" || cmd === "replace") {
            // The CM6 search panel carries the replace controls too.
            window.ASMCM.openSearchPanel(view);
            return true;
          }
          return false;
        },
        on(event, cb) {
          if (event === "change") changeListeners.push(cb);
        },
      },
    };

    ed.onChange(() => {
      _updateStatus();
      changeListeners.forEach(cb => { try { cb(view); } catch (e) { console.error(e); } });
    });
    _updateStatus();

    // ---- toolbar ----
    function fmtBtn(id, title, label, run) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "cm6-btn";
      b.dataset.cmd = id;
      b.title = title;
      b.innerHTML = label;
      b.addEventListener("click", (e) => { e.preventDefault(); run(); ed.focus(); });
      return b;
    }

    function _sel() {
      const { from, to } = view.state.selection.main;
      return { from, to, text: view.state.sliceDoc(from, to) };
    }

    function _replaceSel(insert) {
      view.dispatch({ changes: { from: _sel().from, to: _sel().to, insert } });
    }

    function _wrap(before, after) {
      const s = _sel();
      let inner = s.text;
      // toggle off if already wrapped
      const around = view.state.sliceDoc(
        Math.max(0, s.from - before.length), s.from) === before &&
        view.state.sliceDoc(s.to, Math.min(view.state.doc.length,
          s.to + after.length)) === after;
      if (around) {
        view.dispatch({
          changes: [
            { from: s.from - before.length, to: s.from, insert: "" },
            { from: s.to, to: s.to + after.length, insert: "" },
          ],
        });
      } else {
        if (!inner) inner = before.trim().replace(/[*`]/g, "") || "text";
        _replaceSel(before + inner + after);
      }
    }

    function _linePrefix(prefix, ordered) {
      const { from } = view.state.selection.main;
      const line = view.state.doc.lineAt(from);
      let insert;
      if (ordered) {
        // count consecutive list lines above for numbering
        let n = 1;
        let prev = line.number - 1;
        while (prev >= 1) {
          const t = view.state.doc.line(prev).text;
          const m = /^(\d+)\.\s/.exec(t);
          if (m) { n = +m[1] + 1; break; }
          if (/^\S/.test(t)) break;
          prev--;
        }
        insert = n + ". ";
        // toggle
        if (/^\d+\.\s/.test(line.text)) insert = "";
      } else {
        insert = prefix;
        if (line.text.startsWith(prefix)) insert = "";
      }
      const newText = line.text.startsWith(prefix)
        ? line.text.slice(prefix.length)
        : (ordered && /^\d+\.\s/.test(line.text)
          ? line.text.replace(/^\d+\.\s/, "") : insert + line.text);
      view.dispatch({
        changes: { from: line.from, to: line.to, insert: newText },
      });
    }

    function _promptLink(isImage) {
      const s = _sel();
      const label = s.text || (isImage ? "alt text" : "link text");
      const url = window.prompt(isImage ? "Image URL" : "Link URL", "https://");
      if (!url) return;
      _replaceSel((isImage ? "!" : "") + "[" + label + "](" + url + ")");
    }

    const BUTTONS = [
      { id: "bold", title: "Bold (Ctrl+B)", label: "B",
        run: () => _wrap("**", "**") },
      { id: "italic", title: "Italic (Ctrl+I)", label: "I",
        run: () => _wrap("*", "*") },
      { id: "heading", title: "Heading (Ctrl+H)", label: "H",
        run: () => {
          const { from } = view.state.selection.main;
          const line = view.state.doc.lineAt(from);
          const m = /^(#{1,6})\s/.exec(line.text);
          const level = m ? (m[1].length % 6) + 1 : 1;
          const stripped = line.text.replace(/^#{1,6}\s/, "");
          view.dispatch({
            changes: {
              from: line.from, to: line.to,
              insert: "#".repeat(level) + " " + stripped,
            },
          });
        } },
      { sep: true },
      { id: "quote", title: "Quote (Ctrl+Q)", label: "❝",
        run: () => _linePrefix("> ") },
      { id: "unordered-list", title: "Bulleted list (Ctrl+U)", label: "•",
        run: () => _linePrefix("- ") },
      { id: "ordered-list", title: "Numbered list (Ctrl+O)", label: "1.",
        run: () => _linePrefix(null, true) },
      { sep: true },
      { id: "link", title: "Insert link (Ctrl+K)", label: "🔗",
        run: () => _promptLink(false) },
      { id: "image", title: "Insert image (Ctrl+Shift+I)", label: "🖼",
        run: () => _promptLink(true) },
      { id: "code", title: "Code (Ctrl+`)", label: "</>",
        run: () => {
          const s = _sel();
          if (s.text.includes("\n")) {
            _replaceSel("```\n" + s.text + "\n```");
          } else {
            _wrap("`", "`");
          }
        } },
      { id: "table", title: "Insert table", label: "▦",
        run: () => _replaceSel(
          "\n| Column 1 | Column 2 | Column 3 |\n" +
          "| --- | --- | --- |\n" +
          "| Text | Text | Text |\n") },
      { sep: true },
      { id: "find", title: "Find in this chapter (Ctrl+F)", label: "🔍",
        run: () => api.codemirror.execCommand("find") },
      { id: "replace", title: "Find & Replace (Ctrl+Shift+F)", label: "⇄",
        run: () => api.codemirror.execCommand("replace") },
      { sep: true },
      { id: "preview", title: "Toggle preview", label: "👁",
        run: () => _toggleMode("preview") },
      { id: "side-by-side", title: "Side-by-side", label: "⇉",
        run: () => _toggleMode("side") },
      { id: "fullscreen", title: "Fullscreen (F11)", label: "⛶",
        run: () => api.toggleFullScreen() },
      { sep: true },
      { id: "shortcuts-help", title: "Keyboard shortcuts (Ctrl+/)", label: "?",
        run: () => opts.actions.shortcuts && opts.actions.shortcuts() },
      { id: "guide", title: "Markdown guide", label: "📖",
        run: () => window.open(
          "https://www.markdownguide.org/basic-syntax/", "_blank") },
    ];

    // AI actions come from chapter_editor.js as EasyMDE-shaped objects
    // ({name, action, className, title}) — single source, both engines.
    if (opts.aiEnabled && Array.isArray(opts.aiActions)) {
      const LABELS = {
        "ai-btn-continue": "✍", "ai-btn-context": "✦",
        "ai-btn-summarize": "≡", "ai-btn-tags": "#",
      };
      const ai = opts.aiActions.map(a => ({
        id: a.name,
        title: a.title || a.name,
        label: LABELS[a.className] || "✨",
        run: () => a.action(api),
      }));
      BUTTONS.splice(11, 0, ...ai); // after table, before find — EasyMDE order
    }

    BUTTONS.forEach(b => {
      if (b.sep) {
        const s = document.createElement("span");
        s.className = "cm6-sep";
        toolbar.appendChild(s);
      } else {
        toolbar.appendChild(fmtBtn(b.id, b.title, b.label, b.run));
      }
    });

    // ---- preview (server-rendered) ----
    let previewPending = false;
    async function _renderPreview() {
      if (previewPending) return;
      previewPending = true;
      try {
        const { data } = await window.asmFetch("/chapters/preview-md", {
          method: "POST",
          body: { content: ed.getValue() },
        });
        if (data && data.ok) preview.innerHTML = data.html;
        else preview.innerHTML = "<p>(preview unavailable)</p>";
      } catch (e) {
        preview.innerHTML = "<p>(preview unavailable — offline?)</p>";
      } finally {
        previewPending = false;
      }
    }

    function _toggleMode(mode) {
      const showPreview = mode === "preview"
        ? preview.classList.contains("hidden") : true;
      if (mode === "side") {
        const active = bodyRow.classList.toggle("cm6-side-by-side");
        preview.classList.toggle("hidden", !active);
      } else {
        preview.classList.toggle("hidden", !showPreview);
      }
      if (!preview.classList.contains("hidden")) _renderPreview();
    }

    // preview follows content changes while visible (debounced)
    let previewTimer = null;
    ed.onChange(() => {
      if (preview.classList.contains("hidden")) return;
      if (previewTimer) clearTimeout(previewTimer);
      previewTimer = setTimeout(_renderPreview, 800);
    });

    // ---- statusbar ----
    function _updateStatus() {
      const text = ed.getValue();
      const lines = view.state.doc.lines;
      const words = text.trim().split(/\s+/).filter(Boolean).length;
      const pos = view.state.selection.main.head;
      const line = view.state.doc.lineAt(pos);
      const col = pos - line.from + 1;
      const sLines = statusbar.querySelector('[data-stat="lines"]');
      const sWords = statusbar.querySelector('[data-stat="words"]');
      const sCursor = statusbar.querySelector('[data-stat="cursor"]');
      if (sLines) sLines.textContent = lines + " lines";
      if (sWords) sWords.textContent = words + " words";
      if (sCursor) sCursor.textContent = "Ln " + line.number + ", Col " + col;
    }
    // cursor moves without doc changes update the cursor stat
    view.dom.addEventListener("click", _updateStatus);

    // autofocus (EasyMDE parity)
    ed.focus();

    return api;
  }

  return { create };
})();
