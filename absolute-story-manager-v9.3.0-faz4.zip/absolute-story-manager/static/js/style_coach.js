/* ASM v8.3 — Style Coach 2.0 AI Rewrite Studio
 * Static-JS architecture (v7.5 pattern): no inline Jinja-processed scripts,
 * data flows through data-* attributes, ONE delegated click listener.
 */
(function () {
  "use strict";

  var lang = "en";
  var chapterId = null;
  var activeStream = null;
  var results = {}; // targetIndex -> {original, replacement}

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function toast(msg, tone) {
    if (window.showToast) { window.showToast(msg, tone || "info", 3000); return; }
    try { console.log("[toast]", msg); } catch (e) { /* noop */ }
  }

  // ---- bootstrap: read language + chapter id from the page -------------
  function boot() {
    var badge = $("#scLangBadge");
    if (badge) lang = badge.getAttribute("data-lang") || "en";
    var btn = $(".sc-rewrite-btn");
    if (btn) chapterId = btn.getAttribute("data-chapter-id") || null;
    document.addEventListener("click", onDelegatedClick);
  }

  function onDelegatedClick(ev) {
    var t = ev.target.closest ? ev.target.closest("button") : null;
    if (!t) return;
    try {
      if (t.classList.contains("sc-rewrite-btn")) { ev.preventDefault(); startRewrite(t); }
      else if (t.classList.contains("sc-apply-btn")) { ev.preventDefault(); applyRewrite(t); }
      else if (t.classList.contains("sc-copy-btn")) { ev.preventDefault(); copyResult(t); }
      else if (t.classList.contains("sc-stop-btn")) { ev.preventDefault(); stopStream(); }
    } catch (err) {
      console.error("style coach action failed", err);
      toast("Action failed: " + err.message, "error");
    }
  }

  function targetByIndex(idx) {
    return $('.sc-target[data-target-index="' + idx + '"]');
  }
  function panelByIndex(idx) {
    return $('.sc-rewrite-panel[data-panel-index="' + idx + '"]');
  }

  function setBusy(idx, busy) {
    var btn = $('.sc-rewrite-btn[data-target-index="' + idx + '"]');
    if (btn) { btn.disabled = !!busy; btn.textContent = busy ? "Streaming…" : "✦ Rewrite"; }
  }

  // ---- streaming rewrite ------------------------------------------------
  function startRewrite(btn) {
    var idx = btn.getAttribute("data-target-index");
    var target = targetByIndex(idx);
    if (!target || !window.asmStream) {
      toast("Streaming helper unavailable.", "error");
      return;
    }
    var category = btn.getAttribute("data-category") || "telling";
    var sentenceEl = $(".sc-target-sentence", target);
    var sentence = sentenceEl ? sentenceEl.textContent.trim() : "";

    var panel = panelByIndex(idx);
    var resultEl = $('.sc-rewrite-result[data-result-index="' + idx + '"]');
    var applyBtn = $('.sc-apply-btn[data-target-index="' + idx + '"]');
    var copyBtn = $('.sc-copy-btn[data-target-index="' + idx + '"]');
    var stopBtn = $('.sc-stop-btn[data-target-index="' + idx + '"]');
    panel.classList.remove("hidden");
    resultEl.textContent = "";
    resultEl.classList.add("sc-streaming");
    applyBtn.classList.add("hidden");
    copyBtn.classList.add("hidden");
    stopBtn.classList.remove("hidden");
    setBusy(idx, true);
    results[idx] = { original: sentence, replacement: "" };

    activeStream = window.asmStream(
      "/lint/style-rewrite-stream",
      {
        body: {
          chapter_id: chapterId,
          sentence: sentence,
          category: category,
          lang: lang,
        },
      },
      {
        onStart: function (handle) { activeStream = handle; },
        onChunk: function (text) {
          resultEl.textContent += text;
          resultEl.scrollTop = resultEl.scrollHeight;
        },
        onDone: function (ev) {
          var final = (ev && ev.sentence) || resultEl.textContent;
          if (final) resultEl.textContent = final;
          results[idx].replacement = final;
          finishStream(idx, final);
        },
        onError: function (msg) {
          resultEl.textContent = "⚠ " + msg;
          finishStream(idx, "");
        },
      }
    );
  }

  function finishStream(idx, text) {
    var panel = panelByIndex(idx);
    var resultEl = $('.sc-rewrite-result[data-result-index="' + idx + '"]');
    if (resultEl) resultEl.classList.remove("sc-streaming");
    var stopBtn = $('.sc-stop-btn[data-target-index="' + idx + '"]');
    if (stopBtn) stopBtn.classList.add("hidden");
    if (text) {
      var applyBtn = $('.sc-apply-btn[data-target-index="' + idx + '"]');
      var copyBtn = $('.sc-copy-btn[data-target-index="' + idx + '"]');
      if (applyBtn) applyBtn.classList.remove("hidden");
      if (copyBtn) copyBtn.classList.remove("hidden");
    }
    setBusy(idx, false);
    activeStream = null;
  }

  function stopStream() {
    if (activeStream && activeStream.stop) activeStream.stop();
  }

  // ---- apply / copy ------------------------------------------------------
  function applyRewrite(btn) {
    var idx = btn.getAttribute("data-target-index");
    var r = results[idx];
    if (!r || !r.replacement) return;
    btn.disabled = true;
    btn.textContent = "Applying…";

    fetch("/lint/style-rewrite-apply", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": (window.getCsrfToken ? window.getCsrfToken() : ""),
      },
      body: JSON.stringify({
        chapter_id: chapterId,
        original: r.original,
        replacement: r.replacement,
      }),
    })
      .then(function (res) { return res.json().then(function (j) { return { ok: res.ok, j: j }; }); })
      .then(function (out) {
        if (!out.ok || !out.j.ok) throw new Error(out.j.error || "Apply failed");
        btn.textContent = "✓ Applied";
        btn.disabled = true;
        var delta = out.j.word_delta || 0;
        toast("Applied to chapter (" + (delta >= 0 ? "+" : "") + delta + " words). Previous version snapshotted.", "success");
        var target = targetByIndex(idx);
        if (target) target.classList.add("sc-target-done");
      })
      .catch(function (err) {
        btn.disabled = false;
        btn.textContent = "Apply to chapter";
        toast(err.message, "error");
      });
  }

  function copyResult(btn) {
    var idx = btn.getAttribute("data-target-index");
    var r = results[idx];
    if (!r || !r.replacement) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(r.replacement).then(function () {
        toast("Copied to clipboard", "success");
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
