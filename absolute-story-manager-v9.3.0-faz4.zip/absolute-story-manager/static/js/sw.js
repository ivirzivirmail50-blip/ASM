/* ==========================================================================
   ASM v8.0 — Service Worker ("Everywhere" pillar)
   --------------------------------------------------------------------------
   Strategies:
     - App shell (css/js/icons):  cache-first, filled on install
     - Static assets (/static/):  cache-first with background fill
     - Page navigations:          network-first, cached copy as offline
                                  fallback (gives offline READING of every
                                  visited page), then /offline
     - Non-GET (writes):          network with friendly 503 JSON when offline
   Cache names are version-stamped; activation purges everything older, and
   the page asks waiting workers to SKIP_WAITING so updates land in one
   click (see app.js update toast).
   ========================================================================== */
"use strict";

const VERSION = "v9.3.0";
const SHELL_CACHE = "asm-shell-" + VERSION;
const ASSET_CACHE = "asm-assets-" + VERSION;
const PAGE_CACHE = "asm-pages-" + VERSION;
const OFFLINE_URL = "/offline";
const MAX_PAGE_ENTRIES = 40;

const SHELL_ASSETS = [
  OFFLINE_URL,
  "/static/css/main.css",
  "/static/css/polish.css",
  "/static/css/fa-icons.css",
  "/static/img/icons/icon-192.png",
  "/static/img/icons/icon-512.png",
  "/static/img/icons/favicon-32.png",
  "/manifest.webmanifest",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) =>
      Promise.allSettled(SHELL_ASSETS.map((url) => cache.add(url)))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  const keep = new Set([SHELL_CACHE, ASSET_CACHE, PAGE_CACHE]);
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => !keep.has(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

/* ------------------------------ helpers -------------------------------- */

function isStaticAsset(url) {
  return url.pathname.startsWith("/static/");
}

async function trimPageCache() {
  const cache = await caches.open(PAGE_CACHE);
  const keys = await cache.keys();
  if (keys.length > MAX_PAGE_ENTRIES) {
    // oldest first (insertion order) — drop the third of them
    const drop = keys.slice(0, keys.length - MAX_PAGE_ENTRIES);
    await Promise.all(drop.map((k) => cache.delete(k)));
  }
}

async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(request);
  if (hit) return hit;
  const resp = await fetch(request);
  if (resp && resp.ok && (request.method === "GET")) {
    cache.put(request, resp.clone());
  }
  return resp;
}

async function networkFirstPage(event) {
  const cache = await caches.open(PAGE_CACHE);
  try {
    const resp = await fetch(event.request);
    if (resp && resp.ok) {
      cache.put(event.request, resp.clone()).then(trimPageCache).catch(() => {});
      return resp;
    }
    // non-OK from server — pass through (error pages render normally)
    return resp;
  } catch (err) {
    const cached = await cache.match(event.request, { ignoreSearch: true });
    if (cached) {
      // annotate so the page can show its offline banner
      const headers = new Headers(cached.headers);
      headers.set("X-ASM-From-Cache", "1");
      return new Response(await cached.clone().arrayBuffer(), {
        status: cached.status, statusText: "ASM-offline-cache", headers,
      });
    }
    const offline = await caches.match(OFFLINE_URL);
    if (offline) return offline;
    return new Response(
      "<!doctype html><meta charset='utf-8'><title>Offline</title>" +
      "<body style='background:#0b1020;color:#e8eaf6;font-family:sans-serif;" +
      "display:flex;align-items:center;justify-content:center;height:100vh'>" +
      "<div style='text-align:center'><h1>You are offline</h1>" +
      "<p>Reconnect to keep writing.</p></div></body>",
      { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } }
    );
  }
}

async function offlineWriteGuard(event) {
  try {
    return await fetch(event.request);
  } catch (err) {
    return new Response(
      JSON.stringify({ ok: false, error: "offline", detail: "You are offline — the change was NOT saved." }),
      { status: 503, headers: { "Content-Type": "application/json" } }
    );
  }
}

/* ------------------------------- fetch ---------------------------------- */

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") {
    // Writes: friendly JSON 503 instead of a network error toast wall
    event.respondWith(offlineWriteGuard(event));
    return;
  }

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // let cross-origin pass

  // Never let the SW itself / manifest be served from cache
  if (url.pathname === "/sw.js" || url.pathname === "/manifest.webmanifest") return;

  if (request.mode === "navigate" || (request.headers.get("accept") || "").includes("text/html")) {
    event.respondWith(networkFirstPage(event));
    return;
  }

  if (isStaticAsset(url)) {
    event.respondWith(cacheFirst(request, ASSET_CACHE));
    return;
  }

  // JSON APIs (GET): network-first, small cache for offline dashboards
  if ((request.headers.get("accept") || "").includes("application/json") || url.pathname.startsWith("/api/")) {
    event.respondWith((async () => {
      try {
        return await fetch(request);
      } catch (err) {
        const hit = await caches.match(request);
        if (hit) return hit;
        return new Response(JSON.stringify({ ok: false, error: "offline" }),
          { status: 503, headers: { "Content-Type": "application/json" } });
      }
    })());
  }
  // everything else: default browser behaviour
});
