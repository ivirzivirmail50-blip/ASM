/* v7.8 — char_groups.js · Character detail "Groups" card
   Multi-select group picker: a character can belong to SEVERAL groups.
   - "+ Manage Groups" opens a checkbox modal (current memberships checked)
   - Save → POST /characters/<id>/groups/sync with the full target set
   - Per-badge "×" removes that single membership
   Data flows via #charGroupsCard data-* attributes (static-JS architecture).
*/
(function () {
  "use strict";

  const card = document.getElementById("charGroupsCard");

  function parseData() {
    if (!card) return null;
    try {
      return {
        charId: card.dataset.characterId,
        allGroups: JSON.parse(card.dataset.allGroups || "[]"),
        memberIds: JSON.parse(card.dataset.memberGroupIds || "[]"),
      };
    } catch (e) {
      console.error("char_groups.js: bad data attributes", e);
      return null;
    }
  }

  function openPicker() {
    const d = parseData();
    if (!d) return;
    const memberSet = new Set(d.memberIds);
    const rows = d.allGroups.map(g => `
      <label class="picker-row" data-search="${escapeHtml(g.name.toLowerCase())}">
        <input type="checkbox" value="${g.id}" ${memberSet.has(g.id) ? "checked" : ""}>
        <span style="width: 12px; height: 12px; border-radius: 3px; background: ${g.color}; flex-shrink: 0"></span>
        <span style="color: var(--text)">${escapeHtml(g.name)}</span>
      </label>`).join("");
    if (!rows) {
      showToast("No groups exist yet — create some on the Groups page first.", "info", 4000);
      return;
    }
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <div class="modal-header"><h3 class="modal-title">Manage Groups</h3></div>
        <div class="modal-body">
          <div class="text-sm text-dim mb-2">Check every group this character belongs to — joining one group never removes them from another.</div>
          <input type="text" class="form-input mb-2" id="cgSearch" placeholder="Search groups…">
          <div class="picker-list">${rows}</div>
        </div>
        <div class="modal-footer">
          <button class="btn" data-act="cancel">Cancel</button>
          <button class="btn btn-primary" data-act="ok">Save</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    const close = () => backdrop.remove();
    backdrop.querySelector('[data-act="cancel"]').onclick = close;
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) close(); });
    document.addEventListener("keydown", function esc(e) {
      if (e.key === "Escape") { close(); document.removeEventListener("keydown", esc); }
    });
    const search = backdrop.querySelector("#cgSearch");
    search.addEventListener("input", () => {
      const q = search.value.toLowerCase();
      backdrop.querySelectorAll(".picker-row").forEach(r => {
        r.style.display = r.dataset.search.includes(q) ? "" : "none";
      });
    });
    search.focus();
    backdrop.querySelector('[data-act="ok"]').onclick = async () => {
      const ids = [...backdrop.querySelectorAll(".picker-list input:checked")].map(i => i.value);
      const { data } = await asmFetch(`/characters/${d.charId}/groups/sync`, {
        method: "POST",
        body: { group_ids: ids }
      });
      close();
      if (data.ok) {
        showToast(`Groups saved (+${data.added || 0} / −${data.removed || 0}).`, "success");
        setTimeout(() => location.reload(), 500);
      } else {
        showToast(data.error || "Failed", "error", 5000);
      }
    };
  }

  document.addEventListener("click", (e) => {
    const manage = e.target.closest("#btnManageGroups");
    if (manage) { openPicker(); return; }
    const remove = e.target.closest('[data-act="remove-group"]');
    if (remove) {
      const d = parseData();
      if (!d) return;
      asmFetch("/characters/groups", {
        method: "POST",
        body: { action: "remove", character_id: d.charId, group_id: remove.dataset.groupId }
      }).then(({ data }) => {
        if (data.ok) {
          showToast(`Removed from ${remove.dataset.groupName}.`, "success");
          setTimeout(() => location.reload(), 400);
        } else showToast(data.error || "Failed", "error", 5000);
      });
    }
  });
})();
