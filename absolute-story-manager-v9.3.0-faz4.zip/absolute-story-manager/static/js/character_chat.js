/* ═══════════════════════════════════════════════════════════════════
   v8.1 — Character Chat 2.0

   Rebuild of the character chat page on top of the persistent /chat API:
     • sessions sidebar (search, pin, rename, delete, auto-titles)
     • real conversation memory (server replays the last turns)
     • group scenes: pick who answers or let the AI choose
     • per-message actions: copy / regenerate / delete-from-here
     • markdown-lite rendering for AI replies
     • controls: reply length, creativity, context toggles, chapter anchor
     • export: copy transcript, save as note

   Data flow: cast comes from the #ccCharacters JSON tag (never through
   Jinja inside this file); everything else is fetched from /chat/api/*.
   ═══════════════════════════════════════════════════════════════════ */
(function () {
  "use strict";

  // ---- state ---------------------------------------------------------
  const S = {
    characters: [],        // [{id, name, role, avatar_color, initial}]
    sessions: [],          // session dicts from the API
    active: null,          // active session dict
    messages: [],          // active session messages
    streaming: false,
    streamHandle: null,
    settings: { length: "normal", temperature: 0.8,
               ctx_relationships: true, ctx_world: true,
               ctx_glossary: true, ctx_plot: true },
    autoScroll: true,
    searchTimer: null,
  };

  const $ = (id) => document.getElementById(id);
  const esc = (t) => String(t == null ? "" : t)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  // ---- markdown-lite (safe: escape first, then decorate) --------------
  function mdLite(text) {
    let t = esc(text);
    // fenced code
    t = t.replace(/```([\s\S]*?)```/g, (_, code) =>
      `<pre class="cc-md-pre">${code.trim()}</pre>`);
    t = t.replace(/`([^`\n]+)`/g, "<code class='cc-md-code'>$1</code>");
    // bold / italic / strike
    t = t.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
    t = t.replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,!?;:]|$)/g, "$1<em>$2</em>");
    t = t.replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,!?;:]|$)/g, "$1<em>$2</em>");
    t = t.replace(/~~([^~\n]+)~~/g, "<del>$1</del>");
    // headings (### style)
    t = t.replace(/^### (.+)$/gm, '<div class="cc-md-h">$1</div>');
    t = t.replace(/^## (.+)$/gm, '<div class="cc-md-h">$1</div>');
    t = t.replace(/^# (.+)$/gm, '<div class="cc-md-h">$1</div>');
    // blockquote
    t = t.replace(/^&gt; (.+)$/gm, '<div class="cc-md-q">$1</div>');
    // bullet / numbered lists
    t = t.replace(/^[\s]*[•\-*] (.+)$/gm, '<div class="cc-md-li">• $1</div>');
    t = t.replace(/^[\s]*\d+[.)] (.+)$/gm, (m) =>
      `<div class="cc-md-li">${m.trim()}</div>`);
    // paragraphs
    const paras = t.split(/\n{2,}/).map(p => {
      if (p.includes("cc-md-pre")) return p;
      const inner = p.replace(/\n/g, "<br>");
      return inner.trim() ? `<div class="cc-md-p">${inner}</div>` : "";
    });
    return paras.filter(Boolean).join("");
  }

  // ---- helpers --------------------------------------------------------
  function charById(id) {
    return S.characters.find(c => c.id === id) || null;
  }

  function relTime(iso) {
    if (!iso) return "";
    const d = new Date(iso);
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return "just now";
    if (diff < 3600) return Math.floor(diff / 60) + "m ago";
    if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
    if (diff < 604800) return Math.floor(diff / 86400) + "d ago";
    return d.toLocaleDateString();
  }

  function toast(msg, kind) {
    if (window.showToast) showToast(msg, kind || "info", 2600);
  }

  async function api(url, opts) {
    const res = await fetch(url, Object.assign({
      headers: { "Content-Type": "application/json", "X-CSRFToken": getCsrfToken() },
    }, opts || {}));
    let data;
    try { data = await res.json(); } catch { data = { ok: false, error: "Bad response" }; }
    if (!res.ok && data && data.error) throw new Error(data.error);
    return data;
  }

  // ---- sessions sidebar ------------------------------------------------
  function renderSessions() {
    const list = $("ccSessionList");
    if (!list) return;
    if (!S.sessions.length) {
      list.innerHTML = `<div class="cc-sess-empty">No conversations yet.<br>Start one below! ✨</div>`;
      return;
    }
    list.innerHTML = S.sessions.map(sess => {
      const parts = (sess.character_ids || []).map(charById).filter(Boolean);
      const avatars = parts.slice(0, 4).map(p =>
        `<span class="avatar avatar-xs" style="background:${esc(p.avatar_color)}" title="${esc(p.name)}">${esc(p.initial)}</span>`).join("");
      const icon = sess.mode === "group" ? "👥" : sess.mode === "assistant" ? "✨" : "💬";
      return `
      <div class="cc-sess ${S.active && S.active.id === sess.id ? "active" : ""}"
           data-sid="${esc(sess.id)}" onclick="CC.open('${esc(sess.id)}')">
        <div class="cc-sess-row1">
          <span class="cc-sess-icon">${icon}</span>
          <span class="cc-sess-title">${esc(sess.title || "Conversation")}</span>
          ${sess.pinned ? '<span class="cc-sess-pin">📌</span>' : ""}
        </div>
        <div class="cc-sess-row2">
          <span class="cc-sess-avatars">${avatars || '<span class="text-mute text-xs">assistant</span>'}</span>
          <span class="text-mute text-xs">${sess.message_count} msg · ${relTime(sess.last_message_at)}</span>
        </div>
      </div>`;
    }).join("");
  }

  async function loadSessions(q) {
    try {
      const data = await api("/chat/api/sessions" + (q ? `?q=${encodeURIComponent(q)}` : ""));
      S.sessions = data.sessions || [];
      renderSessions();
    } catch (e) {
      toast("Could not load conversations: " + e.message, "error");
    }
  }

  // ---- conversation rendering ------------------------------------------
  function suggestionPacks() {
    const packs = [
      { icon: "👋", label: "Introduce", text: "Introduce yourself — who are you and what do you do?" },
      { icon: "😱", label: "Biggest fear", text: "What is your biggest fear, and where does it come from?" },
      { icon: "🎯", label: "Greatest desire", text: "What do you want most in the world? What would you sacrifice for it?" },
      { icon: "📖", label: "Childhood", text: "Tell me about your childhood — one memory that shaped you." },
      { icon: "🕯", label: "Secret", text: "What secret are you keeping from the others?" },
      { icon: "⚡", label: "Conflict", text: "Who do you distrust, and why?" },
    ];
    if (S.active && S.active.mode === "group") {
      packs.push({ icon: "🎭", label: "Scene!", text: "Something just happened — everyone, react in character!" });
    }
    return packs;
  }

  function renderSuggestions() {
    const box = $("ccSuggest");
    if (!box) return;
    const msgs = S.messages;
    box.innerHTML = msgs.length ? "" : suggestionPacks().map(p =>
      `<button class="cc-chip" onclick="CC.useSuggestion(this)" data-text="${esc(p.text)}">${p.icon} ${esc(p.label)}</button>`
    ).join("");
  }

  function renderHead() {
    const sess = S.active;
    if (!sess) return;
    const people = $("ccHeadPeople");
    const parts = (sess.character_ids || []).map(charById).filter(Boolean);
    people.innerHTML = parts.map(p => `
      <span class="cc-head-person">
        <span class="avatar" style="background:${esc(p.avatar_color)}">${esc(p.initial)}</span>
        <span class="cc-head-name">${esc(p.name)}</span>
      </span>`).join("") ||
      `<span class="cc-head-person"><span class="avatar" style="background:var(--accent)">✨</span><span class="cc-head-name">AI Assistant</span></span>`;
    const badge = $("ccModeBadge");
    badge.textContent = sess.mode === "group" ? "👥 Group Scene" :
      sess.mode === "assistant" ? "✨ Assistant" : "🎤 Interview";
    badge.dataset.mode = sess.mode;
    // speaker picker for group mode
    const row = $("ccSpeakerRow");
    const sel = $("ccSpeaker");
    if (sess.mode === "group") {
      row.style.display = "flex";
      const cur = sel.value;
      sel.innerHTML = `<option value="">🤖 Auto — AI picks the natural speaker</option>` +
        parts.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("");
      sel.value = cur || "";
    } else {
      row.style.display = "none";
    }
    $("ccPinBtn").style.opacity = sess.pinned ? "1" : "";
    // settings
    const st = sess.settings || {};
    if (st.length) $("ccLength").value = st.length;
    if (st.temperature != null) {
      $("ccTemp").value = st.temperature;
      $("ccTempVal").textContent = st.temperature;
    }
    for (const key of ["ctx_relationships", "ctx_world", "ctx_glossary", "ctx_plot"]) {
      const chip = document.querySelector(`.cc-ctx-chip[data-ctx="${key}"]`);
      if (chip) chip.classList.toggle("on", st[key] !== false);
    }
    if (sess.chapter_id) $("ccChapterAnchor").value = sess.chapter_id;
  }

  function messageHtml(m, idx) {
    const isUser = m.role === "user";
    const time = relTime(m.created_at);
    if (isUser) {
      return `
      <div class="cc-msg user" data-mid="${m.id}">
        <div class="cc-msg-body">
          <div class="cc-msg-bubble">${mdLite(m.content)}</div>
          <div class="cc-msg-actions">
            <button title="Copy" onclick="CC.copyMessage(${m.id})">⧉</button>
            <button title="Edit & resend" onclick="CC.editMessage(${m.id})">✎</button>
            <button title="Delete from here" onclick="CC.deleteMessage(${m.id})">🗑</button>
          </div>
        </div>
        <span class="avatar avatar-sm cc-msg-avatar" style="background:var(--bg-elev-3)">YOU</span>
      </div>`;
    }
    const ch = charById(m.speaker_id)
      || (m.speaker_name ? S.characters.find(c => c.name === m.speaker_name) : null);
    const name = esc(m.speaker_name || (ch ? ch.name : "") || "AI");
    const color = ch ? ch.avatar_color : "var(--accent)";
    const initial = ch ? ch.initial : "✨";
    const lastAi = !S.messages.slice(idx + 1).some(x => x.role === "assistant");
    return `
    <div class="cc-msg char" data-mid="${m.id}">
      <span class="avatar avatar-sm cc-msg-avatar" style="background:${esc(color)}">${esc(initial)}</span>
      <div class="cc-msg-body">
        <div class="cc-msg-name">${name} <span class="cc-msg-time">${esc(time)}</span></div>
        <div class="cc-msg-bubble cc-md">${mdLite(m.content)}</div>
        <div class="cc-msg-actions">
          <button title="Copy" onclick="CC.copyMessage(${m.id})">⧉</button>
          ${lastAi ? `<button title="Regenerate reply" onclick="CC.regenerate()">↻</button>` : ""}
          <button title="Delete from here" onclick="CC.deleteMessage(${m.id})">🗑</button>
        </div>
      </div>
    </div>`;
  }

  function renderMessages() {
    const box = $("ccMessages");
    if (!box) return;
    if (!S.messages.length) {
      const name = (S.active && S.active.character_ids || []).map(id => (charById(id) || {}).name).filter(Boolean);
      box.innerHTML = `<div class="cc-hello">👋 You're now talking with <strong>${esc(name.join(", ") || "your assistant")}</strong>.<br>
        ${S.active && S.active.mode === "group" ? "It's a group scene — they'll react to each other. You direct." : "Ask anything — they remember the whole conversation."}</div>`;
    } else {
      box.innerHTML = S.messages.map(messageHtml).join("");
    }
    box.scrollTop = box.scrollHeight;
  }

  function renderCtxBar(ctx) {
    const bar = $("ccCtxBar");
    if (!ctx) { bar.style.display = "none"; return; }
    const bits = [];
    if (ctx.characters) bits.push(`👤 ${ctx.characters}`);
    if (ctx.relationships) bits.push(`🕸 ${ctx.relationships}`);
    if (ctx.world) bits.push(`🌍 ${ctx.world}`);
    if (ctx.glossary) bits.push(`📖 ${ctx.glossary}`);
    if (ctx.plot) bits.push(`📚 ${ctx.plot}`);
    bar.innerHTML = bits.length
      ? "🧠 knows: " + bits.map(b => `<span class="cc-ctx-pill">${b}</span>`).join("")
      : "🧠 no story context found — add characters/world to enrich answers";
    bar.style.display = "block";
  }

  // ---- conversation lifecycle -------------------------------------------
  async function openSession(sid) {
    if (S.streaming) stopStream();
    try {
      const data = await api(`/chat/api/sessions/${sid}`);
      S.active = data.session;
      S.messages = data.messages || [];
      $("ccEmpty").style.display = "none";
      $("ccActive").style.display = "flex";
      renderHead();
      renderMessages();
      renderSuggestions();
      renderSessions();
      $("ccInput") && $("ccInput").focus();
    } catch (e) {
      toast("Could not open conversation: " + e.message, "error");
    }
  }

  function setStreamingUI(on) {
    S.streaming = on;
    const send = $("ccSendBtn"), stop = $("ccStopBtn"), input = $("ccInput");
    if (!send) return;
    send.style.display = on ? "none" : "";
    stop.style.display = on ? "" : "none";
    input.disabled = on;
    if (!on) input.focus();
  }

  function stopStream() {
    if (S.streamHandle && S.streamHandle.stop) S.streamHandle.stop();
  }

  function typingBubbleHtml() {
    return `
    <div class="cc-msg char cc-typing" id="ccTyping">
      <span class="avatar avatar-sm cc-msg-avatar" style="background:var(--bg-elev-3)">…</span>
      <div class="cc-msg-body">
        <div class="cc-msg-bubble cc-md"><span class="cc-dots"><span></span><span></span><span></span></span></div>
      </div>
    </div>`;
  }

  function streamBubbleHtml(speaker) {
    const ch = speaker ? charById(speaker) : null;
    // match by name too (group mode returns display names)
    const byName = !ch && speaker
      ? S.characters.find(c => c.name === speaker) : null;
    const c = ch || byName;
    const color = c ? c.avatar_color : "var(--accent)";
    const initial = c ? c.initial : (speaker ? speaker.charAt(0).toUpperCase() : "…");
    return `
    <div class="cc-msg char" id="ccStreamMsg">
      <span class="avatar avatar-sm cc-msg-avatar" style="background:${esc(color)}">${esc(initial)}</span>
      <div class="cc-msg-body">
        <div class="cc-msg-name" id="ccStreamName">${esc(speaker || "")}</div>
        <div class="cc-msg-bubble cc-md" id="ccStreamBubble"><span class="cc-caret"></span></div>
      </div>
    </div>`;
  }

  function scrollBottom() {
    const box = $("ccMessages");
    if (box && S.autoScroll) box.scrollTop = box.scrollHeight;
  }

  // send / regenerate share the streaming pipeline
  function runStream(url, body, userText) {
    const box = $("ccMessages");
    if (box.querySelector(".cc-hello")) box.innerHTML = "";
    // user bubble (send only — regenerate keeps the stored question)
    if (userText != null) {
      const div = document.createElement("div");
      div.innerHTML = messageHtml({ id: 0, role: "user", content: userText, created_at: null }, -1);
      const node = div.firstElementChild;
      node.querySelector(".cc-msg-actions").remove();
      box.appendChild(node);
      S.messages.push({ id: 0, role: "user", content: userText, created_at: new Date().toISOString() });
    }
    // typing indicator first, replaced on first chunk
    box.insertAdjacentHTML("beforeend", typingBubbleHtml());
    scrollBottom();
    setStreamingUI(true);

    let full = "";
    let bubble = null;
    let speakerName = window.__ccLastName || "";

    asmStream(url, { body }, {
      onStart(handle) { S.streamHandle = handle; },
      onContext(ctx) {
        renderCtxBar(ctx);
        if (ctx && ctx.speaker) speakerName = ctx.speaker;
        const nameEl = $("ccStreamName");
        if (nameEl && speakerName) nameEl.textContent = speakerName;
      },
      onChunk(_c, all) {
        full = all;
        const typing = $("ccTyping");
        if (typing) {
          typing.remove();
          box.insertAdjacentHTML("beforeend", streamBubbleHtml(speakerName));
        }
        bubble = $("ccStreamBubble");
        if (bubble) {
          bubble.innerHTML = mdLite(full) + '<span class="cc-caret"></span>';
        }
        scrollBottom();
      },
      onDone(finalText) {
        const t = finalText || full;
        const typing = $("ccTyping");
        if (typing) typing.remove();
        const node = $("ccStreamMsg");
        if (node) node.remove();
        S.streamHandle = null;
        setStreamingUI(false);
        if (t && t.trim()) {
          S.messages.push({
            id: 0, role: "assistant", content: t,
            speaker_name: speakerName || "", created_at: new Date().toISOString(),
          });
          renderMessages();
          renderSuggestions();
          loadSessions();
        } else {
          renderMessages();
        }
      },
      onAbort() {
        const node = $("ccStreamMsg") || $("ccTyping");
        S.streamHandle = null;
        setStreamingUI(false);
        if (node) node.remove();
        if (full.trim()) {
          S.messages.push({ id: 0, role: "assistant", content: full + " …",
                            speaker_name: speakerName || "",
                            created_at: new Date().toISOString() });
        }
        renderMessages();
        loadSessions();
      },
      onError(msg) {
        const node = $("ccStreamMsg") || $("ccTyping");
        if (node) node.remove();
        S.streamHandle = null;
        setStreamingUI(false);
        if (userText == null) { /* regenerate error */ }
        toast("AI error: " + (msg || "failed"), "error");
        loadSessions();
      },
    });

    // Hook the SSE 'done' speaker name via a tiny patch: asmStream doesn't
    // expose it, so the speaker arrives through the context event's
    // ctx.speaker field and is used for the optimistic bubble.
  }

  // ---- public API -------------------------------------------------------
  const CC = {

    init() {
      try {
        S.characters = JSON.parse($("ccCharacters").textContent || "[]");
      } catch { S.characters = []; }
      $("ccSearch").addEventListener("input", (e) => {
        clearTimeout(S.searchTimer);
        S.searchTimer = setTimeout(() => loadSessions(e.target.value.trim()), 220);
      });
      const input = $("ccInput");
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); CC.send(); }
      });
      input.addEventListener("input", () => {
        input.style.height = "auto";
        input.style.height = Math.min(input.scrollHeight, 120) + "px";
      });
      // messages click = track autoscroll
      $("ccMessages").addEventListener("scroll", (e) => {
        const el = e.target;
        S.autoScroll = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
      });
      $("ccChapterAnchor").addEventListener("change", () => CC.saveSettings());
      loadSessions();
    },

    async open(sid) { await openSession(sid); },

    // -- new conversation modal --
    newConversation() {
      $("ccNewModal").style.display = "flex";
      document.querySelectorAll(".cc-pick").forEach(el =>
        el.classList.remove("picked"));
      document.querySelectorAll("#ccPickGrid input").forEach(i => i.checked = false);
      CC.pickChanged();
    },

    closeNewModal() { $("ccNewModal").style.display = "none"; },

    pickChanged() {
      const picked = [...document.querySelectorAll("#ccPickGrid input:checked")].map(i => i.value);
      const hint = $("ccPickHint");
      const btn = $("ccStartBtn");
      document.querySelectorAll(".cc-pick").forEach(el => {
        el.classList.toggle("picked", el.querySelector("input").checked);
      });
      if (!picked.length) { hint.textContent = "No one selected"; btn.disabled = true; }
      else if (picked.length === 1) {
        hint.textContent = "🎤 Deep interview — one character, full attention";
        btn.disabled = false;
      } else {
        hint.textContent = `👥 Group scene — ${picked.length} characters react to each other`;
        btn.disabled = false;
      }
    },

    async startConversation() {
      const picked = [...document.querySelectorAll("#ccPickGrid input:checked")].map(i => i.value);
      if (!picked.length) return;
      try {
        const data = await api("/chat/api/sessions", {
          method: "POST",
          body: JSON.stringify({
            mode: picked.length > 1 ? "group" : "character",
            character_ids: picked,
            settings: S.settings,
          }),
        });
        CC.closeNewModal();
        await loadSessions();
        await openSession(data.session.id);
        toast("Conversation started — they remember everything now 🧠", "success");
      } catch (e) {
        toast(e.message, "error");
      }
    },

    // -- messaging --
    send() {
      if (!S.active) { toast("Pick or start a conversation first", "warning"); return; }
      if (S.streaming) return;
      const input = $("ccInput");
      const message = input.value.trim();
      if (!message) return;
      input.value = "";
      input.style.height = "auto";
      const body = {
        message,
        settings: {
          length: $("ccLength").value,
          temperature: parseFloat($("ccTemp").value),
          ctx_relationships: document.querySelector('[data-ctx="ctx_relationships"]').classList.contains("on"),
          ctx_world: document.querySelector('[data-ctx="ctx_world"]').classList.contains("on"),
          ctx_glossary: document.querySelector('[data-ctx="ctx_glossary"]').classList.contains("on"),
          ctx_plot: document.querySelector('[data-ctx="ctx_plot"]').classList.contains("on"),
        },
        speaker_id: ($("ccSpeaker") && $("ccSpeaker").value) || null,
      };
      // remember speaker name for the optimistic bubble
      const sel = $("ccSpeaker");
      if (sel && sel.value) {
        const ch = charById(sel.value);
        window.__ccLastName = ch ? ch.name : "";
      } else if (S.active.character_ids && S.active.character_ids.length === 1) {
        const ch = charById(S.active.character_ids[0]);
        window.__ccLastName = ch ? ch.name : "";
      } else {
        window.__ccLastName = "";
      }
      runStream(`/chat/api/sessions/${S.active.id}/send`, body, message);
    },

    regenerate() {
      if (!S.active || S.streaming) return;
      // optimistic: remove trailing AI bubble(s) from view
      while (S.messages.length && S.messages[S.messages.length - 1].role === "assistant") {
        S.messages.pop();
      }
      renderMessages();
      runStream(`/chat/api/sessions/${S.active.id}/regenerate`, {}, null);
    },

    stop() { stopStream(); },

    useSuggestion(btn) {
      $("ccInput").value = btn.dataset.text;
      CC.send();
    },

    // -- message actions --
    copyMessage(mid) {
      const m = S.messages.find(x => x.id === mid);
      if (!m) return;
      navigator.clipboard.writeText(m.content)
        .then(() => toast("Copied", "success"));
    },

    editMessage(mid) {
      const m = S.messages.find(x => x.id === mid);
      if (!m) return;
      $("ccInput").value = m.content;
      $("ccInput").focus();
      toast("Edit it below, then send — or delete this message first", "info");
    },

    async deleteMessage(mid) {
      if (!S.active) return;
      if (!confirm("Delete this message and everything after it?")) return;
      try {
        const data = await api(`/chat/api/messages/${mid}`, { method: "DELETE" });
        await openSession(S.active.id);
        toast(`Removed ${data.removed} message(s)`, "success");
        loadSessions();
      } catch (e) { toast(e.message, "error"); }
    },

    // -- session actions --
    async renameSession() {
      if (!S.active) return;
      const name = prompt("New name for this conversation:", S.active.title || "");
      if (name == null) return;
      await api(`/chat/api/sessions/${S.active.id}`, {
        method: "PATCH", body: JSON.stringify({ title: name }),
      });
      await loadSessions();
      S.active.title = name;
      renderSessions();
      toast("Renamed", "success");
    },

    async togglePin() {
      if (!S.active) return;
      await api(`/chat/api/sessions/${S.active.id}`, {
        method: "PATCH", body: JSON.stringify({ pinned: !S.active.pinned }),
      });
      S.active.pinned = !S.active.pinned;
      await loadSessions();
      renderHead();
    },

    async deleteSession() {
      if (!S.active) return;
      if (!confirm("Delete this whole conversation? This cannot be undone.")) return;
      try {
        await api(`/chat/api/sessions/${S.active.id}`, { method: "DELETE" });
        S.active = null; S.messages = [];
        $("ccActive").style.display = "none";
        $("ccEmpty").style.display = "flex";
        await loadSessions();
        toast("Conversation deleted", "success");
      } catch (e) { toast(e.message, "error"); }
    },

    async saveSettings() {
      if (!S.active) return;
      const st = {
        length: $("ccLength").value,
        temperature: parseFloat($("ccTemp").value),
        ctx_relationships: document.querySelector('[data-ctx="ctx_relationships"]').classList.contains("on"),
        ctx_world: document.querySelector('[data-ctx="ctx_world"]').classList.contains("on"),
        ctx_glossary: document.querySelector('[data-ctx="ctx_glossary"]').classList.contains("on"),
        ctx_plot: document.querySelector('[data-ctx="ctx_plot"]').classList.contains("on"),
      };
      Object.assign(S.settings, st);
      await api(`/chat/api/sessions/${S.active.id}`, {
        method: "PATCH", body: JSON.stringify({ settings: st }),
      }).catch(() => {});
    },

    toggleCtx(chip) {
      chip.classList.toggle("on");
      CC.saveSettings();
    },

    // -- export --
    async copyTranscript() {
      if (!S.active) return;
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/export`);
        await navigator.clipboard.writeText(data.markdown);
        toast("Transcript copied as Markdown", "success");
      } catch (e) { toast(e.message, "error"); }
    },

    async exportNote() {
      if (!S.active) return;
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/export/note`, { method: "POST" });
        toast(`Saved as note: “${data.title}” — find it in Notes 📝`, "success");
      } catch (e) { toast(e.message, "error"); }
    },

    // -- v8.2 A — Chat → Scene draft ------------------------------------
    async sceneDraft() {
      if (!S.active) return;
      if (!S.messages.length) { toast("Chat a little first — the draft is built from the conversation", "warning"); return; }
      const modal = $("ccDraftModal");
      $("ccDraftTitle").value = "Generating…";
      $("ccDraftText").value = "";
      $("ccDraftHint").textContent = "The AI is turning this conversation into prose…";
      $("ccDraftSaveBtn").disabled = true;
      modal.style.display = "flex";
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/scene-draft`, { method: "POST" });
        $("ccDraftTitle").value = data.draft.title || "Scene draft";
        $("ccDraftText").value = data.draft.text || "";
        $("ccDraftHint").textContent = "Editable preview — save it to the Scenes corkboard when it feels right.";
        $("ccDraftSaveBtn").disabled = false;
      } catch (e) {
        $("ccDraftHint").textContent = "";
        modal.style.display = "none";
        toast(e.message, "error");
      }
    },

    closeDraft() { $("ccDraftModal").style.display = "none"; },

    copyDraft() {
      navigator.clipboard.writeText($("ccDraftText").value)
        .then(() => toast("Draft copied", "success"));
    },

    async saveDraft() {
      if (!S.active) return;
      const draft = { title: $("ccDraftTitle").value, text: $("ccDraftText").value };
      if (!draft.text.trim()) { toast("Nothing to save", "warning"); return; }
      $("ccDraftSaveBtn").disabled = true;
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/scene-draft/save`, {
          method: "POST", body: JSON.stringify({ draft }),
        });
        CC.closeDraft();
        toast(`Scene “${data.title}” saved — open the Scenes page 🎬`, "success", 5000);
      } catch (e) {
        toast(e.message, "error");
        $("ccDraftSaveBtn").disabled = false;
      }
    },

    // -- v8.2 B — Chat → Character card sync ----------------------------
    async syncCharacter(charId) {
      if (!S.active) return;
      if (!S.messages.length) { toast("Chat a little first — there's nothing to extract yet", "warning"); return; }
      const modal = $("ccSyncModal");
      const sel = $("ccSyncChar");
      // populate participant selector (once per open)
      const parts = (S.active.character_ids || []).map(charById).filter(Boolean);
      if (!parts.length) { toast("No characters in this conversation", "warning"); return; }
      sel.innerHTML = parts.map(p =>
        `<option value="${esc(p.id)}" ${charId === p.id ? "selected" : ""}>${esc(p.name)}</option>`).join("");
      modal.style.display = "flex";
      await CC.rerunSync();
    },

    async rerunSync() {
      if (!S.active) return;
      const cid = $("ccSyncChar").value;
      const body = $("ccSyncBody");
      body.innerHTML = '<div class="text-mute text-sm">Analyzing the conversation…</div>';
      $("ccSyncApplyBtn").disabled = true;
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/sync-character`, {
          method: "POST", body: JSON.stringify({ character_id: cid }),
        });
        const ex = data.extraction;
        S.lastSync = ex;
        const groups = [
          ["traits", "🧠 New traits"],
          ["quotes", "💬 Voice quotes"],
          ["background_facts", "📜 Background reveals"],
          ["voice_notes", "🎙 Speech patterns"],
          ["relationship_notes", "🤝 Relationship notes"],
        ];
        let html = "";
        let total = 0;
        for (const [key, label] of groups) {
          const items = ex[key] || [];
          if (!items.length) continue;
          total += items.length;
          html += `<div class="cc-sync-group">
            <div class="cc-sync-group-title">${label} <span class="text-mute">(${items.length})</span></div>
            ${items.map((it, i) => `
              <label class="cc-sync-item">
                <input type="checkbox" checked data-group="${key}" value="${i}">
                <span>${esc(it)}</span>
              </label>`).join("")}
          </div>`;
        }
        body.innerHTML = total
          ? html + `<div class="text-xs text-mute mt-2">${total} new item(s) the conversation revealed for <strong>${esc(ex.character_name)}</strong>. Uncheck anything you disagree with.</div>`
          : `<div class="text-mute text-sm">Nothing new found — the conversation stayed within what's already on ${esc(ex.character_name)}'s card.</div>`;
        $("ccSyncApplyBtn").disabled = total === 0;
      } catch (e) {
        body.innerHTML = `<div class="text-sm" style="color:var(--danger)">${esc(e.message)}</div>`;
      }
    },

    closeSync() { $("ccSyncModal").style.display = "none"; },

    async applySync() {
      const ex = S.lastSync;
      if (!ex || !S.active) return;
      const picked = {};
      document.querySelectorAll("#ccSyncBody input[data-group]").forEach(inp => {
        if (!inp.checked) return;
        const g = inp.dataset.group;
        (picked[g] = picked[g] || []).push((ex[g] || [])[parseInt(inp.value, 10)]);
      });
      const chosen = Object.values(picked).reduce((n, arr) => n + arr.filter(Boolean).length, 0);
      if (!chosen) { toast("Nothing checked — pick at least one item", "warning"); return; }
      $("ccSyncApplyBtn").disabled = true;
      try {
        const data = await api(`/chat/api/characters/${ex.character_id}/sync-character/apply`, {
          method: "POST", body: JSON.stringify({ updates: picked }),
        });
        CC.closeSync();
        toast(`Card updated (${(data.updated || []).join(", ")}) — ${chosen} item(s) added ✍️`, "success", 5000);
      } catch (e) {
        toast(e.message, "error");
        $("ccSyncApplyBtn").disabled = false;
      }
    },

    // -- v8.2 C — Interview coach ----------------------------------------
    async suggestQuestions() {
      if (!S.active) return;
      const row = $("ccSuggest");
      row.innerHTML = `<span class="cc-chip cc-chip-ghost">Thinking of good questions…</span>`;
      try {
        const data = await api(`/chat/api/sessions/${S.active.id}/suggest-questions`, { method: "POST" });
        const qs = data.questions || [];
        if (!qs.length) { row.innerHTML = ""; toast("No suggestions right now", "info"); return; }
        S.coachQuestions = qs;
        row.innerHTML = `<span class="cc-coach-label">💡 Coach:</span>` + qs.map((q, i) =>
          `<button class="cc-chip" data-qi="${i}" onclick="CC.useCoachQuestion(${i})" title="${esc(q)}">${esc(q.length > 64 ? q.slice(0, 61) + "…" : q)}</button>`).join("");
      } catch (e) {
        row.innerHTML = "";
        toast(e.message, "error");
      }
    },

    useCoachQuestion(i) {
      const q = (S.coachQuestions || [])[i];
      if (!q) return;
      $("ccInput").value = q;
      CC.send();
    },
  };

  window.CC = CC;
  document.addEventListener("DOMContentLoaded", () => CC.init());
})();
