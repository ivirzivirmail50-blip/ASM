/* core.js — v9.1.0 (M-05): shared browser helpers, single source.
 *
 * Formerly escapeHtml lived in 3 files (app.js, command_palette.js,
 * reading_mode.js) and asmFetch in 2 (app.js, reading_mode.js) with
 * DIFFERENT return contracts — the last-loaded definition silently won,
 * so reading pages and app pages could disagree about what asmFetch
 * returns. This file loads FIRST in base.html and owns the canonical
 * implementations; page scripts consume them instead of redefining.
 *
 * This is the first step of the gradual ES-module migration: later phases
 * can re-export these via `export` once <script type="module"> lands.
 */
"use strict";

// ---- Namespace (base.html sets window.ASM.csrfToken) --------------------
window.ASM = window.ASM || {};

// ---- HTML escaping (single source, M-05) --------------------------------
window.escapeHtml = function (s) {
  return String(s || "").replace(/[&<>"']/g, function (c) {
    return ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;",
      '"': "&quot;", "'": "&#39;",
    })[c];
  });
};

// ---- CSRF-aware fetch helper (single source, M-05) ----------------------
// Contract (the app-wide standard since app.js v6):
//   returns { res: Response, data: parsed JSON or {ok:false,error:...} }
//   opts.body: object -> JSON-encoded with Content-Type: application/json
window.asmFetch = async function (url, opts) {
  opts = opts || {};
  opts.method = opts.method || "GET";
  opts.headers = opts.headers || {};
  opts.headers["X-CSRFToken"] =
    (window.ASM && window.ASM.csrfToken) || "";
  if (opts.body && !(opts.body instanceof FormData) &&
      !opts.headers["Content-Type"]) {
    opts.headers["Content-Type"] = "application/json";
    if (typeof opts.body !== "string") opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch(url, opts);
  let data;
  try { data = await res.json(); }
  catch (e) { data = { ok: false, error: "Invalid response" }; }
  return { res, data };
};

// ---- Realtime event stream (F-04, v9.3.0) --------------------------------
// Single SSE channel for task progress (export/backup). Auto-reconnect is
// handled by the browser (server sends retry: 3000). Consumers subscribe
// with asmEvents.on("task.done", fn) — payload is the parsed JSON event.
window.asmEvents = (function () {
  var src = null;
  var listeners = {};   // eventName -> [fn]
  var closed = false;

  function ensure() {
    if (src || closed || typeof EventSource === "undefined") return;
    try { src = new EventSource("/events"); } catch (e) { return; }
    src.onmessage = dispatch.bind(null, "message");
    // Named events from the server: hello, task.enqueued, task.progress...
    ["hello", "task.enqueued", "task.progress", "task.done",
     "task.failed", "task.recovered"].forEach(function (name) {
      src.addEventListener(name, function (ev) {
        var payload = {};
        try { payload = JSON.parse(ev.data); } catch (e) { /* yoksay */ }
        dispatch(name, payload);
      });
    });
  }

  function dispatch(name, payload) {
    (listeners[name] || []).forEach(function (fn) {
      try { fn(payload); } catch (e) { /* tüketici hatası akışı düşürmez */ }
    });
  }

  return {
    on: function (name, fn) {
      ensure();
      (listeners[name] = listeners[name] || []).push(fn);
      return function off() {
        listeners[name] = (listeners[name] || []).filter(function (f) {
          return f !== fn;
        });
      };
    },
    close: function () {
      closed = true;
      if (src) { src.close(); src = null; }
    },
  };
})();

// ---- Modal a11y: focus trap + ESC (F-07, v9.3.0) --------------------------
// One delegated handler owns keyboard behavior while ANY modal is visible:
//   * Tab / Shift+Tab cycle inside the topmost visible modal
//   * focus outside the modal is pulled back in
//   * Escape closes the VISIBLE modal (static ones hide, dynamic ones
//     remove) — and stops the legacy app.js handler from deleting hidden
//     static modals it can't see.
window.asmA11y = (function () {
  function visibleBackdrops() {
    var all = document.querySelectorAll(".modal-backdrop");
    var out = [];
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (!el.isConnected) continue;
      var disp = window.getComputedStyle(el).display;
      if (disp && disp !== "none") out.push(el);
    }
    return out;
  }

  function focusables(root) {
    var nodes = root.querySelectorAll(
      "button, [href], input, select, textarea, [tabindex]:not([tabindex=\"-1\"])"
    );
    var out = [];
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.disabled || n.offsetParent === null && n !== document.activeElement) {
        // offsetParent is null for fixed-position ancestors; visibility
        // fallback: bounding rect
        var r = n.getBoundingClientRect();
        if (r.width === 0 && r.height === 0) continue;
      }
      out.push(n);
    }
    return out;
  }

  function closeModal(el) {
    if (el.hasAttribute("data-static-modal")) {
      el.style.display = "none";
    } else {
      el.remove();
    }
  }

  function onKeyDown(e) {
    var modals = visibleBackdrops();
    if (!modals.length) return;
    var top = modals[modals.length - 1];
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopImmediatePropagation();
      closeModal(top);
      return;
    }
    if (e.key !== "Tab") return;
    var items = focusables(top);
    if (!items.length) { e.preventDefault(); return; }
    var idx = items.indexOf(document.activeElement);
    if (idx === -1) {
      // focus escaped the modal — pull it back in
      e.preventDefault();
      items[0].focus();
      return;
    }
    if (e.shiftKey && idx === 0) {
      e.preventDefault();
      items[items.length - 1].focus();
    } else if (!e.shiftKey && idx === items.length - 1) {
      e.preventDefault();
      items[0].focus();
    }
  }

  document.addEventListener("keydown", onKeyDown, true);
  return { visibleBackdrops: visibleBackdrops, closeModal: closeModal };
})();

