/**
 * Writing Insights Dashboard — interactive layer
 *
 * Renders:
 * - Year heatmap (365 cells, hoverable tooltips)
 * - Velocity sparkline (Canvas, no external deps)
 *
 * All data flows in via data-* attributes (NOT inline Jinja) — this is the
 * v7.5 root-architecture rule that prevents Jinja/JS syntax collisions.
 */
(function () {
  'use strict';

  function renderHeatmap() {
    var el = document.getElementById('yearHeatmap');
    if (!el) return;
    var raw;
    try {
      raw = JSON.parse(el.getAttribute('data-days') || '[]');
    } catch (e) {
      console.error('[insights] heatmap data-days parse failed:', e);
      return;
    }
    if (!raw || !raw.length) {
      el.innerHTML = '<div class="text-mute text-sm" style="padding: 1rem; text-align: center">No activity in the last year yet.</div>';
      return;
    }

    // Render cells in 7-row week columns (GitHub-style)
    // Simple approach: render as flexbox-wrap with weekday labels on left
    var html = '<div class="hm-grid">';
    // Weekday labels
    html += '<div class="hm-weekdays">';
    ['Mon', 'Wed', 'Fri', 'Sun'].forEach(function (d) {
      html += '<div class="hm-weekday">' + d + '</div>';
    });
    html += '</div>';
    // Cells container
    html += '<div class="hm-cells">';
    raw.forEach(function (d) {
      var cls = 'insights-heatmap-cell level-' + d.level + (d.is_today ? ' is-today' : '');
      var title = d.date + ': ' + d.words + ' word' + (d.words === 1 ? '' : 's');
      html += '<span class="' + cls + '" data-date="' + d.date + '" data-words="' + d.words + '" title="' + title + '"></span>';
    });
    html += '</div></div>';

    el.innerHTML = html;

    // Click → smooth-scroll to today's date in dashboard
    var todayCell = el.querySelector('.is-today');
    if (todayCell && todayCell.scrollIntoView) {
      // Bring today into view
      todayCell.scrollIntoView({block: 'nearest', inline: 'center', behavior: 'smooth'});
    }
  }

  function renderVelocity() {
    var el = document.getElementById('velocityChart');
    if (!el) return;
    var raw;
    try {
      raw = JSON.parse(el.getAttribute('data-series') || '[]');
    } catch (e) {
      console.error('[insights] velocity data-series parse failed:', e);
      return;
    }
    if (!raw || !raw.length) return;

    var W = el.clientWidth || 320;
    var H = 80;
    var pad = {top: 8, right: 8, bottom: 14, left: 8};
    var innerW = W - pad.left - pad.right;
    var innerH = H - pad.top - pad.bottom;

    var maxVal = Math.max.apply(null, raw.map(function (d) { return d.words; }).concat([1]));
    var stepX = innerW / Math.max(1, raw.length - 1);

    // Build path
    var pathPts = [];
    var areaPts = ['M' + pad.left + ',' + (pad.top + innerH)];
    raw.forEach(function (d, i) {
      var x = pad.left + i * stepX;
      var y = pad.top + innerH - (d.words / maxVal) * innerH;
      pathPts.push((i === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1));
      areaPts.push('L' + x.toFixed(1) + ',' + y.toFixed(1));
    });
    areaPts.push('L' + (pad.left + innerW) + ',' + (pad.top + innerH) + ' Z');

    var svg = [
      '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" preserveAspectRatio="none">',
      '<defs><linearGradient id="velGrad" x1="0" y1="0" x2="0" y2="1">',
      '<stop offset="0%" stop-color="var(--accent)" stop-opacity="0.4"/>',
      '<stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/>',
      '</linearGradient></defs>',
      '<path d="' + areaPts.join(' ') + '" fill="url(#velGrad)"/>',
      '<path d="' + pathPts.join(' ') + '" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>',
      '</svg>'
    ].join('');
    el.innerHTML = svg;
  }

  function init() {
    renderHeatmap();
    renderVelocity();
    // Re-render chart on resize
    var resizeTimer;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(renderVelocity, 200);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
