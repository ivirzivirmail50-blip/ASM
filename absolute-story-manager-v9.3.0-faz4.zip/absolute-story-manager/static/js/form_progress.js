/* v7.4 — form_progress.js
   Adds a sticky "progress bar" + "unsaved changes" pill to any form
   that has class="char-builder" or data-form-progress.

   Usage: just include this script on the page after the form.
   Sections are <details class="char-section"> elements with a
   data-section-key attribute (e.g. data-section-key="identity").
   For each section, define which field selectors determine "completeness"
   via data-section-fields="name,age,gender" (comma-separated).
*/
(function () {
  function init() {
    const form = document.querySelector("form.char-builder, form[data-form-progress]");
    if (!form) return;

    // Avoid double-init
    if (form.dataset.formProgressInit === "1") return;
    form.dataset.formProgressInit = "1";

    // Collect sections
    const sections = Array.from(form.querySelectorAll("details.char-section"));
    if (!sections.length) return;

    // Build progress bar
    const progress = document.createElement("div");
    progress.className = "form-progress-bar";
    progress.setAttribute("role", "navigation");
    progress.setAttribute("aria-label", "Form sections");

    const steps = sections.map((s, i) => {
      const summary = s.querySelector(".char-section-summary");
      if (!summary) return null;
      const title = summary.textContent.trim().replace(/^▸\s*/, "");
      const stepEl = document.createElement("button");
      stepEl.type = "button";
      stepEl.className = "form-progress-step";
      stepEl.dataset.sectionKey = s.dataset.sectionKey || `section-${i}`;
      stepEl.innerHTML = `<span class="step-dot"></span><span>${title}</span>`;
      stepEl.addEventListener("click", () => {
        s.open = true;
        s.scrollIntoView({ behavior: "smooth", block: "start" });
        // Flash the section
        s.style.transition = "box-shadow 0.4s ease";
        s.style.boxShadow = "0 0 0 2px var(--accent)";
        setTimeout(() => s.style.boxShadow = "", 800);
      });
      progress.appendChild(stepEl);
      return stepEl;
    }).filter(Boolean);

    const pctEl = document.createElement("span");
    pctEl.className = "form-progress-pct";
    pctEl.textContent = "0%";
    progress.appendChild(pctEl);

    form.insertBefore(progress, form.querySelector(".char-builder-grid, .card-grid, .char-form-col, .card") || form.firstChild);

    // Build status pill (v7.8: appended into the unified bottom-right dock
    // #brDock so it stacks above the undo toolbar instead of overlapping it)
    const pill = document.createElement("div");
    pill.className = "form-status-pill unsaved";
    pill.innerHTML = '<span class="pill-dot"></span><span class="pill-text">Unsaved changes</span>';
    const dock = document.getElementById("brDock");
    (dock || document.body).appendChild(pill);

    // Section completeness logic — a section is complete when ALL its tracked fields have a value
    function isSectionComplete(section) {
      const fieldsAttr = section.dataset.sectionFields;
      if (!fieldsAttr) return false;
      const fields = fieldsAttr.split(",").map(s => s.trim()).filter(Boolean);
      if (!fields.length) return false;
      return fields.every(name => {
        const el = form.querySelector(`[name="${name}"]`);
        if (!el) return false;
        if (el.type === "checkbox") return el.checked;
        return (el.value || "").trim() !== "";
      });
    }

    function recompute() {
      let complete = 0;
      sections.forEach((s, i) => {
        const ok = isSectionComplete(s);
        if (ok) {
          s.classList.add("complete");
          steps[i]?.classList.add("complete");
          complete++;
        } else {
          s.classList.remove("complete");
          steps[i]?.classList.remove("complete");
        }
      });
      const pct = Math.round((complete / sections.length) * 100);
      progress.style.setProperty("--form-progress", `${pct}%`);
      pctEl.textContent = `${pct}%`;
      // Show the pill if there are any unsaved changes
      const hasAnyInput = sections.some(s => {
        const fields = (s.dataset.sectionFields || "").split(",").map(x => x.trim()).filter(Boolean);
        return fields.some(name => {
          const el = form.querySelector(`[name="${name}"]`);
          return el && (el.value || "").trim() !== "";
        });
      });
      if (hasAnyInput) {
        pill.classList.add("visible");
        pill.querySelector(".pill-text").textContent = "Unsaved changes";
        pill.classList.remove("saving");
      } else {
        pill.classList.remove("visible");
      }
    }

    // Wire up all inputs/textareas/selects to recompute on change
    form.addEventListener("input", recompute);
    form.addEventListener("change", recompute);

    // On submit, mark as saving
    form.addEventListener("submit", () => {
      pill.classList.add("visible", "saving");
      pill.classList.remove("unsaved");
      pill.querySelector(".pill-text").textContent = "Saving…";
    });

    // Initial compute
    recompute();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
