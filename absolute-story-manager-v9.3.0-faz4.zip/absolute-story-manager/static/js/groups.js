/* v7.8 — groups.js · Character Groups page (static-JS architecture)
   All page behaviour for /characters/groups:
   - SortableJS drag between groups (MOVE semantics — familiar)
   - "+ Members" picker: checkbox multi-select that syncs ONE group's member
     list (characters keep memberships in OTHER groups → multi-membership)
   - Per-member "×" removes from that group only
   - Group CRUD (create / edit / delete) modals
   - Group Connections: create / edit / delete group↔group or group↔character
     relationships (first-class, unlike the old auto "group link" edges)

   Architecture (v7.5 notes.js lesson): Jinja never touches this file.
   Data flows in exclusively via #groupsPageData data-* attributes:
     data-groups / data-chars / data-members (JSON)
   Event delegation at document level — one listener survives any DOM change.
*/
(function () {
  "use strict";

  // ---------- data bootstrap ----------
  const dataEl = document.getElementById("groupsPageData");
  let GROUPS = [];
  let CHARS = [];
  let MEMBERS = {};   // groupId -> [characterId]

  function bootstrap() {
    if (!dataEl) return false;
    try {
      GROUPS = JSON.parse(dataEl.dataset.groups || "[]");
      CHARS = JSON.parse(dataEl.dataset.chars || "[]");
      MEMBERS = JSON.parse(dataEl.dataset.members || "{}");
    } catch (e) {
      console.error("groups.js: bad page data", e);
      return false;
    }
    return true;
  }

  const REL_TYPES = ["married_to", "rival_of", "parent_of", "friend_of",
                     "enemy_of", "serves", "mentors", "loves", "betrayed_by", "custom"];

  function groupName(gid) {
    const g = GROUPS.find(x => x.id === gid);
    return g ? g.name : gid;
  }
  function charName(cid) {
    const c = CHARS.find(x => x.id === cid);
    return c ? c.name : cid;
  }
  function nodeLabel(id) {
    return id.startsWith("g-") ? groupName(id.slice(2)) : charName(id);
  }

  // ---------- drag & drop (move) ----------
  function initSortable() {
    if (typeof Sortable === "undefined") return;
    document.querySelectorAll(".kanban-column-body").forEach((c) => {
      Sortable.create(c, {
        group: "characters",
        animation: 150,
        ghostClass: "sortable-ghost",
        chosenClass: "sortable-chosen",
        onEnd: async (evt) => {
          const charId = evt.item.dataset.id;
          const fromGroup = evt.from.dataset.groupId;
          const toGroup = evt.to.dataset.groupId;
          if (fromGroup === toGroup) return;
          if (fromGroup !== "ungrouped") {
            await asmFetch("/characters/groups", {
              method: "POST",
              body: { action: "remove", character_id: charId, group_id: fromGroup }
            });
          }
          if (toGroup !== "ungrouped") {
            await asmFetch("/characters/groups", {
              method: "POST",
              body: { action: "assign", character_id: charId, group_id: toGroup }
            });
          }
          showToast("Character moved.", "success", 1500);
          setTimeout(() => location.reload(), 400);
        }
      });
    });
  }

  // ---------- generic modal helper ----------
  function openModal(title, bodyHtml, okLabel, onOk, opts) {
    opts = opts || {};
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <div class="modal-header"><h3 class="modal-title">${escapeHtml(title)}</h3></div>
        <div class="modal-body">${bodyHtml}</div>
        <div class="modal-footer">
          <button class="btn" data-act="cancel">Cancel</button>
          <button class="btn ${opts.danger ? "btn-danger" : "btn-primary"}" data-act="ok">${escapeHtml(okLabel)}</button>
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    const close = () => backdrop.remove();
    backdrop.querySelector('[data-act="cancel"]').onclick = close;
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) close(); });
    document.addEventListener("keydown", function esc(e) {
      if (e.key === "Escape") { close(); document.removeEventListener("keydown", esc); }
    });
    backdrop.querySelector('[data-act="ok"]').onclick = () => onOk(close, backdrop);
    return backdrop;
  }

  // ---------- "+ Members" picker ----------
  function openMemberPicker(gid) {
    const g = GROUPS.find(x => x.id === gid);
    if (!g) return;
    const current = new Set(MEMBERS[gid] || []);
    const rows = CHARS.map(c => `
      <label class="picker-row" data-search="${escapeHtml((c.name + " " + (c.role || "")).toLowerCase())}">
        <input type="checkbox" value="${c.id}" ${current.has(c.id) ? "checked" : ""}>
        <span class="avatar avatar-sm" style="background: ${c.color}">${escapeHtml(c.name.slice(0, 1).toUpperCase())}</span>
        <span style="color: var(--text)">${escapeHtml(c.name)}</span>
        <span class="text-mute text-xs">${escapeHtml(c.role || "")}</span>
        ${current.has(c.id) ? '<span class="text-xs" style="color: var(--accent-hover)">member</span>' : ""}
      </label>`).join("");
    const body = `
      <div class="text-sm text-dim mb-2">Check everyone who belongs to <strong style="color: var(--text)">${escapeHtml(g.name)}</strong>.
      Their memberships in other groups are kept — one character can be in several groups.</div>
      <input type="text" class="form-input mb-2" id="mpSearch" placeholder="Search characters… (⌘/Ctrl+Enter saves)">
      <div class="picker-list">${rows || '<div class="text-mute text-sm">No characters exist yet.</div>'}</div>`;
    const modal = openModal("Group Members", body, "Save Members", async (close) => {
      const checked = [...modal.querySelectorAll(".picker-list input:checked")].map(i => i.value);
      const { data } = await asmFetch("/characters/groups", {
        method: "POST",
        body: { action: "set_members", group_id: gid, character_ids: checked }
      });
      close();
      if (data.ok) {
        showToast(`Members saved (+${data.added || 0} / −${data.removed || 0}).`, "success");
        setTimeout(() => location.reload(), 500);
      } else {
        showToast(data.error || "Failed", "error", 5000);
      }
    });
    // live search filter
    const search = modal.querySelector("#mpSearch");
    search.addEventListener("input", () => {
      const q = search.value.toLowerCase();
      modal.querySelectorAll(".picker-row").forEach(r => {
        r.style.display = r.dataset.search.includes(q) ? "" : "none";
      });
    });
    search.focus();
  }

  // ---------- group CRUD ----------
  function openGroupModal(g) {
    const isNew = !g;
    const body = `
      <div class="form-row">
        <label class="form-label">Name <span class="text-danger">*</span></label>
        <input type="text" id="gName" class="form-input" placeholder="e.g., Royal Family" value="${g ? escapeHtml(g.name) : ""}">
      </div>
      <div class="form-row">
        <label class="form-label">Description</label>
        <textarea id="gDesc" class="form-textarea" rows="2">${g ? escapeHtml(g.description || "") : ""}</textarea>
      </div>
      <div class="form-row">
        <label class="form-label">Color</label>
        <input type="color" id="gColor" value="${g ? g.color : "#6366f1"}" class="form-input" style="height: 38px">
      </div>`;
    openModal(isNew ? "New Group" : "Edit Group", body, isNew ? "Create" : "Save", async (close) => {
      const name = document.getElementById("gName").value.trim();
      if (!name) { showToast("Name required.", "warning"); return; }
      const payload = {
        action: isNew ? "create" : "update",
        name,
        description: document.getElementById("gDesc").value,
        color: document.getElementById("gColor").value,
      };
      if (!isNew) payload.group_id = g.id;
      const { data } = await asmFetch("/characters/groups", { method: "POST", body: payload });
      close();
      if (data.ok) {
        showToast(isNew ? "Group created." : "Saved.", "success");
        setTimeout(() => location.reload(), 450);
      } else {
        showToast(data.error || "Failed", "error", 5000);
      }
    });
  }

  async function deleteGroup(gid) {
    const ok = await confirmDialog(`Delete group '${groupName(gid)}'? Characters will be ungrouped (not deleted).`,
                                   { danger: true, okLabel: "Delete" });
    if (!ok) return;
    const { data } = await asmFetch("/characters/groups", {
      method: "POST", body: { action: "delete", group_id: gid }
    });
    if (data.ok) { showToast("Group deleted.", "success"); setTimeout(() => location.reload(), 450); }
    else { showToast(data.error || "Failed", "error", 5000); }
  }

  // ---------- connections ----------
  function endpointOptions(selectedId, excludeId) {
    const gOpts = GROUPS.map(g =>
      `<option value="g-${g.id}" ${selectedId === "g-" + g.id ? "selected" : ""}>${escapeHtml(g.name)} (group)</option>`).join("");
    const cOpts = CHARS.map(c =>
      `<option value="${c.id}" ${selectedId === c.id ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("");
    return `<optgroup label="Groups">${gOpts}</optgroup><optgroup label="Characters">${cOpts}</optgroup>`;
  }

  function openConnectionModal(conn) {
    const isNew = !conn;
    const body = `
      <div class="text-sm text-dim mb-3">${isNew ? "Create a new link between two groups — or a group and a character." : "Edit this connection."}</div>
      <div class="form-row">
        <label class="form-label">From</label>
        <select class="form-select" id="connFrom">${endpointOptions(conn ? conn.from_id : null)}</select>
      </div>
      <div class="form-row">
        <label class="form-label">To</label>
        <select class="form-select" id="connTo">${endpointOptions(conn ? conn.to_id : null)}</select>
      </div>
      <div class="form-row">
        <label class="form-label">Type</label>
        <select class="form-select" id="connType">
          ${REL_TYPES.map(t => `<option value="${t}" ${conn && conn.type === t ? "selected" : ""}>${t.replace(/_/g, " ")}</option>`).join("")}
        </select>
      </div>
      <div class="form-row">
        <label class="form-label">Description (optional)</label>
        <textarea class="form-textarea" id="connDesc" rows="2" placeholder="e.g., 'fragile truce since the harbour massacre'">${conn ? escapeHtml(conn.description || "") : ""}</textarea>
      </div>
      <div class="form-row">
        <label class="flex items-center gap-2 text-sm">
          <input type="checkbox" id="connBi" ${conn && parseInt(conn.bidirectional, 10) ? "checked" : ""}> Bidirectional (mutual)
        </label>
      </div>`;
    openModal(isNew ? "New Group Connection" : "Edit Connection", body, isNew ? "Create" : "Save", async (close, modal) => {
      const fromId = modal.querySelector("#connFrom").value;
      const toId = modal.querySelector("#connTo").value;
      if (fromId === toId) { showToast("Pick two different endpoints.", "warning"); return; }
      const type = modal.querySelector("#connType").value;
      const desc = modal.querySelector("#connDesc").value.trim();
      const bi = modal.querySelector("#connBi").checked;
      if (isNew) {
        const { data } = await asmFetch("/characters/relationships/new", {
          method: "POST",
          body: { from_id: fromId, to_id: toId, type, description: desc, bidirectional: bi }
        });
        close();
        if (data.ok) { showToast("Connection created.", "success"); setTimeout(() => location.reload(), 450); }
        else { showToast(data.error || "Failed", "error", 5000); }
      } else {
        const { data } = await asmFetch(`/characters/relationships/${conn.id}/update`, {
          method: "POST",
          body: { type, description: desc, bidirectional: bi }
        });
        close();
        if (data.ok) { showToast("Connection saved.", "success"); setTimeout(() => location.reload(), 450); }
        else { showToast(data.error || "Failed", "error", 5000); }
      }
    });
  }

  async function deleteConnection(row) {
    const connId = row.dataset.connId;
    const desc = `${nodeLabel(row.dataset.fromId)} → ${nodeLabel(row.dataset.toId)}`;
    const ok = await confirmDialog(`Delete connection '${desc}'?`, { danger: true, okLabel: "Delete" });
    if (!ok) return;
    const { data } = await asmFetch(`/characters/relationships/${connId}/delete`, { method: "POST" });
    if (data.ok) {
      showToast("Connection deleted.", "success");
      setTimeout(() => location.reload(), 450);
    } else {
      showToast(data.error || "Failed", "error", 5000);
    }
  }

  // ---------- event delegation ----------
  function wireEvents() {
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-act]");
      if (!btn) return;
      const act = btn.dataset.act;
      try {
        if (act === "new-group") openGroupModal(null);
        else if (act === "edit-group") openGroupModal(GROUPS.find(g => g.id === btn.dataset.groupId));
        else if (act === "delete-group") deleteGroup(btn.dataset.groupId);
        else if (act === "pick-members") openMemberPicker(btn.dataset.groupId);
        else if (act === "remove-member") {
          const gid = btn.dataset.groupId, cid = btn.dataset.characterId;
          asmFetch("/characters/groups", {
            method: "POST",
            body: { action: "remove", character_id: cid, group_id: gid }
          }).then(({ data }) => {
            if (data.ok) {
              showToast(`${charName(cid)} removed from ${groupName(gid)}.`, "success");
              setTimeout(() => location.reload(), 400);
            } else showToast(data.error || "Failed", "error", 5000);
          });
        }
        else if (act === "new-connection") openConnectionModal(null);
        else if (act === "edit-connection") {
          const row = btn.closest(".conn-row");
          openConnectionModal({
            id: row.dataset.connId,
            from_id: row.dataset.fromId,
            to_id: row.dataset.toId,
            type: row.dataset.type,
            description: row.dataset.description,
            bidirectional: row.dataset.bidirectional,
          });
        }
        else if (act === "delete-connection") deleteConnection(btn.closest(".conn-row"));
      } catch (err) {
        console.error("groups.js action failed:", act, err);
        showToast("Action failed — see console (F12).", "error", 5000);
      }
    });
  }

  // ---------- init ----------
  function init() {
    if (!bootstrap()) return;
    initSortable();
    wireEvents();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // public API (for tests / console debugging)
  window.asmGroupsPage = { openMemberPicker, openConnectionModal, openGroupModal };
})();
