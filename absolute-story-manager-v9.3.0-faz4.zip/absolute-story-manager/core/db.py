"""Database engine, scoped sessions, WAL pragmas, write lock.

Concurrency model:
- SQLite WAL mode for concurrent reader/writer throughput.
- Module-level threading.Lock guards write transactions.
- busy_timeout=5000 ensures writers wait briefly instead of erroring.
- Background threads MUST call new_bg_session() to get their own session.
"""
from __future__ import annotations

import logging
import threading
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, scoped_session, sessionmaker

from config import Config, ensure_dirs

log = logging.getLogger("asm.db")

ensure_dirs()

engine = create_engine(
    Config.SQLALCHEMY_DATABASE_URI,
    future=True,
    **Config.SQLALCHEMY_ENGINE_OPTIONS,
)

# Apply SQLite pragmas on every new connection.
@event.listens_for(engine, "connect")
def _set_sqlite_pragmas(dbapi_conn, _record):  # noqa: ANN001
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.execute("PRAGMA busy_timeout=5000")
    cur.execute("PRAGMA foreign_keys=ON")
    # v8.4 — cap the WAL file at 64 MB. Without a limit the -wal file grows
    # to roughly the size of the DB itself (measured: 246 MB WAL next to a
    # 243 MB DB) and never shrinks; checkpointing then truncates it.
    cur.execute("PRAGMA journal_size_limit=67108864")
    cur.close()


session_factory = sessionmaker(bind=engine, expire_on_commit=False, future=True)
SessionLocal = scoped_session(session_factory)

# Single writer lock — every write transaction acquires this.
_write_lock = threading.RLock()


def current_session() -> Session:
    """Return the request-scoped session."""
    return SessionLocal()


@contextmanager
def write_transaction() -> Iterator[Session]:
    """Context manager that yields a session inside a write transaction.

    Acquires the global write lock, begins a transaction, commits on success,
    rolls back on error. Always used for state-changing operations.
    """
    session = SessionLocal()
    try:
        with _write_lock:
            try:
                yield session
                session.commit()
            except Exception:
                session.rollback()
                # v9.1.0 (M-03): a rolled-back write may have (rarely) fed
                # uncommitted values into the settings snapshot via an
                # in-transaction get() — drop it so no phantom data lingers.
                try:
                    from models.settings import invalidate_settings_snapshot
                    invalidate_settings_snapshot()
                except Exception:  # noqa: BLE001 - never mask the real error
                    pass
                raise
    finally:
        SessionLocal.remove()


@contextmanager
def read_session() -> Iterator[Session]:
    """Read-only session context. Auto-closes at the end."""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        SessionLocal.remove()


def new_bg_session() -> Session:
    """Create a fresh session for a background thread.

    Background threads (backup, AI streaming) must NOT share the request
    session. Caller is responsible for committing/rolling back and closing.
    """
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)()


def init_db(seed_defaults: bool = True) -> dict:
    """Bring the schema to the expected Alembic head, then seed defaults.

    v9.1.0 (M-01): table creation and column evolution are owned by Alembic
    migrations (alembic/versions). The old runtime auto-migrate (create_all
    + ADD COLUMN walk) is retired; its logic survives only as the one-time
    legacy adoption bridge inside core.migrations (used when a pre-alembic
    database is detected: align -> backup -> stamp -> upgrade).

    This function:
      1. runs migrations (fresh DB -> full schema; legacy DB -> adopt;
         outdated DB -> upgrade),
      2. installs/refreshes FTS5 tables + triggers (idempotent; outside
         Alembic since FTS virtual tables are not ORM metadata),
      3. re-asserts legacy performance indexes (idempotent safety net,
         asm0002 owns them for new databases),
      4. seeds default snippets and settings.

    Returns a migration report dict (see core.migrations.run_db_migrations).
    """
    from core.migrations import run_db_migrations  # noqa: PLC0415 - lazy

    report = run_db_migrations(engine)

    # Create FTS5 tables + triggers (idempotent).
    from models.search import install_fts
    install_fts(engine)

    # v8.4 — performance indexes (idempotent safety net; migration asm0002
    # is the source of truth for fresh databases).
    try:
        _ensure_performance_indexes(engine)
    except Exception as exc:
        log.warning("Performance index creation skipped: %s", exc)

    # Seed default snippets/templates
    try:
        from services.snippet_service import seed_default_templates
        seed_default_templates()
    except Exception:
        pass  # snippets table might not exist yet on first run

    if seed_defaults:
        _seed_defaults()

    return report


def _get_base():
    """Lazy import of the declarative Base to avoid circular imports."""
    from models import Base
    return Base


# Composite indexes added after v8.4. Each entry: (index_name, table, DDL)
_PERF_INDEXES: tuple[tuple[str, str, str], ...] = (
    # Latest-version lookup: every chapter save runs
    # "SELECT ... WHERE chapter_id = ? ORDER BY version_number DESC LIMIT 1"
    # — with only the single-column chapter_id index SQLite must sort all
    # of a chapter's versions; the composite resolves it directly.
    ("ix_chapter_versions_ch_vnum", "chapter_versions",
     "CREATE INDEX IF NOT EXISTS ix_chapter_versions_ch_vnum "
     "ON chapter_versions (chapter_id, version_number DESC)"),
)


def _ensure_performance_indexes(eng) -> None:
    """Create performance indexes that are missing on older databases."""
    from sqlalchemy import text
    with eng.begin() as conn:
        for _name, table, ddl in _PERF_INDEXES:
            # Guard: skip if the source table doesn't exist yet.
            exists = conn.execute(text(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=:t"
            ), {"t": table}).scalar()
            if exists:
                conn.execute(text(ddl))


def _seed_defaults() -> None:
    """Seed default project + settings rows if missing."""
    from models.project import Project
    from models.settings import DEFAULT_SETTINGS, Setting

    with write_transaction() as s:
        if not s.query(Project).filter_by(id="default").first():
            s.add(Project(id="default", name="My Story",
                          subtitle="Book One of the trilogy"))
        for key, value in DEFAULT_SETTINGS.items():
            if not s.query(Setting).filter_by(key=key).first():
                s.add(Setting(key=key, value=value))
        # v9.1.0 (M-03): rows were inserted bypassing Setting.set — the
        # snapshot (if one exists from an earlier instance) must not shadow
        # the freshly seeded defaults.
        try:
            from models.settings import invalidate_settings_snapshot
            invalidate_settings_snapshot()
        except Exception:  # noqa: BLE001 - best-effort
            pass
