"""Alembic migration runner for Absolute Story Manager (M-01, v9.1.0).

Retires the v9.0.x runtime "auto-migrate" (create_all + ADD COLUMN walk) in
favour of versioned Alembic migrations. The runner is a small state machine:

    alembic_version present?
        yes -> current == EXPECTED_HEAD? -> fast no-op (no alembic import)
               otherwise                  -> alembic upgrade head
        no  -> app tables present? (legacy pre-alembic DB)
               yes -> one-time bridge: align schema to baseline
                      (create_all gap-fill + ADD COLUMN walk — exactly what
                      v9.0.1's init_db did), write a backup next to the DB,
                      stamp baseline, then upgrade to head
               no  -> fresh DB: alembic upgrade head builds the whole schema

FTS5 virtual tables + triggers intentionally stay OUT of Alembic (they are
raw-SQL objects, not ORM metadata) and remain in models.search.install_fts.
"""
from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path
from typing import Any

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine

log = logging.getLogger("asm.migrations")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ALEMBIC_DIR = PROJECT_ROOT / "alembic"
ALEMBIC_INI = PROJECT_ROOT / "alembic.ini"

# The schema revision this codebase expects. Bump when adding a migration.
# Deliberately a literal (NOT derived by walking the script directory) so the
# per-request fast path never has to import alembic.
# test_migrations.py::test_expected_head_matches_script_directory locks this
# constant against the actual alembic script directory.
EXPECTED_HEAD = "asm0005"

# Migration a legacy (pre-alembic) database is stamped at before upgrading.
_BASELINE_REVISION = "asm0001"

# Sentinel table used to recognize a pre-alembic ("legacy") database — one of
# the first tables the old create_all-based init created.
_SENTINEL_TABLE = "projects"


def get_current_revision(eng: Engine) -> str | None:
    """Read the alembic_version row (cheap; no alembic import)."""
    insp = inspect(eng)
    if not insp.has_table("alembic_version"):
        return None
    with eng.connect() as conn:
        return conn.execute(
            text("SELECT version_num FROM alembic_version")
        ).scalar()


def run_db_migrations(eng: Engine) -> dict[str, Any]:
    """Bring `eng`'s database to EXPECTED_HEAD. Returns a report dict.

    Report shape:
        {"action": "noop"|"fresh"|"legacy-adopt"|"upgrade",
         "from": rev|None, "to": rev|None, "backup": Path|None}
    """
    current = get_current_revision(eng)
    if current == EXPECTED_HEAD:
        # Fast path: nothing to do, alembic machinery never imported.
        return {"action": "noop", "from": current, "to": current,
                "backup": None}

    from alembic.config import Config as AlembicConfig

    from alembic import command  # noqa: PLC0415 - lazy: keep fast path cheap

    cfg = AlembicConfig(str(ALEMBIC_INI))
    cfg.set_main_option("script_location", str(ALEMBIC_DIR))
    cfg.set_main_option("sqlalchemy.url", str(eng.url))
    cfg.attributes["configure_logger"] = False

    insp = inspect(eng)
    # v9.3.0 (F-06): an alembic_version TABLE with no row (e.g. a crashed
    # stamp) must fall into the legacy-adopt path, not the plain upgrade
    # path — otherwise alembic would replay asm0001 over existing tables.
    has_version_row = current is not None
    has_app_tables = insp.has_table(_SENTINEL_TABLE)

    backup: Path | None = None
    if has_version_row:
        # Managed DB with pending migrations.
        action = "upgrade"
        log.info("Applying pending schema migrations (at %s)...", current)
        command.upgrade(cfg, "head")
    elif has_app_tables:
        # Legacy database created by v9.x create_all — adopt it.
        action = "legacy-adopt"
        log.info(
            "Legacy database detected (no alembic_version). Aligning schema "
            "to baseline, writing backup, then adopting Alembic..."
        )
        _legacy_align_to_baseline(eng)
        backup = _backup_database(eng)
        command.stamp(cfg, _BASELINE_REVISION)
        command.upgrade(cfg, "head")
    else:
        # Fresh database — migrations build the entire schema.
        action = "fresh"
        log.info("Fresh database: building schema via migrations...")
        command.upgrade(cfg, "head")

    final = get_current_revision(eng)
    report = {"action": action, "from": current, "to": final, "backup": backup}
    if backup is not None:
        log.info("Pre-alembic backup written: %s", backup)
    log.info("Schema now at revision %s (action=%s).", final, action)
    return report


# ---------------------------------------------------------------------------
# Legacy adoption helpers
# ---------------------------------------------------------------------------

def _legacy_align_to_baseline(eng: Engine) -> None:
    """One-time bridge: bring a pre-alembic database to baseline state.

    Reproduces exactly what v9.0.1's init_db did (create_all gap-fill +
    ADD COLUMN auto-migrate) so that stamping the baseline revision is
    truthful. Never drops anything.
    """
    from models import ALL_MODELS, Base  # noqa: PLC0415 - avoids cycles

    Base.metadata.create_all(eng)  # creates missing tables only, idempotent

    from sqlalchemy.sql.schema import Table as _SATable

    seen_tables: set[str] = set()
    for mod in ALL_MODELS:
        for attr_name in dir(mod):
            obj = getattr(mod, attr_name, None)
            if obj is None or not hasattr(obj, "__table__"):
                continue
            tbl_obj = getattr(obj, "__table__", None)
            if not isinstance(tbl_obj, _SATable):
                continue
            tbl = obj.__tablename__
            if tbl in seen_tables:
                continue
            seen_tables.add(tbl)
            insp = inspect(eng)
            if not insp.has_table(tbl):
                continue
            existing_cols = {c["name"] for c in insp.get_columns(tbl)}
            for col in obj.__table__.columns:
                if col.name in existing_cols:
                    continue
                coltype = col.type.compile(eng.dialect)
                sql = f"ALTER TABLE {tbl} ADD COLUMN {col.name} {coltype}"
                if col.server_default is not None:
                    sql += f" DEFAULT {col.server_default.arg}"
                with eng.begin() as conn:
                    conn.execute(text(sql))
                log.info("Legacy align: added %s.%s (%s)",
                         tbl, col.name, coltype)


def _backup_database(eng: Engine) -> Path | None:
    """Copy a file-backed SQLite DB next to itself before legacy adoption.

    Checkpoints WAL first so the copy contains every committed write.
    Returns the backup path, or None for non-file databases (memory).
    """
    from sqlalchemy.engine.url import make_url  # noqa: PLC0415

    db_path = make_url(str(eng.url)).database
    if not db_path or str(db_path) == ":memory:":
        log.warning("Pre-alembic backup skipped: database is not file-backed.")
        return None
    src = Path(str(db_path))
    if not src.exists():
        return None

    # Flush WAL into the main file so the backup is complete.
    try:
        with eng.connect() as conn:
            conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
    except Exception as exc:  # noqa: BLE001 - backup must be best-effort
        log.warning("WAL checkpoint before backup failed: %s", exc)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    dst = src.with_name(f"{src.name}.pre-alembic-{stamp}.bak")
    shutil.copy2(src, dst)
    return dst
