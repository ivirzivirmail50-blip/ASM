"""Eklenti yüzeyi — harici betik hook noktaları (F-12, v9.3.0).

v10 vizyonunun tohumu: uygulamanın belirli olaylarında kullanıcının kendi
betikleri çalışır (export sonrası, bölüm kaydında, yedek sonrası).

Güvenlik modeli (bilinçli tasarım):
  * Varsayılan KAPALI — ``hooks_enabled`` ayarı açık değilse hiçbir betik
    çalışmaz.
  * Betik listesi ``hooks_scripts`` ayarında JSON olarak kullanıcı tarafından
    elle girilir: [{"name": "...", "events": ["after_export"], "command":
    "..."}]. Betikler kullanıcı ayrıcalıklarıyla yerel çalışır — bu, her
   hangi bir masaüstü uygulamasının "çalıştır" davranışıyla aynıdır; ayar
    tablosuna yazabilmek zaten tam kontrole eşdeğerdir.
  * Betik stderr/stdout'u log'lanır, 30 sn zaman aşımı, başarısızlık ANA
    akışı ASLA bozmaz (fire asla raise etmez).

Çağrı protokolü: betik şöyle çağrılır
    <command>            # sh -c ile (Windows: cmd /c)
    stdin:  {"event": "...", ...payload}   (UTF-8 JSON)
    exit 0 = başarı; aksi halde hata kaydı
"""
from __future__ import annotations

import json
import logging
import subprocess
from typing import Any

log = logging.getLogger("asm.hooks")

HOOK_EVENTS = ("after_export", "after_chapter_save", "after_backup")

_TIMEOUT_SECONDS = 30


def hooks_enabled() -> bool:
    from core.db import read_session
    from models.settings import Setting

    try:
        with read_session() as s:
            return bool(Setting.get(s, "hooks_enabled", False))
    except Exception:
        return False


def _load_scripts() -> list[dict[str, Any]]:
    from core.db import read_session
    from models.settings import Setting

    try:
        with read_session() as s:
            raw = Setting.get(s, "hooks_scripts", "[]") or "[]"
    except Exception:
        return []
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        log.warning("hooks_scripts ayarı geçersiz JSON — yoksayıldı.")
        return []
    if not isinstance(data, list):
        return []
    out: list[dict[str, Any]] = []
    for item in data:
        if isinstance(item, dict) and item.get("command") and item.get("events"):
            out.append(item)
    return out


def fire(event: str, payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Bir olayı dinleyen tüm betikleri çalıştır. Asla raise etmez.

    Dönen: betik başına {"name", "command", "ok", "exit_code", "output"}.
    """
    if event not in HOOK_EVENTS:
        log.warning("Bilinmeyen hook olayı yoksayıldı: %s", event)
        return []
    if not hooks_enabled():
        return []

    results: list[dict[str, Any]] = []
    data = json.dumps({"event": event, **payload}, ensure_ascii=False,
                      default=str)
    for script in _load_scripts():
        if event not in (script.get("events") or []):
            continue
        command = str(script["command"])
        name = str(script.get("name") or command[:40])
        try:
            proc = subprocess.run(  # noqa: S602 - kullanıcı tanımlı komut
                command, shell=True, input=data.encode("utf-8"),
                capture_output=True, timeout=_TIMEOUT_SECONDS)
            ok = proc.returncode == 0
            output = (proc.stdout or b"").decode("utf-8", "replace")[-2000:]
            if not ok:
                output += (proc.stderr or b"").decode("utf-8", "replace")[-2000:]
            log.info("Hook %s (%s) %s", name, event,
                     "ok" if ok else f"failed rc={proc.returncode}")
        except subprocess.TimeoutExpired:
            ok, output = False, f"timeout after {_TIMEOUT_SECONDS}s"
            log.warning("Hook %s (%s) zaman aşımı.", name, event)
        except Exception as exc:  # noqa: BLE001 - hook asla akışı bozmasın
            ok, output = False, f"{type(exc).__name__}: {exc}"
            log.warning("Hook %s (%s) çalıştırılamadı: %s", name, event, exc)
        results.append({"name": name, "command": command, "ok": ok,
                        "output": output})
    return results
