"""Single source of truth for the ASM version (S-06).

Previously THREE version strings drifted apart: pyproject.toml said 4.0.0,
app.py's banner said 9.0 and start.bat said 5.0. Every consumer now imports
``__version__`` (or reads it via :func:`get_version`) from this module.
"""
from __future__ import annotations

# v9.3.0 — Faz 4 / backlog turu (F-04..F-12): veri modeli sağlamlaştırması
# (FK/unique/CHECK, asm0003), dayanıklı görev kuyruğu (asm0004), merkezi
# SSE kanalı, yedek 2.0 (AES şifreleme + harici hedef + artımlı), eklenti
# hook'ları, erişilebilirlik paketi, undo/redo iki-yığın (asm0005), kademeli
# strict mypy, Playwright E2E.
# v9.2.0 — Faz 3 (F-01..F-03): AI sağlayıcı adaptör katmanı (4 sağlayıcı,
# retry/backoff), gerçek i18n (JSON çeviriler + sunucu-tarafı t() + latin-ext
# fontlar), editör modernizasyonu (EasyMDE → CodeMirror 6, feature flag'li).
# v9.1.0 — Faz 2 (M-01..M-08): Alembic şema evrimi, proje izolasyonu,
# N+1/cache paketi, merkezi hata zarfı, helper dedup + core.js, editör JS
# göçü, vendor lazy-load + ?v= cache-busting, kapsam delikleri.
__version__ = "9.3.0"

# Human-readable banner lines for the console output in app.py / start scripts.
BANNER_LINES = (
    "  Series Bible · Cross-Book Continuity · Series Hub",
)


def get_version() -> str:
    """Return the application version string."""
    return __version__
