"""CSRF setup via Flask-WTF."""
from __future__ import annotations

from flask_wtf.csrf import CSRFProtect

csrf = CSRFProtect()


def init_csrf(app) -> None:  # noqa: ANN001
    """Attach CSRFProtect to the app."""
    csrf.init_app(app)


def exempt_blueprints_for_loopback(app, blueprints) -> int:  # noqa: ANN001
    """S-02 — grant CSRF exemptions ONLY on loopback deployments.

    The historical design note claimed "the app runs on 127.0.0.1 — no
    external network access", but nothing enforced it: the app actually
    bound to 0.0.0.0 while every blueprint was CSRF-exempted. This function
    closes that gap:

    * Loopback bind host (default) → blueprints are exempted (local-first,
      single-user ergonomics are preserved; forms still carry ``csrf_token``
      fields and ``asmFetch`` still sends ``X-CSRFToken`` as defense-in-depth).
    * Any other host (e.g. ``ASM_HOST=0.0.0.0``) → NO exemption; every write
      request must present a valid CSRF token.

    Returns the number of blueprints actually exempted.
    """
    from config import is_loopback_deployment, resolve_bind_host

    if is_loopback_deployment():
        for bp in blueprints:
            csrf.exempt(bp)
        return len(blueprints)

    app.logger.warning(
        "CSRF: non-loopback bind host %r — CSRF protection is ENFORCED on "
        "all blueprints (no exemptions). Write requests must include a "
        "csrf_token field or the X-CSRFToken header.",
        resolve_bind_host(),
    )
    return 0
