"""Merkezi gerçek-zaman olay hub'ı (F-04, v9.3.0).

Tek publish/subscribe noktası: AI akışı, export ilerlemesi (F-05 kuyruğu),
yedekleme durumu — hepsi bu veri yoluna olay iter; ``/events`` SSE kanalı
abonelere dağıtır.

Tasarım notları:
  * Her abone kendi ``queue.Queue(maxsize=200)`` alır — yavaş bir sekme
    hızlı üreticiyi asla bloklamaz; kuyruğu dolan abone olayları SESSİZCE
    düşürür (SSE'de tek olay kaybı kabul edilebilir; tam durum
    ``/tasks/<id>`` yoklamasıyla toparlanır).
  * ``publish`` hiçbir zaman istisna fırlatmaz — üretici (worker) asla
    yayın hatasıyla ölmez.
  * Tek süreç, tek kullanıcı → bellek-içi veri yolu yeterli (Redis yok).
"""
from __future__ import annotations

import logging
import queue
import threading
from typing import Any

log = logging.getLogger("asm.events")

_SUBSCRIBER_BACKLOG = 200


class EventBus:
    """Bellek-içi pub/sub veri yolu (thread-safe)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subscribers: list[queue.Queue] = []

    def subscribe(self) -> queue.Queue:
        """Yeni abone kuyruğu; SSE akışı başına bir kez çağrılır."""
        q: queue.Queue = queue.Queue(maxsize=_SUBSCRIBER_BACKLOG)
        with self._lock:
            self._subscribers.append(q)
        log.debug("SSE subscriber added (%d active)", len(self._subscribers))
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._lock:
            if q in self._subscribers:
                self._subscribers.remove(q)
        log.debug("SSE subscriber removed (%d active)", len(self._subscribers))

    def publish(self, event: dict[str, Any]) -> int:
        """Olayı tüm abonelere bırak. Dönen: teslim edilen abone sayısı.

        Dolu abone kuyruğunda olay sessizce düşer (block=False) — publish
        asla bloklamaz, asla istisna fırlatmaz.
        """
        delivered = 0
        with self._lock:
            targets = list(self._subscribers)
        for q in targets:
            try:
                q.put_nowait(event)
                delivered += 1
            except queue.Full:
                log.warning("SSE subscriber backlog full — event dropped: %s",
                            event.get("event"))
        return delivered

    @property
    def subscriber_count(self) -> int:
        with self._lock:
            return len(self._subscribers)


# Modül tekil örneği — uygulama genelinde tek veri yolu.
bus = EventBus()


def publish(event: dict[str, Any]) -> int:
    """Kısayol: bus.publish (üreticiler bunu çağırır)."""
    return bus.publish(event)
