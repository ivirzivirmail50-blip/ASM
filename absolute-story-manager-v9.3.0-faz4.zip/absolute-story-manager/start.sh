#!/usr/bin/env bash
# ============================================================
#  Absolute Story Manager — Linux/macOS launcher (S-08)
#  Mirrors start.bat: venv + requirements + DB init + browser.
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

# ---- Bind host (S-01): loopback by default -----------------
# Uncomment to expose the app on your LAN (CSRF is then enforced):
# export ASM_HOST=0.0.0.0
export ASM_HOST="${ASM_HOST:-127.0.0.1}"
export PORT="${PORT:-3000}"

# ---- Version banner (S-06): single source of truth ---------
ASM_VERSION="$(python3 -c 'import sys; sys.path.insert(0,"."); from core.version import __version__; print(__version__)' 2>/dev/null || echo '9.3.0')"

echo
echo "============================================"
echo "  Absolute Story Manager v${ASM_VERSION} - Launcher"
echo "============================================"
echo

# ---- Check Python ------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 not found on PATH."
    echo "Install Python 3.11+ (https://python.org) and re-run."
    exit 1
fi

PYVER_OK="$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 11) else 0)')"
if [ "$PYVER_OK" != "1" ]; then
    echo "[ERROR] Python 3.11+ required (found: $(python3 --version))."
    exit 1
fi

# ---- Check / create venv -----------------------------------
if [ ! -x ".venv/bin/python" ]; then
    echo "[INFO] Creating virtual environment..."
    python3 -m venv .venv
    echo "[OK] Virtual environment created."
else
    echo "[OK] Virtual environment found."
fi

# ---- Activate venv -----------------------------------------
# shellcheck disable=SC1091
source .venv/bin/activate

# ---- Install / update requirements -------------------------
echo "[INFO] Checking requirements..."
pip install -q -r requirements.txt
echo "[OK] Requirements installed."

# ---- Initialize DB if needed -------------------------------
if [ ! -f "data/asm.db" ]; then
    echo "[INFO] Initializing database..."
    PYTHONPATH=. python scripts/init_db.py \
        && echo "[OK] Database initialized." \
        || echo "[WARN] DB init failed - the app will try again on first run."
fi

# ---- Env vars ----------------------------------------------
export FLASK_APP=app.py
export PYTHONPATH=.

echo
echo "============================================"
echo "  Starting Absolute Story Manager..."
echo "  Browser will open at http://127.0.0.1:${PORT}/"
echo "  Press Ctrl+C to stop."
echo "============================================"
echo

# ---- Start app (browser opens automatically via app.py) ----
exec python app.py
