/* CodeMirror 6 bundle entry — F-03 (v9.2.0).
 *
 * Builds a single IIFE exposing window.ASMCM.createMarkdownEditor(), a
 * high-level factory so page code never imports @codemirror internals.
 * The single integration point stays static/js/cm6_editor.js.
 *
 * Build: see scripts/build_cm6.sh
 */
import { EditorState, Compartment } from "@codemirror/state";
import {
  EditorView, keymap, lineNumbers, highlightActiveLine,
  highlightActiveLineGutter, drawSelection, dropCursor,
  rectangularSelection, crosshairCursor, highlightSpecialChars,
} from "@codemirror/view";
import {
  defaultKeymap, history, historyKeymap, indentWithTab,
} from "@codemirror/commands";
import {
  searchKeymap, highlightSelectionMatches, search, openSearchPanel,
} from "@codemirror/search";
import {
  HighlightStyle, syntaxHighlighting, bracketMatching,
  Language, foldNodeProp, indentNodeProp, languageDataProp,
  defineLanguageFacet, foldService, syntaxTree, LanguageSupport,
} from "@codemirror/language";
import { parser as mdParser, GFM, Subscript, Superscript, Emoji } from "@lezer/markdown";
import { NodeProp } from "@lezer/common";
import { tags as t } from "@lezer/highlight";

/* Theme-aware syntax colors via CSS variables defined in main.css */
const asmHighlight = HighlightStyle.define([
  { tag: t.heading, fontWeight: "600" },
  { tag: t.strong, fontWeight: "600" },
  { tag: t.emphasis, fontStyle: "italic" },
  { tag: t.strikethrough, textDecoration: "line-through" },
  { tag: t.link, color: "var(--accent)", textDecoration: "underline" },
  { tag: t.url, color: "var(--accent)" },
  { tag: t.monospace, fontFamily: "var(--font-mono, monospace)" },
  { tag: t.quote, color: "var(--text-dim)" },
  { tag: t.list, color: "var(--accent)" },
  { tag: t.processingInstruction, color: "var(--text-mute)" },
  { tag: t.invalid, color: "var(--danger)" },
]);

const asmTheme = EditorView.theme({
  "&": { height: "auto", minHeight: "400px", fontSize: "1rem" },
  ".cm-scroller": {
    fontFamily: "var(--font-body, 'Inter', sans-serif)",
    lineHeight: "1.7",
  },
  ".cm-content": { padding: "12px 0" },
  ".cm-gutters": {
    backgroundColor: "var(--bg-elev-1)", color: "var(--text-mute)",
    border: "none", borderRight: "1px solid var(--border)",
  },
  "&.cm-focused": { outline: "none" },
  ".cm-activeLine": { backgroundColor: "var(--accent-light)" },
  ".cm-activeLineGutter": { backgroundColor: "var(--accent-light)" },
  ".cm-selectionMatch": { backgroundColor: "var(--accent-soft)" },
  "&.cm-focused .cm-cursor": { borderLeftColor: "var(--accent)" },
});


/* Markdown language WITHOUT nested code languages (EasyMDE parity: it did
 * not parse fenced js/css/html either). Replicates @codemirror/lang-markdown's
 * mkLang minus the lang-html import chain (~120 KB saved). */
const _mdData = defineLanguageFacet({
  commentTokens: { block: { open: "<!--", close: "-->" } },
});
const _headingProp = new NodeProp();

function _isHeading(type) {
  const m = /^(?:ATX|Setext)Heading(\d)$/.exec(type.name);
  return m ? +m[1] : undefined;
}
function _isList(type) {
  return type.name === "OrderedList" || type.name === "BulletList";
}

function asmMarkdownLanguage() {
  const commonmark = mdParser.configure({
    props: [
      foldNodeProp.add(type => {
        return !type.is("Block") || type.is("Document") ||
          _isHeading(type) != null || _isList(type) ? undefined
          : (tree, state) => ({ from: state.doc.lineAt(tree.from).to, to: tree.to });
      }),
      _headingProp.add(_isHeading),
      indentNodeProp.add({ Document: () => null }),
      languageDataProp.add({ Document: _mdData }),
    ],
  });
  const extended = commonmark.configure([GFM, Subscript, Superscript, Emoji, {
    props: [
      foldNodeProp.add({
        Table: (tree, state) => ({ from: state.doc.lineAt(tree.from).to, to: tree.to }),
      }),
    ],
  }]);
  return new LanguageSupport(new Language(_mdData, extended, [], "markdown"));
}

function createMarkdownEditor(opts) {
  /* opts: { parent, doc, onChange, spellcheck, tabSize, readOnly } */
  const listeners = [];
  const view = new EditorView({
    parent: opts.parent,
    state: EditorState.create({
      doc: opts.doc || "",
      extensions: [
        lineNumbers(),
        highlightActiveLineGutter(),
        highlightSpecialChars(),
        history(),
        drawSelection(),
        dropCursor(),
        EditorState.allowMultipleSelections.of(true),
        rectangularSelection(),
        crosshairCursor(),
        highlightActiveLine(),
        highlightSelectionMatches(),
        bracketMatching(),
        asmMarkdownLanguage(),
        syntaxHighlighting(asmHighlight),
        asmTheme,
        search({ top: true }),
        keymap.of([
          ...searchKeymap,
          ...historyKeymap,
          ...defaultKeymap,
          indentWithTab,
        ]),
        EditorState.tabSize.of(opts.tabSize || 4),
        opts.spellcheck === false ? [] : [
          EditorView.contentAttributes.of({ spellcheck: "true" }),
        ],
        EditorView.updateListener.of((v) => {
          if (v.docChanged) listeners.forEach((cb) => cb(v));
        }),
      ],
    }),
  });
  return {
    view,
    onChange(cb) { listeners.push(cb); },
    getValue() { return view.state.doc.toString(); },
    setValue(text) {
      view.dispatch({
        changes: { from: 0, to: view.state.doc.length, insert: text || "" },
      });
    },
    focus() { view.focus(); },
    destroy() { view.destroy(); },
  };
}

window.ASMCM = {
  // The CM6 search panel includes the replace controls (toggle in-panel),
  // so one entry point covers both find and replace.
  createMarkdownEditor, openSearchPanel,
};
