"""v8.0 seed — emotionally varied Turkish chapters for live verification
of the Emotion Arc engine + PWA + mobile audit."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from core.db import init_db, read_session, write_transaction
from models.chapter import Chapter
from models.project import Project
from services._common import new_uuid, now_utc

app = create_app()
init_db(seed_defaults=True)

CH1 = """Sabah sessizce başladı. Köyün üzerinde ince bir sis asılıydı ve Aylin, fenerin
titreyen ışığında mektubu okudu. Kelimeler kısaydı ama her biri göğsüne bir yumruk
gibi indi. Babası ölmüştü. Gözyaşları mektubun satırlarını bulanıklaştırdı,
hüzün odanın duvarlarına kadar yayıldı.

Cenaze günü kasaba halkı sessizce toplandı. Yas, kapıların önüne siyah kumaşlar
astı. Aylin yalnızlığını bir kaya gibi taşıyordu; kimse ona dokunmaya cesaret
edemiyordu. Annesi sürekli ağladı, pişmanlık cümleleri kuruyordu: keşke daha
fazla zaman olsaydı, keşke son bir kez sarılsaydık.

Gece çöktüğünde ormandan gelen sesler değişti. Önce bir çığlık, sonra kesilen
bir sessizlik. Aylin korkuyla geri çekildi; karanlığın içinde bir çift göz
parlıyordu. Kalbi göğsünde çılgınca vuruyordu. Kaçtı, dallar yüzünü
kesiyordu, arkasında dev bir yaratığın nefesini duyuyordu. Tehlike her
adımda biraz daha yaklaşıyordu ve tek düşüncesi hayatta kalmaktı."""

CH2 = """Güneş doğduğunda kasaba uyandı ve herkes meydana toplandı. Zafer haberi gece
boyunca ev ev dolaşmıştı. Aylin sevinçle güldü, komşularına sarıldı;
çocuklar şarkılar söyleyerek sokaklarda koşuyordu. Yıllardır ilk kez
sokaklarda özgürlük ve umut konuşuluyordu.

Fenerler yeniden yakılmıştı, uzun masalar kurulmuş, herkes kutlamaya
hazırdı. Kahkaha sesleri gökyüzüne yükseliyordu. Aylin'in kalbi sevgiyle
doluydu; Kerem'in elini tuttuğunda dünyanın yeniden başladığını hissetti.
Huzur, aylar sonra ilk kez kasabanın üzerine çöktü ve kimse bu barışı
bozmak istemiyordu."""

CH3 = """Liman şehrinde sabah, tuz kokusu ve martı sesleriyle başladı. Balıkçılar
ağlarını topluyor, çocuklar iskelede koşuyordu. Her şey dingin görünüyordu;
denizin üstünde hafif bir pus, uzakta yelkenliler.

Öğlene doğru limana yabancı bir gemi yanaştı. Bayrağı hiçbir krallığa
ait değildi. Seyirciler merakla toplandı; kimse bu gemiyi daha önce
görmemişti. Güverteye çıkan adamın yüzünde ne gülümseme ne tehdit vardı;
yalnızca yorgun, gölgeli bir ifade.

Adam kıyıya indiğinde ilk sözü "ihanet" oldu. Şehirde bir vardiyanın
sırrını taşıdığını, gece yarısı eski fenerin altında buluşacaklarını
fısıldadı. Aylin'in içine şüphe düştü: bu adam kime çalışıyordu ve bu sır
kimleri yakacaktı? Karanlık planlar, tuz kokusunun altında, dalgalar gibi
şehre doğru ilerliyordu."""

with app.app_context():
    with write_transaction() as s:
        if not s.get(Project, "default"):
            s.add(Project(id="default", name="Gölge Şehir", genre="fantasy",
                          target_words=80000, created_at=now_utc()))
        old = s.query(Chapter).all()
        for o in old:
            s.delete(o)
        s.flush()
        for i, (title, content) in enumerate([
            ("Küllerin Ardından", CH1),
            ("Fenerlerin Şarkısı", CH2),
            ("Yabancı Gemi", CH3),
        ]):
            s.add(Chapter(id=new_uuid(), title=title, content=content,
                          sort_order=i,
                          word_count=len(content.split()),
                          created_at=now_utc()))
    with read_session() as s:
        print("chapters:", s.query(Chapter).count())
print("v8.0 seed done")
