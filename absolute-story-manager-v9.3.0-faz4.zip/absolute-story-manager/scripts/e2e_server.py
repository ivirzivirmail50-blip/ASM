"""F-08 E2E: gerçek tarayıcı testi için izole ASM sunucusu.

Kullanım (testten çağrılır):
    python scripts/e2e_server.py <port>

* ASM_DB_URI ortam değişkeni geçici bir dosyaya işaret etmeli (çağıran
  ayarlar) — kalıcı geliştirme DB'sine dokunulmaz.
* Testing modu KAPALI: gerçek worker (F-05) + gerçek SSE (F-04) koşar.
* Ctrl-C / SIGTERM ile kapanır; stdout'a READY yazar.
"""
from __future__ import annotations

import os
import signal
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def main() -> int:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8377

    from app import create_app

    app = create_app()  # production wiring (worker + migrations)

    def _stop(*_args):  # noqa: ANN001, ANN202
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
        os._exit(0)

    signal.signal(signal.SIGTERM, _stop)

    print(f"READY port={port}", flush=True)
    app.run(host="127.0.0.1", port=port, threaded=True,
            debug=False, use_reloader=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
