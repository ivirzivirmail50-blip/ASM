"""Reading Mode 2.0 smoke — page render + external JS + chapter API + no inline Jinja-killer."""
import os
import sys

sys.path.insert(0, os.path.abspath('.'))

from app import create_app

app = create_app()
client = app.test_client()

errors = []

# Page renders
r = client.get('/reading/')
print(f"[page] /reading/ -> {r.status_code}")
if r.status_code != 200:
    errors.append(f"/reading/ page failed: {r.status_code}")
    print(r.data.decode()[:600])
else:
    body = r.data.decode()
    for marker in ["Reading Mode", "readerContent", "highlightToolbar",
                   "bookmarksPanel", "/static/js/reading_mode.js"]:
        if marker not in body:
            errors.append(f"Missing marker: {marker}")
            print(f"  [MISSING] {marker}")

# External JS check
if '/static/js/reading_mode.js' not in body:
    errors.append("reading_mode.js not referenced")
else:
    print("[ok] external reading_mode.js referenced")

# No reading-specific inline script — all moved to static file.
# (base.html has its own inline scripts for sidebar/book switcher which are tested separately)
import re

# Find scripts inside {% block scripts %} ... {% endblock %} — reading.html's own block.
# Easier: check that the rendered page's reading-specific JS is loaded via /static/js/reading_mode.js
if '/static/js/reading_mode.js' not in body:
    errors.append("reading_mode.js not referenced via <script src>")
# Verify the page no longer contains the OLD inline reading functions
for marker in ['async function loadChapters', 'function renderChapters',
               'function attachChapterObserver', 'function applyTheme']:
    if marker in body:
        errors.append(f"Old inline function still in template: {marker}")
        print(f"  [OLD-MARKER] {marker}")

# Static JS exists and is syntactically valid (node --check)
import subprocess

js_path = os.path.abspath('static/js/reading_mode.js')
result = subprocess.run(['node', '--check', js_path], capture_output=True, text=True)
if result.returncode != 0:
    errors.append(f"reading_mode.js SyntaxError: {result.stderr[:300]}")
    print(f"  [SYNTAX-ERROR] {result.stderr[:300]}")
else:
    print("[ok] reading_mode.js node --check passed")

# Chapter API still works
r = client.get('/reading/api/chapters')
print(f"[api] /reading/api/chapters -> {r.status_code}")
if r.status_code != 200:
    errors.append("chapter API failed")
else:
    data = r.get_json()
    if not data.get('ok'):
        errors.append("chapter API returned ok=False")

if errors:
    print("\n❌ ERRORS:")
    for e in errors:
        print(f"  - {e}")
    sys.exit(1)
else:
    print("\n✅ All reading mode checks passed")
