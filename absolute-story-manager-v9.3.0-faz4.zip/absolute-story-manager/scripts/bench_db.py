#!/usr/bin/env python3
"""ASM DB benchmark — measures how DB size affects app performance.

Seeds synthetic data at 3 scales into a scratch DB (never touches real data):
  S1 "one book":     40 ch × 2.5k words,   5 versions/ch
  S2 "series writer": 120 ch × 3k words,  15 versions/ch
  S3 "heavy vault":   300 ch × 3k words,  40 versions/ch + notes/chat/activity

Then times the hot paths: chapter list, dashboard, analytics, FTS search,
chapter save (version snapshot), version list, backup.
Usage: python scripts/bench_db.py [--quick] [--keep]
"""
from __future__ import annotations

import argparse
import json
import os
import random
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP_DIR = HERE.parent
sys.path.insert(0, str(APP_DIR))

BENCH_DIR = APP_DIR / "data" / "bench"
SCALE = {
    "S1": {"chapters": 40, "words": 2500, "versions": 5,
           "label": "1 kitap (~100k kelime)"},
    "S2": {"chapters": 120, "words": 3000, "versions": 15,
           "label": "seri yazarı (~360k kelime)"},
    "S3": {"chapters": 300, "words": 3000, "versions": 40,
           "label": "ağır kasa (~900k kelime)"},
}

_TR_WORDS = (
    "gece sabah pencere deniz fener rüzgar taş duvar sessizlik "
    "kırık hayalet anı şehir sokak lamba gölge su kuyu orman yol "
    "kapı anahtar ses nefes kalp el göz bakış adım kelimeler kitap "
    "mektup sabır korku umut ışık karanlık sonbahar yağmur toprak"
).split()


def _synth_chapter(rng: random.Random, n_words: int) -> str:
    """Turkish-flavoured synthetic prose: paragraphs + dialogue lines."""
    paras = []
    while n_words > 0:
        take = min(rng.randint(40, 120), n_words)
        words = [rng.choice(_TR_WORDS) for _ in range(take)]
        text = " ".join(words)
        text = text[0].upper() + text[1:]
        if rng.random() < 0.18:
            text += f' — "{ " ".join(rng.choice(_TR_WORDS) for _ in range(rng.randint(3, 9))) }"'
        paras.append(text)
        n_words -= take
    return "\n\n".join(paras)


def _fmt_bytes(n: float) -> str:
    mb = n / (1024 * 1024)
    return f"{mb:.1f} MB" if mb >= 1 else f"{n/1024:.0f} KB"


def _fmt_ms(sec: float) -> str:
    return f"{sec * 1000:7.1f} ms"


def setup_scale(tag: str, cfg: dict) -> None:
    """Point the app at a fresh scratch DB and seed it."""
    bench_db = BENCH_DIR / f"bench_{tag}.db"
    if bench_db.exists():
        bench_db.unlink()
    for suffix in ("-wal", "-shm"):
        p = BENCH_DIR / f"bench_{tag}.db{suffix}"
        if p.exists():
            p.unlink()
    os.environ["ASM_DB_URI"] = f"sqlite:///{bench_db}"
    os.environ["ASM_SECRET_KEY"] = "bench-secret"

    # Force fresh import of app modules under the new URI
    for mod in list(sys.modules):
        if mod.startswith(("app", "core", "models", "services", "routes", "config")):
            del sys.modules[mod]

    from core.db import init_db, write_transaction
    init_db(seed_defaults=True)

    from models.activity import ActivityLog
    from models.chapter import Chapter, ChapterVersion
    from models.character import Character
    from models.chat import ChatMessage, ChatSession
    from models.note import Note

    rng = random.Random(42)  # deterministic
    t0 = time.perf_counter()
    with write_transaction() as s:
        # characters
        char_ids = []
        for i in range(12):
            cid = f"benchchar{i}"
            s.add(Character(id=cid, project_id="default", name=f"Karakter {i}",
                            role="main" if i < 3 else "side"))
            char_ids.append(cid)
        # chapters + versions
        for i in range(cfg["chapters"]):
            chid = f"benchch{i:04d}"
            content = _synth_chapter(rng, cfg["words"])
            s.add(Chapter(id=chid, project_id="default",
                          title=f"Bölüm {i + 1}: Uzun Yolun {rng.choice(_TR_WORDS)}",
                          content=content,
                          status=rng.choice(["draft", "revised", "final"]),
                          word_count=content.count(" ") + 1,
                          sort_order=i,
                          character_ids=json.dumps(
                              rng.sample(char_ids, rng.randint(1, 4)),
                          )))
            # versions: each slightly different (simulate edit history)
            base = content
            for v in range(cfg["versions"]):
                mutated = base + f"\n\n(Düzenleme {v + 1}: " + " ".join(
                    rng.choice(_TR_WORDS) for _ in range(20)) + ")"
                s.add(ChapterVersion(
                    id=f"{chid}_v{v:03d}", chapter_id=chid, version_number=v + 1,
                    content=mutated, word_count=mutated.count(" ") + 1,
                    source="manual",
                ))
        # notes
        for i in range(80):
            s.add(Note(id=f"benchnote{i}", project_id="default",
                       title=f"Fikir {i}", body=_synth_chapter(rng, 150),
                       category="idea"))
        # chat sessions + messages
        for i in range(10):
            sess = f"benchsess{i}"
            s.add(ChatSession(id=sess, project_id="default", mode="character",
                              title=f"Sohbet {i}"))
            for m in range(30):
                s.add(ChatMessage(
                    session_id=sess, role="user" if m % 2 == 0 else "assistant",
                    content=_synth_chapter(rng, 60)))
        # activity log
        for i in range(400):
            s.add(ActivityLog(entity_type="chapter",
                              entity_id=f"benchch{i % cfg['chapters']:04d}",
                              action="update", word_count_delta=rng.randint(-50, 200)))
    seed_s = time.perf_counter() - t0

    wal = BENCH_DIR / f"bench_{tag}.db-wal"
    print(f"  [seed] {cfg['chapters']} bölüm, {cfg['versions']} versiyon/bölüm "
          f"→ {seed_s:.1f}s | DB: {_fmt_bytes(bench_db.stat().st_size)}"
          f" (+WAL {_fmt_bytes(wal.stat().st_size if wal.exists() else 0)})")


def run_scale(tag: str, cfg: dict) -> dict:
    """Time the hot paths on the seeded DB. Returns result dict."""
    results: dict[str, float] = {}
    from core import cache as app_cache

    def clear_cache():
        with app_cache.cache._lock:
            app_cache.cache._store.clear()

    from services import analytics_service, chapter_service, stats_service

    def bench(name: str, fn, repeat: int = 1):
        clear_cache()
        best = min(
            (lambda: (lambda t0: (fn(), time.perf_counter() - t0)[1])(
                time.perf_counter()))() for _ in range(repeat)
        )
        results[name] = best
        print(f"    {name:<38} {_fmt_ms(best)}")

    print(f"  [{tag}] {cfg['label']} ölçümleri:")

    # 1. Chapter list page (page 1, 50/page)
    def _list():
        chapter_service.list_chapters(page=1, per_page=50)
    bench("list_chapters (sayfa 1, 50/blok)", _list, repeat=3)

    # 2. Dashboard stats (cold cache)
    bench("dashboard stats (soğuk önbellek)",
          stats_service.all_dashboard_stats)

    # 3. Analytics: all chapters table
    bench("analytics: all_chapters_analytics",
          analytics_service.all_chapters_analytics)

    # 4. Analytics: manuscript summary (full manuscript scan)
    bench("analytics: manuscript_summary (tam tarama)",
          analytics_service.manuscript_summary)

    # 5. Top words (second full scan)
    bench("analytics: top_words (tam tarama)", analytics_service.top_words)

    # 6. FTS search
    from services import search_service
    def _fts():
        try:
            search_service.search_chapters("fener", limit=20)
        except Exception:
            pass
    bench("FTS5 arama ('fener')", _fts, repeat=3)

    # 7. Chapter save path (version snapshot decision)
    def _save():
        ch = chapter_service.get_chapter("benchch0005")
        chapter_service.update_chapter(
            "benchch0005",
            content=(ch.content or "") + " Ek bir cümle daha eklendi.",
            create_version=True)
    bench("update_chapter (kayıt+versiyon)", _save, repeat=2)

    # 8. Version list for a chapter
    bench("get_chapter_with_versions",
          lambda: chapter_service.get_chapter_with_versions("benchch0005"))

    # 9. Backup (zip whole DB) — redirect to bench dir so we never touch real backups
    from config import Config as _Cfg
    from services import backup_service
    _real_backup_dir = _Cfg.BACKUP_DIR
    _Cfg.BACKUP_DIR = BENCH_DIR
    try:
        bench("create_backup (tam zip)",
              lambda: backup_service.create_backup(), repeat=1)
    finally:
        _Cfg.BACKUP_DIR = _real_backup_dir
        for f in BENCH_DIR.glob("asm_backup_*.zip"):
            f.unlink()

    # sizes
    bench_db = BENCH_DIR / f"bench_{tag}.db"
    wal = BENCH_DIR / f"bench_{tag}.db-wal"
    results["_db_mb"] = bench_db.stat().st_size / (1024 * 1024)
    results["_wal_mb"] = (wal.stat().st_size / (1024 * 1024)) if wal.exists() else 0
    print(f"    {'— dosya boyutu':<38} "
          f"{results['_db_mb']:7.1f} MB (+WAL {results['_wal_mb']:.1f} MB)")

    # cleanup backups created by the bench
    for f in BENCH_DIR.glob("asm_backup_*.zip"):
        f.unlink()
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true",
                        help="only S1 + S2 (skip the 10-minute S3 seed)")
    args = parser.parse_args()

    BENCH_DIR.mkdir(parents=True, exist_ok=True)
    tags = ["S1", "S2"] if args.quick else ["S1", "S2", "S3"]
    all_results: dict[str, dict] = {}

    print("=" * 78)
    print("ASM VERİTABANI PERFORMANS ÖLÇÜMÜ")
    print("=" * 78)
    for tag in tags:
        cfg = SCALE[tag]
        setup_scale(tag, cfg)
        all_results[tag] = run_scale(tag, cfg)
        print()

    # Comparative table
    print("=" * 78)
    print(f"{'İşlem':<40}", end="")
    for tag in tags:
        print(f"{tag:>12}", end="")
    print()
    print("-" * 78)
    keys = [k for k in all_results[tags[0]] if not k.startswith("_")]
    for k in keys:
        print(f"{k:<40}", end="")
        for tag in tags:
            print(f"{all_results[tag][k]*1000:>10.0f}ms", end="  ")
        print()
    print("-" * 78)
    print(f"{'DB dosyası':<40}", end="")
    for tag in tags:
        print(f"{all_results[tag]['_db_mb']:>9.1f}MB", end="  ")
    print()
    print(f"{'WAL dosyası':<40}", end="")
    for tag in tags:
        print(f"{all_results[tag]['_wal_mb']:>9.1f}MB", end="  ")
    print()
    print("=" * 78)
    out = BENCH_DIR / "bench_results.json"
    out.write_text(json.dumps(all_results, indent=2, default=str))
    print(f"Sonuçlar: {out}")


if __name__ == "__main__":
    main()
