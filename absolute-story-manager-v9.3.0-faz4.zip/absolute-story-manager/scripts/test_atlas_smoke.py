"""Atlas smoke test — page render + APIs + pin CRUD."""
import json
import os
import sys

sys.path.insert(0, os.path.abspath('.'))

from app import create_app

app = create_app()
client = app.test_client()

errors = []

# Page renders
r = client.get('/atlas/')
print(f"[page] /atlas/ -> {r.status_code}")
if r.status_code != 200:
    errors.append(f"/atlas/ page failed: {r.status_code}")
    print(r.data.decode()[:600])
else:
    body = r.data.decode()
    for marker in ["Story Atlas", "atlasTree", "atlasPinsList", "atlasRoutesList", "/atlas"]:
        if marker not in body:
            errors.append(f"Missing marker: {marker}")
            print(f"  [MISSING] {marker}")

# APIs
for endpoint in ['/atlas/api/full', '/atlas/api/tree', '/atlas/api/pins',
                 '/atlas/api/routes', '/atlas/api/candidates']:
    r = client.get(endpoint)
    print(f"[api] {endpoint} -> {r.status_code}")
    if r.status_code != 200:
        errors.append(f"{endpoint} failed: {r.status_code}")
    else:
        data = r.get_json()
        if not data.get('ok'):
            errors.append(f"{endpoint} returned ok=False")

# Try a pin create + delete roundtrip — use candidates first
r = client.get('/atlas/api/candidates')
data = r.get_json()
chars = data.get('characters', [])
locs = data.get('locations', [])
if not chars or not locs:
    print(f"[skip] pin roundtrip — no candidates (chars={len(chars)}, locs={len(locs)})")
else:
    # Create pin
    r = client.post('/atlas/api/pin',
                    data=json.dumps({
                        "character_id": chars[0]['id'],
                        "location_id": locs[0]['id'],
                        "kind": "current_residence",
                        "note": "smoke test pin"
                    }),
                    content_type='application/json')
    print(f"[api] POST /atlas/api/pin -> {r.status_code}")
    pdata = r.get_json()
    if not pdata.get('ok'):
        errors.append(f"Pin create failed: {pdata}")
    else:
        pin_id = pdata['id']
        # Delete it
        r = client.delete(f'/atlas/api/pin/{pin_id}')
        print(f"[api] DELETE /atlas/api/pin/{pin_id[:8]} -> {r.status_code}")
        ddata = r.get_json()
        if not ddata.get('ok'):
            errors.append(f"Pin delete failed: {ddata}")

# Bad pin (missing fields)
r = client.post('/atlas/api/pin', data=json.dumps({}), content_type='application/json')
print(f"[api] POST /atlas/api/pin (empty) -> {r.status_code} (expected 400)")
if r.status_code != 400:
    errors.append(f"Empty pin should return 400, got {r.status_code}")

# External JS check
r = client.get('/atlas/')
body = r.data.decode()
if '/static/js/atlas.js' in body:
    print("[ok] external atlas.js referenced")
else:
    errors.append("atlas.js not referenced")

if errors:
    print("\n❌ ERRORS:")
    for e in errors:
        print(f"  - {e}")
    sys.exit(1)
else:
    print("\n✅ All atlas checks passed")
