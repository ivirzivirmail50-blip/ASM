"""Quick sanity check for v7.6 insights module — render + API smoke."""
import os
import sys

sys.path.insert(0, os.path.abspath('.'))

from app import create_app

app = create_app()
client = app.test_client()

errors = []

# Page renders
r = client.get('/insights/')
print(f"[page] /insights/ → {r.status_code}")
if r.status_code != 200:
    errors.append(f"/insights/ page failed: {r.status_code}")
    print(r.data.decode()[:600])
else:
    body = r.data.decode()
    # Critical structure markers
    for marker in [
        "Writing Insights",
        "Year Activity Heatmap",
        "Cross-Book Progress",
        "id=\"yearHeatmap\"",
        "id=\"velocityChart\"",
        "/insights",
    ]:
        if marker not in body:
            errors.append(f"Missing marker: {marker}")
            print(f"  [MISSING] {marker}")

# APIs
for endpoint in ['/insights/api/dashboard', '/insights/api/heatmap',
                 '/insights/api/today', '/insights/api/cross-book',
                 '/insights/api/velocity']:
    r = client.get(endpoint)
    print(f"[api] {endpoint} → {r.status_code}")
    if r.status_code != 200:
        errors.append(f"{endpoint} failed: {r.status_code}")
    else:
        data = r.get_json()
        if not data.get('ok'):
            errors.append(f"{endpoint} returned ok=False")

# Inline script safety check — make sure no Python slice syntax leaked into JS
r = client.get('/insights/')
body = r.data.decode()
import re

# Extract script blocks
scripts = re.findall(r'<script[^>]*>(.*?)</script>', body, re.DOTALL)
# Actually insights template uses external JS file — verify
if 'src=' in body and '/static/js/insights.js' in body:
    print("[ok] external insights.js referenced")
else:
    errors.append("insights.js not referenced")

if errors:
    print("\n❌ ERRORS:")
    for e in errors:
        print(f"  - {e}")
    sys.exit(1)
else:
    print("\n✅ All checks passed")
