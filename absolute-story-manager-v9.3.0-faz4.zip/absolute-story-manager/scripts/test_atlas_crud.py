"""Atlas pin CRUD round-trip test with seeded data."""
import json
import os
import sys

sys.path.insert(0, os.path.abspath('.'))

from app import create_app

app = create_app()
client = app.test_client()

# Seed a character + location first
import uuid

from core.db import write_transaction
from models.character import Character
from models.world import WorldEntry

with write_transaction() as s:
    from services._common import current_project_id
    pid = current_project_id(s)
    char = Character(id="atlas_test_char", project_id=pid, name="Atlas Test Hero",
                     role="protagonist", avatar_color="#ff6b6b")
    loc = WorldEntry(id="atlas_test_loc", project_id=pid, type="location",
                     name="Atlas Test City", category="city-state")
    loc2 = WorldEntry(id="atlas_test_loc2", project_id=pid, type="location",
                      name="Atlas Hidden Cave", category="hideout",
                      parent_id="atlas_test_loc")
    s.add(char)
    s.add(loc)
    s.add(loc2)

print("[seed] Character + 2 nested locations added")

errors = []

# Verify candidates now show them
r = client.get('/atlas/api/candidates')
data = r.get_json()
chars = [c for c in data['characters'] if c['id'] == 'atlas_test_char']
locs = [l for l in data['locations'] if l['id'] == 'atlas_test_loc']
print(f"[verify] character found: {len(chars)==1}, location found: {len(locs)==1}")
if not chars or not locs:
    errors.append("Seed data not found")

# Create pin
r = client.post('/atlas/api/pin',
                data=json.dumps({
                    "character_id": "atlas_test_char",
                    "location_id": "atlas_test_loc2",
                    "kind": "hiding",
                    "note": "after the duel"
                }),
                content_type='application/json')
print(f"[api] POST /atlas/api/pin -> {r.status_code}")
pdata = r.get_json()
if not pdata.get('ok'):
    errors.append(f"Pin create failed: {pdata}")
    print(pdata)
else:
    pin_id = pdata['id']

    # Verify pin appears in atlas pins
    r = client.get('/atlas/api/pins')
    pins_data = r.get_json()
    found_pin = next((p for p in pins_data['pins'] if p['id'] == pin_id), None)
    if not found_pin:
        errors.append("Pin not found in /api/pins")
    else:
        print(f"[verify] pin found: kind={found_pin['kind']}, location={found_pin['location']['name']}")
        if found_pin['kind'] != 'hiding':
            errors.append(f"Expected kind=hiding, got {found_pin['kind']}")
        if found_pin['location']['name'] != 'Atlas Hidden Cave':
            errors.append(f"Wrong location: {found_pin['location']['name']}")

    # Verify pin count shows in tree
    r = client.get('/atlas/api/tree')
    tree_data = r.get_json()
    # Walk to find atlas_test_loc2
    def find_node(nodes, target_id):
        for n in nodes:
            if n['id'] == target_id:
                return n
            sub = find_node(n.get('children', []), target_id)
            if sub:
                return sub
        return None
    node = find_node(tree_data['roots'], 'atlas_test_loc2')
    if node and node.get('pins') != 1:
        errors.append(f"Tree pin count for atlas_test_loc2: expected 1, got {node.get('pins')}")
    else:
        print("[verify] tree pin count OK (loc2 has 1 pin)")

    # Delete pin
    r = client.delete(f'/atlas/api/pin/{pin_id}')
    print(f"[api] DELETE /atlas/api/pin/{pin_id[:8]} -> {r.status_code}")
    ddata = r.get_json()
    if not ddata.get('ok'):
        errors.append(f"Pin delete failed: {ddata}")

    # Verify pin gone
    r = client.get('/atlas/api/pins')
    pins_data = r.get_json()
    if any(p['id'] == pin_id for p in pins_data['pins']):
        errors.append("Pin still exists after delete")

# Try delete non-existent pin
r = client.delete('/atlas/api/pin/nonexistent_id')
print(f"[api] DELETE non-existent -> {r.status_code}")
if r.status_code != 404:
    errors.append(f"Expected 404 for non-existent pin, got {r.status_code}")

# Cleanup seed data — delete child first (parent_id FK)
with write_transaction() as s:
    for eid in ["atlas_test_loc2", "atlas_test_loc"]:
        obj = s.get(WorldEntry, eid)
        if obj:
            s.delete(obj)
    obj = s.get(Character, "atlas_test_char")
    if obj:
        s.delete(obj)

if errors:
    print("\n❌ ERRORS:")
    for e in errors:
        print(f"  - {e}")
    sys.exit(1)
else:
    print("\n✅ All atlas CRUD checks passed")
