"""Mock multi-provider AI server for live AI testing (F-01, v9.2.0).

One server, four provider dialects — dispatch by URL path:

- POST /v1/chat/completions      OpenAI-compatible (streaming + JSON)
- POST /v1/messages              Anthropic native (streaming + JSON)
- POST /v1beta/models/{m}:generateContent      Gemini
- POST /v1beta/models/{m}:streamGenerateContent?alt=sse  Gemini streaming
- POST /api/generate             Ollama
- GET  /api/tags                 Ollama model list
- GET  /v1/models                OpenAI-compat / Anthropic model list
- GET  /v1beta/models            Gemini model list

Echoes deterministic Turkish-flavored test prose.
"""
import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


def _reply_for(prompt: str) -> str:
    p = prompt.lower()
    if '"speaker"' in prompt or "reply only as json" in p or "reply only with" in p:
        if "speaker" in p:
            return '{"speaker": "Ayşe Yılmazoğlu"}'
        if "questions" in p:
            return json.dumps({"questions": [
                "Kız kardeşini en son ne zaman gördün ve o gün ne oldu?",
                "Botlara karşı bu korku nereden geliyor?",
                "Bu şehirde kaybolmak ister misin, yoksa bulunmak mı?",
                "Sana en çok kim yanlış anlaşıldı der?",
                "Yarın her şey yıkılsa ilk neyi kurtarırsın?",
            ]}, ensure_ascii=False)
        if "traits" in p or "character card" in p:
            return json.dumps({
                "traits": ["Teknelerden korkuyor ama denizi seviyor — çelişkili cesaret"],
                "quotes": ["Ben Ayşe. Denizi severim ama tekneden korkarım."],
                "background_facts": ["Bir kız kardeşi varmış"],
                "voice_notes": ["Kısa cümleler kuruyor, sorulara direkt cevap veriyor"],
                "relationship_notes": [],
            }, ensure_ascii=False)
    if "scene draft" in p or "scene" in p and "transcript" in p:
        return ("TITLE: Boğazda Bir Akşam\n\n"
                "Rüzgâr Boğaz'ın üstünden geçerken Ayşe kıyıya yaslandı. "
                "Deniz onu hep çağırırdı; tekneler ise tam tersi. "
                "\"Korkuyorum,\" dedi sonunda, sesi suyun sesine karışarak. "
                "\"Ama buradan gitmek de istemiyorum.\"")
    # v8.9 — Review Loop: AI fix suggestion for a beta comment
    if "revision assistant" in p and "beta reader" in p:
        return ("Sorun: Beta okuyucu açılışın temposunu yavaş buluyor — "
                "atmosfer kurmak için harcanan cümleler sahneyi geciktiriyor.\n\n"
                "Çözüm: İlk paragrafı ikiye böl; fener ışığı ve tuz kokusu "
                "detaylarını Mihri'nin karşılama sahnesine taşı, böylece "
                "atmosfer tanıtımı diyalogla aynı anda kurulur.\n\n"
                "Örnek: \"Fenerin ışığı siste süzülürken Mihri onu bekliyordu "
                "— 'Geç kaldın,' dedi, sesi rüzgârda kaybolurken.\"")
    # v8.3 — Style Coach AI Rewrite (show-don't-tell rewrites)
    if "duyguyu doğrudan" in p or "tells the emotion" in p:
        return ("Aylin'in parmakları haritanın kenarında bembeyaz kesildi; "
                "fenerin titrek ışığında yüzüne bir gölge düştü.")
    if "filtre kelime" in p or "filter words" in p or "filter word" in p:
        return ("Islak çakılların üstünden liman zili duyuldu — üç kez, "
                "tuz kokusuyla karışık bir gecenin içinde.")
    if "klişe" in p or "stock phrase" in p:
        return ("Aylin nefesini tuttu: göğsünün altında bir yumruk "
                "kapıyı çalıyordu sanki, her vuruşta biraz daha sert.")
    if "plot hole" in p or "developmental editor" in p:
        return ("## Olası açık noktalar\n\n"
                "1. **Ayşe'nin tekne korkusu** — neden olduğu hiç açıklanmamış. "
                "Öneri: 2. bölümde çocukluk anısı eklenebilir.\n"
                "2. **Kız kardeş** — adı geçiyor ama sahnede yok. "
                "Öneri: bir sahnede mektup ya da telefon.")
    return ("Bu, hikâye bağlamına dayanan bir test yanısıdır. "
            "Karakterler, dünya ve olay örgüsü hatırlanıyor — akış çalışıyor.")


class Handler(BaseHTTPRequestHandler):
    # -- helpers -----------------------------------------------------------
    def _send_json(self, payload: dict, status: int = 200) -> None:
        data = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _start_sse(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()

    def _sse(self, obj: dict) -> None:
        self.wfile.write(f"data: {json.dumps(obj)}\n\n".encode())
        self.wfile.flush()

    @staticmethod
    def _prompt_from(body: dict) -> str:
        # OpenAI-compat / Anthropic
        prompt = ""
        for m in body.get("messages", []):
            prompt += str(m.get("content", "")) + "\n"
        if not prompt:
            # Gemini: contents[].parts[].text
            for c in body.get("contents", []):
                for part in c.get("parts", []):
                    prompt += str(part.get("text", "")) + "\n"
        if not prompt:
            # Ollama: flat prompt field
            prompt = str(body.get("prompt", ""))
        return prompt

    # -- GET: model lists ---------------------------------------------------
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/tags":
            return self._send_json({"models": [
                {"name": "mock-llama3"},
                {"name": "mock-qwen2"},
            ]})
        if path == "/v1/models":
            return self._send_json({"data": [
                {"id": "mock-gpt"},
                {"id": "mock-claude"},
            ]})
        if path == "/v1beta/models":
            return self._send_json({"models": [
                {"name": "models/mock-gemini-flash"},
                {"name": "models/mock-gemini-pro"},
            ]})
        return self._send_json({"error": f"unknown GET {path}"}, status=404)

    # -- POST: generation, all dialects --------------------------------------
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        path = self.path.split("?")[0]
        want_stream = bool(body.get("stream")) or ":streamGenerateContent" in self.path
        text = _reply_for(self._prompt_from(body))

        if path == "/v1/messages":
            return self._anthropic(body, text, want_stream)
        if path.endswith(":generateContent"):
            return self._gemini(text, want_stream=False)
        if path.endswith(":streamGenerateContent"):
            return self._gemini(text, want_stream=True)
        if path == "/api/generate":
            return self._ollama(text, want_stream)
        # default: OpenAI-compatible
        return self._openai(body, text, want_stream)

    def _openai(self, body, text, want_stream):
        if not want_stream:
            return self._send_json({
                "choices": [{"message": {"content": text},
                             "finish_reason": "stop"}],
            })
        self._start_sse()
        for i in range(0, len(text), 7):
            piece = text[i:i + 7]
            self._sse({"choices": [{"delta": {"content": piece}}]})
            time.sleep(0.01)
        self._sse({"choices": [{"delta": {}, "finish_reason": "stop"}]})
        self.wfile.write(b"data: [DONE]\n\n")

    def _anthropic(self, body, text, want_stream):
        if not want_stream:
            return self._send_json({
                "id": "msg_mock",
                "type": "message",
                "role": "assistant",
                "model": body.get("model", "mock-claude"),
                "content": [{"type": "text", "text": text}],
                "stop_reason": "end_turn",
            })
        self._start_sse()
        self._sse({"type": "message_start",
                   "message": {"role": "assistant", "content": []}})
        self._sse({"type": "content_block_start", "index": 0,
                   "content_block": {"type": "text", "text": ""}})
        for i in range(0, len(text), 9):
            piece = text[i:i + 9]
            self._sse({"type": "content_block_delta", "index": 0,
                       "delta": {"type": "text_delta", "text": piece}})
            time.sleep(0.01)
        self._sse({"type": "content_block_stop", "index": 0})
        self._sse({"type": "message_delta",
                   "delta": {"stop_reason": "end_turn"}})
        self._sse({"type": "message_stop"})

    def _gemini(self, text, want_stream):
        if not want_stream:
            return self._send_json({
                "candidates": [{"content": {"role": "model",
                                            "parts": [{"text": text}]},
                                "finishReason": "STOP"}],
                "modelVersion": "mock-gemini",
            })
        self._start_sse()
        for i in range(0, len(text), 11):
            piece = text[i:i + 11]
            self._sse({"candidates": [{"content": {"parts": [{"text": piece}]}}]})
            time.sleep(0.01)
        self._sse({"candidates": [{"finishReason": "STOP"}]})

    def _ollama(self, text, want_stream):
        if not want_stream:
            return self._send_json({"response": text, "done": True})
        self._start_sse()
        for i in range(0, len(text), 8):
            piece = text[i:i + 8]
            self.wfile.write(
                f"{json.dumps({'response': piece, 'done': False})}\n".encode())
            self.wfile.flush()
            time.sleep(0.01)
        self.wfile.write(
            f"{json.dumps({'response': '', 'done': True})}\n".encode())

    def log_message(self, *a):  # quiet
        pass


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 11434), Handler).serve_forever()
