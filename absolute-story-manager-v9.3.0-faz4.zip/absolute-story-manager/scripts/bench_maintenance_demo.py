#!/usr/bin/env python3
"""Demo: what happens to a 243 MB heavy vault after v8.4 maintenance.

Loads the S3 bench DB (300 chapters × 40 versions) and runs the exact
Storage & Health actions: prune versions → VACUUM → sizes before/after.
Usage: python scripts/bench_maintenance_demo.py
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP_DIR = HERE.parent
sys.path.insert(0, str(APP_DIR))

BENCH_DB = APP_DIR / "data" / "bench" / "bench_S3.db"

if not BENCH_DB.exists():
    print("Önce bench_db.py çalıştır (S3 seed'i yok):", BENCH_DB)
    sys.exit(1)

os.environ["ASM_DB_URI"] = f"sqlite:///{BENCH_DB}"
os.environ["ASM_SECRET_KEY"] = "bench-secret"

for mod in list(sys.modules):
    if mod.startswith(("app", "core", "models", "services", "routes", "config")):
        del sys.modules[mod]

from core.db import init_db

init_db(seed_defaults=True)

from services import storage_service


def _mb(p: Path) -> float:
    return round(p.stat().st_size / (1024 * 1024), 1)


wal = BENCH_DB.with_name(BENCH_DB.name + "-wal")

print("=" * 66)
print("AĞIR KASA BAKIM DEMOSU — 300 bölüm × 40 versiyon")
print("=" * 66)
stats = storage_service.db_stats()
print(f"BAŞLANGIÇ: DB {stats['db']['mb']} MB | WAL {stats['wal']['mb']} MB | "
      f"{stats['versions']['total']} versiyon satırı "
      f"({stats['versions']['text_mb']} MB metin)")
print(f"Versiyon limiti: {stats['versions']['limit']} | "
      f"Budanabilir tahmini: {stats['versions']['prunable_estimate']} satır")
print()

t0 = time.perf_counter()
r = storage_service.prune_versions()
t1 = time.perf_counter()
print(f"1) VERSİYON BUDAMA: {r['deleted']} satır silindi, "
      f"~{r['reclaimed_mb']} MB metin geri kazanıldı ({t1-t0:.1f}s)")

t0 = time.perf_counter()
r = storage_service.vacuum()
t1 = time.perf_counter()
print(f"2) VACUUM: {r['before_mb']} MB → {r['after_mb']} MB "
      f"({r['reclaimed_mb']} MB dosya küçüldü, {t1-t0:.1f}s)")

stats = storage_service.db_stats()
print()
print(f"SONUÇ:   DB {stats['db']['mb']} MB | WAL {stats['wal']['mb']} MB | "
      f"{stats['versions']['total']} versiyon satırı")
print(f"İpucu durumu: {[h['key'] for h in stats['hints']]}")
print("=" * 66)
