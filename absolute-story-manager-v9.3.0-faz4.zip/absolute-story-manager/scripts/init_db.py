"""Initialize the database: run migrations + seed defaults.

v9.1.0 (M-01): schema management is now owned by Alembic. This script runs
the same code path the app uses on first request (core.db.init_db), which:
  - fresh DB  -> builds the full schema via `alembic upgrade head`
  - legacy DB -> aligns schema, writes a backup, stamps baseline, upgrades
  - current   -> no-op fast path

Manual migration control is also available:
    alembic upgrade head      (apply pending migrations)
    alembic downgrade -1      (roll back one step)
    alembic revision --autogenerate -m "..."   (create a new migration)
"""
from __future__ import annotations

import sys
from pathlib import Path

# v9.1.0 (M-01): allow `python scripts/init_db.py` from any cwd — the
# project root must be importable for `core` / `models` packages.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.db import init_db  # noqa: E402
from core.logging import configure_logging  # noqa: E402


def main() -> int:
    configure_logging()
    print("Initializing database…")
    print("Note: schema evolution is managed by Alembic (alembic/versions).")
    report = init_db(seed_defaults=True)
    action = report.get("action")
    if action == "legacy-adopt":
        print(f"Legacy database adopted: aligned to baseline, stamped, then "
              f"upgraded to {report.get('to')}.")
        backup = report.get("backup")
        if backup:
            print(f"Pre-migration backup written: {backup}")
            print("Keep this file until you have verified the app works.")
    elif action == "fresh":
        print(f"Fresh database built via migrations (now at {report.get('to')}).")
    elif action == "upgrade":
        print(f"Pending migrations applied (now at {report.get('to')}).")
    else:
        print(f"Schema already up to date (at {report.get('to')}).")
    print("Database ready.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
