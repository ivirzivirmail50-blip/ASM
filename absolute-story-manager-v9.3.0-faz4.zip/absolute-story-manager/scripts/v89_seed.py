"""v8.9 Review Loop — live demo seed.

Turkish demo book with chapters, beta comments from two readers,
an author reply, one resolved thread, and read progress.
Run with:  python scripts/v89_seed.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.db import init_db  # noqa: E402
from services import beta_service, chapter_service  # noqa: E402


def seed() -> None:
    init_db()
    chs = []
    samples = [
        ("Gölge Şehrin Kapısı", [
            "Gece limana çöktü. Fenerlerin ışığı sisten süzülerek rıhtımdaki "
            "balıkçı teknelerine düşüyordu. Elara, babasının eski haritasını "
            "katlayarak cebine koydu; kâğıdın kenarında hâlâ tuz kokusu vardı.\n\n"
            "Kapı bekçisi Mihri, fenerin altında onu bekliyordu. \"Geç kaldın,\" "
            "dedi; sesi rüzgârda neredeyse kayboluyordu.\n\n"
            "\"Fırtına limanı tavsiye etmedi,\" diye cevap verdi Elara. "
            "Külbeyaz'ın uğultusu uzaklardan geliyordu, sanki şehir kendisi "
            "homurdanıyordu."]),
        ("Tuzun Hafızası", [
            "Sabah, dün gece kaybolan teknelerin izini sürmekle geçti. Elara "
            "kayıklardan birinde babasının mührünü buldu; mührün arka "
            "yüzünde, hiç görmediği bir harita kazınmıştı.\n\n"
            "\"Bu mühür Fener Bekçileri'ne ait,\" dedi Mihri. \"Ama onlar yüz "
            "yıl önce dağıldı. Kimse hayatta kalmadı.\""]),
        ("Külbeyaz'ın Çağrısı", [
            "Dağın eteğindeki mağarada Suirler'in izleri tazeydi. Elara "
            "duvarlardaki yazıları okumaya çalışırken, gölgeler arasında bir "
            "şekil kıpırdadı.\n\n\"Korkma,\" dedi şekil. \"Ben seni bekledim.\""]),
    ]
    for title, paragraphs in samples:
        chs.append(chapter_service.create_chapter(
            title=title, content="\n\n".join(paragraphs)))

    a = beta_service.add_comment(
        chs[0].id, "Açılış çok atmosferik ama tempo biraz yavaş — ilk paragraf "
        "kısaltılabilir mi?",
        reader_name="Elif", selected_text="Gece limana çöktü.")
    beta_service.add_reply(
        a.id, "Katılıyorum; ikinci taslakta ilk paragrafı fener sahnesine "
        "odaklayacağım.", reader_name="Yazar", is_author_reply=True)
    beta_service.add_comment(
        chs[0].id, "Mihri'nin diyalogları çok doğal. Fırtına limanı nerede? "
        "Daha önce bahsedilmemiş gibi.",
        reader_name="Mert", selected_text="Fırtına limanı tavsiye etmedi")
    c = beta_service.add_comment(
        chs[1].id, "Mühür sahnesi harika ama Elara'nın tepkisi eksik — "
        "babasının mührünü bulunca ne hissetti?",
        reader_name="Elif", selected_text="babasının mührünü buldu")
    beta_service.resolve_comment(c.id)
    beta_service.add_comment(
        chs[2].id, "\"Ben seni bekledim\" — mükemmel bölüm sonu!",
        reader_name="Mert", selected_text="Ben seni bekledim")

    # Read progress: Elif finished chapters 1-2, Mert finished chapter 1
    beta_service.mark_read(chs[0].id, "Elif")
    beta_service.mark_read(chs[1].id, "Elif")
    beta_service.mark_read(chs[0].id, "Mert")

    print("Seeded:", len(chs), "chapters;",
          "comments: Elif x2, Mert x2, 1 author reply, 1 resolved;",
          "progress: Elif 2/3, Mert 1/3")


if __name__ == "__main__":
    seed()
