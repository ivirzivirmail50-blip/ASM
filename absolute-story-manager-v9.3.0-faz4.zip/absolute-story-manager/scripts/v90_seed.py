"""v9.0 Series Bible — live demo seed.

Two Turkish books sharing characters/world with deliberate continuity
issues (role drift, eye-color conflict, divergent world description,
unlinked same-name entities) + one existing series link.
Run with:  python scripts/v90_seed.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.db import init_db, write_transaction  # noqa: E402
from models.project import Project  # noqa: E402
from models.settings import Setting  # noqa: E402
from services import (  # noqa: E402
    chapter_service,
    character_service,
    series_service,
    world_service,  # noqa: E402
)


def seed() -> None:
    init_db()

    # Ensure a clean second book exists
    from sqlalchemy import select

    from core.db import read_session
    with read_session() as s:
        existing = s.scalars(select(Project).where(
            Project.name == "Külbeyaz'ın Mirası")).first()
    if existing is None:
        with write_transaction() as s:
            pid = "book2-v90"
            s.add(Project(id=pid, name="Külbeyaz'ın Mirası",
                          genre="Fantasy", color="#f59e0b",
                          target_words=80000))
            Setting.set(s, "active_project_id", pid)
    else:
        pid = existing.id
        with write_transaction() as s:
            Setting.set(s, "active_project_id", pid)

    # ---- Book 1 (default "Test Story"→ rename to a proper series book) ----
    with write_transaction() as s:
        p = s.get(Project, "default")
        if p:
            p.name = "Gölge Şehrin Sırrı"
            p.genre = "Fantasy"
            p.color = "#6366f1"
    with write_transaction() as s:
        Setting.set(s, "active_project_id", "default")

    # Book 1 content
    chapter_service.create_chapter(
        title="Gece Limanı",
        content=("Gece limana çöktü. Elara babasının eski haritasını "
                 "katladı ve Fırtına Limanı'na doğru yola çıktı. " * 25))

    character_service.create_character(
        name="Elara", role="protagonist",
        physical="Yeşil gözlü, siyah saçlı genç bir kadın.")
    character_service.create_character(
        name="Mihri", role="supporting",
        physical="Fener bekçisi, gri gözlü yaşlı bir adam.")
    character_service.create_character(
        name="Suir", role="antagonist",
        physical="Külbeyaz'ın efendisi.")

    world_service.create_entry(
        name="Fırtına Limanı", type_="location",
        description="Batı kıyısındaki en büyük liman kenti, fenerleriyle ünlü.")
    world_service.create_entry(
        name="Külbeyaz", type_="magic_system",
        description="Dağın içinde uyuyan eski büyü sistemi.")

    # ---- Book 2 content ----
    with write_transaction() as s:
        Setting.set(s, "active_project_id", pid)

    chapter_service.create_chapter(
        title="Üç Yıl Sonra",
        content=("Üç yıl geçmişti. Elara artık Kâhinler Meclisi'nin "
                 "en genç üyesiydi. Fırtına Limanı değişmişti. " * 25))

    character_service.create_character(
        name="Elara", role="supporting",
        physical="Mavi gözlü, kır saçlı olgun bir kâhin.")  # eye conflict!
    character_service.create_character(
        name="Mihri", role="supporting",
        physical="Fener bekçisi, gri gözlü yaşlı bir adam.")
    character_service.create_character(
        name="Kael", role="protagonist",
        physical="Genç bir haritacı.")

    world_service.create_entry(
        name="Fırtına Limanı", type_="location",
        description="Kuzeydeki dağların eteğinde bir maden kasabası.")  # drift!
    world_service.create_entry(
        name="Kâhinler Meclisi", type_="faction",
        description="Külbeyaz'ı yöneten ruhlar meclisi.")

    # Back to book 1 + one explicit series link: Suir → book 2
    with write_transaction() as s:
        Setting.set(s, "active_project_id", "default")

    from models.character import Character
    with read_session() as s:
        suir = s.scalars(select(Character).where(
            Character.name == "Suir",
            Character.project_id == "default")).first()
    if suir:
        try:
            series_service.link_entity(
                "character", suir.id, pid, note="Gölge olarak geri döner")
            print(f"series link: Suir → {pid}")
        except Exception as exc:
            print("link skipped:", exc)

    print("v9.0 demo seed complete: 2 books, 5 characters (Elara/Mihri shared, "
          "Suir linked), 3 world entries (Fırtına Limanı drifted)")


if __name__ == "__main__":
    seed()
