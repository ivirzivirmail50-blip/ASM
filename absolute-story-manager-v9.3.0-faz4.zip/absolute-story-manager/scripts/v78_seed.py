"""v7.8 seed — characters, groups, memberships, relationships for live diagnosis."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from core.db import init_db, read_session, write_transaction
from models.character import Character, CharacterGroup, CharacterGroupMember, CharacterRelationship
from models.project import Project
from services._common import new_uuid, now_utc

app = create_app()
init_db(seed_defaults=True)
with app.app_context():
    with write_transaction() as s:
        if not s.get(Project, "default"):
            s.add(Project(id="default", name="Gölge Şehir", genre="fantasy",
                          target_words=80000, created_at=now_utc()))
        # wipe previous v78 seed
        s.query(CharacterGroupMember).delete()
        s.query(CharacterRelationship).delete()
        s.query(CharacterGroup).delete()
        for name in ("Aylin", "Kerem", "Bay Vefa", "Zeynep", "Mihri", "Selim"):
            old = s.query(Character).filter_by(name=name).all()
            for o in old:
                s.delete(o)
        s.flush()

        chars = {}
        data = [
            ("Aylin", "protagonist", "#ec4899"),
            ("Kerem", "mentor", "#22c55e"),
            ("Bay Vefa", "antagonist", "#ef4444"),
            ("Zeynep", "supporting", "#3b82f6"),
            ("Mihri", "supporting", "#f59e0b"),
            ("Selim", "supporting", "#a78bfa"),
        ]
        for name, role, color in data:
            c = Character(id=new_uuid(), name=name, role=role, avatar_color=color,
                          created_at=now_utc())
            s.add(c)
            chars[name] = c
        s.flush()

        g1 = CharacterGroup(id=new_uuid(), name="Gölge Tarikatı",
                            description="Şehrin altındaki gizli örgüt", color="#ef4444")
        g2 = CharacterGroup(id=new_uuid(), name="Fener Bekçileri",
                            description="Eski şehir muhafızları", color="#3b82f6")
        g3 = CharacterGroup(id=new_uuid(), name="Çarşı Esnafı",
                            description="Pazar halkı", color="#f59e0b")
        s.add_all([g1, g2, g3])
        s.flush()

        for name, g in [("Bay Vefa", g1), ("Zeynep", g1), ("Selim", g1),
                        ("Aylin", g2), ("Kerem", g2), ("Zeynep", g2),
                        ("Mihri", g3)]:
            s.add(CharacterGroupMember(id=new_uuid(),
                                       character_id=chars[name].id, group_id=g.id))

        rels = [
            ("Aylin", "Kerem", "mentors", "Ustası ve çırağı", False),
            ("Aylin", "Bay Vefa", "enemy_of", "Ailelerini yok etti", True),
            ("Kerem", "Zeynep", "friend_of", "Eski dostlar", True),
            ("Mihri", "Selim", "rival_of", "Çarşıda rekabet", True),
        ]
        for f, t, typ, desc, bi in rels:
            s.add(CharacterRelationship(id=new_uuid(),
                                        from_character_id=chars[f].id,
                                        to_character_id=chars[t].id,
                                        relationship_type=typ, description=desc,
                                        is_bidirectional=bi, created_at=now_utc()))
        s.flush()
        print("SEEDED:", [c.name for c in chars.values()])
        print("GROUPS:", g1.id[:8], g2.id[:8], g3.id[:8])
        print("Zeynep in 2 groups (many-to-many works at DB level)")
