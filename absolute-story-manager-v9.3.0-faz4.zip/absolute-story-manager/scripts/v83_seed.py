"""v8.3 demo seed — Turkish chapters with story dates, characters, plan events."""
import sys

sys.path.insert(0, ".")

from app import create_app
from core.db import init_db, read_session, write_transaction
from models.chapter import Chapter
from models.character import Character
from models.plan import Plan
from services._common import new_uuid


def seed():
    app = create_app()
    with app.app_context():
        init_db(seed_defaults=True)

        with read_session() as s:
            existing = s.query(Chapter).count()
        if existing:
            print(f"already seeded ({existing} chapters) — skipping")
            return

        chapters = [
            ("Küllerin Ardından", "2026-03-01", 1, """Aylin fenerin ışığında haritayı inceledi. Parmaklarının ucunda soğuk bir titreme vardı.
Kerem kapıyı araladı; dışarıdan limanın kokusu, tuz ve katran karışımı, odaya doldu.
"Gidiyoruz," dedi Aylin. Sesi kararlıydı ama içinden bir ses bunun son yolculuk olabileceğini fısıldıyordu.
Bay Vefa köşede oturuyordu, elleri dizlerinde, gözleri kapalı. Derin bir nefes aldı ve sustu.
Rıhtımda martılar çığlık atıyordu. Su, iskelelerin altında hışırtıyla kabarıyordu.
Aylin çantasını topladı. Haritayı son bir kez katladı, kalbinin üstünde tuttu.""", "draft"),
            ("Taneusmae", "2026-03-04", 2, """Üç gün süren sessizlik sonunda bozuldu. Kerem ilk kez o gece konuştu.
"Bana güvenebilir misin?" diye sordu. Aylin cevap vermedi ama omzu Kerem'in omzuna değdi.
Kamp ateşinin sıcaklığı yüzlerine vuruyordu. Odunlar çıtırtıyla yanıyordu.
Aylin bir zamanlar her şeyin bu kadar karmaşık olmadığını düşündü. Şimdi her adım bir tuzağa dönüşebilirdi.
"Eskiden iyiydik," dedi Kerem. Sözleri rüzgarda kayboldu.
Sabah olduğunda sis her yeri kaplamıştı. Aylin ürperdi ve paltosunu sıkıca sardı.""", "revision"),
            ("Seur Kapıları", "2026-03-09", 3, """Seur'un kapıları karardan önce açıldı. Taşların üzerinden soğuk bir rüzgar esiyordu.
Şehrin kokusu metroplexin hiçbir yerine benzemiyordu: yağmur sonrası toprak, eski taş, duman.
Aylin kalabalığa karıştı. Yüzündeki ifadeyi bir maskeye dönüştürdü.
Bay Vefa'nın verdiği yüzük parmağında ağırlık yapıyordu. Metal soğuktu, sanki onu bekliyordu.
İleride bir köşede bir çocuk balon satıyordu. Renkler bu gri şehirde birer parıltıydı.
"Güven bana," dedi kendi kendine. Bu kez kimse duymadı.""", "draft"),
            ("Kanlı Düğün", "2026-03-10", 4, """Düğün salonunun avizesi bin kristal damla gibi titreşiyordu.
Aylin kalabalığın arasında Kerem'i aradı. Onu gördüğünde nefesi kesildi — ama bu sefer mutluluktan değil.
Kapı çalındı ve her şey değişti. İlk çığlık geldi, sonra cam kırılma sesi.
Kerem onu yere çekti. "Kımıldama!" diye bağırdı ama Aylin çoktan ayağa kalkmıştı bile.
Kanı dondu. Karşıda duran adamın yüzü, yıllar önce kaybettiği babasının yüzüydü.
Derin bir nefes aldı ve zamana meydan okudu.""", "draft"),
        ]

        chars = [
            ("Aylin", '["Ayla", "Lin"]'),
            ("Kerem", '["Kero"]'),
            ("Bay Vefa", '["Vefa Amca"]'),
        ]

        plans = [
            ("Liman'da buluşma", "2026-03-01", "plot_point", "Ana Hikaye"),
            ("Kerem'in itirafı", "2026-03-04", "character_moment", "Ana Hikaye"),
            ("Seur'a giriş", "2026-03-09", "plot_point", "Ana Hikaye"),
            ("Düğün saldırısı", "2026-03-10", "climax", "Ana Hikaye"),
            ("Kaçış planı", "2026-03-12", "plot_point", "Ana Hikaye"),
            ("Final düellosu", "2026-04-20", "climax", "Ana Hikaye"),
        ]

        with write_transaction() as s:
            for title, story_date, sort_order, content, status in chapters:
                s.add(Chapter(
                    id=new_uuid(), project_id="default", title=title,
                    story_date=story_date, sort_order=sort_order,
                    status=status, content=content,
                    word_count=len(content.split()),
                ))
            for name, aliases in chars:
                s.add(Character(
                    id=new_uuid(), project_id="default", name=name,
                    aliases=aliases, role="main",
                ))
            for title, story_date, event_type, track in plans:
                s.add(Plan(
                    id=new_uuid(), project_id="default", title=title,
                    story_date=story_date, event_type=event_type, track=track,
                    status="idea", sort_order=0,
                ))
        print("seeded:", len(chapters), "chapters,", len(chars), "chars,", len(plans), "plans")


if __name__ == "__main__":
    seed()
