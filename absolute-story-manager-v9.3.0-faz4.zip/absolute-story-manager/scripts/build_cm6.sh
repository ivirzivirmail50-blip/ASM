#!/usr/bin/env bash
# F-03 (v9.2.0) — build the CodeMirror 6 vendor bundle.
#
# The bundle is BUILT locally (CodeMirror 6 ships ESM modules only, no UMD)
# and committed to static/vendor/codemirror/ — the app never needs npm at
# runtime. Re-run this only when upgrading the @codemirror/* dependencies.
#
# Requirements: node >= 18, npm.
set -euo pipefail
cd "$(dirname "$0")/cm6_build"

if [ ! -d node_modules ]; then
  echo ">> installing @codemirror/* + esbuild (first run)…"
  npm install --no-audit --no-fund \
    @codemirror/state@6 @codemirror/view@6 @codemirror/commands@6 \
    @codemirror/search@6 @codemirror/language@6 @codemirror/lang-markdown@6 \
    @lezer/highlight@^1 @lezer/markdown@^1 @lezer/common@^1 esbuild
fi

echo ">> bundling…"
./node_modules/.bin/esbuild entry.mjs \
  --bundle --minify --format=iife \
  --outfile=../../static/vendor/codemirror/codemirror.bundle.min.js

echo ">> refreshing vendor manifest…"
cd ../..
"$(command -v python3 || true)" scripts/fetch_vendor.py >/dev/null 2>&1 || \
  python scripts/fetch_vendor.py >/dev/null

echo ">> done:"
ls -la static/vendor/codemirror/codemirror.bundle.min.js
