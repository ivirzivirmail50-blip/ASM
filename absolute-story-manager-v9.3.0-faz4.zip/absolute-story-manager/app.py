"""Flask app factory for Absolute Story Manager."""
from __future__ import annotations

import logging
import traceback
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request, url_for

from config import Config, ensure_dirs
from core.csrf import init_csrf
from core.db import init_db
from core.errors import AsmError
from core.logging import configure_logging, set_request_id


def _verify_vendor_manifest(log) -> None:
    """Verify all vendor assets listed in MANIFEST.txt exist on disk.

    Warns (does NOT crash) if any asset is missing, pointing the user to
    `python scripts/fetch_vendor.py`.
    """
    manifest = Path(__file__).parent / "static" / "vendor" / "MANIFEST.txt"
    if not manifest.exists():
        log.warning(
            "Vendor manifest not found at %s. "
            "Run: python scripts/fetch_vendor.py", manifest
        )
        return
    base = manifest.parent.parent  # static/
    missing: list[str] = []
    checked = 0
    try:
        for line in manifest.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Format: name | version | source_url | local_path | sha256
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 4:
                continue
            local_path = parts[3]
            full = base / local_path.replace("static/", "", 1)
            checked += 1
            if not full.exists():
                missing.append(local_path)
    except Exception as exc:
        log.warning("Failed to read vendor manifest: %s", exc)
        return
    if missing:
        log.warning(
            "Vendor manifest check: %d/%d assets OK, %d missing. "
            "Run: python scripts/fetch_vendor.py. Missing: %s",
            checked - len(missing), checked, len(missing),
            ", ".join(missing[:5]),
        )
    else:
        log.info("Vendor manifest OK: %d assets verified.", checked)


def create_app(testing: bool = False) -> Flask:
    """App factory: register config, blueprints, error handlers, CSRF."""
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)
    if testing:
        app.config["TESTING"] = True
        app.config["WTF_CSRF_ENABLED"] = False
    # Auto-reload templates on change (local-first app; small perf cost is OK)
    app.config["TEMPLATES_AUTO_RELOAD"] = True
    app.jinja_env.auto_reload = True

    # Logging
    configure_logging()
    log = logging.getLogger("asm.app")

    # Ensure data dirs
    ensure_dirs()

    # Vendor manifest check (warn, don't crash)
    _verify_vendor_manifest(log)

    # Initialize DB on first request (lazy init avoids import-time DB creation
    # during testing).
    _db_initialized = {"done": False}
    _backup_checked = {"done": False}

    @app.before_request
    def _ensure_db():  # noqa: ANN202
        if not _db_initialized["done"]:
            try:
                init_db(seed_defaults=True)
            except Exception:
                log.exception("DB init failed")
            _db_initialized["done"] = True
            # v8.8 — background auto-maintenance (PRAGMA optimize + WAL
            # checkpoint) at most every N days, never blocking startup.
            if not app.config.get("TESTING"):
                try:
                    from services.perf_service import start_boot_maintenance
                    start_boot_maintenance()
                except Exception:
                    pass
                # v9.3.0 (F-05): durable task worker — recovers stale
                # running tasks on startup, then drains the queue.
                try:
                    from services.task_queue_service import start_worker
                    start_worker()
                except Exception:
                    log.exception("Task worker failed to start")
        if not _backup_checked["done"]:
            _backup_checked["done"] = True
            try:
                from services.backup_service import maybe_auto_backup
                maybe_auto_backup()
            except Exception:
                pass
        set_request_id()

    # CSRF
    init_csrf(app)

    # Register blueprints
    # v6.0: auto-discovery — every routes/*.py module exposing `bp` is
    # registered automatically (deterministic sorted order). Previously this
    # was a hand-maintained list repeated 3 times (import / exempt / register).
    import importlib
    import pkgutil

    from routes import __path__ as routes_path

    csrf_exempted_bps: list = []
    for mod_info in sorted(pkgutil.iter_modules(routes_path), key=lambda m: m.name):
        try:
            mod = importlib.import_module(f"routes.{mod_info.name}")
        except Exception:
            log.exception("Failed to import routes.%s — skipped", mod_info.name)
            continue
        bp = getattr(mod, "bp", None)
        if bp is not None and hasattr(bp, "register"):
            app.register_blueprint(bp)
            csrf_exempted_bps.append(bp)

    # CSRF Exemption — Design Decision (v9.0.1 / S-02: enforced by code)
    # ================================================================
    # This is a local-first, single-user application (loopback only, no auth).
    # CSRF protection is exempted on blueprints ONLY while the effective bind
    # host is loopback (the default since S-01):
    #   1. Default bind host is 127.0.0.1 — no external network access
    #   2. No user authentication = no session hijacking risk
    #   3. All forms include hidden csrf_token fields as defense-in-depth
    #   4. JSON API endpoints (asmFetch) send X-CSRFToken header
    # If the app is made network-accessible (ASM_HOST=0.0.0.0), the
    # exemptions are NOT granted and every write request must present a
    # valid CSRF token.
    from core.csrf import exempt_blueprints_for_loopback
    exempted = exempt_blueprints_for_loopback(app, csrf_exempted_bps)
    log.info("Registered %d blueprints via auto-discovery "
             "(%d CSRF-exempted: loopback deployment).",
             len(csrf_exempted_bps), exempted)

    # Static file route for data/media (so map images etc. can be served)
    @app.route("/media/<path:filename>")
    def _serve_media(filename: str):  # noqa: ANN202
        import logging as _lg
        import mimetypes

        from flask import abort, send_file

        from config import Config
        from security.upload import safe_join
        _log = _lg.getLogger("asm.media")
        try:
            safe_path = safe_join(Config.MEDIA_DIR, *filename.split("/"))
            if not safe_path.exists():
                _log.warning("Media not found: %s -> %s", filename, safe_path)
                abort(404)
            mime = mimetypes.guess_type(str(safe_path))[0] or 'application/octet-stream'
            _log.info("Serving media: %s (mime=%s, size=%d)", safe_path, mime, safe_path.stat().st_size)
            resp = send_file(str(safe_path), mimetype=mime, conditional=False)
            resp.headers['Cache-Control'] = 'no-cache'
            return resp
        except Exception as exc:
            _log.error("Media serve error: %s -> %s", filename, exc)
            abort(404)

    # Inject settings + theme into every template
    @app.context_processor
    def _inject_asset() -> dict[str, Any]:
        """v9.1.0 (M-07): single source for static URLs with ?v= stamping.

        Every `{{ asset('js/app.js') }}` renders as
        `/static/js/app.js?v=<__version__>` — one macro stamps ALL assets
        (previously a handful of templates carried hand-written ?v=2 / ?v=4
        / ?v=v83 tags that went stale). The version bump is synchronized
        with the service worker's cache names (static/js/sw.js VERSION), so
        a release invalidates both browser cache entries and SW caches.
        """
        from core.version import __version__

        def _asset(path: str) -> str:
            return f"{url_for('static', filename=path)}?v={__version__}"

        return {"asset": _asset, "app_version": __version__}

    @app.context_processor
    def _inject_globals() -> dict[str, Any]:
        # v9.1.0 (M-03): this processor ran on EVERY request and issued
        # (a) one settings query, (b) one projects query and (c) ONE
        # word_count query PER PROJECT (classic N+1 — 10 books = 10 extra
        # queries per page). Now: single session, ONE grouped SUM query,
        # and a 60 s TTL cache (invalidated instantly on any Setting.set).
        from core.cache import cache

        cached = cache.get("globals:v1")
        if cached is not None:
            return cached

        from sqlalchemy import func

        from core.db import read_session
        from models.chapter import Chapter
        from models.project import Project
        from models.settings import Setting
        try:
            with read_session() as s:
                settings = Setting.all_settings(s)
                # v7.0 — story_title comes from the ACTIVE PROJECT (single
                # source of truth), with legacy-setting and "My Story"
                # fallbacks; the book list feeds the topbar switcher.
                active_pid = settings.get("active_project_id", "default") or "default"
                active_project_name = settings.get("story_title", "My Story")
                active_project = None
                books: list[dict[str, Any]] = []
                # ONE grouped query replaces the per-project word_count loop.
                words_by_pid: dict[str, int] = {
                    pid: (total or 0) for pid, total in (
                        s.query(Chapter.project_id,
                                func.sum(Chapter.word_count))
                        .group_by(Chapter.project_id)
                        .all()
                    )
                }
                prows = s.query(Project).order_by(Project.created_at.asc()).all()
                for p in prows:
                    is_active = p.id == active_pid
                    if is_active:
                        active_project_name = p.name
                        active_project = p
                    books.append({
                        "id": p.id, "name": p.name, "genre": p.genre,
                        "color": p.color or "var(--accent)",
                        "is_active": is_active,
                        "words": words_by_pid.get(p.id, 0),
                    })
                if not prows:
                    books.append({"id": "default", "name": "My Story",
                                  "genre": None, "color": "var(--accent)",
                                  "is_active": True, "words": 0})
        except Exception:
            settings = {}
            active_pid = "default"
            active_project_name = settings.get("story_title", "My Story")
            active_project = None
            books = [{"id": "default", "name": "My Story", "genre": None,
                      "color": "var(--accent)", "is_active": True, "words": 0}]
        # Generate custom theme CSS if configured
        custom_theme_css = ""
        try:
            from services.theme_service import generate_css, get_config
            custom_theme_css = generate_css(get_config())
        except Exception:
            pass
        payload = {
            "settings": settings,
            "theme": settings.get("theme", "dark"),
            "story_title": active_project_name,
            "active_project_name": active_project_name,
            "active_project": active_project,
            "books": books,
            "custom_theme_css": custom_theme_css,
            "ui_version": settings.get("ui_version", "v2"),
        }
        cache.set("globals:v1", payload, ttl_seconds=60)
        return payload

    # Inject i18n (translations + language) into every template
    @app.context_processor
    def _inject_i18n() -> dict[str, Any]:
        try:
            from services.i18n_service import (
                SUPPORTED_LANGUAGES,
                get_current_language,
                get_translation_dict,
            )
            lang = get_current_language()
            translations = get_translation_dict(lang)
            return {
                "ui_lang": lang,
                "t": lambda key: translations.get(key, key),
                # v9.2.0 (F-02): flat dict for window.ASM_T (command palette
                # + JS consumers) — cached, so this costs nothing per render.
                "asm_translations": translations,
                "supported_languages": SUPPORTED_LANGUAGES,
            }
        except Exception:
            return {"ui_lang": "en", "t": lambda key: key, "supported_languages": {}}

    # Inject CSRF token into templates
    @app.context_processor
    def _inject_csrf() -> dict[str, Any]:
        from flask_wtf.csrf import generate_csrf
        return {"csrf_token": generate_csrf()}

    # Error handlers
    @app.errorhandler(404)
    def _not_found(err):  # noqa: ANN202
        if request.path.startswith("/api/") or request.is_json:
            return jsonify({"ok": False, "error": "Not found"}), 404
        return render_template("404.html", path=request.path), 404

    @app.errorhandler(500)
    def _server_error(err):  # noqa: ANN202
        from core.logging import get_request_id
        rid = get_request_id() or "unknown"
        log.error("500 error: %s\n%s", err, traceback.format_exc())
        if request.path.startswith("/api/") or request.is_json:
            return jsonify({"ok": False, "error": "Server error",
                            "request_id": rid}), 500
        return render_template("500.html", request_id=rid), 500

    @app.errorhandler(AsmError)
    def _asm_error(err: AsmError):  # noqa: ANN202
        log.warning("ASM error: %s (%s)", err.user_message, err.code)
        # v9.1.0 (M-04): route-level `except AsmError -> jsonify` blocks were
        # centralized here. JSON is returned for anything that is not a
        # browser page navigation: /api/ paths, JSON bodies, XHR, or clients
        # that do not explicitly prefer text/html. Plain browser navigation
        # (Accept: text/html,...) gets the friendly error page.
        prefers_html = (
            request.accept_mimetypes.best_match(["application/json",
                                                 "text/html"])
            == "text/html"
        )
        wants_json = (
            request.path.startswith("/api/")
            or request.is_json
            or bool(request.headers.get("X-Requested-With"))
            or not prefers_html
        )
        if wants_json:
            return jsonify({"ok": False, "error": err.user_message,
                            "code": err.code}), err.status_code
        return render_template("500.html",
                                request_id="",
                                message=err.user_message), err.status_code

    @app.template_filter("from_json")
    def _from_json(value):  # noqa: ANN202
        import json
        if not value:
            return []
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return []

    @app.template_filter("truncate_text")
    def _truncate_text(value, length=200):  # noqa: ANN202
        if not value:
            return ""
        if len(value) <= length:
            return value
        return value[:length].rsplit(" ", 1)[0] + "…"

    @app.template_filter("markdown")
    def _markdown(value):  # noqa: ANN202
        """Render markdown to safe HTML for templates (use with |safe).

        Defensively degrades if bleach isn't installed (no HTML sanitization,
        but markdown still renders). This prevents 500 errors when the optional
        bleach dependency is missing.
        """
        if not value:
            return ""
        try:
            import markdown as _md
            html = _md.markdown(
                value,
                extensions=["extra", "nl2br", "sane_lists", "fenced_code"],
            )
        except Exception as exc:
            log.warning("Markdown render failed: %s", exc)
            # Fallback: escape HTML and return as preformatted text
            import html as _html
            return f"<pre style='white-space: pre-wrap'>{_html.escape(value)}</pre>"
        # Sanitize with bleach if available; otherwise return as-is (markdown
        # library output is generally safe-ish for local-first apps).
        try:
            import bleach as _bleach
            allowed_tags = [
                "p", "br", "hr", "h1", "h2", "h3", "h4", "h5", "h6",
                "ul", "ol", "li", "blockquote", "pre", "code",
                "em", "strong", "del", "a", "img", "table", "thead",
                "tbody", "tr", "th", "td", "span", "div",
            ]
            allowed_attrs = {
                "a": ["href", "title", "target"],
                "img": ["src", "alt", "title", "width", "height"],
                "span": ["class"],
                "div": ["class"],
                "th": ["align"],
                "td": ["align"],
                "code": ["class"],
                "pre": ["class"],
            }
            return _bleach.clean(html, tags=allowed_tags, attributes=allowed_attrs, strip=True)
        except ImportError:
            # bleach not installed — return markdown HTML without sanitization.
            # For a local-first single-user app this is acceptable; if the user
            # wants sanitization they can `pip install bleach`.
            return html
        except Exception as exc:
            log.warning("Bleach sanitization failed: %s", exc)
            return html

    # Jinja global: build a URL for a cross-reference link from a note
    @app.template_global("link_url")
    def _link_url(link):  # noqa: ANN202
        # v9.0.1 (S-09/ruff): url_for was never imported — every note
        # cross-reference silently fell through to "#" (the bare except
        # swallowed the NameError). It is imported at module level now.
        if not link or not isinstance(link, dict):
            return "#"
        et = link.get("entity_type")
        eid = link.get("entity_id", "")
        try:
            if et == "chapter":
                return url_for("chapters.detail", chapter_id=eid)
            if et == "character":
                return url_for("characters.detail", character_id=eid)
            if et == "world_entry":
                return url_for("world.detail", entry_id=eid)
            if et == "plan":
                return url_for("plans.detail", plan_id=eid)
        except Exception:
            pass
        return "#"

    log.info("Absolute Story Manager app created.")
    return app


# Allow `python app.py` for local dev.
if __name__ == "__main__":
    import os
    import threading
    import webbrowser

    app = create_app()

    # Caddy reverse proxy expects the app on port 3000.
    # When running locally without Caddy, use 5555.
    PORT = int(os.environ.get("PORT", 3000))
    # v9.0.1 (S-01): loopback by default — exposing the app to the network
    # is a conscious choice: ASM_HOST=0.0.0.0 (or HOST=0.0.0.0).
    from config import resolve_bind_host
    HOST = resolve_bind_host()

    # Only open browser in the reloader child process (not the parent)
    # This prevents the browser from opening twice when debug=True
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug:
        def _open_browser() -> None:
            import time
            time.sleep(1.5)
            webbrowser.open(f"http://127.0.0.1:{PORT}/")
        threading.Thread(target=_open_browser, daemon=True).start()

    # v9.0.1 (S-06): version comes from the single source of truth.
    from core.version import BANNER_LINES, __version__
    print("=" * 50)
    print(f"  Absolute Story Manager v{__version__}")
    for line in BANNER_LINES:
        print(line)
    print(f"  Listening on http://{HOST}:{PORT}/")
    print("  Press Ctrl+C to stop.")
    print("=" * 50)

    # use_reloader=False prevents double-start
    app.run(host=HOST, port=PORT, debug=False, use_reloader=False)
